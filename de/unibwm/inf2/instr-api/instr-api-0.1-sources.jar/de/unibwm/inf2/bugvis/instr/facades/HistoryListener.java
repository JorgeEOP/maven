package de.unibwm.inf2.bugvis.instr.facades;

import java.util.Collection;
import java.util.Map;

public interface HistoryListener {
    <T> void collectionModified(Collection<T> facade, Collection<T> contents);

    <K, V> void mapModified(Map<K, V> facade, Map<K, V> contents);
}
