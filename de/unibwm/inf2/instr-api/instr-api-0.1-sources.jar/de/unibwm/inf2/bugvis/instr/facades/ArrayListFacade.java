package de.unibwm.inf2.bugvis.instr.facades;

import java.util.ArrayList;
import java.util.Spliterator;

/**
 * Facade for ArrayList objects
 * @param <E> Object type to be stored
 */
public class ArrayListFacade<E> extends ListFacade<E, ArrayList<E>> implements ArrayListInterface<E>, Cloneable {

    /**
     *
     * @param wrapped Instance of wrapped ArrayList
     * @param historyListener
     */
    public ArrayListFacade(ArrayList<E> wrapped, HistoryListener historyListener) {
        super(wrapped, historyListener);
    }

    /**
     *
     */
    public void trimToSize() {
        wrapped.trimToSize();
    } // Würde nicht getestet

    /**
     *
     * @param minCapacity
     */
    public void ensureCapacity(int minCapacity) {
        wrapped.ensureCapacity(minCapacity);
    } //Würde nicht getestet

    /**
     *
     * @return
     */
    @Override
    public Object clone() {
        return new ArrayListFacade<E>((ArrayList<E>) wrapped.clone(), history);
    }

    /**
     *
     * @return
     */
    @Override
    public Spliterator<E> spliterator() {
        throw new UnsupportedOperationException();
    }
}
