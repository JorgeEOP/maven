package de.unibwm.inf2.bugvis.instr.facades;

import java.util.Set;

public interface HashSetInterface<E> extends Set<E>, Cloneable {
    Object clone();
}
