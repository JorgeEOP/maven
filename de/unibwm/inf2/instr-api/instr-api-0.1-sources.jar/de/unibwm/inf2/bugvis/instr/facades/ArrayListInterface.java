package de.unibwm.inf2.bugvis.instr.facades;

import java.util.List;

public interface ArrayListInterface<E> extends List<E> {
    List<E> reversed();

    Object clone();

    void ensureCapacity(int capacity);

    void trimToSize();
}
