package de.unibwm.inf2.bugvis.instr.runtime;

public interface StmtRuntime {
    /**
     * Announcement of a return stmt with the soon-to-be returned value.
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param value       The soon-to-be returned value.
     */
    void returnValue(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                     ObjectClassTuple value);

    /**
     * Announcement of a return stmt without value.
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     */
    void returnWithoutValue(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first);

    /**
     * Announcement of a yield stmt with the soon-to-be yielded value.
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param value       The soon-to-be yielded value.
     */
    void yieldValue(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first, ObjectClassTuple value);

    /**
     * Announcement of entering a switch stmt/expr case.
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param caseLabels  The label of the case.
     */
    void caseEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first, String caseLabels);

    /**
     * Announcement of leaving a switch stmt/expr case.
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param caseLabels  The label of the case.
     */
    void caseLeaving(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first, String caseLabels);
}
