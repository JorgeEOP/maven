package de.unibwm.inf2.bugvis.instr.runtime;

import de.unibwm.inf2.bugvis.instr.facades.HistoryListener;

public class BugVisInstr {
    private static DeclarationRuntime declRuntime;
    private static ExprRuntime exprRuntime;
    private static StmtRuntime stmtRuntime;
    private static HistoryListener histListener;

    private BugVisInstr() { /* don't instantiate */ }

    public static DeclarationRuntime getDeclRuntime() {
        return declRuntime;
    }

    public static void setDeclRuntime(DeclarationRuntime declRuntime) {
        BugVisInstr.declRuntime = declRuntime;
    }

    public static ExprRuntime getExprRuntime() {
        return exprRuntime;
    }

    public static void setExprRuntime(ExprRuntime exprRuntime) {
        BugVisInstr.exprRuntime = exprRuntime;
    }

    public static StmtRuntime getStmtRuntime() {
        return stmtRuntime;
    }

    public static void setStmtRuntime(StmtRuntime stmtRuntime) {
        BugVisInstr.stmtRuntime = stmtRuntime;
    }

    public static void setHistListener(HistoryListener histListener) {BugVisInstr.histListener = histListener;}

    public static HistoryListener getHistListener() {return histListener;}

    // Value //////////////////////////////////////////////////////////////////

    public static ObjectClassTuple v(boolean b) {return new ObjectClassTuple(b, boolean.class);}

    public static ObjectClassTuple v(char c) {return new ObjectClassTuple(c, char.class);}

    public static ObjectClassTuple v(byte b) {return new ObjectClassTuple(b, byte.class);}

    public static ObjectClassTuple v(short s) {return new ObjectClassTuple(s, short.class);}

    public static ObjectClassTuple v(int i) {return new ObjectClassTuple(i, int.class);}

    public static ObjectClassTuple v(long l) {return new ObjectClassTuple(l, long.class);}

    public static ObjectClassTuple v(float f) {return new ObjectClassTuple(f, float.class);}

    public static ObjectClassTuple v(double d) {return new ObjectClassTuple(d, double.class);}

    public static ObjectClassTuple v(Object o) {return new ObjectClassTuple(o);}

    // Parameter //////////////////////////////////////////////////////////////

    public static Parameter p(String paramType, String name, boolean b) {
        return new Parameter(paramType, name, b, boolean.class);
    }

    public static Parameter p(String paramType, String name, char c) {
        return new Parameter(paramType, name, c, char.class);
    }

    public static Parameter p(String paramType, String name, byte b) {
        return new Parameter(paramType, name, b, byte.class);
    }

    public static Parameter p(String paramType, String name, short s) {
        return new Parameter(paramType, name, s, short.class);
    }

    public static Parameter p(String paramType, String name, int i) {
        return new Parameter(paramType, name, i, int.class);
    }

    public static Parameter p(String paramType, String name, long l) {
        return new Parameter(paramType, name, l, long.class);
    }

    public static Parameter p(String paramType, String name, float f) {
        return new Parameter(paramType, name, f, float.class);
    }

    public static Parameter p(String paramType, String name, double d) {
        return new Parameter(paramType, name, d, double.class);
    }

    public static Parameter p(String paramType, String name, Object o) {
        return new Parameter(paramType, name, o);
    }
}
