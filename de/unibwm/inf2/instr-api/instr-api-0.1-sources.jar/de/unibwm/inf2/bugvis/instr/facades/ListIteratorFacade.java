package de.unibwm.inf2.bugvis.instr.facades;

import java.util.List;
import java.util.ListIterator;

public class ListIteratorFacade<T, L extends List<T>> extends CollectionIteratorFacade<T, L, ListFacade<T, L>> implements ListIterator<T> {

    final ListIterator<T> listIterator;

    public ListIteratorFacade(ListFacade<T, L> list, ListIterator<T> listIterator) {
        super(list, listIterator);
        this.listIterator = listIterator;
    }

    @Override
    public boolean hasPrevious() {
        return listIterator.hasPrevious();
    }

    @Override
    public T previous() {
        return listIterator.previous();
    }

    @Override
    public int nextIndex() {
        return listIterator.nextIndex();
    }

    @Override
    public int previousIndex() {
        return listIterator.previousIndex();
    }

    @Override
    public void set(T t) {
        listIterator.set(t);
        collectionFacade.history.collectionModified(collectionFacade, collectionFacade.wrapped);
    }

    @Override
    public void add(T t) {
        listIterator.add(t);
        collectionFacade.history.collectionModified(collectionFacade, collectionFacade.wrapped);
    }
}
