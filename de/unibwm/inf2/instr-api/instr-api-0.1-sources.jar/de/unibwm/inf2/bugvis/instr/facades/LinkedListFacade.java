package de.unibwm.inf2.bugvis.instr.facades;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListFacade<E> extends ListFacade<E, LinkedList<E>> implements LinkedListInterface<E> {

    public LinkedListFacade(LinkedList<E> wrapped, HistoryListener history) {
        super(wrapped, history);
    }

    @Override
    public void addFirst(E e) {
        wrapped.addFirst(e);
        history.collectionModified(this, wrapped);
    }

    @Override
    public void addLast(E e) {
        wrapped.addLast(e);
        history.collectionModified(this, wrapped);
    }

    @Override
    public E getFirst() {
        return wrapped.getFirst();
    }

    @Override
    public E getLast() {
        return wrapped.getLast();
    }

    @Override
    public E removeFirst() {
        E removed = wrapped.removeFirst();
        history.collectionModified(this, wrapped);
        return removed;
    }

    @Override
    public E removeLast() {
        E removed = wrapped.removeLast();
        history.collectionModified(this, wrapped);
        return removed;
    }

    @Override
    public boolean offerFirst(E e) {
        boolean added = wrapped.offerFirst(e);
        if (added) history.collectionModified(this, wrapped);
        return added;
    }

    @Override
    public boolean offerLast(E e) {
        boolean added = wrapped.offerLast(e);
        if (added) history.collectionModified(this, wrapped);
        return added;
    }

    @Override
    public E pollFirst() {
        E polled = wrapped.pollFirst();
        history.collectionModified(this, wrapped);
        return polled;
    }

    @Override
    public E pollLast() {
        E polled = wrapped.pollLast();
        history.collectionModified(this, wrapped);
        return polled;
    }

    @Override
    public E peekFirst() {
        return wrapped.peekFirst();
    }

    @Override
    public E peekLast() {
        return wrapped.peekLast();
    }

    @Override
    public boolean offer(E e) {
        boolean added = wrapped.offer(e);
        if (added) history.collectionModified(this, wrapped);
        return added;
    }

    @Override
    public E remove() {
        E removed = wrapped.remove();
        history.collectionModified(this, wrapped);
        return removed;
    }

    @Override
    public E poll() {
        E removed = wrapped.poll();
        history.collectionModified(this, wrapped);
        return removed;
    }

    @Override
    public E peek() {
        return wrapped.peek();
    }

    @Override
    public E element() {
        return wrapped.element();
    }

    @Override
    public void push(E e) {
        wrapped.push(e);
        history.collectionModified(this, wrapped);
    }

    @Override
    public E pop() {
        E removed = wrapped.pop();
        history.collectionModified(this, wrapped);
        return removed;
    }

    @Override
    public LinkedListInterface<E> reversed() {
        return new LinkedListFacade<>(wrapped.reversed(), history);
    }

    @Override
    public boolean removeFirstOccurrence(Object o) {
        boolean removed = wrapped.removeFirstOccurrence(o);
        history.collectionModified(this, wrapped);
        return removed;
    }

    @Override
    public boolean removeLastOccurrence(Object o) {
        boolean removed = wrapped.removeLastOccurrence(o);
        history.collectionModified(this, wrapped);
        return removed;
    }

    @Override
    public Iterator<E> descendingIterator() {
        return wrapped.descendingIterator();
    }

    @Override
    public Object clone() {
        return new LinkedListFacade<E>((LinkedList<E>) wrapped.clone(), history);
    }
}
