package de.unibwm.inf2.bugvis.instr.metainfo;

import com.fasterxml.jackson.annotation.JsonProperty;

public record LineRange(@JsonProperty int from, @JsonProperty int to) {
    public boolean inRange(int line) {return line >= from && line <= to;}
}
