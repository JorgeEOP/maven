package de.unibwm.inf2.bugvis.instr.runtime;

public class Parameter extends ObjectClassTuple {

    private final String name;
    private final String paramType;

    public Parameter(String paramType, String name, Object object, Class<?> clazz) {
        super(object, clazz);
        this.name = name;
        this.paramType = paramType;
    }

    public Parameter(String paramType, String name, Object object) {
        this(paramType, name, object, object == null ? null : object.getClass());
    }

    public String getName() {return name;}

    public String getParamType() {return paramType;}
}
