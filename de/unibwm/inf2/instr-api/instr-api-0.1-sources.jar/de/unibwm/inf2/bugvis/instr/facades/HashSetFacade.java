package de.unibwm.inf2.bugvis.instr.facades;

import java.util.HashSet;
import java.util.Spliterator;

public class HashSetFacade<E> extends SetFacade<E, HashSet<E>> implements HashSetInterface<E> {
    public HashSetFacade(HashSet<E> wrapped, HistoryListener history) {
        super(wrapped, history);
    }

    @Override
    public HashSetFacade<E> clone() {
        return new HashSetFacade<>((HashSet<E>) wrapped.clone(), history);
    }

    @Override
    public Spliterator<E> spliterator() {
        throw new UnsupportedOperationException();
    }
}
