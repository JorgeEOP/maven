package de.unibwm.inf2.bugvis.instr.facades;

import java.util.HashMap;
import java.util.function.BiFunction;
import java.util.function.Function;

public class HashMapFacade<K, V> extends MapFacade<K, V, HashMap<K, V>> implements HashMapInterface<K, V> {

    public HashMapFacade(HashMap<K, V> wrapped, HistoryListener history) {
        super(wrapped, history);
    }

    @Override
    public V compute(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
        V val = wrapped.compute(key, remappingFunction);
        history.mapModified(this, wrapped);
        return val;
    }

    @Override
    public V computeIfAbsent(K key, Function<? super K, ? extends V> mappingFunction) {
        V val = wrapped.computeIfAbsent(key, mappingFunction);
        history.mapModified(this, wrapped);
        return val;
    }

    @Override
    public V computeIfPresent(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
        V val = wrapped.computeIfPresent(key, remappingFunction);
        history.mapModified(this, wrapped);
        return val;
    }

    @Override
    public V getOrDefault(Object key, V defaultValue) {
        return wrapped.getOrDefault(key, defaultValue);
    }

    @Override
    public V merge(K key, V value, BiFunction<? super V, ? super V, ? extends V> remappingFunction) {
        V val = wrapped.merge(key, value, remappingFunction);
        history.mapModified(this, wrapped);
        return val;
    }

    @Override
    public V putIfAbsent(K key, V value) {
        V val = wrapped.putIfAbsent(key, value);
        history.mapModified(this, wrapped);
        return val;
    }

    @Override
    public boolean replace(K key, V oldValue, V newValue) {
        boolean replaced = wrapped.replace(key, oldValue, newValue);
        history.mapModified(this, wrapped);
        return replaced;
    }

    @Override
    public V replace(K key, V value) {
        V val = wrapped.replace(key, value);
        history.mapModified(this, wrapped);
        return val;
    }

    @Override
    public void replaceAll(BiFunction<? super K, ? super V, ? extends V> function) {
        wrapped.replaceAll(function);
        history.mapModified(this, wrapped);
    }

    @Override
    public Object clone() {
        return new HashMapFacade<>((HashMap<K, V>) wrapped.clone(), history);
    }
}
