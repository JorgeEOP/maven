package de.unibwm.inf2.bugvis.instr.runtime;

public class ObjectClassTuple {
    private final Object object;
    private final Class<?> clazz;

    public ObjectClassTuple(Object object, Class<?> clazz) {
        this.object = object;
        this.clazz = clazz;
    }

    public ObjectClassTuple(Object object) {this(object, object == null ? null : object.getClass());}

    public Class<?> getClazz() {return clazz;}

    public Object getObject() {return object;}
}
