package de.unibwm.inf2.bugvis.instr.metainfo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static java.lang.System.Logger.Level.DEBUG;

public class MetaInfo {
    private static final Logger LOGGER = System.getLogger(MetaInfo.class.getName());

    @JsonProperty
    private final List<FileMetaInfo> fileMetaInfo = new ArrayList<>();

    @JsonProperty
    private final Map<String, Set<String>> instrClassMethodMap = new HashMap<>();

    public void add(FileMetaInfo fileMetaInfo) {this.fileMetaInfo.add(fileMetaInfo);}

    public FileMetaInfo getFileMetaInfo(int id) {return fileMetaInfo.get(id);}

    public int size() {return fileMetaInfo.size();}

    public List<FileMetaInfo> getFileMetaInfo() {return Collections.unmodifiableList(fileMetaInfo);}

    public void addInstrMethod(String className, String methodSignature) {
        instrClassMethodMap.computeIfAbsent(className, k -> new HashSet<>()).add(methodSignature);
    }

    public boolean containsInstrClass(String className) {
        return instrClassMethodMap.containsKey(className);
    }

    public boolean containsInstrMethod(String className, String methodSignature) {
        if (!containsInstrClass(className))
            return false;
        return instrClassMethodMap.get(className).contains(methodSignature);
    }

    @JsonIgnore
    public List<String> getFilePaths() {
        return getFileMetaInfo().stream()
                                .map(FileMetaInfo::getRelativeFilePath)
                                .sorted()
                                .toList();
    }

    @Override
    public String toString() {
        return "MetaInfo: \n" + String.join("\n\t", fileMetaInfo.stream()
                                                                .map(FileMetaInfo::toString)
                                                                .toList());
    }

    public static MetaInfo readMetaInfo(File file) throws IOException {
        LOGGER.log(Level.INFO, () -> "trying to read 'MetaInfo.json' from: " + file.getAbsolutePath());
        final ObjectMapper mapper = new ObjectMapper();
        try (FileInputStream stream = new FileInputStream(file)) {
            return mapper.readValue(stream, MetaInfo.class);
        }
    }

    public static void writeMetaInfo(MetaInfo metaInfo, File file) throws IOException {
        LOGGER.log(Level.INFO, "write meta info to {0}", file.getAbsolutePath());
        final ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        try {
            LOGGER.log(DEBUG, metaInfo);
            mapper.writeValue(file, metaInfo);
        }
        catch (JsonProcessingException e) {throw new IOException(e.getMessage(), e);}
    }
}
