package de.unibwm.inf2.bugvis.instr.runtime;

import java.util.List;

public interface DeclarationRuntime {

    // CONSTRUCTORS ////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * The constructor has been entered.
     * <p>
     * Instrumentation: We are in a helper class and announce that we entered the constructor. This is the first
     * announcement for this constructor. After the helper class constructor finishes, we will proceed with another
     * constructor of the class or one of the super class. If another constructor was called, an announcement is
     * following.
     *
     * @param fileId               ID of the file in which this call is located.
     * @param lineStart            First line of the instrumented stmt/expr/declaration.
     * @param columnStart          First column of the instrumented stmt/expr/declaration.
     * @param lineEnd              Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd            Last column of the instrumented stmt/expr/declaration.
     * @param clazz                Class-object of the constructor.
     * @param constructorSignature Signature of the constructor.
     * @param parameters           Given parameters of the constructor.
     */
    void constructorEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            Class<?> clazz, String constructorSignature, List<Parameter> parameters);

    /**
     * The constructor has been entered.
     * This method calls {@link #constructorEntered(int, int, int, int, int, boolean, Class, String, java.util.List)}
     * with an empty list of parameters.
     * <p>
     * Instrumentation: We are in a helper class and announce that we entered the constructor. This is the first
     * announcement for this constructor. After the helper class constructor finishes, we will proceed with another
     * constructor of the class or one of the super class. If another constructor was called, an announcement is
     * following.
     *
     * @param fileId               ID of the file in which this call is located.
     * @param lineStart            First line of the instrumented stmt/expr/declaration.
     * @param columnStart          First column of the instrumented stmt/expr/declaration.
     * @param lineEnd              Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd            Last column of the instrumented stmt/expr/declaration.
     * @param clazz                Class-object of the constructor.
     * @param constructorSignature Signature of the constructor.
     * @see #constructorEntered(int, int, int, int, int, boolean, Class, String, java.util.List)
     */
    void constructorEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            Class<?> clazz, String constructorSignature);

    /**
     * The constructor of an enum has been entered.
     *
     * @param fileId               ID of the file in which this call is located.
     * @param lineStart            First line of the instrumented stmt/expr/declaration.
     * @param columnStart          First column of the instrumented stmt/expr/declaration.
     * @param lineEnd              Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd            Last column of the instrumented stmt/expr/declaration.
     * @param receiver             Enum constant.
     * @param constructorSignature Signature of the constructor.
     * @param parameters           Given parameters of the constructor.
     */
    void constructorEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            Parameter receiver, String constructorSignature, List<Parameter> parameters);

    /**
     * The constructor of an enum has been entered.
     * This method calls {@link #constructorEntered(int, int, int, int, int, boolean, Parameter, String, java.util.List)}
     * with an empty list of parameters.
     *
     * @param fileId               ID of the file in which this call is located.
     * @param lineStart            First line of the instrumented stmt/expr/declaration.
     * @param columnStart          First column of the instrumented stmt/expr/declaration.
     * @param lineEnd              Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd            Last column of the instrumented stmt/expr/declaration.
     * @param receiver             Enum constant.
     * @param constructorSignature Signature of the constructor.
     * @see #constructorEntered(int, int, int, int, int, boolean, Parameter, String, java.util.List)
     */
    void constructorEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            Parameter receiver, String constructorSignature);

    /**
     * The constructor is going to be left.
     *
     * @param fileId               ID of the file in which this call is located.
     * @param lineStart            First line of the instrumented stmt/expr/declaration.
     * @param columnStart          First column of the instrumented stmt/expr/declaration.
     * @param lineEnd              Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd            Last column of the instrumented stmt/expr/declaration.
     * @param objectClassTuple     Object and result of the constructor.
     * @param constructorSignature Signature of the constructor.
     */
    void leavingConstructor(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            ObjectClassTuple objectClassTuple, String constructorSignature);

    /**
     * This method is used in intermediate classes, before the announced constructor call of another constructor is
     * performed.
     *
     * @param fileId               ID of the file in which this call is located.
     * @param lineStart            First line of the instrumented stmt/expr/declaration.
     * @param columnStart          First column of the instrumented stmt/expr/declaration.
     * @param lineEnd              Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd            Last column of the instrumented stmt/expr/declaration.
     * @param clazz                Class object of the soon-to-be called constructor.
     * @param constructorSignature Signature of the soon-to-be called constructor.
     * @param parameters           Parameters which are given to the soon-to-be called constructor.
     */
    void constructorCall(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                         Class<?> clazz, String constructorSignature, List<Parameter> parameters);

    /**
     * This method is used in intermediate classes, before the announced constructor call of another constructor is
     * performed. This method calls {@link #constructorCall(int, int, int, int, int, boolean, Class, String, java.util.List)}
     * with an empty list of parameters.
     *
     * @param fileId               ID of the file in which this call is located.
     * @param lineStart            First line of the instrumented stmt/expr/declaration.
     * @param columnStart          First column of the instrumented stmt/expr/declaration.
     * @param lineEnd              Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd            Last column of the instrumented stmt/expr/declaration.
     * @param clazz                Class object of the soon-to-be called constructor.
     * @param constructorSignature Signature of the soon-to-be called constructor.
     * @see #constructorCall(int, int, int, int, int, boolean, Class, String, java.util.List)
     */
    void constructorCall(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                         Class<?> clazz, String constructorSignature);

    /**
     * This method announces, that another constructor just finished. The result of the constructor is given.
     * <p>
     * The finished constructor was another constructor of the same class or a super class constructor.
     *
     * @param fileId            ID of the file in which this call is located.
     * @param lineStart         First line of the instrumented stmt/expr/declaration.
     * @param columnStart       First column of the instrumented stmt/expr/declaration.
     * @param lineEnd           Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd         Last column of the instrumented stmt/expr/declaration.
     * @param constructorResult The result of the just finished constructor.
     */
    void constructorResult(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                           ObjectClassTuple constructorResult);

    // METHODS /////////////////////////////////////////////////////////////////////////////////////////////////////////

    // instance method

    /**
     * The called method has been entered.
     *
     * @param fileId          ID of the file in which this call is located.
     * @param lineStart       First line of the instrumented stmt/expr/declaration.
     * @param columnStart     First column of the instrumented stmt/expr/declaration.
     * @param lineEnd         Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd       Last column of the instrumented stmt/expr/declaration.
     * @param receiver        The receiving object of the method call.
     * @param methodSignature The signature of the called method.
     * @param parameters      The parameters of the entered method.
     */
    void methodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                       Parameter receiver, String methodSignature, List<Parameter> parameters);

    /**
     * The called method has been entered. This method calls
     * {@link #methodEntered(int, int, int, int, int, boolean, Parameter, String, java.util.List)}
     * with an empty list of parameters.
     *
     * @param fileId          ID of the file in which this call is located.
     * @param lineStart       First line of the instrumented stmt/expr/declaration.
     * @param columnStart     First column of the instrumented stmt/expr/declaration.
     * @param lineEnd         Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd       Last column of the instrumented stmt/expr/declaration.
     * @param receiver        The receiving object of the method call.
     * @param methodSignature The signature of the called method.
     * @see #methodEntered(int, int, int, int, int, boolean, Parameter, String, java.util.List)
     */
    void methodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                       Parameter receiver, String methodSignature);

    /**
     * The method is going to be left.
     *
     * @param fileId           ID of the file in which this call is located.
     * @param lineStart        First line of the instrumented stmt/expr/declaration.
     * @param columnStart      First column of the instrumented stmt/expr/declaration.
     * @param lineEnd          Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd        Last column of the instrumented stmt/expr/declaration.
     * @param objectClassTuple The receiving object of the method call.
     * @param methodSignature  Signature of the method.
     */
    void leavingMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                       ObjectClassTuple objectClassTuple, String methodSignature);

    // static method

    /**
     * The called static method has been entered.
     *
     * @param fileId          ID of the file in which this call is located.
     * @param lineStart       First line of the instrumented stmt/expr/declaration.
     * @param columnStart     First column of the instrumented stmt/expr/declaration.
     * @param lineEnd         Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd       Last column of the instrumented stmt/expr/declaration.
     * @param clazz           The class object of the method call.
     * @param methodSignature The signature of the called method.
     * @param parameters      The parameters of the entered method.
     */
    void staticMethodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                             Class<?> clazz, String methodSignature, List<Parameter> parameters);

    /**
     * The called static method has been entered. This method calls
     * {@link #staticMethodEntered(int, int, int, int, int, boolean, Class, String, java.util.List)}
     * with an empty list of parameters.
     *
     * @param fileId          ID of the file in which this call is located.
     * @param lineStart       First line of the instrumented stmt/expr/declaration.
     * @param columnStart     First column of the instrumented stmt/expr/declaration.
     * @param lineEnd         Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd       Last column of the instrumented stmt/expr/declaration.
     * @param clazz           The class object of the method call.
     * @param methodSignature The signature of the called method.
     * @see #staticMethodEntered(int, int, int, int, int, boolean, Class, String, java.util.List)
     */
    void staticMethodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                             Class<?> clazz, String methodSignature);

    /**
     * The static method is going to be left.
     *
     * @param fileId          ID of the file in which this call is located.
     * @param lineStart       First line of the instrumented stmt/expr/declaration.
     * @param columnStart     First column of the instrumented stmt/expr/declaration.
     * @param lineEnd         Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd       Last column of the instrumented stmt/expr/declaration.
     * @param clazz           The class object of the method call.
     * @param methodSignature Signature of the method.
     */
    void leavingStaticMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                             Class<?> clazz, String methodSignature);

    // instance method in anon class

    /**
     * The called method in an anonymous class has been entered.
     *
     * @param fileId                   ID of the file in which this call is located.
     * @param lineStart                First line of the instrumented stmt/expr/declaration.
     * @param columnStart              First column of the instrumented stmt/expr/declaration.
     * @param lineEnd                  Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd                Last column of the instrumented stmt/expr/declaration.
     * @param containingClass          The class object of the containing class of this anonymous class.
     * @param anonymousClassIdentifier The numeric part of the class identifier for this anonymous class.
     * @param receiver                 The receiving object of the method call.
     * @param methodSignature          The signature of the called method.
     * @param parameters               The parameters of the entered method.
     */
    void methodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                       Class<?> containingClass, List<Integer> anonymousClassIdentifier, Parameter receiver,
                       String methodSignature, List<Parameter> parameters);

    /**
     * The called method in an anonymous class has been entered. This method calls
     * {@link #methodEntered(int, int, int, int, int, boolean, Class, java.util.List, Parameter, String, java.util.List)}
     * with an empty list of parameters.
     *
     * @param fileId                   ID of the file in which this call is located.
     * @param lineStart                First line of the instrumented stmt/expr/declaration.
     * @param columnStart              First column of the instrumented stmt/expr/declaration.
     * @param lineEnd                  Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd                Last column of the instrumented stmt/expr/declaration.
     * @param containingClass          The class object of the containing class of this anonymous class.
     * @param anonymousClassIdentifier The numeric part of the class identifier for this anonymous class.
     * @param receiver                 The receiving object of the method call.
     * @param methodSignature          The signature of the called method.
     * @see #methodEntered(int, int, int, int, int, boolean, Class, java.util.List, Parameter, String, java.util.List)
     */
    void methodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                       Class<?> containingClass, List<Integer> anonymousClassIdentifier, Parameter receiver,
                       String methodSignature);

    /**
     * The method is going to be left.
     *
     * @param fileId                   ID of the file in which this call is located.
     * @param lineStart                First line of the instrumented stmt/expr/declaration.
     * @param columnStart              First column of the instrumented stmt/expr/declaration.
     * @param lineEnd                  Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd                Last column of the instrumented stmt/expr/declaration.
     * @param containingClass          The class object of the containing class of this anonymous class.
     * @param anonymousClassIdentifier The numeric part of the class identifier for this anonymous class.
     * @param objectClassTuple         The receiving object of the method call.
     * @param methodSignature          Signature of the method.
     */
    void leavingMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                       Class<?> containingClass, List<Integer> anonymousClassIdentifier, ObjectClassTuple objectClassTuple,
                       String methodSignature);

    // static method in anon class

    /**
     * The called static method of an anonymous class has been entered.
     *
     * @param fileId                   ID of the file in which this call is located.
     * @param lineStart                First line of the instrumented stmt/expr/declaration.
     * @param columnStart              First column of the instrumented stmt/expr/declaration.
     * @param lineEnd                  Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd                Last column of the instrumented stmt/expr/declaration.
     * @param containingClass          The class object of the containing class of this anonymous class.
     * @param anonymousClassIdentifier The numeric part of the class identifier for this anonymous class.
     * @param methodSignature          The signature of the called method.
     * @param parameters               The parameters of the entered method.
     */
    void staticMethodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                             Class<?> containingClass, List<Integer> anonymousClassIdentifier,
                             String methodSignature, List<Parameter> parameters);

    /**
     * The called static method of an anonymous class has been entered. This method calls
     * {@link #staticMethodEntered(int, int, int, int, int, boolean, Class, java.util.List, String, java.util.List)}
     * with an empty list of parameters.
     *
     * @param fileId                   ID of the file in which this call is located.
     * @param lineStart                First line of the instrumented stmt/expr/declaration.
     * @param columnStart              First column of the instrumented stmt/expr/declaration.
     * @param lineEnd                  Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd                Last column of the instrumented stmt/expr/declaration.
     * @param containingClass          The class object of the containing class of this anonymous class.
     * @param anonymousClassIdentifier The numeric part of the class identifier for this anonymous class.
     * @param methodSignature          The signature of the called method.
     * @see #staticMethodEntered(int, int, int, int, int, boolean, Class, java.util.List, String, java.util.List)
     */
    void staticMethodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                             Class<?> containingClass, List<Integer> anonymousClassIdentifier,
                             String methodSignature);

    /**
     * The static method is going to be left.
     *
     * @param fileId                   ID of the file in which this call is located.
     * @param lineStart                First line of the instrumented stmt/expr/declaration.
     * @param columnStart              First column of the instrumented stmt/expr/declaration.
     * @param lineEnd                  Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd                Last column of the instrumented stmt/expr/declaration.
     * @param containingClass          The class object of the containing class of this anonymous class.
     * @param anonymousClassIdentifier The numeric part of the class identifier for this anonymous class.
     * @param methodSignature          Signature of the method.
     */
    void leavingStaticMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                             Class<?> containingClass, List<Integer> anonymousClassIdentifier,
                             String methodSignature);

    // INITIALIZERS ////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Initializer entered.
     *
     * @param fileId      ID of the file in which this initializer is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     */
    void initializerEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            ObjectClassTuple receiver);

    /**
     * Leaving initializer.
     *
     * @param fileId      ID of the file in which this initializer is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     */
    void leavingInitializer(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first);

    /**
     * Static initializer entered.
     *
     * @param fileId      ID of the file in which this static initializer is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     */
    void staticInitializerEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                  Class<?> clazz);

    /**
     * Leaving static initializer.
     *
     * @param fileId      ID of the file in which this static initializer is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     */
    void leavingStaticInitializer(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first);

    // FIELDS //////////////////////////////////////////////////////////////////////////////////////////////////////////

    // field

    /**
     * Declaration of a field in an object.
     *
     * @param fileId           ID of the file in which this call is located.
     * @param lineStart        First line of the instrumented stmt/expr/declaration.
     * @param columnStart      First column of the instrumented stmt/expr/declaration.
     * @param lineEnd          Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd        Last column of the instrumented stmt/expr/declaration.
     * @param objectClassTuple The object which contains this field.
     * @param fieldName        The name of the field.
     * @param fieldType        The type of the field.
     * @param defaultValue     The default value depending on the type.
     * @param declaringClass   The class which declares this field.
     */
    void fieldDeclaration(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                          ObjectClassTuple objectClassTuple, String fieldName, String fieldType,
                          ObjectClassTuple defaultValue, Class<?> declaringClass);

    /**
     * Field assignment.
     *
     * @param fileId           ID of the file in which this call is located.
     * @param lineStart        First line of the instrumented stmt/expr/declaration.
     * @param columnStart      First column of the instrumented stmt/expr/declaration.
     * @param lineEnd          Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd        Last column of the instrumented stmt/expr/declaration.
     * @param objectClassTuple The object which contains this field.
     * @param fieldName        The name of the field.
     * @param fieldValue       The new value of the field.
     * @param declaringClass   The class which declares this field.
     */
    void fieldAssignment(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                         ObjectClassTuple objectClassTuple, String fieldName, ObjectClassTuple fieldValue,
                         Class<?> declaringClass);

    // static field

    /**
     * Declaration of a static field in a class.
     *
     * @param fileId       ID of the file in which this call is located.
     * @param lineStart    First line of the instrumented stmt/expr/declaration.
     * @param columnStart  First column of the instrumented stmt/expr/declaration.
     * @param lineEnd      Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd    Last column of the instrumented stmt/expr/declaration.
     * @param clazz        The containing class of this static field.
     * @param fieldName    The name of the field.
     * @param fieldType    The type of the field.
     * @param defaultValue The default value depending on the type.
     */
    void staticFieldDeclaration(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                Class<?> clazz, String fieldName, String fieldType, ObjectClassTuple defaultValue);

    /**
     * Static field assignment.
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param clazz       The containing class of this static field.
     * @param fieldName   The name of the field.
     * @param fieldValue  The new value of the field.
     */
    void staticFieldAssignment(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                               Class<?> clazz, String fieldName, ObjectClassTuple fieldValue);

    // field in anon class

    /**
     * Declaration of a field in an object of an anonymous class.
     *
     * @param fileId                   ID of the file in which this call is located.
     * @param lineStart                First line of the instrumented stmt/expr/declaration.
     * @param columnStart              First column of the instrumented stmt/expr/declaration.
     * @param lineEnd                  Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd                Last column of the instrumented stmt/expr/declaration.
     * @param containingClass          The class object of the containing class of this anonymous class.
     * @param anonymousClassIdentifier The numeric part of the class identifier for this anonymous class.
     * @param objectClassTuple         The object which contains this field.
     * @param fieldName                The name of the field.
     * @param fieldType                The type of the field.
     * @param defaultValue             The default value depending on the type.
     */
    void fieldDeclaration(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                          Class<?> containingClass, List<Integer> anonymousClassIdentifier,
                          ObjectClassTuple objectClassTuple, String fieldName, String fieldType,
                          ObjectClassTuple defaultValue);

    /**
     * Field assignment in an object of an anonymous class.
     *
     * @param fileId                   ID of the file in which this call is located.
     * @param lineStart                First line of the instrumented stmt/expr/declaration.
     * @param columnStart              First column of the instrumented stmt/expr/declaration.
     * @param lineEnd                  Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd                Last column of the instrumented stmt/expr/declaration.
     * @param containingClass          The class object of the containing class of this anonymous class.
     * @param anonymousClassIdentifier The numeric part of the class identifier for this anonymous class.
     * @param objectClassTuple         The object which contains this field.
     * @param fieldName                The name of the field.
     * @param fieldValue               The new value of the field.
     */
    void fieldAssignment(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                         Class<?> containingClass, List<Integer> anonymousClassIdentifier,
                         ObjectClassTuple objectClassTuple, String fieldName, ObjectClassTuple fieldValue);

    // static field in anon class

    /**
     * Declaration of a static field in an anonymous class.
     *
     * @param fileId                   ID of the file in which this call is located.
     * @param lineStart                First line of the instrumented stmt/expr/declaration.
     * @param columnStart              First column of the instrumented stmt/expr/declaration.
     * @param lineEnd                  Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd                Last column of the instrumented stmt/expr/declaration.
     * @param containingClass          The class object of the containing class of this anonymous class.
     * @param anonymousClassIdentifier The numeric part of the class identifier for this anonymous class.
     * @param fieldName                The name of the field.
     * @param fieldType                The type of the field.
     * @param defaultValue             The default value depending on the type.
     */
    void staticFieldDeclaration(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                Class<?> containingClass, List<Integer> anonymousClassIdentifier,
                                String fieldName, String fieldType, ObjectClassTuple defaultValue);

    /**
     * Static field assignment of an anonymous class.
     *
     * @param fileId                   ID of the file in which this call is located.
     * @param lineStart                First line of the instrumented stmt/expr/declaration.
     * @param columnStart              First column of the instrumented stmt/expr/declaration.
     * @param lineEnd                  Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd                Last column of the instrumented stmt/expr/declaration.
     * @param containingClass          The class object of the containing class of this anonymous class.
     * @param anonymousClassIdentifier The numeric part of the class identifier for this anonymous class.
     * @param fieldName                The name of the field.
     * @param fieldValue               The new value of the field.
     */
    void staticFieldAssignment(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                               Class<?> containingClass, List<Integer> anonymousClassIdentifier, String fieldName,
                               ObjectClassTuple fieldValue);
}
