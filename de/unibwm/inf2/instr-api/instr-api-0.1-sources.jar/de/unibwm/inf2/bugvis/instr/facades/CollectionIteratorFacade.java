package de.unibwm.inf2.bugvis.instr.facades;

import java.util.Collection;
import java.util.Iterator;

public class CollectionIteratorFacade<T, C extends Collection<T>, F extends CollectionFacade<T, C>> implements Iterator<T> {
    final F collectionFacade;
    final Iterator<T> iterator;

    public CollectionIteratorFacade(F collectionFacade, Iterator<T> iterator) {
        this.collectionFacade = collectionFacade;
        this.iterator = iterator;
    }

    @Override
    public boolean hasNext() {
        return iterator.hasNext();
    }

    @Override
    public T next() {
        return iterator.next();
    }

    @Override
    public void remove() {
        iterator.remove();
        collectionFacade.history.collectionModified(collectionFacade, collectionFacade.wrapped);
    }
}
