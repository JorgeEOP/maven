package de.unibwm.inf2.bugvis.instr.facades;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;

public class MapFacade<K, V, M extends Map<K, V>> implements Map<K, V> {

    final M wrapped;
    final HistoryListener history;

    public MapFacade(M wrapped, HistoryListener history) {
        this.wrapped = wrapped;
        this.history = history;
    }

    @Override
    public int size() {
        return wrapped.size();
    }

    @Override
    public boolean isEmpty() {
        return wrapped.isEmpty();
    }

    @Override
    public boolean containsKey(Object key) {
        return wrapped.containsKey(key);
    }

    @Override
    public boolean containsValue(Object value) {
        return wrapped.containsValue(value);
    }

    @Override
    public V get(Object key) {
        return wrapped.get(key);
    }

    @Override
    public V put(K key, V value) {
        V result = wrapped.put(key, value);
        history.mapModified(this, wrapped);
        return result;
    }

    @Override
    public V remove(Object key) {
        V result = wrapped.remove(key);
        history.mapModified(this, wrapped);
        return result;
    }

    @Override
    public void putAll(Map<? extends K, ? extends V> m) {
        wrapped.putAll(m);
        history.mapModified(this, wrapped);
    }

    @Override
    public void clear() {
        wrapped.clear();
        history.mapModified(this, wrapped);
    }

    @Override
    public Set<K> keySet() {
        return new SetFacade<>(wrapped.keySet(), history);
    }

    @Override
    public Collection<V> values() {
        return new CollectionFacade<>(wrapped.values(), history);
    }

    @Override
    public Set<Entry<K, V>> entrySet() {
        return new SetFacade<>(wrapped.entrySet(), history);
    }

    @Override
    public String toString() {
        return wrapped.toString();
    }

    @Override
    public void replaceAll(BiFunction<? super K, ? super V, ? extends V> function) {
        wrapped.replaceAll(function);
        history.mapModified(this, wrapped);
    }
}
