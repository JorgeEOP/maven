package de.unibwm.inf2.bugvis.instr.facades;

import java.util.Map;

public interface HashMapInterface<K, V> extends Map<K, V>, Cloneable {
    Object clone();
}
