package de.unibwm.inf2.bugvis.instr.facades;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Spliterator;
import java.util.function.UnaryOperator;

public class ListFacade<E, L extends List<E>> extends CollectionFacade<E, L> implements List<E> {

    public ListFacade(L wrapped, HistoryListener history) {
        super(wrapped, history);
    }

    @Override
    public Iterator<E> iterator() {
        return listIterator(0);
    }

    @Override
    public boolean addAll(int index, Collection<? extends E> c) {
        boolean modified = wrapped.addAll(index, c);
        if (modified) history.collectionModified(this, wrapped);
        return modified;
    }

    @Override
    public E get(int index) {
        return wrapped.get(index);
    }

    @Override
    public E set(int index, E element) {
        E old = wrapped.set(index, element);
        history.collectionModified(this, wrapped);
        return old;
    }

    @Override
    public void add(int index, E element) {
        wrapped.add(index, element);
        history.collectionModified(this, wrapped);
    }

    @Override
    public E remove(int index) {
        E removed = wrapped.remove(index);
        history.collectionModified(this, wrapped);
        return removed;
    }

    @Override
    public int indexOf(Object o) {
        return wrapped.indexOf(o);
    }

    @Override
    public int lastIndexOf(Object o) {
        return wrapped.lastIndexOf(o);
    }

    @Override
    public ListIterator<E> listIterator() {
        return new ListIteratorFacade<>(this, wrapped.listIterator());
    }

    @Override
    public ListIterator<E> listIterator(int index) {
        return new ListIteratorFacade<>(this, wrapped.listIterator(index));
    }

    @Override
    public List<E> subList(int fromIndex, int toIndex) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void replaceAll(UnaryOperator<E> operator) {
        wrapped.replaceAll(operator);
        history.collectionModified(this, wrapped);
    }

    @Override
    public void sort(Comparator<? super E> c) {
        wrapped.sort(c);
        history.collectionModified(this, wrapped);
    }

    @Override
    public Spliterator<E> spliterator() {
        throw new UnsupportedOperationException();
    }

    @Override
    public List<E> reversed() {
        return new ListFacade<>(List.super.reversed(), history);
    }
}
