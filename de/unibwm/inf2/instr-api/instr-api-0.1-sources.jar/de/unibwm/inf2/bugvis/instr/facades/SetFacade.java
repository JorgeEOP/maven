package de.unibwm.inf2.bugvis.instr.facades;

import java.util.Set;
import java.util.Spliterator;

public class SetFacade<E, S extends Set<E>> extends CollectionFacade<E, S> implements Set<E> {

    public SetFacade(S wrapped, HistoryListener history) {
        super(wrapped, history);
    }

    @Override
    public boolean equals(Object o) {
        return wrapped.equals(o);
    }

    @Override
    public Spliterator<E> spliterator() {
        throw new UnsupportedOperationException();
    }
}
