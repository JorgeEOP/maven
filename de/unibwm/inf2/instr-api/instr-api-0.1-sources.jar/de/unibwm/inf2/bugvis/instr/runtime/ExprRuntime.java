package de.unibwm.inf2.bugvis.instr.runtime;

import java.util.List;

public interface ExprRuntime {

    // OBJECT CREATION EXPRS ///////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Announcement of an object creation expression.
     *
     * @param fileId               ID of the file in which this call is located.
     * @param lineStart            First line of the instrumented stmt/expr/declaration.
     * @param columnStart          First column of the instrumented stmt/expr/declaration.
     * @param lineEnd              Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd            Last column of the instrumented stmt/expr/declaration.
     * @param clazz                The class object of the object creation expression.
     * @param constructorSignature The signature of the corresponding constructor.
     * @param arguments            The arguments of the object creation expression.
     */
    void objectCreation(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                        Class<?> clazz, String constructorSignature, List<ObjectClassTuple> arguments);

    /**
     * Announcement of an object creation expression. This method calls
     * {@link #objectCreation(int, int, int, int, int, boolean, Class, String, java.util.List)}
     * with an empty list of arguments.
     *
     * @param fileId               ID of the file in which this call is located.
     * @param lineStart            First line of the instrumented stmt/expr/declaration.
     * @param columnStart          First column of the instrumented stmt/expr/declaration.
     * @param lineEnd              Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd            Last column of the instrumented stmt/expr/declaration.
     * @param clazz                The class object of the object creation expression.
     * @param constructorSignature The signature of the corresponding constructor.
     * @see #objectCreation(int, int, int, int, int, boolean, Class, String, java.util.List)
     */
    void objectCreation(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                        Class<?> clazz, String constructorSignature);

    /**
     * Announcing the result of an object creation expression.
     *
     * @param fileId           ID of the file in which this call is located.
     * @param lineStart        First line of the instrumented stmt/expr/declaration.
     * @param columnStart      First column of the instrumented stmt/expr/declaration.
     * @param lineEnd          Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd        Last column of the instrumented stmt/expr/declaration.
     * @param objectClassTuple The result of the object creation expression.
     */
    void objectCreationResult(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                              ObjectClassTuple objectClassTuple);

    // METHOD CALLS ////////////////////////////////////////////////////////////////////////////////////////////////////

    // instance methods

    /**
     * Instance method call announcement.
     *
     * @param fileId          ID of the file in which this call is located.
     * @param lineStart       First line of the instrumented stmt/expr/declaration.
     * @param columnStart     First column of the instrumented stmt/expr/declaration.
     * @param lineEnd         Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd       Last column of the instrumented stmt/expr/declaration.
     * @param object          Object of the method call.
     * @param methodSignature Signature of the called method.
     * @param arguments       Arguments of the method call.
     */
    void callInstanceMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            ObjectClassTuple object, String methodSignature, List<ObjectClassTuple> arguments);

    /**
     * Instance method call announcement. This method calls
     * {@link #callInstanceMethod(int, int, int, int, int, boolean, ObjectClassTuple, String, java.util.List)}
     * with an empty list of arguments.
     *
     * @param fileId          ID of the file in which this call is located.
     * @param lineStart       First line of the instrumented stmt/expr/declaration.
     * @param columnStart     First column of the instrumented stmt/expr/declaration.
     * @param lineEnd         Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd       Last column of the instrumented stmt/expr/declaration.
     * @param object          Object of the method call.
     * @param methodSignature Signature of the called method.
     * @see #callInstanceMethod(int, int, int, int, int, boolean, ObjectClassTuple, String, java.util.List)
     */
    void callInstanceMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            ObjectClassTuple object, String methodSignature);

    // static methods

    /**
     * Static method call announcement.
     *
     * @param fileId          ID of the file in which this call is located.
     * @param lineStart       First line of the instrumented stmt/expr/declaration.
     * @param columnStart     First column of the instrumented stmt/expr/declaration.
     * @param lineEnd         Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd       Last column of the instrumented stmt/expr/declaration.
     * @param clazz           Class object of the method call.
     * @param methodSignature Signature of the called method.
     * @param arguments       Arguments of the method call.
     */
    void callStaticMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                          Class<?> clazz, String methodSignature, List<ObjectClassTuple> arguments);

    /**
     * Static method call announcement. This method calls
     * {@link #callStaticMethod(int, int, int, int, int, boolean, Class, String, java.util.List)}
     * with an empty list of arguments.
     *
     * @param fileId          ID of the file in which this call is located.
     * @param lineStart       First line of the instrumented stmt/expr/declaration.
     * @param columnStart     First column of the instrumented stmt/expr/declaration.
     * @param lineEnd         Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd       Last column of the instrumented stmt/expr/declaration.
     * @param clazz           Class object of the method call.
     * @param methodSignature Signature of the called method.
     * @see #callStaticMethod(int, int, int, int, int, boolean, Class, String, java.util.List)
     */
    void callStaticMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                          Class<?> clazz, String methodSignature);

    // explicit super class method call

    /**
     * Explicit super class method call announcement.
     *
     * @param fileId          ID of the file in which this call is located.
     * @param lineStart       First line of the instrumented stmt/expr/declaration.
     * @param columnStart     First column of the instrumented stmt/expr/declaration.
     * @param lineEnd         Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd       Last column of the instrumented stmt/expr/declaration.
     * @param object          Object of the method call.
     * @param clazz           Class in which the method is declared.
     * @param methodSignature Signature of the called method.
     * @param arguments       Arguments of the method call.
     */
    void callInstanceMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            ObjectClassTuple object, Class<?> clazz, String methodSignature, List<ObjectClassTuple> arguments);

    /**
     * Explicit super class method call announcement. This method calls
     * {@link #callInstanceMethod(int, int, int, int, int, boolean, ObjectClassTuple, Class, String, java.util.List)}
     * with an empty list of arguments.
     *
     * @param fileId          ID of the file in which this call is located.
     * @param lineStart       First line of the instrumented stmt/expr/declaration.
     * @param columnStart     First column of the instrumented stmt/expr/declaration.
     * @param lineEnd         Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd       Last column of the instrumented stmt/expr/declaration.
     * @param object          Object of the method call.
     * @param clazz           Class in which the method is declared.
     * @param methodSignature Signature of the called method.
     * @see #callInstanceMethod(int, int, int, int, int, boolean, ObjectClassTuple, Class, String, java.util.List)
     */
    void callInstanceMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            ObjectClassTuple object, Class<?> clazz, String methodSignature);

    // returned method calls

    // instance methods

    /**
     * Method is returned with result.
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param object      Object of the method call.
     * @param returnValue Returned value.
     */
    void returnedValue(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                       ObjectClassTuple object, ObjectClassTuple returnValue);

    /**
     * Void method is returned.
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param object      Object of the method call.
     */
    void returned(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                  ObjectClassTuple object);

    // static methods

    /**
     * Method is returned with result.
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param clazz       Class in which the method is declared.
     * @param returnValue Returned value.
     */
    void returnedValue(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                       Class<?> clazz, ObjectClassTuple returnValue);

    /**
     * Void method is returned.
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param clazz       Class in which the method is declared.
     */
    void returned(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                  Class<?> clazz);

    // LAMBDA EXPRS

    /**
     * @param fileId      ID of the file in which this lambda is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param clazz       The class of the lambda expression.
     * @param signature   The signature of the lambda.
     * @param parameters  The parameters of the lambda.
     */
    void lambdaEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                       Class<?> clazz, String signature, List<Parameter> parameters);

    /**
     * @param fileId      ID of the file in which this lambda is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param clazz       The class of the lambda expression.
     * @param signature   The signature of the lambda.
     */
    void lambdaEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                       Class<?> clazz, String signature);

    /**
     * @param fileId      ID of the file in which this lambda is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param clazz       The class of the lambda expression.
     * @param signature   Signature of the method.
     */
    void leavingLambda(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                       Class<?> clazz, String signature);

    // VARIABLE ////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Announce a variable declaration.
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param varType     The variable's type.
     * @param varName     The variable's name.
     */
    void variableDeclaration(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                             String varType, String varName);

    /**
     * Announce a variable assignment.
     *
     * @param fileId          ID of the file in which this call is located.
     * @param lineStart       First line of the instrumented stmt/expr/declaration.
     * @param columnStart     First column of the instrumented stmt/expr/declaration.
     * @param lineEnd         Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd       Last column of the instrumented stmt/expr/declaration.
     * @param varName         The variable's name.
     * @param valueClassTuple The new value.
     */
    void variableAssignment(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            String varName, ObjectClassTuple valueClassTuple);

    // FIELD ACCESS ////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Access to a field in an object.
     *
     * @param fileId           ID of the file in which this call is located.
     * @param lineStart        First line of the instrumented stmt/expr/declaration.
     * @param columnStart      First column of the instrumented stmt/expr/declaration.
     * @param lineEnd          Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd        Last column of the instrumented stmt/expr/declaration.
     * @param objectClassTuple The object which contains this field.
     * @param fieldName        The name of the field.
     * @param declaringClass   The class which declares this field.
     */
    void fieldAccess(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                     ObjectClassTuple objectClassTuple, String fieldName, Class<?> declaringClass);

    /**
     * Access to a static field.
     *
     * @param fileId         ID of the file in which this call is located.
     * @param lineStart      First line of the instrumented stmt/expr/declaration.
     * @param columnStart    First column of the instrumented stmt/expr/declaration.
     * @param lineEnd        Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd      Last column of the instrumented stmt/expr/declaration.
     * @param clazz          The class which contains this field.
     * @param fieldName      The name of the field.
     * @param declaringClass The class which declares this field.
     */
    void fieldAccess(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                     Class<?> clazz, String fieldName, Class<?> declaringClass);

    // ARRAYS //////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Access to an array component
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param array       The array which is accessed.
     * @param index       The array index.
     * @param value       The value which was accessed.
     */
    void arrayAccess(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                     ObjectClassTuple array, int index, ObjectClassTuple value);

    /**
     * Announce an assignment for an array at a given index.
     *
     * @param fileId          ID of the file in which this call is located.
     * @param lineStart       First line of the instrumented stmt/expr/declaration.
     * @param columnStart     First column of the instrumented stmt/expr/declaration.
     * @param lineEnd         Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd       Last column of the instrumented stmt/expr/declaration.
     * @param arrayClassTuple The array.
     * @param index           The corresponding index.
     * @param target          A String representing the array access.
     * @param value           The new value of the array at the given index.
     */
    void arrayAssignment(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                         ObjectClassTuple arrayClassTuple, int index, String target, ObjectClassTuple value);

    // BINARY OPERATION ////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Announcement of a binary expression.
     *
     * @param fileId       ID of the file in which this call is located.
     * @param lineStart    First line of the instrumented stmt/expr/declaration.
     * @param columnStart  First column of the instrumented stmt/expr/declaration.
     * @param lineEnd      Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd    Last column of the instrumented stmt/expr/declaration.
     * @param leftOperand  The left operand.
     * @param operator     The operator.
     * @param rightOperand The right operand.
     * @param result       The resulting value.
     */
    void binaryOperation(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                         String leftOperand, String operator, String rightOperand, ObjectClassTuple result);

    /**
     * Announcement of an instanceof expression.
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param expr        The expression.
     * @param type        The type.
     * @param result      The resulting value.
     */
    void instanceOfOperation(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                             String expr, String type, ObjectClassTuple result);

    // UNARY OPERATION /////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Announcement of a unary expression.
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param expression  The expression.
     * @param operator    The operator.
     * @param result      The result of the unary operation.
     */
    void unaryOperation(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                        String expression, String operator, ObjectClassTuple result);

    /**
     * Announcement of a unary prefix operation.
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param expression  The expression.
     * @param operator    The operator.
     * @param newValue    The resulting value.
     */
    void unaryPrefixOperation(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                              String expression, String operator, ObjectClassTuple newValue);

    /**
     * Announcement of a unary postfix operation.
     *
     * @param fileId      ID of the file in which this call is located.
     * @param lineStart   First line of the instrumented stmt/expr/declaration.
     * @param columnStart First column of the instrumented stmt/expr/declaration.
     * @param lineEnd     Last line of the instrumented stmt/expr/declaration.
     * @param columnEnd   Last column of the instrumented stmt/expr/declaration.
     * @param expression  The expression.
     * @param operator    The operator.
     * @param oldValue    The old value.
     * @param newValue    The resulting value.
     */
    void unaryPostfixOperation(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                               String expression, String operator, ObjectClassTuple oldValue, ObjectClassTuple newValue);
}
