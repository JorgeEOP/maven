package de.unibwm.inf2.bugvis.instr.facades;

import java.util.Collection;
import java.util.Iterator;

public class CollectionFacade<E, C extends Collection<E>> implements Collection<E> {

    final C wrapped;
    final HistoryListener history;

    public CollectionFacade(C wrapped, HistoryListener history) {
        this.wrapped = wrapped;
        this.history = history;
    }

    @Override
    public int size() {
        return wrapped.size();
    }

    @Override
    public boolean isEmpty() {
        return wrapped.isEmpty();
    }

    @Override
    public boolean contains(Object o) {
        return wrapped.contains(o);
    }

    @Override
    public Iterator<E> iterator() {
        return new CollectionIteratorFacade<>(this, this.wrapped.iterator());
    }

    @Override
    public Object[] toArray() {
        return wrapped.toArray();
    }

    @Override
    public <T> T[] toArray(T[] a) {
        return wrapped.toArray(a);
    }

    @Override
    public boolean add(E e) {
        boolean modified = wrapped.add(e);
        if (modified) history.collectionModified(this, wrapped);
        return modified;
    }

    @Override
    public boolean remove(Object o) {
        boolean modified = wrapped.remove(o);
        if (modified) history.collectionModified(this, wrapped);
        return modified;
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        return wrapped.containsAll(c);
    }

    @Override
    public boolean addAll(Collection<? extends E> c) {
        boolean modified = wrapped.addAll(c);
        if (modified) history.collectionModified(this, wrapped);
        return modified;
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        boolean modified = wrapped.removeAll(c);
        if (modified) history.collectionModified(this, wrapped);
        return modified;
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        boolean modified = wrapped.retainAll(c);
        if (modified) history.collectionModified(this, wrapped);
        return modified;
    }

    @Override
    public void clear() {
        wrapped.clear();
        history.collectionModified(this, wrapped);
    }

    @Override
    public String toString() {
        return wrapped.toString();
    }
}
