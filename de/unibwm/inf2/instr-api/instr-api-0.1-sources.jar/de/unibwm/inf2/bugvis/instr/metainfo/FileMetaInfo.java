package de.unibwm.inf2.bugvis.instr.metainfo;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class FileMetaInfo {
    private static int fileCounter = 0;

    @JsonProperty
    private final int fileId;

    @JsonProperty
    private final String relativeFilePath;

    @JsonProperty
    private Set<LineRange> breakpointRanges = new HashSet<>();

    @JsonProperty
    private Map<String, Set<String>> staticMethods = new HashMap<>();

    public FileMetaInfo(String relativeFilePath) {
        fileId = fileCounter++;
        this.relativeFilePath = relativeFilePath;
    }

    @JsonCreator
    public FileMetaInfo(@JsonProperty(value = "fileId") int fileId,
                        @JsonProperty(value = "relativeFilePath") String relativeFilePath,
                        @JsonProperty(value = "breakpointRanges") Set<LineRange> breakpointRanges,
                        @JsonProperty(value = "staticMethods") Map<String, Set<String>> staticMethods) {
        this.fileId = fileId;
        this.relativeFilePath = relativeFilePath;
        this.breakpointRanges = breakpointRanges;
        this.staticMethods = staticMethods;
    }

    public int getFileId() {return fileId;}

    public String getRelativeFilePath() {return relativeFilePath;}

    public void addBreakpointRange(LineRange breakpointRange) {this.breakpointRanges.add(breakpointRange);}

    public Set<LineRange> getBreakpointRanges() {return Collections.unmodifiableSet(breakpointRanges);}

    public boolean inBreakpointRange(int line) {return breakpointRanges.stream().anyMatch(r -> r.inRange(line));}

    public void addStaticMethod(String className, String signature) {
        staticMethods.computeIfAbsent(className, k -> new HashSet<>()).add(signature);
    }

    public Map<String, Set<String>> getStaticMethods() {return Collections.unmodifiableMap(staticMethods);}

    @Override
    public String toString() {
        return "FileMetaInfo{" +
               "fileId=" + fileId +
               ", relativeFilePath=" + relativeFilePath +
               ", ranges=" + breakpointRanges +
               ", staticMethods=" + staticMethods +
               '}';
    }
}
