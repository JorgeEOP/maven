package de.unibwm.inf2.bugvis.instr.facades;

import java.util.Deque;
import java.util.List;

public interface LinkedListInterface<E> extends List<E>, Deque<E> {
    @Override
    LinkedListInterface<E> reversed();

    @Override
    default void addFirst(E e) {List.super.addFirst(e);}

    @Override
    default void addLast(E e) {List.super.addLast(e);}

    @Override
    default E getFirst() {return List.super.getFirst();}

    @Override
    default E getLast() {return List.super.getLast();}

    @Override
    default E removeFirst() {return List.super.removeFirst();}

    @Override
    default E removeLast() {return List.super.removeLast();}
}
