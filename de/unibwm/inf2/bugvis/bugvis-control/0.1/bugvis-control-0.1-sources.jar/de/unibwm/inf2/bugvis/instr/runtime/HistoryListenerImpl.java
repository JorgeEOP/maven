package de.unibwm.inf2.bugvis.instr.runtime;

import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.instr.facades.HistoryListener;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.history.Command;
import de.unibwm.inf2.bugvis.model.history.ModifiedListCmd;
import de.unibwm.inf2.bugvis.model.history.ModifiedMapCmd;
import de.unibwm.inf2.bugvis.model.notification.debugee.FacadeModifiedEvent;
import de.unibwm.inf2.bugvis.model.value.Value;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public class HistoryListenerImpl implements HistoryListener {

    private final DebugControl control;

    public HistoryListenerImpl(DebugControl control) {
        this.control = control;
    }

    @Override
    public <T> void collectionModified(Collection<T> facade, Collection<T> contents) {
        final ProgramState state = control.getState();
        final Value facadeMirror = state.getMirrorObject(new ObjectClassTuple(facade));
        final List<Value> elementMirrors = state.mirrorElements(contents);
        final Command cmd = new ModifiedListCmd(state, facadeMirror, elementMirrors);
        addAndExecute(cmd);
        control.getState().notifyListeners(new FacadeModifiedEvent(facade));
    }

    @Override
    public <K, V> void mapModified(Map<K, V> facade, Map<K, V> contents) {
        final ProgramState state = control.getState();
        final Value facadeMirror = state.getMirrorObject(new ObjectClassTuple(facade));
        final Map<Value, Value> newMap = state.mirrorEntries(contents);
        final Command cmd = new ModifiedMapCmd(state, facadeMirror, newMap);
        addAndExecute(cmd);
        control.getState().notifyListeners(new FacadeModifiedEvent(facade));
    }

    private void addAndExecute(Command cmd) {
        control.getHistory().addSubCommandToLastCommand(cmd);
        cmd.execute();
    }
}
