package de.unibwm.inf2.bugvis.control;

/**
 * Enumeration represents the different stepping-kinds
 */
public enum SteppingKind {
    /**
     * Represents a stepping action which holds at every instruction
     */
    STEP_INSTRUCTION,
    /**
     * Represents the step-into action
     */
    STEP_INTO,
    /**
     * Represents the step-over action
     */
    STEP_OVER,
    /**
     * Represents the step-out action
     */
    STEP_OUT,
    /**
     * Represents a resume of execution
     */
    RESUME
}
