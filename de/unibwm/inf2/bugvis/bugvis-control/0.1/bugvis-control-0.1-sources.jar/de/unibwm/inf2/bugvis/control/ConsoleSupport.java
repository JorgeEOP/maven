package de.unibwm.inf2.bugvis.control;

import de.unibwm.inf2.bugvis.model.history.OutputStreamCmd;
import de.unibwm.inf2.bugvis.model.history.OutputStreamCmd.OutputType;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Arrays;

import static de.unibwm.inf2.bugvis.control.events.DebugeeStateEvent.WAITING_FOR_INPUT;

public class ConsoleSupport {
    private static final Object SYNC_CONSOLE = new Object();
    private static final PrintStream DEFAULT_SYSTEM_ERR = System.err;
    private static PrintStream consoleErr;

    public static PrintStream getConsoleErr() {return consoleErr;}

    public static PrintStream getDefaultSystemErr() {return DEFAULT_SYSTEM_ERR;}

    private final DebugControl control;
    private final PrintStreamCapturer outCapturer;
    private final PrintStreamCapturer errCapturer;
    private final WritableByteArrayInputStream consoleIn;
    private final InputStreamCapturer inCapturer;

    public ConsoleSupport(DebugControl control) {
        this.control = control;
        final PrintStream consoleOut = new PrintStream(new CommandOutputStream(OutputType.DEFAULT), true);
        outCapturer = new PrintStreamCapturer(consoleOut, this::getSystemOut, System::setOut);
        consoleErr = new PrintStream(new CommandOutputStream(OutputType.ERROR), true);
        errCapturer = new PrintStreamCapturer(consoleErr, this::getSystemErr, System::setErr);
        consoleIn = new WritableByteArrayInputStream();
        inCapturer = new InputStreamCapturer(new BufferedInputStream(consoleIn), this::getSystemIn, System::setIn);
    }

    private class CommandOutputStream extends ByteArrayOutputStream {
        private final OutputType outputType;

        public CommandOutputStream(OutputType outputType) {this.outputType = outputType;}

        @Override
        public void flush() throws IOException {
            super.flush();
            final String content = toString();
            if (!content.isEmpty()) {
                createAndExecuteOutputStreamCmd(content, outputType);
                super.reset();
            }
        }
    }

    private class WritableByteArrayInputStream extends ByteArrayInputStream {

        public WritableByteArrayInputStream() {super(new byte[0]);}

        public void write(String str) {
            synchronized (SYNC_CONSOLE) {
                final byte[] bytes = str.getBytes();
                final int length = this.count + bytes.length;
                if (length >= this.buf.length)
                    this.buf = Arrays.copyOf(this.buf, length);
                System.arraycopy(bytes, 0, this.buf, this.count, bytes.length);
                this.count += bytes.length;
                SYNC_CONSOLE.notifyAll();
            }

            if (control.getHistory().getRedoCommandSize() == 0)
                createAndExecuteOutputStreamCmd(str, OutputType.INPUT);
        }

        @Override
        public synchronized int read() {
            waitForInput();
            return super.read();
        }

        @Override
        public synchronized int read(byte[] b, int off, int len) {
            waitForInput();
            return super.read(b, off, len);
        }

        private void waitForInput() {
            try {
                synchronized (SYNC_CONSOLE) {
                    while (pos >= count) {
                        control.setState(WAITING_FOR_INPUT);
                        SYNC_CONSOLE.wait();
                    }
                }
            }
            catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private InputStream getSystemIn() {return System.in;}

    private PrintStream getSystemOut() {return System.out;}

    private PrintStream getSystemErr() {return System.err;}

    private void createAndExecuteOutputStreamCmd(String content, OutputType outputType) {
        final OutputStreamCmd cmd = new OutputStreamCmd(control.getState(), content, outputType);
        control.getHistory().addSubCommandToLastCommand(cmd);
        cmd.execute();
    }

    public void startCaptureIn() {inCapturer.startCapture();}

    public void startCaptureErr() {errCapturer.startCapture();}

    public void startCaptureOut() {outCapturer.startCapture();}

    public void endCaptureErr() {errCapturer.endCapture();}

    public void endCaptureOut() {outCapturer.endCapture();}

    public void writeToIn(String text) {consoleIn.write(text);}
}
