package de.unibwm.inf2.bugvis.control;

import de.unibwm.inf2.bugvis.model.VisualizationObject;
import de.unibwm.inf2.bugvis.model.history.Command;
import de.unibwm.inf2.bugvis.model.history.StartVisualizationCmd;
import de.unibwm.inf2.bugvis.model.history.StopVisualizationCmd;
import de.unibwm.inf2.bugvis.model.history.UpdateVisualizationCmd;
import de.unibwm.inf2.bugvis.model.notification.debugee.ArrayAssignmentEvent;
import de.unibwm.inf2.bugvis.model.notification.debugee.DebugeeEventListener;
import de.unibwm.inf2.bugvis.model.notification.debugee.FacadeModifiedEvent;
import de.unibwm.inf2.bugvis.model.notification.debugee.FieldAssignmentEvent;
import de.unibwm.inf2.bugvis.model.notification.debugee.FrameEnteredEvent;
import de.unibwm.inf2.bugvis.model.notification.debugee.ObjectCreationEvent;
import de.unibwm.inf2.bugvis.model.notification.debugee.StaticFieldAssignmentEvent;

import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;

import static java.lang.System.Logger.Level.INFO;
import static java.lang.System.identityHashCode;

public class PluginControl implements DebugeeEventListener {
    private static final Logger LOGGER = System.getLogger(PluginControl.class.getName());

    private final DebugControl control;
    private final DependencyStore dependencyStore;
    private final List<Plugin> plugins = new ArrayList<>();

    public PluginControl(DebugControl control) {
        this.control = control;
        dependencyStore = new DependencyStore(control);
        control.getState().addDebugeeEventListener(this);
    }

    // event handling //////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public void receivedEvent(ArrayAssignmentEvent event) {
        final Object object = event.getObject();
        dependencyStore.getDependencies(new ArrayComponentIdentifier(object, event.getIndex()))
                       .forEach(this::update);
    }

    @Override
    public void receivedEvent(FieldAssignmentEvent event) {
        final Object object = event.getObject();
        final Class<?> clazz = event.getIdentifier().declaringClass();
        final String name = event.getIdentifier().name();
        dependencyStore.getDependencies(new ObjectFieldIdentifier(object, clazz, name))
                       .forEach(this::update);
    }

    @Override
    public void receivedEvent(FacadeModifiedEvent event) {
        final Object facade = event.getFacade();
        dependencyStore.getDependencies(facade).forEach(this::update);
    }

    @Override
    public void receivedEvent(FrameEnteredEvent event) {
        final String signature = event.getSignature();
        final Object object = event.getReceiverParameter();

        if (object != null &&
            control.getState().getVisualizationState().contains(System.identityHashCode(object)) &&
            plugins.stream()
                   .anyMatch(p -> p.hasToBeDeleted(object, signature)))
            registerAndExecute(new StopVisualizationCmd(control.getState(), object));
    }

    @Override
    public void receivedEvent(ObjectCreationEvent event) {
        updateVisualization(event.getObject(), o -> new StartVisualizationCmd(control.getState(), o));
    }

    @Override
    public void receivedEvent(StaticFieldAssignmentEvent event) {
        dependencyStore.getDependencies(event.getIdentifier()).forEach(this::update);
    }

    private void registerAndExecute(Command cmd) {
        control.getHistory().addSubCommandToLastCommand(cmd);
        cmd.execute();
    }

    // visualization helper ////////////////////////////////////////////////////////////////////////////////////////////

    private void update(Object object) {
        updateVisualization(object, o -> new UpdateVisualizationCmd(control.getState(), o));
    }

    private void updateVisualization(Object object, Function<VisualizationObject, Command> mkCommand) {
        LOGGER.log(INFO, "update visualization of {0} class {1}", identityHashCode(object), object.getClass().getName());
        if (object instanceof String)
            LOGGER.log(INFO, "String: {0}", object);

        plugins.stream()
               .filter(f -> f.isApplicable(object))
               .findAny()
               .map(p -> dependencyStore.updateDependencies(p, object))
               .ifPresent(o -> registerAndExecute(mkCommand.apply(o)));
    }

    // Plugin handling /////////////////////////////////////////////////////////////////////////////////////////////////

    public void addPlugin(Plugin<?, ?>... plugins) {Collections.addAll(this.plugins, plugins);}

    public void removePlugin(Plugin<?, ?> plugin) {plugins.remove(plugin);}

    public DependencyStore getDependencyStore() {return dependencyStore;}
}
