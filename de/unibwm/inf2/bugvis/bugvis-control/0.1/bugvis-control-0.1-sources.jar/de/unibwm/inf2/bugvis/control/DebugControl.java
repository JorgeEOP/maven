package de.unibwm.inf2.bugvis.control;

import de.unibwm.inf2.bugvis.control.events.BreakpointEvent;
import de.unibwm.inf2.bugvis.control.events.ControlEvent;
import de.unibwm.inf2.bugvis.control.events.ControlEventListener;
import de.unibwm.inf2.bugvis.control.events.DebugeeStateEvent;
import de.unibwm.inf2.bugvis.control.events.SelectEvent;
import de.unibwm.inf2.bugvis.control.events.SelectEventListener;
import de.unibwm.inf2.bugvis.instr.metainfo.MetaInfo;
import de.unibwm.inf2.bugvis.instr.runtime.BugVisInstr;
import de.unibwm.inf2.bugvis.instr.runtime.DeclarationRuntimeImpl;
import de.unibwm.inf2.bugvis.instr.runtime.ExprRuntimeImpl;
import de.unibwm.inf2.bugvis.instr.runtime.HistoryListenerImpl;
import de.unibwm.inf2.bugvis.instr.runtime.StmtRuntimeImpl;
import de.unibwm.inf2.bugvis.model.Breakpoint;
import de.unibwm.inf2.bugvis.model.CallStack;
import de.unibwm.inf2.bugvis.model.LineBreakpoint;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.StackFrame;
import de.unibwm.inf2.bugvis.model.history.Command;
import de.unibwm.inf2.bugvis.model.history.EnterFrameCmd;
import de.unibwm.inf2.bugvis.model.history.History;
import de.unibwm.inf2.bugvis.model.history.PositionCommand;
import de.unibwm.inf2.bugvis.model.notification.visualize.VisualizationBigStepEvent;

import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static de.unibwm.inf2.bugvis.control.SteppingKind.STEP_INTO;
import static de.unibwm.inf2.bugvis.control.events.DebugeeStateEvent.PAUSED;
import static de.unibwm.inf2.bugvis.control.events.DebugeeStateEvent.RUNNING;
import static de.unibwm.inf2.bugvis.control.events.DebugeeStateEvent.WAITING_FOR_INPUT;
import static java.lang.System.Logger.Level.INFO;

/**
 * Base class for debug controls.
 */
public class DebugControl {
    private static final Logger LOGGER = System.getLogger(DebugControl.class.getName());
    private static final Object SYNC = new Object();

    private final ProgramState state = new ProgramState();
    private final Set<Breakpoint> breakpoints = new HashSet<>();
    private final PluginControl pluginControl = new PluginControl(this);
    private final ConsoleSupport console = new ConsoleSupport(this);
    private final List<ControlEventListener> controlListeners = new ArrayList<>();
    private final List<SelectEventListener> selectListeners = new ArrayList<>();
    private final DebugeeSupport debugeeSupport;
    private final ControlOptions options;

    private final DebugControlState historyState = new HistoryState(this);
    private final DebugControlState dummyState = new DebugControlStateAdapter();

    private DebugControlState controlState = historyState;
    /**
     * Indicates which kind of stepping action should be performed next
     */
    private SteppingKind step;
    /**
     * Frame in which the program was last stopped and before it started a new step.
     */
    private StackFrame startFrame;
    private boolean debugeePaused;
    private ExecutorService executor;
    private Command previousCommand;

    public DebugControl(ControlOptions options) {
        this.options = options;
        this.debugeeSupport = new DebugeeSupport(options);
        console.startCaptureIn();
    }

    /**
     * Runs the debugee in a separate thread, as it blocks indefinitely.
     */
    public void runDebugee() {getExecutor().execute(this::execute);}

    /**
     * Returns the executor service used for multi-threading.
     */
    public ExecutorService getExecutor() {
        if (executor == null)
            executor = Executors.newCachedThreadPool();
        return executor;
    }

    /**
     * Execute the debugee controlled by this debug control.
     * This method does not return; instead, it blocks the
     * calling thread when the debugee reaches a breakpoint
     * or runs in single-step mode.
     */
    private void execute() {
        prepareNextStep(STEP_INTO);
        setState(RUNNING);
        startOutErrStreamCapture();
        try {
            debugeeSupport.runDebugee();
        }
        catch (InvocationTargetException e) {
            e.getCause().printStackTrace();
        }
        setState(PAUSED);
        stopOutErrStreamCapture();
        while (true)
            pauseExecution();
    }

    public void useDefaultInstrumentationRuntime() {
        BugVisInstr.setDeclRuntime(new DeclarationRuntimeImpl(this));
        BugVisInstr.setStmtRuntime(new StmtRuntimeImpl(this));
        BugVisInstr.setExprRuntime(new ExprRuntimeImpl(this));
        BugVisInstr.setHistListener(new HistoryListenerImpl(this));
    }

    /**
     * Stops the debugee execution and blocks at the {@link #pauseDebugee()} call until {@link #continueDebugee()} has
     * been called.
     * <p>
     * Sets the state accordingly, which notifies listeners.
     */
    void pauseExecution() {
        setState(PAUSED);
        stopOutErrStreamCapture();
        pauseDebugee();
        startOutErrStreamCapture();
        setState(RUNNING);
    }

    /**
     * Resumes control to the front end for inspecting the debugee's state and controlling how to
     * continue the debugee.
     * <p>
     * Blocks until {@link #continueDebugee()} has been called.
     */
    private void pauseDebugee() {
        debugeePaused = true;
        try {
            synchronized (SYNC) {
                while (debugeePaused) SYNC.wait();
            }
        }
        catch (InterruptedException e) {
            LOGGER.log(Level.ERROR, "Wait was interrupted", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Ends the blocking behavior of {@link #pauseDebugee()}.
     */
    private void continueDebugee() {
        debugeePaused = false;
        synchronized (SYNC) {
            SYNC.notifyAll();
        }
    }

    /**
     * Executes the debugee in a forward fashion performing the specified step. Returns true
     * if the specified step is not yet complete when this method returns, that is,
     * debugee execution must be continued.
     *
     * @param step the step to be done by the debugee in a forward fashion.
     */
    public void forward(SteppingKind step) {
        prepareNextStep(step);
        setState(RUNNING);
        if (getHistory().redo(this::stopNecessary))
            setState(PAUSED);
        else
            continueDebugee();
    }

    /**
     * Executes the debugee in a backward fashion performing the specified step.
     *
     * @param step the step to be done by the debugee in a backward fashion.
     */
    public void backward(SteppingKind step) {
        prepareNextStep(step);
        setState(RUNNING);
        getHistory().undo(this::stopNecessary);
        setState(PAUSED);
    }

    /**
     * Prepares the next code stepping action. This method must be called when the program has been
     * stopped and immediately before it is going to be continued.
     *
     * @param step The kind of the next stepping-action or null if the debugee shall just resume.
     */
    private void prepareNextStep(SteppingKind step) {
        this.step = step;
        startFrame = currentFrame();
    }

    /**
     * Checks whether execution has reached the end of the current step or a breakpoint
     * before executing the specified command.
     */
    boolean stopNecessary(PositionCommand cmd) {
        final boolean firstInFrame = previousCommand instanceof EnterFrameCmd;
        previousCommand = cmd;
        final boolean negativeLine = cmd.getPosition().firstLine() < 0;
        if (negativeLine) return false;
        if (cmd.alwaysContinue()) return false;

        final boolean newLineWithCode = cmd.isFirstInLine();
        boolean stepFinished = switch (step) {
            case STEP_INSTRUCTION -> true;
            case STEP_INTO -> firstInFrame || newLineWithCode || stackDepthLessThan();
            case STEP_OVER -> newLineWithCode && stackDepthLessThanOrEqual();
            case STEP_OUT -> stackDepthLessThan();
            case RESUME -> false;
        };
        boolean breakpointReached = newLineWithCode && breakpointReached();

        return stepFinished || breakpointReached;
    }

    private boolean stackDepthLessThanOrEqual() {return currentFrame().getDepth() <= startFrame.getDepth();}

    private boolean stackDepthLessThan() {return currentFrame().getDepth() < startFrame.getDepth();}

    private boolean breakpointReached() {
        final StackFrame stackFrame = currentFrame();
        final int fileId = stackFrame.getMethod().getFileId();
        final int line = stackFrame.getPosition().firstLine();
        final Breakpoint bp = new LineBreakpoint(fileId, line);
        return breakpoints.contains(bp);
    }

    /**
     * Returns the program state of the target controlled by this control.
     */
    public ProgramState getState() {return state;}

    /**
     * Informs observers whether the debugee has been started or stopped, or is waiting for input.
     *
     * @param newState the new state of the debugee.
     */
    void setState(DebugeeStateEvent newState) {
        if (newState == PAUSED || newState == WAITING_FOR_INPUT)
            state.getVisualizationState().notifyListeners(VisualizationBigStepEvent.INSTANCE);
        fireControlEvent(newState);
    }

    public ControlOptions getOptions() {return options;}

    public MetaInfo getMetaInfo() {return options.getMetaInfo();}

    public StackFrame currentFrame() {return getCallStack().getCurrentFrame();}

    public CallStack getCallStack() {return state.getCallStack();}

    public History getHistory() {return state.getHistory();}

    public PluginControl getPluginControl() {return pluginControl;}

    public boolean isDebugeeFinished() {return debugeeSupport.isDebugeeExecutionFinished();}

    public boolean isDebugeeException() {return debugeeSupport.isDebugeeException();}

    // States //////////////////////////////////////////////////////////////////////////////////////////////////////////

    public void activateHistoryState() {setControlState(historyState);}

    public void activateDummyState() {setControlState(dummyState);}

    public DebugControlState getControlState() {return controlState;}

    public void setControlState(DebugControlState newState) {controlState = newState;}

    // Control events //////////////////////////////////////////////////////////////////////////////////////////////////

    public void addControlListener(ControlEventListener listener) {
        synchronized (controlListeners) {
            LOGGER.log(INFO, "add control listener {0}", listener);
            controlListeners.add(listener);
        }
    }

    public void removeControlListener(ControlEventListener listener) {
        synchronized (controlListeners) {
            LOGGER.log(INFO, "remove control listener {0}", listener);
            controlListeners.removeIf(x -> x == listener);
        }
    }

    private void fireControlEvent(ControlEvent event) {controlListeners.forEach(event::notifyListener);}

    // SelectEvent /////////////////////////////////////////////////////////////////////////////////////////////////////

    public void addSelectListener(SelectEventListener listener) {selectListeners.add(listener);}

    public void removeSelectListener(SelectEventListener listener) {selectListeners.remove(listener);}

    public void notifyListeners(SelectEvent event) {
        for (SelectEventListener listener : selectListeners)
            event.notifyListeners(listener);
    }

    // Breakpoints /////////////////////////////////////////////////////////////////////////////////////////////////////

    public Set<Breakpoint> getBreakpoints() {return Collections.unmodifiableSet(breakpoints);}

    public boolean addBreakpoint(Breakpoint bp) {
        if (!breakpoints.add(bp)) return false;

        fireControlEvent(new BreakpointEvent(bp, true));
        return true;
    }

    public void removeBreakpoint(Breakpoint breakpoint) {
        if (breakpoints.remove(breakpoint))
            fireControlEvent(new BreakpointEvent(breakpoint, false));
    }

    public void clearBreakpoints() {
        final ArrayList<Breakpoint> copy = new ArrayList<>(breakpoints);
        breakpoints.clear();
        for (Breakpoint bp : copy)
            fireControlEvent(new BreakpointEvent(bp, false));
    }

    // System.out/err-Capture //////////////////////////////////////////////////////////////////////////////////////////

    public void startOutErrStreamCapture() {
        console.startCaptureOut();
        console.startCaptureErr();
    }

    public void stopOutErrStreamCapture() {
        console.endCaptureOut();
        console.endCaptureErr();
    }

    public void writeToInputStream(String text) {console.writeToIn(text);}
}