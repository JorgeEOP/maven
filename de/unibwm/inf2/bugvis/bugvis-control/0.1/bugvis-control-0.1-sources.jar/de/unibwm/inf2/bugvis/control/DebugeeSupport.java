package de.unibwm.inf2.bugvis.control;

import javax.swing.JOptionPane;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import static java.lang.System.Logger.Level.INFO;

public class DebugeeSupport {
    private static final Logger LOGGER = System.getLogger(DebugeeSupport.class.getName());

    private static final char BRACE_LEFT = '(';
    private static final char BRACE_RIGHT = ')';
    private static final char BRACKET_LEFT = '[';
    private static final String BRACKET_PAIR = "[]";
    private static final String COMMA = ",";

    private final ControlOptions options;

    private boolean debugeeExecutionFinished = false;
    private boolean debugeeException = false;

    public DebugeeSupport(ControlOptions options) {this.options = options;}

    public void runDebugee() throws InvocationTargetException {
        try {
            final Method method = getDebugeeMainMethod();
            if (method.getParameterCount() > 0 && method.getParameterTypes()[0].isArray())
                method.invoke(null, (Object) options.getArguments().toArray(new String[0]));
            else
                method.invoke(null, (Object[]) options.getArguments().toArray(new String[0]));
            debugeeExecutionFinished = true;
        }
        catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException | IllegalArgumentException e) {
            LOGGER.log(Level.ERROR, e.toString(), e);
            final String message = switch (e) {
                case ClassNotFoundException i -> "The class '" + e.getMessage() + "' could not be found.";
                case NoSuchMethodException i -> "The method '" + e.getMessage() + "' could not be found.";
                case IllegalAccessException i -> "Illegal access: " + e.getMessage();
                case IllegalArgumentException i -> "Wrong arguments or non-static method selected: " + e.getMessage();
                default -> null /* not possible*/;
            };
            final String title = "Error: The debugee method could not be started.";
            JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
        catch (InvocationTargetException e) {
            debugeeExecutionFinished = true;
            debugeeException = true;
            throw e;
        }
    }

    private Method getDebugeeMainMethod() throws NoSuchMethodException, ClassNotFoundException {
        LOGGER.log(INFO, "debugee class: {0}, debugee signature: {1}",
                   options.getDebugeeClassName(), options.getDebugeeMethodSignature());
        return Class.forName(options.getDebugeeClassName())
                    .getMethod(methodName(options.getDebugeeMethodSignature()),
                               parameterClassesAsArray(options.getDebugeeMethodSignature()));
    }

    private String methodName(String dms) {
        return dms.substring(0, dms.indexOf(BRACE_LEFT));
    }

    private Class<?>[] parameterClassesAsArray(String signature) throws ClassNotFoundException {
        final String parameters = signature.substring(signature.indexOf(BRACE_LEFT) + 1, signature.indexOf(BRACE_RIGHT));
        List<Class<?>> classes = new ArrayList<>();
        for (final String t : parameters.split(COMMA)) {
            String type = t.trim().replace("...", BRACKET_PAIR);
            if (type.contains(BRACKET_PAIR)) {
                Class<?> clazz = null;
                final int endIndex = type.indexOf(BRACKET_LEFT);
                String componentType = type.substring(0, endIndex);
                clazz = Class.forName(componentType);
                StringBuilder brackets = new StringBuilder(type.substring(endIndex));
                while (!brackets.isEmpty()) {
                    brackets.delete(0, BRACKET_PAIR.length());
                    clazz = clazz.arrayType();
                }
                classes.add(clazz);
            }
            else if (!type.isEmpty())
                classes.add(Class.forName(t));
        }
        return classes.toArray(new Class<?>[0]);
    }

    public boolean isDebugeeException() {return debugeeException;}

    public boolean isDebugeeExecutionFinished() {return debugeeExecutionFinished;}
}
