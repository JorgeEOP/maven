package de.unibwm.inf2.bugvis.control;

public record ObjectFieldIdentifier(int idHashCode, Class<?> clazz, String name) {
    public ObjectFieldIdentifier(Object obj, Class<?> clazz, String name) {
        this(System.identityHashCode(obj), clazz, name);
    }
}
