package de.unibwm.inf2.bugvis.control.events;

public interface ControlEventListener {
    void receivedEvent(BreakpointEvent event);

    void receivedEvent(DebugeeStateEvent event);
}
