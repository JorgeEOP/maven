package de.unibwm.inf2.bugvis.control.events;

import de.unibwm.inf2.bugvis.model.Breakpoint;

/**
 * Represents a control event sent when a breakpoint has been added or removed.
 *
 * @param breakpoint the breakpoint that has been added or removed.
 * @param add        indicates whether the breakpoint has been added ({@code true}) or removed ({@code false}).
 */
public record BreakpointEvent(Breakpoint breakpoint, boolean add) implements ControlEvent {
    @Override
    public void notifyListener(ControlEventListener listener) {
        listener.receivedEvent(this);
    }
}
