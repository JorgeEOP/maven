package de.unibwm.inf2.bugvis.control.events;

public interface ControlEvent {
    void notifyListener(ControlEventListener listener);
}
