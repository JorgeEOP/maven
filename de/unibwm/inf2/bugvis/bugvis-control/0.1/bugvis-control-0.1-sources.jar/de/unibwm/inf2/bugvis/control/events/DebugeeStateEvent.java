package de.unibwm.inf2.bugvis.control.events;

/**
 * Represents a control event sent when the debugee state has changed.
 */
public enum DebugeeStateEvent implements ControlEvent {
    /**
     * The event to be sent when the debugee is currently running,
     * that is, observers will receive inconsistent results when
     * watching its internal states.
     */
    RUNNING,
    /**
     * The event to be sent when the debugee is currently paused,
     * e.g., at a breakpoint.
     */
    PAUSED,
    /**
     * The event to be sent when the debugee is waiting for console input.
     */
    WAITING_FOR_INPUT;

    @Override
    public void notifyListener(ControlEventListener listener) {
        listener.receivedEvent(this);
    }
}
