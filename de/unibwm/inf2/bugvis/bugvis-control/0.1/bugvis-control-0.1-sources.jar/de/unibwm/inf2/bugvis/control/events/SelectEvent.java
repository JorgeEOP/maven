package de.unibwm.inf2.bugvis.control.events;

public class SelectEvent {
    private final int hashCode;

    public SelectEvent(int hashCode) {this.hashCode = hashCode;}

    public void notifyListeners(SelectEventListener listener) {listener.receivedEvent(this);}

    public int getHashCode() {return hashCode;}
}
