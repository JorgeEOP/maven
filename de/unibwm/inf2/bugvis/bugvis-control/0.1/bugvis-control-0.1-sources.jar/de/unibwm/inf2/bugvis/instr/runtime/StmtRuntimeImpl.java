package de.unibwm.inf2.bugvis.instr.runtime;

import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.control.DebugControlState;
import de.unibwm.inf2.bugvis.model.Position;

import java.lang.System.Logger;

public class StmtRuntimeImpl implements StmtRuntime {
    private static final Logger LOGGER = System.getLogger(StmtRuntimeImpl.class.getName());

    private final DebugControl control;

    public StmtRuntimeImpl(DebugControl control) {
        this.control = control;
    }

    private DebugControlState getState() {
        return control.getControlState();
    }

    @Override
    public void returnValue(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            ObjectClassTuple value) {
        getState().setReturn(value,
                             new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                             first);
    }

    @Override
    public void returnWithoutValue(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first) {
        getState().positionReached(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                   first);
    }

    @Override
    public void yieldValue(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                           ObjectClassTuple value) {
        getState().positionReached(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                   first);
    }

    @Override
    public void caseEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            String caseLabels) {
        getState().positionReached(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                   first);
    }

    @Override
    public void caseLeaving(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            String caseLabels) {
        getState().positionReached(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                   first);
    }
}
