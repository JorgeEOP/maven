package de.unibwm.inf2.bugvis.control;

import de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple;
import de.unibwm.inf2.bugvis.instr.runtime.Parameter;
import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.VarKind;

import java.util.List;

public class DebugControlStateAdapter implements DebugControlState {

    // Position reached ////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * The specified position in the source code has been reached.
     *
     * @param position      reached position.
     * @param isFirstInLine Specifies if this action is the first action in a new line.
     */
    @Override
    public void positionReached(Position position, boolean isFirstInLine) {}

    // Enter and exit StackFrames //////////////////////////////////////////////////////////////////////////////////////

    /**
     * Enters a new {@link de.unibwm.inf2.bugvis.model.Method} {@link de.unibwm.inf2.bugvis.model.StackFrame} with the
     * given {@link de.unibwm.inf2.bugvis.instr.runtime.Parameter}s.
     *
     * @param position          position of the method declaration
     * @param isFirstInLine     Specifies if this action is the first action in a new line.
     * @param clazz             in which the method is declared
     * @param signature         signature of the called method
     * @param receiverParameter receiver parameter
     * @param parameters        containing the parameters of this method invocation
     */
    @Override
    public void methodFrameEntered(Position position, boolean isFirstInLine, Class<?> clazz, String signature,
                                   ObjectClassTuple receiverParameter, List<Parameter> parameters) {}

    /**
     * Enters a new {@link de.unibwm.inf2.bugvis.model.Initializer} {@link de.unibwm.inf2.bugvis.model.StackFrame}.
     *
     * @param position          position of the initializer declaration
     * @param isFirstInLine     Specifies if this action is the first action in a new line.
     * @param receiverParameter receiver parameter
     */
    @Override
    public void initializerFrameEntered(Position position, boolean isFirstInLine, ObjectClassTuple receiverParameter) {}

    /**
     * Enters a new static {@link de.unibwm.inf2.bugvis.model.Initializer} {@link de.unibwm.inf2.bugvis.model.StackFrame}.
     *
     * @param position      position of the static initializer declaration
     * @param isFirstInLine Specifies if this action is the first action in a new line.
     * @param clazz         in which the initializer is declared
     */
    @Override
    public void staticInitializerFrameEntered(Position position, boolean isFirstInLine, Class<?> clazz) {}

    /**
     * Exits the current stackFrame
     *
     * @param position      target position of the method end
     * @param isFirstInLine Specifies if this action is the first action in a new line.
     */
    @Override
    public void frameLeft(Position position, boolean isFirstInLine) {}

    // Receiver Parameter //////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Sets the given receiver parameter for the current stackframe.
     *
     * @param objectClassTuple The receiver parameter object.
     * @param position         The current position in the original code.
     * @param isFirstInLine    Specifies if this action is the first action in a new line.
     */
    @Override
    public void setReceiverParameter(ObjectClassTuple objectClassTuple, Position position, boolean isFirstInLine) {}

    // Return //////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Sets the given return value as return value the parent frame
     *
     * @param objectClassTuple return value as {@link de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple}.
     * @param position         target position where return value is set
     * @param isFirstInLine    Specifies if this action is the first action in a new line.
     */
    @Override
    public void setReturn(ObjectClassTuple objectClassTuple, Position position, boolean isFirstInLine) {}

    // Method returned /////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Information that a called method returned.
     *
     * @param object        The object of the called method as {@link de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple}.
     * @param position      The {@link de.unibwm.inf2.bugvis.model.Position} of the method call.
     * @param isFirstInLine Specifies if this action is the first action in a new line.
     * @param value         the returned value.
     */
    @Override
    public void methodReturned(ObjectClassTuple object, Position position, boolean isFirstInLine, ObjectClassTuple value) {}

    /**
     * Intermediate results, which are stored in the active Stackframe.
     *
     * @param position      Position of the code producing the result.
     * @param isFirstInLine Specifies if this action is the first action in a new line.
     * @param value         The intermediate result, to be stored.
     */
    @Override
    public void intermediateResult(Position position, boolean isFirstInLine, ObjectClassTuple value) {}

    // Access to, declarations of and assignments to arrays, variables, fields and static fields. //////////////////////

    // declarations

    /**
     * Declares a new attribute with the given parameters
     *
     * @param objectClassTuple The object (as {@link de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple}) of the
     *                         {@link de.unibwm.inf2.bugvis.model.Field}.
     * @param type             The type of the {@link de.unibwm.inf2.bugvis.model.Field}.
     * @param name             The name of the {@link de.unibwm.inf2.bugvis.model.Field}.
     * @param initialValue     The initial value of the {@link de.unibwm.inf2.bugvis.model.Field}.
     * @param position         The {@link de.unibwm.inf2.bugvis.model.Position} of the declaration.
     * @param isFirstInLine    Specifies if this action is the first action in a new line.
     * @param declaringClass   The declaring class of the {@link de.unibwm.inf2.bugvis.model.Field}.
     */
    @Override
    public void fieldDeclaration(ObjectClassTuple objectClassTuple, String type, String name, ObjectClassTuple initialValue,
                                 Position position, boolean isFirstInLine, Class<?> declaringClass) {}

    /**
     * Declares a static field with the given parameters.
     *
     * @param varKinds       to specify properties of this static field
     * @param type           The type of the static field
     * @param name           The name of the static field
     * @param position       The {@link de.unibwm.inf2.bugvis.model.Position} of the declaration.
     * @param isFirstInLine  Specifies if this action is the first action in a new line.
     * @param declaringClass The declaring class of the static field.
     */
    @Override
    public void staticFieldDeclaration(List<VarKind> varKinds, String type, String name, Position position, boolean isFirstInLine,
                                       Class<?> declaringClass) {}

    /**
     * Declares a local {@link de.unibwm.inf2.bugvis.model.Variable} with the given parameters in the current frame.
     *
     * @param varKinds      to specify properties of this {@link de.unibwm.inf2.bugvis.model.Variable}.
     * @param type          The type of the {@link de.unibwm.inf2.bugvis.model.Variable}.
     * @param name          the name of the {@link de.unibwm.inf2.bugvis.model.Variable}.
     * @param position      The {@link de.unibwm.inf2.bugvis.model.Position} of the declaration.
     * @param isFirstInLine Specifies if this action is the first action in a new line.
     */
    @Override
    public void variableDeclaration(List<VarKind> varKinds, String type, String name, Position position, boolean isFirstInLine) {}

    // assignments

    /**
     * Assign a value to an array component.
     *
     * @param arrayClassTuple The array as {@link de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple}
     *                        of which a component was assigned.
     * @param index           The index of the component.
     * @param value           The assigned value as {@link de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple}.
     * @param position        The {@link de.unibwm.inf2.bugvis.model.Position} of the assignment.
     * @param isFirstInLine   Specifies if this action is the first action in a new line.
     */
    @Override
    public void arrayAssignment(ObjectClassTuple arrayClassTuple, int index, ObjectClassTuple value, Position position, boolean isFirstInLine) {}

    /**
     * Sets the attribute of an object representation
     *
     * @param objectClassTuple    the object as {@link de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple}
     *                            of which the mirror is to be changed.
     * @param name                The name of the {@link de.unibwm.inf2.bugvis.model.Field}.
     * @param attributeClassTuple the {@link de.unibwm.inf2.bugvis.model.Field}s value as
     *                            {@link de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple}.
     * @param position            {@link de.unibwm.inf2.bugvis.model.Position} of the assignment.
     * @param isFirstInLine       Specifies if this action is the first action in a new line.
     * @param declaringClass      The declaring class of the {@link de.unibwm.inf2.bugvis.model.Field}.
     */
    @Override
    public void fieldAssignment(ObjectClassTuple objectClassTuple, String name, ObjectClassTuple attributeClassTuple,
                                Position position, boolean isFirstInLine, Class<?> declaringClass) {}

    /**
     * Assigns a given objectClassTuple to the static variable with the given name
     *
     * @param name             name of the static field
     * @param staticOf         class this variable is a static of
     * @param objectClassTuple assigned value as {@link de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple}
     * @param position         target position of the assignment
     * @param isFirstInLine    Specifies if this action is the first action in a new line.
     */
    @Override
    public void staticFieldAssignment(String name, Class<?> staticOf, ObjectClassTuple objectClassTuple, Position position, boolean isFirstInLine) {}

    /**
     * Assigns a given value to the local variable with the given name
     *
     * @param name             name of the variable
     * @param objectClassTuple assigned value as {@link de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple}
     * @param position         target position of the assignment
     * @param isFirstInLine    Specifies if this action is the first action in a new line.
     */
    @Override
    public void variableAssignment(String name, ObjectClassTuple objectClassTuple, Position position, boolean isFirstInLine) {}

    // access

    /**
     * A component of an array was accessed.
     *
     * @param array         The array accessed as {@link de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple}.
     * @param index         The index of the accessed component.
     * @param value         The retrieved value.
     * @param position      The {@link de.unibwm.inf2.bugvis.model.Position} of the access expression.
     * @param isFirstInLine Specifies if this action is the first action in a new line.
     */
    @Override
    public void arrayAccess(ObjectClassTuple array, int index, ObjectClassTuple value, Position position, boolean isFirstInLine) {}

    /**
     * A field of an object is about to be accessed.
     *
     * @param objectClassTuple The object holding the field as an
     *                         {@link de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple}.
     * @param fieldName        The name of the field.
     * @param declaringClass   The {@link Class} in which this field was declared.
     * @param position         The {@link de.unibwm.inf2.bugvis.model.Position} of the access expression.
     * @param isFirstInLine    Specifies if this action is the first action in a new line.
     */
    @Override
    public void fieldAccess(ObjectClassTuple objectClassTuple, String fieldName, Class<?> declaringClass, Position position, boolean isFirstInLine) {}

    /**
     * A static field of an object is about to be accessed.
     *
     * @param clazz          The {@link Class} holding the static field.
     * @param fieldName      The name of the field.
     * @param declaringClass The {@link Class} in which this field was declared.
     * @param position       The {@link de.unibwm.inf2.bugvis.model.Position} of the access expression.
     * @param isFirstInLine  Specifies if this action is the first action in a new line.
     */
    @Override
    public void fieldAccess(Class<?> clazz, String fieldName, Class<?> declaringClass, Position position, boolean isFirstInLine) {}
}
