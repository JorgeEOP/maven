package de.unibwm.inf2.bugvis.instr.runtime;

import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.control.DebugControlState;
import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.VarKind;

import java.lang.System.Logger;
import java.util.List;

public class DeclarationRuntimeImpl implements DeclarationRuntime {
    private static final Logger LOGGER = System.getLogger(DeclarationRuntimeImpl.class.getName());
    private static final String TO_STRING = "toString()";

    private final DebugControl control;

    private int toStringCounter;
    private DebugControlState previousState;

    public DeclarationRuntimeImpl(DebugControl control) {
        this.control = control;
    }

    private DebugControlState getState() {
        return control.getControlState();
    }

    // CONSTRUCTORS ////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void constructorEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                   Class<?> clazz, String constructorSignature, List<Parameter> parameters) {
        getState().methodFrameEntered(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                      first,
                                      clazz,
                                      constructorSignature,
                                      null,
                                      parameters);
    }

    @Override
    public void constructorEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                   Class<?> clazz, String constructorSignature) {
        constructorEntered(fileId, lineStart, columnStart, lineEnd, columnEnd, first, clazz, constructorSignature, List.of());
    }

    @Override
    public void constructorEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                   Parameter receiver, String constructorSignature, List<Parameter> parameters) {
        getState().methodFrameEntered(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                      first,
                                      receiver.getClazz(),
                                      constructorSignature,
                                      receiver,
                                      parameters);
    }

    @Override
    public void constructorEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                   Parameter receiver, String constructorSignature) {
        constructorEntered(fileId, lineStart, columnStart, lineEnd, columnEnd, first, receiver, constructorSignature, List.of());
    }

    @Override
    public void leavingConstructor(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                   ObjectClassTuple objectClassTuple, String constructorSignature) {
        getState().frameLeft(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                             first);
    }

    @Override
    public void constructorCall(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                Class<?> clazz, String constructorSignature, List<Parameter> parameters) {
        getState().positionReached(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                   first);
    }

    @Override
    public void constructorCall(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                Class<?> clazz, String constructorSignature) {
        constructorCall(fileId, lineStart, columnStart, lineEnd, columnEnd, first, clazz, constructorSignature, List.of());
    }

    @Override
    public void constructorResult(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                  ObjectClassTuple constructorResult) {
        getState().setReceiverParameter(constructorResult,
                                        new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                        first);
    }

    // METHODS /////////////////////////////////////////////////////////////////////////////////////////////////////////

    // instance method

    @Override
    public void methodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                              Parameter receiver, String methodSignature, List<Parameter> parameters) {
        if (control.getOptions().getExternalDebuggerMode() && methodSignature.equals(TO_STRING) && toStringCounter++ == 0) {
            previousState = getState();
            control.activateDummyState();
        }
        getState().methodFrameEntered(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                      first,
                                      receiver.getClazz(),
                                      methodSignature,
                                      receiver,
                                      parameters);
    }

    @Override
    public void methodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                              Parameter receiver, String methodSignature) {
        methodEntered(fileId, lineStart, columnStart, lineEnd, columnEnd, first, receiver, methodSignature, List.of());
    }

    @Override
    public void leavingMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                              ObjectClassTuple objectClassTuple, String methodSignature) {
        getState().frameLeft(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                             first);
        if (control.getOptions().getExternalDebuggerMode() && methodSignature.equals(TO_STRING) && --toStringCounter == 0) {
            control.setControlState(previousState);
        }
    }

    // static method

    @Override
    public void staticMethodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                    Class<?> clazz, String methodSignature, List<Parameter> parameters) {
        getState().methodFrameEntered(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                      first,
                                      clazz,
                                      methodSignature,
                                      null,
                                      parameters);
    }

    @Override
    public void staticMethodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                    Class<?> clazz, String methodSignature) {
        staticMethodEntered(fileId, lineStart, columnStart, lineEnd, columnEnd, first, clazz, methodSignature, List.of());
    }

    @Override
    public void leavingStaticMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                    Class<?> clazz, String methodSignature) {
        getState().frameLeft(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                             first);
    }

    // instance method in anon class

    @Override
    public void methodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                              Class<?> containingClass, List<Integer> anonymousClassIdentifier, Parameter receiver,
                              String methodSignature, List<Parameter> parameters) {
        getState().methodFrameEntered(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                      first,
                                      containingClass,
                                      methodSignature,
                                      receiver,
                                      parameters);
    }

    @Override
    public void methodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                              Class<?> containingClass, List<Integer> anonymousClassIdentifier, Parameter receiver,
                              String methodSignature) {
        methodEntered(fileId, lineStart, columnStart, lineEnd, columnEnd, first, containingClass,
                      anonymousClassIdentifier, receiver, methodSignature, List.of());
    }

    @Override
    public void leavingMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                              Class<?> containingClass, List<Integer> anonymousClassIdentifier,
                              ObjectClassTuple objectClassTuple, String methodSignature) {
        getState().frameLeft(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                             first);
    }

    // static method in anon class

    @Override
    public void staticMethodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                    Class<?> containingClass, List<Integer> anonymousClassIdentifier,
                                    String methodSignature, List<Parameter> parameters) {
        getState().methodFrameEntered(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                      first,
                                      containingClass,
                                      methodSignature,
                                      null,
                                      parameters);
    }

    @Override
    public void staticMethodEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                    Class<?> containingClass, List<Integer> anonymousClassIdentifier,
                                    String methodSignature) {
        staticMethodEntered(fileId, lineStart, columnStart, lineEnd, columnEnd, first, containingClass,
                            anonymousClassIdentifier, methodSignature, List.of());
    }

    @Override
    public void leavingStaticMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                    Class<?> containingClass, List<Integer> anonymousClassIdentifier,
                                    String methodSignature) {
        getState().frameLeft(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                             first);
    }

    @Override
    public void initializerEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                   ObjectClassTuple receiver) {
        getState().initializerFrameEntered(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                           first,
                                           receiver);
    }

    @Override
    public void leavingInitializer(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first) {
        getState().frameLeft(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                             first);
    }

    @Override
    public void staticInitializerEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                         Class<?> clazz) {
        getState().staticInitializerFrameEntered(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                                 first,
                                                 clazz);
    }

    @Override
    public void leavingStaticInitializer(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first) {
        getState().frameLeft(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                             first);
    }

    // FIELDS //////////////////////////////////////////////////////////////////////////////////////////////////////////

    // field
    @Override
    public void fieldDeclaration(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                 ObjectClassTuple objectClassTuple, String fieldName, String fieldType,
                                 ObjectClassTuple defaultValue, Class<?> declaringClass) {
        getState().fieldDeclaration(objectClassTuple,
                                    fieldType,
                                    fieldName,
                                    defaultValue,
                                    new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                    first,
                                    declaringClass);
    }

    @Override
    public void fieldAssignment(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                ObjectClassTuple objectClassTuple, String fieldName, ObjectClassTuple fieldValue,
                                Class<?> declaringClass) {
        getState().fieldAssignment(objectClassTuple,
                                   fieldName,
                                   fieldValue,
                                   new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                   first,
                                   declaringClass);
    }

    // static field

    @Override
    public void staticFieldDeclaration(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                       Class<?> clazz, String fieldName, String fieldType, ObjectClassTuple defaultValue) {
        getState().staticFieldDeclaration(List.of(VarKind.STATIC, VarKind.FIELD),
                                          fieldType,
                                          fieldName,
                                          new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                          first,
                                          clazz);
    }

    @Override
    public void staticFieldAssignment(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                      Class<?> clazz, String fieldName, ObjectClassTuple fieldValue) {
        getState().staticFieldAssignment(fieldName,
                                         clazz,
                                         fieldValue,
                                         new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                         first);
    }

    // field in anon class

    @Override
    public void fieldDeclaration(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                 Class<?> containingClass, List<Integer> anonymousClassIdentifier,
                                 ObjectClassTuple objectClassTuple, String fieldName, String fieldType,
                                 ObjectClassTuple defaultValue) {
        // TODO: check parent class!
        getState().fieldDeclaration(objectClassTuple,
                                    fieldType,
                                    fieldName,
                                    defaultValue,
                                    new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                    first,
                                    containingClass);
    }

    @Override
    public void fieldAssignment(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                Class<?> containingClass, List<Integer> anonymousClassIdentifier,
                                ObjectClassTuple objectClassTuple, String fieldName, ObjectClassTuple fieldValue) {
        getState().fieldAssignment(objectClassTuple,
                                   fieldName,
                                   fieldValue,
                                   new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                   first,
                                   containingClass);
    }

    // static field in anon class

    @Override
    public void staticFieldDeclaration(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                       Class<?> containingClass, List<Integer> anonymousClassIdentifier,
                                       String fieldName, String fieldType, ObjectClassTuple defaultValue) {
        getState().staticFieldDeclaration(List.of(VarKind.STATIC, VarKind.FIELD),
                                          fieldType,
                                          fieldName,
                                          new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                          first,
                                          containingClass);
    }

    @Override
    public void staticFieldAssignment(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                      Class<?> containingClass, List<Integer> anonymousClassIdentifier, String fieldName,
                                      ObjectClassTuple fieldValue) {
        getState().staticFieldAssignment(fieldName,
                                         containingClass,
                                         fieldValue,
                                         new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                         first);
    }
}
