package de.unibwm.inf2.bugvis.control.logging;

import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.LogRecord;
import java.util.logging.SimpleFormatter;

import static de.unibwm.inf2.bugvis.control.ConsoleSupport.getConsoleErr;
import static de.unibwm.inf2.bugvis.control.ConsoleSupport.getDefaultSystemErr;

public final class BugVisConsoleHandler extends Handler {

    private final Formatter fmt = new SimpleFormatter();
    private final List<String> altPrefixes;

    public BugVisConsoleHandler() {
        String cn = getClass().getName();
        LogManager lm = LogManager.getLogManager();
        String raw = lm.getProperty(cn + ".altPrefixes");
        if (raw != null && !raw.isBlank())
            altPrefixes = Arrays.stream(raw.split(","))
                                .map(String::trim)
                                .filter(s -> !s.isEmpty())
                                .toList();
        else
            altPrefixes = List.of();
        String level = lm.getProperty(cn + ".level");
        if (level != null)
            setLevel(Level.parse(level));
    }

    @Override
    public void publish(LogRecord r) {
        if (!isLoggable(r)) return;

        String name = r.getLoggerName();
        PrintStream ps = altLogger(name, altPrefixes) ? getConsoleErr() : getDefaultSystemErr();
        if (ps == null) ps = getDefaultSystemErr();
        ps.print(fmt.format(r));
        ps.flush();
    }

    @Override
    public void flush() { /* flush at publish */ }

    @Override
    public void close() throws SecurityException {flush();}

    private boolean altLogger(String name, List<String> paths) {
        for (String path : paths)
            if (name != null && (name.equals(path) || name.startsWith(path + ".")))
                return true;
        return false;
    }
}