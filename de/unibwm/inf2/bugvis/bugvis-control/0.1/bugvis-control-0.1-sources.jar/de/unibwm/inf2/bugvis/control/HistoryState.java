package de.unibwm.inf2.bugvis.control;

import de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple;
import de.unibwm.inf2.bugvis.instr.runtime.Parameter;
import de.unibwm.inf2.bugvis.model.Field;
import de.unibwm.inf2.bugvis.model.FieldIdentifier;
import de.unibwm.inf2.bugvis.model.Initializer;
import de.unibwm.inf2.bugvis.model.Method;
import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.StackFrame;
import de.unibwm.inf2.bugvis.model.VarKind;
import de.unibwm.inf2.bugvis.model.Variable;
import de.unibwm.inf2.bugvis.model.history.AssignArrayCmd;
import de.unibwm.inf2.bugvis.model.history.AssignFieldCmd;
import de.unibwm.inf2.bugvis.model.history.AssignStaticFieldCmd;
import de.unibwm.inf2.bugvis.model.history.AssignVariableCmd;
import de.unibwm.inf2.bugvis.model.history.DeclareFieldCmd;
import de.unibwm.inf2.bugvis.model.history.DeclareStaticFieldCmd;
import de.unibwm.inf2.bugvis.model.history.DeclareVariableCmd;
import de.unibwm.inf2.bugvis.model.history.EnterFrameCmd;
import de.unibwm.inf2.bugvis.model.history.ExitFrameCmd;
import de.unibwm.inf2.bugvis.model.history.IntermediateResultCmd;
import de.unibwm.inf2.bugvis.model.history.PositionCommand;
import de.unibwm.inf2.bugvis.model.history.ReceiverParameterCmd;
import de.unibwm.inf2.bugvis.model.history.ReturnCmd;
import de.unibwm.inf2.bugvis.model.notification.debugee.ArrayAssignmentEvent;
import de.unibwm.inf2.bugvis.model.notification.debugee.DebugeeEvent;
import de.unibwm.inf2.bugvis.model.notification.debugee.FieldAssignmentEvent;
import de.unibwm.inf2.bugvis.model.notification.debugee.FrameEnteredEvent;
import de.unibwm.inf2.bugvis.model.notification.debugee.StaticFieldAssignmentEvent;
import de.unibwm.inf2.bugvis.model.value.ReferenceValue;
import de.unibwm.inf2.bugvis.model.value.Value;
import de.unibwm.inf2.bugvis.model.value.VoidValue;

import java.lang.System.Logger;
import java.util.List;

import static java.lang.System.Logger.Level.DEBUG;

public class HistoryState implements DebugControlState {
    private static final Logger LOGGER = System.getLogger(HistoryState.class.getName());

    private final DebugControl debugControl;

    public HistoryState(DebugControl debugControl) {
        this.debugControl = debugControl;
    }

    private boolean stopNecessary(PositionCommand cmd) {return debugControl.stopNecessary(cmd);}

    /**
     * Stops execution of the debugee and transfers control to user interface.
     */
    private void pauseExecution() {debugControl.pauseExecution();}

    /**
     * Executes the given command, adds it to the command history and checks if stop of the debugee is necessary.
     *
     * @param cmd The command to execute and store.
     */
    private void execute(PositionCommand cmd) {
        getState().getHistory().setPendingCommand(cmd);
        cmd.updatePosition();
        if (stopNecessary(cmd))
            pauseExecution();
        cmd.execute();
        getState().getHistory().addCommand(cmd);
    }

    private ProgramState getState() {
        return debugControl.getState();
    }

    private Value getMirrorObject(ObjectClassTuple tuple) {
        return getState().getMirrorObject(tuple);
    }

    private void notifyListeners(DebugeeEvent event) {
        getState().notifyListeners(event);
    }

    // Position reached ////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public void positionReached(Position position, boolean isFirstInLine) {
        final PositionCommand cmd = new PositionCommand(getState(), position, isFirstInLine);
        execute(cmd);
    }

    // Enter and exit StackFrames //////////////////////////////////////////////////////////////////////////////////////

    /**
     * Enters a new {@link de.unibwm.inf2.bugvis.model.Method} {@link de.unibwm.inf2.bugvis.model.StackFrame} with the
     * given {@link de.unibwm.inf2.bugvis.instr.runtime.Parameter}s.
     *
     * @param position          position of the method declaration
     * @param clazz             in which the method is declared
     * @param signature         signature of the called method
     * @param receiverParameter receiver parameter
     * @param parameters        containing the parameters of this method invocation
     */
    @Override
    public void methodFrameEntered(Position position, boolean isFirstInLine, Class<?> clazz, String signature,
                                   ObjectClassTuple receiverParameter, List<Parameter> parameters) {
        frameEntered(new Method(signature, clazz, position.fileId()),
                     position, isFirstInLine, receiverParameter, parameters);
    }

    /**
     * Enters a new {@link de.unibwm.inf2.bugvis.model.Initializer} {@link de.unibwm.inf2.bugvis.model.StackFrame}.
     *
     * @param position          position of the initializer declaration
     * @param receiverParameter receiver parameter
     */
    @Override
    public void initializerFrameEntered(Position position, boolean isFirstInLine, ObjectClassTuple receiverParameter) {
        frameEntered(new Initializer(receiverParameter.getClazz(), position.fileId()),
                     position, isFirstInLine, receiverParameter, List.of());
    }

    /**
     * Enters a new static {@link de.unibwm.inf2.bugvis.model.Initializer} {@link de.unibwm.inf2.bugvis.model.StackFrame}.
     *
     * @param position position of the static initializer declaration
     * @param clazz    in which the initializer is declared
     */
    @Override
    public void staticInitializerFrameEntered(Position position, boolean isFirstInLine, Class<?> clazz) {
        frameEntered(new Initializer(clazz, position.fileId()),
                     position, isFirstInLine, null, List.of());
    }

    private void frameEntered(Method method, Position position, boolean isFirstInLine, ObjectClassTuple receiverParameter,
                              List<Parameter> parameters) {
        final StackFrame sf = new StackFrame(getState().getCallStack(), method, position);
        sf.addParameters(parameters);
        final EnterFrameCmd cmd = new EnterFrameCmd(getState(), sf);
        if (receiverParameter != null)
            cmd.addSubCommand(new ReceiverParameterCmd(getState(), position, isFirstInLine, getMirrorObject(receiverParameter)));
        execute(cmd);
        notifyListeners(new FrameEnteredEvent(receiverParameter, method.getSignature()));
    }

    @Override
    public void frameLeft(Position position, boolean isFirstInLine) {
        execute(new ExitFrameCmd(getState(), position, isFirstInLine));
    }

    // Receiver Parameter //////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public void setReceiverParameter(ObjectClassTuple objectClassTuple, Position position, boolean isFirstInLine) {
        final Value receiverParameter = getMirrorObject(objectClassTuple);
        execute(new ReceiverParameterCmd(getState(), position, isFirstInLine, receiverParameter));
    }

    // Return //////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public void setReturn(ObjectClassTuple objectClassTuple, Position position, boolean isFirstInLine) {
        final Value returnValue = getMirrorObject(objectClassTuple);
        execute(new ReturnCmd(getState(), position, isFirstInLine, returnValue));
    }

    // Method returned /////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public void methodReturned(ObjectClassTuple object, Position position, boolean isFirstInLine, ObjectClassTuple value) {
        if (value != null)
            intermediateResult(position, isFirstInLine, value);
        else
            positionReached(position, isFirstInLine);
    }

    @Override
    public void intermediateResult(Position position, boolean isFirstInLine, ObjectClassTuple value) {
        execute(new IntermediateResultCmd(getState(), position, isFirstInLine, value));
    }

    // Access to, declarations of and assignments to arrays, variables, fields and static fields. //////////////////////

    // declarations

    @Override
    public void fieldDeclaration(ObjectClassTuple objectClassTuple, String type, String name, ObjectClassTuple initialValue,
                                 Position position, boolean isFirstInLine, Class<?> declaringClass) {
        final Value mirrorObject = getMirrorObject(objectClassTuple);
        if (mirrorObject == null || !mirrorObject.isReferenceValue())
            throw new IllegalStateException();
        final ReferenceValue referenceValue = mirrorObject.asReferenceValue();
        final Field field = new Field(List.of(VarKind.FIELD), type, name, getMirrorObject(initialValue),
                                      declaringClass);
        execute(new DeclareFieldCmd(getState(), position, isFirstInLine, referenceValue, field));
    }

    @Override
    public void staticFieldDeclaration(List<VarKind> varKinds, String type, String name, Position position, boolean isFirstInLine,
                                       Class<?> declaringClass) {
        final Field field = new Field(varKinds, type, name, VoidValue.INSTANCE, declaringClass);
        execute(new DeclareStaticFieldCmd(getState(), position, isFirstInLine, field));
    }

    @Override
    public void variableDeclaration(List<VarKind> varKinds, String type, String name, Position position, boolean isFirstInLine) {
        final Variable variable = new Variable(varKinds, type, name);
        execute(new DeclareVariableCmd(getState(), position, isFirstInLine, variable));
    }

    // assignments

    @Override
    public void arrayAssignment(ObjectClassTuple arrayClassTuple, int index, ObjectClassTuple value, Position position, boolean isFirstInLine) {
        final Value arrayValue = getMirrorObject(arrayClassTuple);
        if (!arrayValue.isArrayValue())
            throw new IllegalArgumentException("array value is not an array");
        execute(new AssignArrayCmd(getState(), position, isFirstInLine, arrayValue.asArrayValue(), index, getMirrorObject(value)));
        notifyListeners(new ArrayAssignmentEvent(arrayClassTuple.getObject(), index));
    }

    @Override
    public void fieldAssignment(ObjectClassTuple objectClassTuple, String name, ObjectClassTuple attributeClassTuple,
                                Position position, boolean isFirstInLine, Class<?> declaringClass) {
        final Value mirrorObject = getMirrorObject(objectClassTuple);
        if (mirrorObject == null || !mirrorObject.isReferenceValue())
            throw new IllegalStateException();
        final ReferenceValue referenceValue = mirrorObject.asReferenceValue();
        final FieldIdentifier identifier = new FieldIdentifier(declaringClass, name);
        final Value valueMirrorObject = getMirrorObject(attributeClassTuple);
        execute(new AssignFieldCmd(getState(), position, isFirstInLine, referenceValue, identifier, valueMirrorObject));
        notifyListeners(new FieldAssignmentEvent(objectClassTuple.getObject(), identifier));
    }

    @Override
    public void staticFieldAssignment(String name, Class<?> staticOf, ObjectClassTuple objectClassTuple, Position position, boolean isFirstInLine) {
        final FieldIdentifier identifier = new FieldIdentifier(staticOf, name);
        final Field field = getState().getStaticField(identifier);
        if (field == null)
            throw new IllegalStateException();
        execute(new AssignStaticFieldCmd(getState(), position, isFirstInLine, field, getMirrorObject(objectClassTuple)));
        notifyListeners(new StaticFieldAssignmentEvent(identifier));
    }

    @Override
    public void variableAssignment(String name, ObjectClassTuple objectClassTuple, Position position, boolean isFirstInLine) {
        final Variable variable = getState().getCallStack().getCurrentFrame().getLocalVariable(name);
        if (variable == null)
            throw new IllegalStateException();
        execute(new AssignVariableCmd(getState(), position, isFirstInLine, variable, getMirrorObject(objectClassTuple)));
    }

    // access

    @Override
    public void arrayAccess(ObjectClassTuple array, int index, ObjectClassTuple value, Position position, boolean isFirstInLine) {
        intermediateResult(position, isFirstInLine, value);
    }

    @Override
    public void fieldAccess(ObjectClassTuple objectClassTuple, String fieldName, Class<?> declaringClass,
                            Position position, boolean isFirstInLine) {
        LOGGER.log(DEBUG, () -> "Access to field '" + fieldName + "' from object " +
                                System.identityHashCode(objectClassTuple.getObject()) +
                                " declared in " + declaringClass.getName());
        positionReached(position, isFirstInLine);
    }

    @Override
    public void fieldAccess(Class<?> clazz, String fieldName, Class<?> declaringClass, Position position, boolean isFirstInLine) {
        LOGGER.log(DEBUG, () -> "Access to field '" + fieldName + "' from class " +
                                clazz.getName() +
                                " declared in " + declaringClass.getName());

        positionReached(position, isFirstInLine);
    }
}
