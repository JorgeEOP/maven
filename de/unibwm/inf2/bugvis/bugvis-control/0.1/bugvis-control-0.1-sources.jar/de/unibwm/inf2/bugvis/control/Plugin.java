package de.unibwm.inf2.bugvis.control;

import de.unibwm.inf2.bugvis.model.VisualizationObject;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.ERROR;

public interface Plugin<O, V extends VisualizationObject> {

    abstract class AbstractExtractor<V> {
        private static final String EXCEPTION_OCCURRED = "Unexpected exception occurred";
        private static final Logger LOGGER = System.getLogger(AbstractExtractor.class.getName());

        boolean error = false;

        public void extract(Runnable runnable) {
            try {runnable.run();}
            catch (Exception e) {
                LOGGER.log(ERROR, EXCEPTION_OCCURRED, e);
                error = true;
            }
        }

        protected abstract V create();

        public boolean getError() {return error;}
    }

    boolean isApplicable(Object object);

    V createModel(O origin);

    boolean hasToBeDeleted(Object object, String signature);
}
