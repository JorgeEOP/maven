package de.unibwm.inf2.bugvis.control;

import java.io.InputStream;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class InputStreamCapturer {
    private final Supplier<InputStream> getter;
    private final Consumer<InputStream> setter;
    private final InputStream stream;

    private boolean capture = false;
    private InputStream previousStream;
    private final ReentrantLock lock = new ReentrantLock();

    public InputStreamCapturer(InputStream stream, Supplier<InputStream> getter, Consumer<InputStream> setter) {
        this.stream = stream;
        this.getter = getter;
        this.setter = setter;
    }

    public void startCapture() {
        lock.lock();
        try {
            if (capture) return;

            previousStream = getter.get();
            setter.accept(stream);
            capture = true;
        }
        finally {
            lock.unlock();
        }
    }

    public void endCapture() {
        lock.lock();
        try {
            if (!capture) return;

            setter.accept(previousStream);
            capture = false;
        }
        finally {
            lock.unlock();
        }
    }
}
