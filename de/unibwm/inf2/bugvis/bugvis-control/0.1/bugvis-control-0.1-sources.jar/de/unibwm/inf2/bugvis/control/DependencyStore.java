package de.unibwm.inf2.bugvis.control;

import de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple;
import de.unibwm.inf2.bugvis.model.Field;
import de.unibwm.inf2.bugvis.model.FieldIdentifier;
import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.VisualizationObject;
import de.unibwm.inf2.bugvis.model.value.ReferenceValue;
import de.unibwm.inf2.bugvis.model.value.UnknownFieldException;
import de.unibwm.inf2.bugvis.model.value.Value;

import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import static java.lang.System.identityHashCode;

class DependencyStore {
    private static final List<Object> EMPTY = Collections.emptyList();
    private static final Logger LOGGER = System.getLogger(DependencyStore.class.getName());

    private final DebugControl control;

    /// Array components on which visualized objects depend
    private final Map<ArrayComponentIdentifier, Map<Object, Void>> arrayMap = new HashMap<>();
    /// Fields on which visualized objects depend
    private final Map<ObjectFieldIdentifier, Map<Object, Void>> fieldMap = new HashMap<>();
    /// Static fields on which visualized objects depend
    private final Map<FieldIdentifier, Map<Object, Void>> staticFieldMap = new HashMap<>();
    /// Objects on which visualized objects depend
    private final Map<Object, Map<Object, Void>> objectMap = new IdentityHashMap<>();

    private static <T, O> void add(Map<T, Map<O, Void>> map, O object, T id) {
        map.computeIfAbsent(id, x -> new IdentityHashMap<>()).put(object, null);
    }

    private static <T> List<Object> get(Map<T, Map<Object, Void>> map, T identifier) {
        final Map<Object, Void> idMap = map.get(identifier);
        if (idMap == null) return EMPTY;
        return new ArrayList<>(idMap.keySet());
    }

    private static <T, O> void remove(Map<T, Map<O, Void>> map, O object) {
        final List<T> removeList = new ArrayList<>();
        for (Entry<T, Map<O, Void>> entry : map.entrySet()) {
            entry.getValue().remove(object);
            if (entry.getValue().isEmpty())
                removeList.add(entry.getKey());
        }
        removeList.forEach(map::remove);
    }

    public DependencyStore(DebugControl control) {
        this.control = control;
    }

    <O, V extends VisualizationObject> V updateDependencies(Plugin<O, V> plugin, O object) {
        control.setControlState(new UpdateControlState(object));
        remove(arrayMap, object);
        remove(fieldMap, object);
        remove(staticFieldMap, object);
        remove(objectMap, object);
        control.stopOutErrStreamCapture();
        try {return plugin.createModel(object);}
        finally {
            control.startOutErrStreamCapture();
            control.activateHistoryState();
        }
    }

    List<Object> getDependencies(ArrayComponentIdentifier identifier) {return get(arrayMap, identifier);}

    List<Object> getDependencies(ObjectFieldIdentifier identifier) {return get(fieldMap, identifier);}

    List<Object> getDependencies(FieldIdentifier identifier) {return get(staticFieldMap, identifier);}

    List<Object> getDependencies(Object identifier) {return get(objectMap, identifier);}

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("DependencyStore:\n")
          .append("  arrayMap:\n");
        for (Entry<ArrayComponentIdentifier, Map<Object, Void>> entry : arrayMap.entrySet()) {
            sb.append("\n    ")
              .append(entry.getKey())
              .append(": ");
            for (Object o : entry.getValue().keySet())
                sb.append("\n      ")
                  .append("[")
                  .append(entry.getKey().index())
                  .append("]: ")
                  .append(identityHashCode(o));
        }
        sb.append("\n  fieldMap:\n");
        for (Entry<ObjectFieldIdentifier, Map<Object, Void>> entry : fieldMap.entrySet()) {
            sb.append("\n    ")
              .append(entry.getKey())
              .append(": ");
            for (Object o : entry.getValue().keySet())
                sb.append("\n      ")
                  .append(identityHashCode(o));
        }
        sb.append("\n  staticFieldMap:\n");
        for (Entry<FieldIdentifier, Map<Object, Void>> entry : staticFieldMap.entrySet()) {
            sb.append("\n    ").append(entry.getKey())
              .append(": ");
            for (Object o : entry.getValue().keySet())
                sb.append("\n      ")
                  .append(identityHashCode(o));
        }
        sb.append("\n  objectMap:\n");
        for (Entry<Object, Map<Object, Void>> entry : objectMap.entrySet()) {
            sb.append("\n    ").append(identityHashCode(entry.getKey()))
              .append(": ");
            for (Object o : entry.getValue().keySet())
                sb.append("\n      ")
                  .append(identityHashCode(o));
        }

        return sb.toString();
    }

    private class UpdateControlState extends DebugControlStateAdapter {
        private final Object object;

        UpdateControlState(Object object) {
            this.object = object;
        }

        // TODO: add write-access operations

        // access

        @Override
        public void arrayAccess(ObjectClassTuple array, int index, ObjectClassTuple value, Position position, boolean isFirstInLine) {
            add(arrayMap, object, new ArrayComponentIdentifier(array.getObject(), index));
            add(objectMap, object, value.getObject());
        }

        @Override
        public void fieldAccess(ObjectClassTuple objectClassTuple, String fieldName, Class<?> declaringClass,
                                Position position, boolean isFirstInLine) {
            add(fieldMap, object, new ObjectFieldIdentifier(objectClassTuple.getObject(), declaringClass, fieldName));

            final Value mirrorObject = getState().getMirrorObject(objectClassTuple);
            if (mirrorObject.isReferenceValue()) {
                final ReferenceValue referenceValue = mirrorObject.asReferenceValue();
                try {
                    final Field field = referenceValue.getField(new FieldIdentifier(declaringClass, fieldName));
                    addFieldValueToObjectMap(field);
                }
                catch (UnknownFieldException e) {
                    // do nothing, this happens when objects are being created
                    // and the specified field was not yet declared.
                }
            }
        }

        @Override
        public void fieldAccess(Class<?> clazz, String fieldName, Class<?> declaringClass, Position position, boolean isFirstInLine) {
            add(staticFieldMap, object, new FieldIdentifier(declaringClass, fieldName));

            final Field field = getState().getStaticField(new FieldIdentifier(declaringClass, fieldName));
            addFieldValueToObjectMap(field);
        }

        private void addFieldValueToObjectMap(Field field) {
            final Value value = field.getValue();
            final Object fieldObject = value.getObject();
            if (fieldObject != null && !value.getClazz().isPrimitive())
                add(objectMap, object, fieldObject);
        }

        private ProgramState getState() {return control.getState();}
    }
}
