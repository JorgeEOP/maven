package de.unibwm.inf2.bugvis.control.events;

public interface SelectEventListener {
    void receivedEvent(SelectEvent event);
}
