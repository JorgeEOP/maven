package de.unibwm.inf2.bugvis.control;

import de.unibwm.inf2.bugvis.instr.metainfo.MetaInfo;

import java.io.File;
import java.util.List;

public interface ControlOptions {
    boolean getExternalDebuggerMode();

    MetaInfo getMetaInfo();

    File getOriginalSourceDirectory();

    List<String> getArguments();

    String getDebugeeClassName();

    String getDebugeeMethodSignature();
}
