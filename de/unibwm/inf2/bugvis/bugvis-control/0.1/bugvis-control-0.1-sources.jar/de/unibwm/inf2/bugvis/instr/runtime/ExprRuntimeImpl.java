package de.unibwm.inf2.bugvis.instr.runtime;

import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.control.DebugControlState;
import de.unibwm.inf2.bugvis.model.Position;

import java.lang.System.Logger;
import java.util.List;

import static java.lang.System.Logger.Level.INFO;

public class ExprRuntimeImpl implements ExprRuntime {
    private static final Logger LOGGER = System.getLogger(ExprRuntimeImpl.class.getName());
    private final DebugControl control;

    public ExprRuntimeImpl(DebugControl control) {
        this.control = control;
    }

    private DebugControlState getState() {
        return control.getControlState();
    }

    // OBJECT CREATION EXPRS ///////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public void objectCreation(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                               Class<?> clazz, String constructorSignature, List<ObjectClassTuple> arguments) {
        LOGGER.log(INFO, () -> clazz.getName() + "::" + constructorSignature);
        getState().positionReached(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                   first);
    }

    @Override
    public void objectCreation(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                               Class<?> clazz, String constructorSignature) {
        objectCreation(fileId, lineStart, columnStart, lineEnd, columnEnd, first, clazz, constructorSignature, List.of());
    }

    @Override
    public void objectCreationResult(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd,
                                     boolean first, ObjectClassTuple objectClassTuple) {
        getState().methodReturned(null,
                                  new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                  first,
                                  objectClassTuple);
    }

    // METHOD CALLS ////////////////////////////////////////////////////////////////////////////////////////////////////

    // instance methods

    @Override
    public void callInstanceMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                   ObjectClassTuple object, String methodSignature, List<ObjectClassTuple> arguments) {
        LOGGER.log(INFO, () -> object.getClass().getName() + "::" + methodSignature);
        getState().positionReached(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                   first);
    }

    @Override
    public void callInstanceMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                   ObjectClassTuple object, String methodSignature) {
        callInstanceMethod(fileId, lineStart, columnStart, lineEnd, columnEnd, first, object, methodSignature, List.of());
    }

    // static methods

    @Override
    public void callStaticMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                 Class<?> clazz, String methodSignature, List<ObjectClassTuple> arguments) {
        LOGGER.log(INFO, () -> clazz.getName() + "::" + methodSignature);
        getState().positionReached(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                   first);
    }

    @Override
    public void callStaticMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                 Class<?> clazz, String methodSignature) {
        callStaticMethod(fileId, lineStart, columnStart, lineEnd, columnEnd, first, clazz, methodSignature, List.of());
    }

    // explicit super class method call

    @Override
    public void callInstanceMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                   ObjectClassTuple object, Class<?> clazz, String methodSignature,
                                   List<ObjectClassTuple> arguments) {
        LOGGER.log(INFO, () -> object.getClass().getName() + "::" + methodSignature);
        getState().positionReached(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                   first);
    }

    @Override
    public void callInstanceMethod(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                   ObjectClassTuple object, Class<?> clazz, String methodSignature) {
        callInstanceMethod(fileId, lineStart, columnStart, lineEnd, columnEnd, first, object, clazz, methodSignature,
                           List.of());
    }

    // returned method calls

    // instance methods

    @Override
    public void returnedValue(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                              ObjectClassTuple object, ObjectClassTuple returnValue) {
        LOGGER.log(INFO, () -> "method result: " + System.identityHashCode(returnValue));
        getState().methodReturned(object,
                                  new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                  first,
                                  returnValue);
    }

    @Override
    public void returned(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                         ObjectClassTuple object) {
        LOGGER.log(INFO, () -> "method returned");
        getState().methodReturned(object,
                                  new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                  first,
                                  null);
    }

    // static methods

    @Override
    public void returnedValue(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                              Class<?> clazz, ObjectClassTuple returnValue) {
        getState().methodReturned(null,
                                  new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                  first,
                                  returnValue);
    }

    @Override
    public void returned(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                         Class<?> clazz) {
        getState().methodReturned(null,
                                  new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                  first,
                                  null);
    }

    // LAMBDA EXPRS

    @Override
    public void lambdaEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                              Class<?> clazz, String signature, List<Parameter> parameters) {
        getState().methodFrameEntered(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                      first,
                                      clazz,
                                      signature,
                                      null,
                                      parameters);
    }

    @Override
    public void lambdaEntered(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                              Class<?> clazz, String signature) {
        lambdaEntered(fileId, lineStart, columnStart, lineEnd, columnEnd, first, clazz, signature, List.of());
    }

    @Override
    public void leavingLambda(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                              Class<?> clazz, String signature) {
        getState().frameLeft(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                             first);
    }

    // VARIABLE ////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public void variableDeclaration(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                    String varType, String varName) {
        getState().variableDeclaration(List.of(),
                                       varType,
                                       varName,
                                       new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                       first);
    }

    @Override
    public void variableAssignment(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                   String varName, ObjectClassTuple valueClassTuple) {
        getState().variableAssignment(varName,
                                      valueClassTuple,
                                      new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                      first);
    }

    // FIELD ACCESS ////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public void fieldAccess(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            ObjectClassTuple objectClassTuple, String fieldName, Class<?> declaringClass) {
        getState().fieldAccess(objectClassTuple,
                               fieldName,
                               declaringClass,
                               new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                               first);
    }

    @Override
    public void fieldAccess(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            Class<?> clazz, String fieldName, Class<?> declaringClass) {
        getState().fieldAccess(clazz,
                               fieldName,
                               declaringClass,
                               new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                               first);
    }

    // ARRAYS //////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public void arrayAccess(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                            ObjectClassTuple array, int index, ObjectClassTuple value) {
        LOGGER.log(INFO, () -> "Object array (" + System.identityHashCode(array) + ")[" + index + "]");
        getState().arrayAccess(array,
                               index,
                               value,
                               new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                               first);
    }

    @Override
    public void arrayAssignment(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                ObjectClassTuple arrayClassTuple, int index, String target, ObjectClassTuple value) {
        getState().arrayAssignment(arrayClassTuple,
                                   index,
                                   value,
                                   new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                   first);
    }

    // BINARY OPERATION ////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public void binaryOperation(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                String leftOperand, String operator, String rightOperand, ObjectClassTuple result) {
        getState().intermediateResult(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                      first,
                                      result);
    }

    @Override
    public void instanceOfOperation(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                    String expr, String type, ObjectClassTuple result) {
        getState().intermediateResult(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                      first,
                                      result);
    }

    // UNARY OPERATION /////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public void unaryOperation(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                               String expression, String operator, ObjectClassTuple result) {
        getState().intermediateResult(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                      first,
                                      result);
    }

    @Override
    public void unaryPrefixOperation(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                     String expression, String operator, ObjectClassTuple newValue) {
        getState().intermediateResult(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                      first,
                                      newValue);
    }

    @Override
    public void unaryPostfixOperation(int fileId, int lineStart, int columnStart, int lineEnd, int columnEnd, boolean first,
                                      String expression, String operator,
                                      ObjectClassTuple oldValue, ObjectClassTuple newValue) {
        getState().intermediateResult(new Position(fileId, lineStart, columnStart, lineEnd, columnEnd),
                                      first,
                                      newValue);
    }
}
