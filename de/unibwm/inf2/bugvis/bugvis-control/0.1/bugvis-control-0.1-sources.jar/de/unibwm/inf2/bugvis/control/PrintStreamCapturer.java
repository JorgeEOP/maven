package de.unibwm.inf2.bugvis.control;

import java.io.PrintStream;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class PrintStreamCapturer {
    private final Supplier<PrintStream> getter;
    private final Consumer<PrintStream> setter;
    private final PrintStream stream;

    private boolean capture = false;
    private PrintStream previousStream;
    private final ReentrantLock lock = new ReentrantLock();

    public PrintStreamCapturer(PrintStream stream, Supplier<PrintStream> getter, Consumer<PrintStream> setter) {
        this.stream = stream;
        this.getter = getter;
        this.setter = setter;
    }

    public void startCapture() {
        lock.lock();
        try {
            if (capture) return;

            previousStream = getter.get();
            previousStream.flush();
            setter.accept(stream);
            capture = true;
        }
        finally {
            lock.unlock();
        }
    }

    public void endCapture() {
        lock.lock();
        try {
            if (!capture) return;

            final PrintStream printStream = getter.get();
            printStream.flush();
            setter.accept(previousStream);
            capture = false;
        }
        finally {
            lock.unlock();
        }
    }
}
