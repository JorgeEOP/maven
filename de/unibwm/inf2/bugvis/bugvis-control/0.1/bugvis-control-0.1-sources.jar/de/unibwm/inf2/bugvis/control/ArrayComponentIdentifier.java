package de.unibwm.inf2.bugvis.control;

public record ArrayComponentIdentifier(int idHashCode, int index) {
    public ArrayComponentIdentifier(Object obj, int index) {
        this(System.identityHashCode(obj), index);
    }
}
