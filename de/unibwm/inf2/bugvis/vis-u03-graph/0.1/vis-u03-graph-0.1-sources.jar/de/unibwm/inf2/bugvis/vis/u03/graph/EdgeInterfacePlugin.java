package de.unibwm.inf2.bugvis.vis.u03.graph;

import de.unibwm.inf2.bugvis.control.Plugin;
import uebung.u03.graph.EdgeInterface;

import java.awt.Color;

import static java.awt.Color.RED;

public class EdgeInterfacePlugin implements Plugin<EdgeInterface<?, ?>, EdgeModel> {
    public static final Color EDGE_COLOR = new Color(210, 175, 38);

    @Override
    public boolean isApplicable(Object object) {return object instanceof EdgeInterface<?, ?>;}

    @Override
    public EdgeModel createModel(EdgeInterface<?, ?> edge) {
        class Extractor extends AbstractExtractor<EdgeModel> {
            final String label = String.valueOf(edge.getLength());
            int target;

            public EdgeModel create() {
                extract(() -> target = System.identityHashCode(edge.getTarget()));
                final Color color = getError() ? RED : EDGE_COLOR;
                return new EdgeModel(System.identityHashCode(edge), target, label, color);
            }
        }

        return new Extractor().create();
    }

    @Override
    public boolean hasToBeDeleted(Object object, String signature) {return false;}
}
