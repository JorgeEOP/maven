package de.unibwm.inf2.bugvis.vis.u03.graph;

import de.unibwm.inf2.bugvis.control.Plugin;
import uebung.u03.graph.EdgeInterface;
import uebung.u03.graph.NodeInterface;

import java.awt.Color;
import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.List;

import static java.awt.Color.LIGHT_GRAY;
import static java.awt.Color.RED;
import static java.awt.Color.WHITE;
import static java.awt.Color.YELLOW;
import static java.lang.System.Logger.Level.INFO;

public class NodeInterfacePlugin implements Plugin<NodeInterface<?, ?>, NodeModel> {
    public static final Color ELEGANT_BLUE = new Color(65, 105, 225);
    private static final Logger LOGGER = System.getLogger(NodeInterfacePlugin.class.getName());

    @Override
    public boolean isApplicable(Object object) {return object instanceof NodeInterface<?, ?>;}

    @Override
    public NodeModel createModel(NodeInterface<?, ?> node) {
        class Extractor extends AbstractExtractor<NodeModel> {
            String label = "";
            boolean marked = false;
            List<Integer> outgoing = new ArrayList<>();

            public NodeModel create() {
                extract(() -> marked = node.isMarked());
                extract(() -> {
                    String name = node.getName();
                    if (name != null)
                        label = name;
                });
                extract(() -> {
                    List<? extends EdgeInterface<? extends NodeInterface<?, ?>, ? extends EdgeInterface<?, ?>>> out = node.getOutgoing();
                    if (out != null) {
                        for (Object outgoingEdges : node.getOutgoing())
                            outgoing.add(System.identityHashCode(outgoingEdges));
                    }
                });

                final Color foreground;
                final Color background;
                if (getError()) {
                    foreground = RED;
                    background = YELLOW;
                }
                else if (marked) {
                    foreground = RED;
                    background = LIGHT_GRAY;
                }
                else {
                    foreground = ELEGANT_BLUE;
                    background = WHITE;
                }
                LOGGER.log(INFO, "Creating_Node_Model");
                return new NodeModel(System.identityHashCode(node), outgoing, label, foreground, background);
            }
        }

        return new Extractor().create();
    }

    @Override
    public boolean hasToBeDeleted(Object object, String signature) {return false;}
}
