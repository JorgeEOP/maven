package de.unibwm.inf2.bugvis.vis.u03.graph;

import com.yworks.yfiles.geometry.RectD;
import com.yworks.yfiles.geometry.SizeD;
import com.yworks.yfiles.graph.GraphItemTypes;
import com.yworks.yfiles.graph.IGraph;
import com.yworks.yfiles.graph.ILabel;
import com.yworks.yfiles.graph.INode;
import com.yworks.yfiles.layout.ILayoutAlgorithm;
import com.yworks.yfiles.layout.hierarchic.HierarchicLayout;
import com.yworks.yfiles.view.GraphComponent;
import com.yworks.yfiles.view.input.GraphViewerInputMode;
import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.control.events.SelectEvent;
import de.unibwm.inf2.bugvis.gui.visulization.AbstractYFilesVisualizationPane;
import de.unibwm.inf2.bugvis.model.notification.visualize.VisualizationBigStepEvent;

import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.lang.System.Logger;
import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.CountDownLatch;

import static java.lang.System.Logger.Level.DEBUG;
import static java.lang.System.Logger.Level.INFO;

public class GraphVisualizationPane
        extends AbstractYFilesVisualizationPane
        implements VisualizationEventDispatcher {
    static final Logger LOGGER = System.getLogger(GraphVisualizationPane.class.getName());
    private static final int MIN_WIDTH = 30;
    private static final int NODE_SIZE_DELTA = 5;
    private static final int PANE_WIDTH = 100;
    private static final int PANE_HEIGHT = 100;

    // YFiles Components
    private final GraphComponent graphComponent;
    private final IGraph graph;
    private final ILayoutAlgorithm layoutAlgorithm;

    // event management
    private final Deque<Runnable> smallStepQueue = new ArrayDeque<>();
    private final GraphHandler graphHandler;

    public GraphVisualizationPane(DebugControl control) {
        this(control, new HierarchicLayout());
    }

    public GraphVisualizationPane(DebugControl control, ILayoutAlgorithm layoutAlgorithm) {
        this.layoutAlgorithm = layoutAlgorithm;
        control.addSelectListener(this);
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(PANE_WIDTH, PANE_HEIGHT));
        graphComponent = new GraphComponent();

        final GraphViewerInputMode inputMode = new GraphViewerInputMode();
        inputMode.setToolTipItems(GraphItemTypes.LABEL_OWNER);
        inputMode.setClickableItems(GraphItemTypes.NODE);
        inputMode.setFocusableItems(GraphItemTypes.NODE);
        inputMode.setSelectableItems(GraphItemTypes.NODE);
        inputMode.setMarqueeSelectableItems(GraphItemTypes.NODE);

        graphComponent.setInputMode(inputMode);
        add(graphComponent, BorderLayout.CENTER);
        graph = graphComponent.getGraph();

        graph.addLabelAddedListener((o, e) -> updateNodeSize(e.getItem()));
        graph.addLabelPreferredSizeChangedListener((o, e) -> updateNodeSize(e.getItem()));

        graphHandler = new GraphHandler(this, graph, inputMode);
    }

    @Override
    public GraphComponent getGraphComponent() {
        return graphComponent;
    }

    private void updateNodeSize(ILabel label) {
        final double width = label.getPreferredSize().getWidth() + NODE_SIZE_DELTA;
        SizeD size = new SizeD(MIN_WIDTH, MIN_WIDTH);
        if (width > MIN_WIDTH) size = new SizeD(width, width);
        if (label.getOwner() instanceof INode node)
            graph.setNodeLayout(node, RectD.fromCenter(node.getLayout().getCenter(), size));
    }

    public void startVisualization(EdgeModel edgeModel, CountDownLatch count) {
        processSmallStep(() -> invoke(() -> graphHandler.createNewEdge(edgeModel)), count);
    }

    public void startVisualization(NodeModel nodeModel, CountDownLatch count) {
        processSmallStep(() -> invoke(() -> graphHandler.createNode(nodeModel)), count);
    }

    @Override
    public void stopVisualization(NodeModel nodeModel, CountDownLatch count) {
        processSmallStep(() -> invoke(() -> graphHandler.removeNode(nodeModel)), count);
    }

    @Override
    public void stopVisualization(EdgeModel edgeModel, CountDownLatch count) {
        processSmallStep(() -> invoke(() -> graphHandler.removeEdge(edgeModel)), count);
    }

    @Override
    public void updateVisualization(NodeModel newNodeModel, NodeModel oldNodeModel, CountDownLatch count) {
        processSmallStep(() -> invoke(() -> graphHandler.updateVisualization(newNodeModel, oldNodeModel)), count);
    }

    @Override
    public void updateVisualization(EdgeModel newEdgeModel, EdgeModel oldEdgeModel, CountDownLatch count) {
        processSmallStep(() -> invoke(() -> graphHandler.updateVisualization(newEdgeModel, oldEdgeModel)), count);
    }

    @Override
    public void receivedEvent(VisualizationBigStepEvent event, CountDownLatch count) {
        if (smallStepQueue.isEmpty())
            count.countDown();
        else {
            LOGGER.log(INFO, "visualizationBigStepEvent received, start smallStepQueue ...");
            while (!smallStepQueue.isEmpty())
                smallStepQueue.poll().run();
            LOGGER.log(INFO, "... start smallStepQueue finished");
            applyLayout(count);
        }
    }

    private void processSmallStep(Runnable smallStep, CountDownLatch count) {
        if (getBigStepVisualizations()) {
            smallStepQueue.addLast(smallStep);
            count.countDown();
        }
        else {
            while (!smallStepQueue.isEmpty())
                smallStepQueue.poll().run();
            smallStep.run();
            applyLayout(count);
        }
    }

    private void applyLayout(CountDownLatch count) {
        invoke(() -> {
            LOGGER.log(DEBUG, "apply Layout");
            graphComponent.morphLayout(layoutAlgorithm, Duration.of(100, ChronoUnit.MILLIS), graphHandler.getLayoutData())
                          .thenRun(graphHandler::resetAffectedNodes)
                          .thenRun(count::countDown)
                          .thenRun(() -> LOGGER.log(INFO, "layout applied."));
        });
    }

    @Override
    public void computeLayout() {
        invoke(() -> graph.applyLayout(layoutAlgorithm));
    }

    public ILayoutAlgorithm getLayoutAlgorithm() {
        return layoutAlgorithm;
    }

    @Override
    public void receivedEvent(SelectEvent event) {
        invoke(() -> graphHandler.selectNode(event.getHashCode()));
    }

    private void invoke(Runnable runnable) {SwingUtilities.invokeLater(runnable);}
}
