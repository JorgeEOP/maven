package de.unibwm.inf2.bugvis.vis.u03.graph;

import de.unibwm.inf2.bugvis.model.VisualizationObject;

import java.awt.Color;
import java.util.List;

public class NodeModel implements VisualizationObject {
    private final int hashCode;

    private final List<Integer> outgoing;

    private final String label;
    private final Color backgroundColor;
    private final Color foregroundColor;

    public NodeModel(int hashCode,
                     List<Integer> outgoing,
                     String label,
                     Color foregroundColor,
                     Color backgroundColor) {
        this.hashCode = hashCode;
        this.outgoing = outgoing;
        this.label = label;
        this.backgroundColor = backgroundColor;
        this.foregroundColor = foregroundColor;
    }

    @Override
    public int getHashCode() {
        return hashCode;
    }

    public String getLabel() {
        return label;
    }

    public Color getBackgroundColor() {
        return backgroundColor;
    }

    public Color getForegroundColor() {
        return foregroundColor;
    }

    public List<Integer> getOutgoing() {
        return outgoing;
    }
}
