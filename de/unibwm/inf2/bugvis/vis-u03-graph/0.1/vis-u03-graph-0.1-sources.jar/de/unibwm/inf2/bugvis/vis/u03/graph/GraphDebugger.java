package de.unibwm.inf2.bugvis.vis.u03.graph;

import com.yworks.yfiles.layout.ParallelEdgeRouter;
import com.yworks.yfiles.layout.organic.OrganicLayout;
import com.yworks.yfiles.layout.organic.Scope;
import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.gui.BugVisFrame;
import de.unibwm.inf2.bugvis.gui.options.Options;
import de.unibwm.inf2.bugvis.gui.visulization.VisualizationFrame;

import javax.swing.SwingUtilities;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.System.Logger;
import java.util.logging.LogManager;

import static java.lang.System.Logger.Level.DEBUG;
import static java.lang.System.Logger.Level.ERROR;

public class GraphDebugger {
    public static final String TITLE = "BugVis (U03: Graph)";
    private static final String LOGGING_PROPERTIES = "app-logging.properties";

    static {
        Logger logger;
        try {
            LogManager.getLogManager().readConfiguration(new FileInputStream(LOGGING_PROPERTIES));
            logger = System.getLogger(GraphDebugger.class.getName());
            logger.log(DEBUG, "Successfully read logging properties"); //NON-NLS
        }
        catch (IOException e) {
            logger = System.getLogger(GraphDebugger.class.getName());
            logger.log(ERROR, e::getMessage);
        }
    }

    public static void main(String[] args) {
        final Options options = new Options(args);
        final DebugControl control = new DebugControl(options);
        control.useDefaultInstrumentationRuntime();
        control.getPluginControl().addPlugin(new NodeInterfacePlugin(), new EdgeInterfacePlugin());
        BugVisFrame.initUI();
        SwingUtilities.invokeLater(() -> {
            final BugVisFrame frame = new BugVisFrame(control);
            frame.setTitle(TITLE);
            frame.pack();
            frame.setVisible(true);
            final VisualizationFrame visFrame = new VisualizationFrame(frame);
            visFrame.setTitle(TITLE + " Visualization");

            final OrganicLayout layout = new OrganicLayout();
            final ParallelEdgeRouter parallelLayout = new ParallelEdgeRouter();

            parallelLayout.setJoiningEndsEnabled(true);
            parallelLayout.setLineDistance(50);

            layout.setScope(Scope.MAINLY_SUBSET);
            layout.setParallelEdgeRouter(parallelLayout);

            visFrame.setVisualizationPane(new GraphVisualizationPane(control, layout));
            visFrame.pack();
            visFrame.setVisible(true);
            control.runDebugee();
        });
    }
}