package graph;

import java.util.ArrayList;
import java.util.List;

public class Node implements NodeInterface<Node, Edge> {
    private boolean marked = false;
    private final String name;
    private List<Edge> outgoing;

    public Node(String name, List<Edge> outgoing) {
        this.name = name;
        this.outgoing = outgoing;
    }

    public Node(String name) {this(name, new ArrayList<>());}

    @Override
    public String getName() {return name;}

    @Override
    public List<Edge> getOutgoing() {return outgoing;}

    @Override
    public boolean isMarked() {return marked;}

    public void setMarked(boolean marked) {this.marked = marked;}

    @Override
    public String toString() {
        if (outgoing == null)
            return "";
        StringBuilder str = new StringBuilder();
        str.append(name).append(": [");
        for (int i = 0; i < outgoing.size(); i++) {
            if (i > 0) str.append(", ");
            str.append(outgoing.get(i));
        }
        str.append("]");
        return str.toString();
    }

    public void addEdge(Edge e) {outgoing.add(e);}

    public void setEdges(List<Edge> outgoing) {
        this.outgoing = outgoing;
    }
}
