package graph;

public interface EdgeInterface<N extends NodeInterface<N, E>, E extends EdgeInterface<N, E>> {
    int getLength();

    N getTarget();
}
