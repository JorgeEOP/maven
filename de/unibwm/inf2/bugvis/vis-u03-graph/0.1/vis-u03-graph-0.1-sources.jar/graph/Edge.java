package graph;

public class Edge implements EdgeInterface<Node, Edge> {
    private int length;
    private Node target;

    public Edge(int length, Node target) {
        this.length = length;
        this.target = target;
    }

    @Override
    public int getLength() {return length;}

    @Override
    public Node getTarget() {return target;}

    public void setTarget(Node target) {this.target = target;}

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("-").append(length).append("->");
        if (target != null)
            sb.append(target.getName());
        return sb.toString();
    }
}
