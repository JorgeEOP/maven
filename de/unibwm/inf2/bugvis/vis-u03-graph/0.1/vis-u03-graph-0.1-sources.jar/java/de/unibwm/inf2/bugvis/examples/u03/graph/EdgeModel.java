package de.unibwm.inf2.bugvis.examples.u03.graph;

import de.unibwm.inf2.bugvis.model.VisualizationObject;

import java.awt.Color;

public class EdgeModel implements VisualizationObject {
    private final int hashCode;

    private final String label;
    private final int targetHashCode;
    private final Color color;

    public EdgeModel(int hashCode,
                     int targetHashCode,
                     String label,
                     Color color) {
        this.hashCode = hashCode;
        this.targetHashCode = targetHashCode;
        this.label = label;
        this.color = color;
    }

    @Override
    public int getHashCode() {
        return hashCode;
    }

    public Color getColor() {
        return color;
    }

    public String getLabel() {
        return label;
    }

    public int getTargetHashCode() {
        return targetHashCode;
    }
}
