package uebung.u03.graph;

import java.util.List;

public interface NodeInterface<N extends NodeInterface<N, E>, E extends EdgeInterface<N, E>> {
    String getName();

    List<E> getOutgoing();

    boolean isMarked();
}
