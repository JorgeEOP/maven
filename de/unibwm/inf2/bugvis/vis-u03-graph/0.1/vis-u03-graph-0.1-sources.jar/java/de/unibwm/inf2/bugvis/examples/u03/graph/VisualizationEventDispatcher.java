package de.unibwm.inf2.bugvis.examples.u03.graph;

import de.unibwm.inf2.bugvis.model.VisualizationObject;
import de.unibwm.inf2.bugvis.model.notification.visualize.StartVisualizationEvent;
import de.unibwm.inf2.bugvis.model.notification.visualize.StopVisualizationEvent;
import de.unibwm.inf2.bugvis.model.notification.visualize.UpdateVisualizationEvent;
import de.unibwm.inf2.bugvis.model.notification.visualize.VisualizeEventListener;

import java.util.concurrent.CountDownLatch;

public interface VisualizationEventDispatcher extends VisualizeEventListener {
    @Override
    default void receivedEvent(StartVisualizationEvent ev, CountDownLatch count) {
        final VisualizationObject vo = ev.getVisualizationObject();
        if (vo instanceof NodeModel nm)
            startVisualization(nm, count);
        else if (vo instanceof EdgeModel pm)
            startVisualization(pm, count);
        else
            throw new UnsupportedOperationException("Unsupported event type: " + vo);
    }

    @Override
    default void receivedEvent(StopVisualizationEvent ev, CountDownLatch count) {
        final VisualizationObject vo = ev.getVisualizationObject();
        if (vo instanceof NodeModel nm)
            stopVisualization(nm, count);
        else if (vo instanceof EdgeModel pm)
            stopVisualization(pm, count);
        else
            throw new UnsupportedOperationException("Unsupported event type: " + vo);
    }

    @Override
    default void receivedEvent(UpdateVisualizationEvent ev, CountDownLatch count) {
        final VisualizationObject newVO = ev.getNewVisualizationObject();
        final VisualizationObject oldVO = ev.getOldVisualizationObject();
        if (newVO instanceof NodeModel nm && oldVO instanceof NodeModel om)
            updateVisualization(nm, om, count);
        else if (newVO instanceof EdgeModel nm && oldVO instanceof EdgeModel om)
            updateVisualization(nm, om, count);
        else
            throw new UnsupportedOperationException("Unsupported event types: " + newVO + ", " + oldVO);
    }

    void startVisualization(EdgeModel pm, CountDownLatch count);

    void startVisualization(NodeModel nm, CountDownLatch count);

    void updateVisualization(NodeModel newNodeModel, NodeModel oldNodeModel, CountDownLatch count);

    void updateVisualization(EdgeModel newEdgeModel, EdgeModel oldEdgeModel, CountDownLatch count);

    void stopVisualization(EdgeModel pm, CountDownLatch count);

    void stopVisualization(NodeModel nm, CountDownLatch count);
}
