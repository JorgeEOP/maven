package de.unibwm.inf2.bugvis.examples.u03.graph;

import com.yworks.yfiles.analysis.Reachability;
import com.yworks.yfiles.analysis.Reachability.Result;
import com.yworks.yfiles.geometry.RectD;
import com.yworks.yfiles.graph.IEdge;
import com.yworks.yfiles.graph.IGraph;
import com.yworks.yfiles.graph.INode;
import com.yworks.yfiles.graph.styles.ArcEdgeStyle;
import com.yworks.yfiles.graph.styles.Arrow;
import com.yworks.yfiles.graph.styles.ArrowType;
import com.yworks.yfiles.layout.organic.OrganicLayoutData;
import com.yworks.yfiles.utils.IListEnumerable;
import com.yworks.yfiles.view.Pen;
import com.yworks.yfiles.view.input.GraphViewerInputMode;
import de.unibwm.inf2.bugvis.model.Shape;

import java.lang.System.Logger.Level;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static de.unibwm.inf2.bugvis.examples.u03.graph.EdgeInterfacePlugin.EDGE_COLOR;
import static de.unibwm.inf2.bugvis.examples.u03.graph.GraphVisualizationPane.LOGGER;
import static java.lang.System.Logger.Level.DEBUG;
import static java.lang.System.Logger.Level.INFO;
import static java.lang.System.identityHashCode;

class GraphHandler {
    final List<INode> staticNodes = new ArrayList<>();
    private final IGraph graph;
    // References between HashCode(NodeInterfaces) and INodes
    private final Map<Integer, INode> nodesMap = new HashMap<>();
    // References between HashCodes(EdgeInterfaces) and IEdge
    private final Map<Integer, IEdge> edgesMap = new HashMap<>();
    // References between INodes and bubble-edges (Edges that belong to outgoing edges of a node and are null objects)
    private final Map<INode, List<IEdge>> bubblesMap = new IdentityHashMap<>();
    private final GraphVisualizationPane pane;
    private final OrganicLayoutData layoutData;
    private final GraphViewerInputMode inputMode;

    GraphHandler(GraphVisualizationPane pane, IGraph graph, GraphViewerInputMode inputMode) {
        this.pane = pane;
        this.graph = graph;
        this.inputMode = inputMode;
        this.layoutData = new OrganicLayoutData();
        this.layoutData.setMinimumNodeDistances(30);
        this.layoutData.setPreferredEdgeLengths(40);
    }

    private void updateStyle(NodeModel oldNodeModel, NodeModel newEdgeModel) {
        if (Objects.equals(oldNodeModel.getForegroundColor(), newEdgeModel.getForegroundColor()) &&
            Objects.equals(oldNodeModel.getBackgroundColor(), newEdgeModel.getBackgroundColor())) return;
        final INode iNode = nodesMap.get(newEdgeModel.getHashCode());
        if (iNode == null)
            throw new IllegalArgumentException("Cannot find node with origin: " + newEdgeModel.getHashCode());
        pane.setStyle(iNode, Shape.FANCY20, 1.,
                      newEdgeModel.getForegroundColor(),
                      newEdgeModel.getBackgroundColor());
    }

    /**
     * This method visualizes the outgoing edges that do not exist in the current state of the NodeModel.
     *
     * @param oldNodeModel NodeModel with the current outgoing edges that are visualized
     * @param newNodeModel NodeModel with the outgoing edges for the new visualization
     */
    private void updateOutgoingEdges(NodeModel oldNodeModel, NodeModel newNodeModel) {
        var addedEdges = new ArrayList<>(newNodeModel.getOutgoing());
        oldNodeModel.getOutgoing().forEach(addedEdges::remove);
        var removedEdges = new ArrayList<>(oldNodeModel.getOutgoing());
        newNodeModel.getOutgoing().forEach(removedEdges::remove);

        final INode sourceNode = nodesMap.get(newNodeModel.getHashCode());

        // remove edges that are no longer attached
        for (int remove : removedEdges) {
            IEdge edge = edgesMap.get(remove);
            if (edge == null)
                removeOutgoingNull(sourceNode);
            else
                removeOutgoingEdge(sourceNode, remove);
        }

        // add newly attached edges
        if (sourceNode == null)
            throw new IllegalStateException("Cannot find node with origin: " + newNodeModel.getHashCode());
        for (int add : addedEdges) {
            IEdge addEdge = edgesMap.get(add);
            if (addEdge == null)
                addOutgoingNull(sourceNode);
            else
                addOutgoingEdge(sourceNode, add);
        }
    }

    private void addOutgoingEdge(INode sourceNode, int edge) {
        final IEdge addedIEdge = edgesMap.get(edge);
        if (addedIEdge == null)
            throw new IllegalStateException("Cannot find edge with origin: " + edge);

        setIncrementalAffectedNodes(getReachableNodesFrom(sourceNode));

        graph.createEdge(sourceNode, addedIEdge.getSourceNode());
    }

    private void removeOutgoingEdge(INode sourceNode, int remove) {
        final IEdge iEdge = edgesMap.get(remove);
        if (iEdge == null)
            throw new IllegalArgumentException("Cannot find node with origin: " + remove);
        final IListEnumerable<IEdge> incoming = graph.inEdgesAt(iEdge.getSourceNode());
        if (incoming == null)
            throw new IllegalStateException("Cannot find edge with target: " + iEdge.getSourceNode() + " (incoming is null)");
        final IEdge toDelete = incoming.stream()
                                       .filter(e -> e.getSourceNode() == sourceNode)
                                       .findFirst()
                                       .orElse(null);
        if (toDelete != null)
            graph.remove(toDelete);
        else
            throw new IllegalStateException("Cannot find edge with target: " + iEdge.getTargetNode());
    }

    private void removeOutgoingNull(INode sourceNode) {
        LOGGER.log(INFO, "Removing Bubble edge");
        List<IEdge> bubbles = bubblesMap.get(sourceNode);
        if (bubbles == null || bubbles.isEmpty()) throw new IllegalStateException("Node has no bubble edges");
        graph.remove(bubbles.removeLast().getTargetNode());
        LOGGER.log(INFO, "Bubble edge removed");
    }

    private void addOutgoingNull(INode sourceNode) {
        LOGGER.log(INFO, "Adding Bubble edge");
        bubblesMap.computeIfAbsent(sourceNode, n -> new ArrayList<>())
                  .add(graph.createEdge(sourceNode, createDotNode()));
        LOGGER.log(INFO, "Bubble edge added");
    }

    private void updateNodeLabel(NodeModel oldNodeModel, NodeModel newNodeModel) {
        if (Objects.equals(oldNodeModel.getLabel(), newNodeModel.getLabel())) return;
        LOGGER.log(INFO, "update label for {0} with label {1}.", newNodeModel.getHashCode(), newNodeModel.getLabel());
        final INode iNode = nodesMap.get(newNodeModel.getHashCode());
        if (iNode == null)
            throw new IllegalArgumentException("Cannot find node with origin: " + newNodeModel.getHashCode());
        iNode.getLabels().stream().toList().forEach(graph::remove);
        graph.addLabel(iNode, newNodeModel.getLabel());
        LOGGER.log(INFO, "Label updated.");
    }

    void createNode(NodeModel nodeModel) {
        LOGGER.log(DEBUG, "Create Node for NodeModel: {0} with label {1}", identityHashCode(nodeModel.getHashCode()), nodeModel.getLabel());
        final INode node = graph.createNode();
        pane.setStyle(node, Shape.FANCY20, 1., nodeModel.getForegroundColor(), nodeModel.getBackgroundColor());
        graph.addLabel(node, nodeModel.getLabel());

        setIncrementalAffectedNodes(getReachableNodesFrom(node));

        graph.applyLayout(pane.getLayoutAlgorithm(), layoutData);
        nodesMap.put(nodeModel.getHashCode(), node);
        LOGGER.log(INFO, "Node created. nodesMap::keySet: {0}",
                   nodesMap.keySet().stream().map(System::identityHashCode).toList());
    }

    /**
     * This method only creates edges that are part of an {@code EdgeModel}.
     * The creation of the edges should only take place after receiving the event {@code StartVisualizationEvent}
     * in the method {@code receivedEvent(StartVisualizationEvent, CountDownLatch)}.
     * An Edge created with this method, always has a dotNode as an origin.
     *
     * @param edgeModel model from where to get the Edge information
     */
    void createNewEdge(EdgeModel edgeModel) {
        LOGGER.log(INFO, "Create Edge for Object: {0} with label: {1}", identityHashCode(edgeModel.getHashCode()), edgeModel.getLabel());

        final INode sourceNode = createDotNode();
        final INode tmp = nodesMap.get(edgeModel.getTargetHashCode());
        final INode targetNode = tmp != null ? tmp : createDotNode();

        final ArcEdgeStyle edgeStyle = createArcEdgeStyle(createEdgePen(edgeModel));
        final IEdge iEdge = graph.createEdge(sourceNode, targetNode, edgeStyle);

        graph.addLabel(iEdge, edgeModel.getLabel());
        edgesMap.put(edgeModel.getHashCode(), iEdge);
    }

    private void updateEdgeLabel(EdgeModel oldEdgeModel, EdgeModel newEdgeModel) {
        if (Objects.equals(oldEdgeModel.getLabel(), newEdgeModel.getLabel())) return;
        final IEdge iEdge = edgesMap.get(newEdgeModel.getHashCode());
        if (iEdge == null)
            throw new IllegalStateException("Edge not found for origin: " + newEdgeModel.getHashCode());
        iEdge.getLabels().stream().toList().forEach(graph::remove);
        graph.addLabel(iEdge, newEdgeModel.getLabel());
        LOGGER.log(INFO, "Label updated.");
    }

    private void updateEdgeTarget(EdgeModel oldEdgeModel, EdgeModel newEdgeModel) {
        LOGGER.log(INFO, "Updating edge target");
        final int oldTargetHash = oldEdgeModel.getTargetHashCode();
        final int newTargetHash = newEdgeModel.getTargetHashCode();

        if (oldTargetHash == newTargetHash) return;

        final IEdge iEdge = edgesMap.remove(oldEdgeModel.getHashCode());
        final INode sourceNode = iEdge.getSourceNode();
        final INode oldTargetNode = iEdge.getTargetNode();
        graph.remove(iEdge);
        final INode newTargetNode;
        if (oldTargetHash == 0) {
            // edge without a real target got a real target
            graph.remove(oldTargetNode);
            newTargetNode = nodesMap.get(newTargetHash);
        }
        else if (newTargetHash == 0) {
            // edge with a real target got a pseudo target
            newTargetNode = createDotNode();
        }
        else {
            // edge with a real target got a new real target
            newTargetNode = nodesMap.get(newTargetHash);
        }
        final ArcEdgeStyle edgeStyle = createArcEdgeStyle(createEdgePen(newEdgeModel));

        setIncrementalAffectedNodes(getReachableNodesFrom(newTargetNode));

        final IEdge updatedEdge = graph.createEdge(sourceNode, newTargetNode, edgeStyle);

        graph.addLabel(updatedEdge, newEdgeModel.getLabel());
        edgesMap.put(newEdgeModel.getHashCode(), updatedEdge); //update edgesMap
    }

    private INode createDotNode() {
        final RectD dotRectD = new RectD(10d, 10d, 5d, 5d); // a very small node
        INode node = graph.createNode(dotRectD);

        setIncrementalAffectedNodes(getReachableNodesFrom(node));

        return node;
    }

    private List<INode> getReachableNodesFrom(INode node) {
        final List<INode> reachableNodes = new ArrayList<>();
        final Reachability reachability = new Reachability();
        reachability.setDirected(false);
        reachability.setStartNodes(node);
        final Result result = reachability.run(graph);
        result.getReachableNodes().forEach(reachableNodes::add);
        return reachableNodes;
    }

    private void setIncrementalAffectedNodes(List<INode> nodes) {
        staticNodes.addAll(nodes);
        layoutData.setAffectedNodes(staticNodes);
    }

    private Pen createEdgePen(EdgeModel edgeModel) {
        final Pen edgePen = new Pen();
        edgePen.setPaint(edgeModel.getColor());
        edgePen.setThickness(2);
        return edgePen;
    }

    private ArcEdgeStyle createArcEdgeStyle(Pen pen) {
        final ArcEdgeStyle arcEdgeStyle = new ArcEdgeStyle();
        arcEdgeStyle.setTargetArrow(new Arrow(ArrowType.SHORT, pen, pen.getPaint()));
        arcEdgeStyle.setSourceArrow(new Arrow(ArrowType.CIRCLE, pen, EDGE_COLOR, 1, 0.9));
        arcEdgeStyle.setPen(pen);
        return arcEdgeStyle;
    }

    void removeNode(NodeModel nodeModel) {
        LOGGER.log(INFO, "Remove Node for " + identityHashCode(nodeModel));
        INode iNode = nodesMap.remove(nodeModel.getHashCode());
        if (iNode != null && graph.contains(iNode))
            graph.remove(iNode);
        else
            LOGGER.log(Level.INFO, "Node for given object not found!");
    }

    void removeEdge(EdgeModel edgeModel) {
        LOGGER.log(INFO, "Stopping visualization of: {0}", identityHashCode(edgeModel));
        LOGGER.log(INFO, "Remove Edge with id: ( {0} ) ", identityHashCode(edgeModel));
        final IEdge iEdge = edgesMap.get(edgeModel.getHashCode());
        if (iEdge == null)
            throw new IllegalStateException("Edge not found for " + identityHashCode(edgeModel));
        final INode sourceNode = iEdge.getSourceNode();
        final INode targetNode = iEdge.getTargetNode();
        graph.remove(iEdge);

        if (!nodesMap.containsKey(edgeModel.getTargetHashCode()))
            graph.remove(targetNode);

        graph.remove(sourceNode);
        edgesMap.remove(edgeModel.getHashCode());
    }

    void updateVisualization(NodeModel newNodeModel, NodeModel oldNodeModel) {
        LOGGER.log(INFO, "Updating visualization of: {0} with id: {1}", oldNodeModel, identityHashCode(oldNodeModel));
        LOGGER.log(INFO, "oldNodeModel original: ( {0} ) ; newOldModel original: ( {1} )", oldNodeModel.getLabel(), oldNodeModel.getLabel());
        updateStyle(oldNodeModel, newNodeModel);
        updateOutgoingEdges(oldNodeModel, newNodeModel);
        updateNodeLabel(oldNodeModel, newNodeModel);
        LOGGER.log(DEBUG, "... visualization update finished");
    }

    void updateVisualization(EdgeModel newEdgeModel, EdgeModel oldEdgeModel) {
        LOGGER.log(INFO, "Updating visualization of: {0} with id: {1}", oldEdgeModel, identityHashCode(oldEdgeModel));
        updateEdgeTarget(oldEdgeModel, newEdgeModel);
        updateEdgeLabel(oldEdgeModel, newEdgeModel);
    }

    void selectNode(int hashCode) {
        final INode node = nodesMap.get(hashCode);
        if (node == null) return;
        for (INode n : nodesMap.values())
            inputMode.setSelected(n, false);
        inputMode.setSelected(node, true);
    }

    public OrganicLayoutData getLayoutData() {
        return layoutData;
    }

    public void resetAffectedNodes() {
        staticNodes.clear();
    }
}
