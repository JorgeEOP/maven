package de.unibwm.inf2.bugvis.gui.rsyntaxtextarea;

import de.unibwm.inf2.bugvis.instr.metainfo.FileMetaInfo;
import org.fife.ui.rsyntaxtextarea.FileLocation;

import java.io.IOException;

public class MetaInfoBookmarkedTextEditorPane extends BookmarkedTextEditorPane {

    private final FileMetaInfo fileMetaInfo;

    public MetaInfoBookmarkedTextEditorPane(int textMode, boolean wordWrapEnabled, FileLocation loc, FileMetaInfo fileMetaInfo)
            throws IOException {
        super(textMode, wordWrapEnabled, loc);
        this.fileMetaInfo = fileMetaInfo;
    }

    @Override
    public boolean isBookmarkAllowed(int line) {return fileMetaInfo.inBreakpointRange(line + 1);}
}
