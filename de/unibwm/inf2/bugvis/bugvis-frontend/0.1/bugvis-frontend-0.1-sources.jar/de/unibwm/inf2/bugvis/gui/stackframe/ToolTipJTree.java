package de.unibwm.inf2.bugvis.gui.stackframe;

import javax.swing.JTree;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import java.awt.event.MouseEvent;
import java.util.Hashtable;
import java.util.Vector;

public class ToolTipJTree extends JTree {

    public ToolTipJTree() {super();}

    public ToolTipJTree(Object[] value) {super(value);}

    public ToolTipJTree(Vector<?> value) {super(value);}

    public ToolTipJTree(Hashtable<?, ?> value) {super(value);}

    public ToolTipJTree(TreeNode root) {super(root);}

    public ToolTipJTree(TreeNode root, boolean asksAllowsChildren) {super(root, asksAllowsChildren);}

    public ToolTipJTree(TreeModel model) {super(model);}

    @Override
    public String getToolTipText(MouseEvent e) {
        final TreePath pathForLocation = getPathForLocation(e.getX(), e.getY());
        if (pathForLocation != null && pathForLocation.getLastPathComponent() instanceof ToolTipAble toolTipAble)
            return toolTipAble.getToolTipText();
        return super.getToolTipText(e);
    }
}
