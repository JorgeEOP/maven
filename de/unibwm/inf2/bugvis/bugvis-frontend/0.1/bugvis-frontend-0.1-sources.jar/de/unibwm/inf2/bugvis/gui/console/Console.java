package de.unibwm.inf2.bugvis.gui.console;

import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.model.history.OutputStreamCmd.OutputType;

import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;

public class Console extends JPanel {
    private static final Logger LOGGER = System.getLogger(Console.class.getName());
    private static final String NEW_LINE_REG_EX = "\\n|\\r\\n|\\n\\r";

    private final DebugControl debugControl;
    private final ConsoleLogModel model;
    private final JTextField inputField;

    public Console(DebugControl debugControl) {
        this.debugControl = debugControl;
        setLayout(new BorderLayout());
        model = new ConsoleLogModel();
        final JList<StyledLine> jList = setUpConsoleJList();
        final JScrollPane scrollPane = new JScrollPane(jList);
        setUpAutoScroller(scrollPane);
        add(scrollPane, BorderLayout.CENTER);
        inputField = setUpInputField();
    }

    private JList<StyledLine> setUpConsoleJList() {
        JList<StyledLine> jList = new JList<>(model);
        jList.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        jList.setCellRenderer(new StyledLineRenderer());
        jList.setFixedCellHeight(jList.getFontMetrics(jList.getFont()).getHeight());
        return jList;
    }

    private void setUpAutoScroller(JScrollPane scrollPane) {
        final AutoScroller autoScroller = new AutoScroller(scrollPane);
        model.addListDataListener(new ListDataListener() {
            @Override
            public void intervalAdded(ListDataEvent e) {autoScroller.onModelChanged();}

            @Override
            public void intervalRemoved(ListDataEvent e) {autoScroller.onModelChanged();}

            @Override
            public void contentsChanged(ListDataEvent e) {autoScroller.onModelChanged();}
        });
    }

    private JTextField setUpInputField() {
        final JTextField textField = new JTextField();
        textField.setForeground(Color.green.darker().darker());
        textField.setFont(textField.getFont().deriveFont(Font.ITALIC).deriveFont(Font.BOLD));
        textField.addActionListener(this::processInput);
        add(textField, BorderLayout.SOUTH);
        return textField;
    }

    private void processInput(ActionEvent actionEvent) {
        final Object source = actionEvent.getSource();
        if (source == inputField) {
            final String input = inputField.getText().trim() + System.lineSeparator();
            debugControl.writeToInputStream(input);
            SwingUtilities.invokeLater(() -> {
                inputField.setText("");
                inputField.setBackground(Color.WHITE);
            });
        }
    }

    public void highlightInput() {invoke(() -> inputField.setBackground(Color.YELLOW.brighter()));}

    public void addText(String text, OutputType outputType) {
        LOGGER.log(Level.DEBUG, () -> text.length() + " : " + text);
        model.appendChunk(new StyledLine(text, outputType));
    }

    public void deleteTextAtEnd(String text) {
        final int length = text.replaceAll(NEW_LINE_REG_EX, "").length();
        model.truncateTailChars(length);
    }

    private void invoke(Runnable r) {SwingUtilities.invokeLater(r);}
}
