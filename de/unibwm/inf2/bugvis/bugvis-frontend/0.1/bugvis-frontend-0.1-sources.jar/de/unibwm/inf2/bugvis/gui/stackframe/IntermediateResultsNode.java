package de.unibwm.inf2.bugvis.gui.stackframe;

import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.StackFrame;
import de.unibwm.inf2.bugvis.model.value.Value;

import javax.swing.tree.TreeNode;
import java.util.List;

public class IntermediateResultsNode extends InnerNode {
    private static final String INTERMEDIATE_RESULTS = "Intermediate results";
    private final StackFrame frame;

    public IntermediateResultsNode(StackFrame frame) {
        super(INTERMEDIATE_RESULTS, INTERMEDIATE_RESULTS, null);
        this.frame = frame;
    }

    @Override
    public int getChildCount() {
        return frame.getIntermediateResults().size();
    }

    void fill(List<TreeNode> children) {
        frame.getIntermediateResults().keySet().stream()
             .sorted(Position.COMPARATOR)
             .forEach(p -> children.add(getIntermediateResult(p).accept(
                     new TreeNodeValueVisitor(null, this) {
                         @Override
                         protected String prefix() {
                             return String.format("{%d:(%d,%d)-(%d,%d)}=",
                                                  p.fileId(), p.firstLine(), p.firstCol(), p.lastLine(), p.lastCol());
                         }
                     })));
    }

    private Value getIntermediateResult(Position position) {
        return frame.getIntermediateResults().get(position);
    }
}
