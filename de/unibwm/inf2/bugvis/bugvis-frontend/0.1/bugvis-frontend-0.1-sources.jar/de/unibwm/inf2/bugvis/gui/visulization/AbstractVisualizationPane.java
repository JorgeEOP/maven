package de.unibwm.inf2.bugvis.gui.visulization;

import de.unibwm.inf2.bugvis.gui.BugVisToolbar;

public abstract class AbstractVisualizationPane extends VisualizationPane {
    public void addControls(BugVisToolbar toolBar) {}
}
