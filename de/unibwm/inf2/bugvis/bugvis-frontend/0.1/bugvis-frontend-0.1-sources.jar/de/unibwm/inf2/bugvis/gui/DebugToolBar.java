package de.unibwm.inf2.bugvis.gui;

import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.control.SteppingKind;
import de.unibwm.inf2.bugvis.gui.codeview.CodeView;

import javax.swing.JComboBox;
import java.lang.System.Logger.Level;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.function.Consumer;

import static de.unibwm.inf2.bugvis.control.SteppingKind.RESUME;
import static de.unibwm.inf2.bugvis.control.SteppingKind.STEP_INSTRUCTION;
import static de.unibwm.inf2.bugvis.control.SteppingKind.STEP_INTO;
import static de.unibwm.inf2.bugvis.control.SteppingKind.STEP_OUT;
import static de.unibwm.inf2.bugvis.control.SteppingKind.STEP_OVER;
import static java.text.MessageFormat.format;

/**
 * The debugger's main toolbar.
 */
public class DebugToolBar extends BugVisToolbar {
    private final BugVisFrame bugvisFrame;
    private final DebugPanel debugPanel;

    /**
     * Constructs a new GuiControlPanel with the specified debugging control.
     *
     * @param bugvisFrame the BugVis frame
     */
    public DebugToolBar(BugVisFrame bugvisFrame, DebugPanel debugPanel) {
        setFloatable(false);
        this.bugvisFrame = bugvisFrame;
        this.debugPanel = debugPanel;
        initButtons();
    }

    private DebugControl getControl() {
        return bugvisFrame.getControl();
    }

    /**
     * Initializes and sets up the buttons.
     */
    public void initButtons() {
        addButtons(getControl()::forward, "f");
        addSeparator();
        addButtons(getControl()::backward, "b");
        addSeparator();
        // TODO: following four lines are for debugging purposes only, remove before release
        addButton("History", null, e -> System.out.println(bugvisFrame.getControl().getHistory().toString()));
        addSeparator();
        addButton("DepStore", null, e -> System.out.println(bugvisFrame.getControl().getPluginControl().getDependencyStore()));
        addSeparator();
        addHighlightControl();
    }

    /**
     * Adds a set of stepping buttons to the specified panel.
     * <p>
     * The buttons added are "Resume", "Step Into", "Step Over", and "Step Out", each
     * invoking the given action with the corresponding {@link SteppingKind}.
     *
     * @param action the action to be executed when a button is pressed.
     * @param name
     */
    private void addButtons(Consumer<SteppingKind> action, String name) {
        addButton(format("Resume ({0})", name), format("/img/resume_{0}.png", name), e -> execute(action, RESUME));
        addButton(format("Step Instruction ({0})", name), format("/img/step_instr_{0}.png", name), e -> execute(action, STEP_INSTRUCTION));
        addButton(format("Step Into ({0})", name), format("/img/step_in_{0}.png", name), e -> execute(action, STEP_INTO));
        addButton(format("Step Over ({0})", name), format("/img/step_over_{0}.png", name), e -> execute(action, STEP_OVER));
        addButton(format("Step Out ({0})", name), format("/img/step_out_{0}.png", name), e -> execute(action, STEP_OUT));
    }

    /**
     * Executes the specified stepping action asynchronously.
     * <p>
     * This method disables the control buttons, submits the stepping action to an executor,
     * and schedules a task to re-enable the buttons when the action has finished.
     *
     * @param action the stepping action to be executed.
     * @param step   the kind of stepping to perform.
     */
    private void execute(Consumer<SteppingKind> action, SteppingKind step) {
        enableControl(false);
        final Future<?> future = getControl().getExecutor().submit(() -> action.accept(step));
        getControl().getExecutor().execute(() -> enableWhenFinished(future));
    }

    /**
     * Waits for the given future to complete and then re-enables the control buttons.
     * <p>
     * If the waiting is interrupted or an execution error occurs, an error is logged
     * and a {@link RuntimeException} is thrown.
     *
     * @param future the Future representing the asynchronous stepping action.
     */
    private void enableWhenFinished(Future<?> future) {
        try {
            future.get();
        }
        catch (InterruptedException | ExecutionException e) {
            LOGGER.log(Level.ERROR, "Wait was interrupted", e);
            throw new RuntimeException(e);
        }
        enableControl(true);
    }

    private void addHighlightControl() {
        final String[] choices = {"Instruction Highlighting", "Line Highlighting"};
        final JComboBox<String> highlightComboBox = new JComboBox<>(choices);
        highlightComboBox.setMaximumSize(highlightComboBox.getPreferredSize());
        highlightComboBox.setEditable(false);
        final CodeView codeView = debugPanel.getCodeView();
        highlightComboBox.setSelectedIndex(codeView.isInstructionHighlighting() ? 0 : 1);
        highlightComboBox.addActionListener(e -> {
            final boolean instructionHighlighting = highlightComboBox.getSelectedIndex() == 0;
            codeView.setInstructionHighlighting(instructionHighlighting);
        });
        add(highlightComboBox);
    }
}
