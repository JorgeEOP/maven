package de.unibwm.inf2.bugvis.gui;

import de.unibwm.inf2.bugvis.instr.metainfo.FileMetaInfo;
import de.unibwm.inf2.bugvis.model.Method;
import de.unibwm.inf2.bugvis.model.StackFrame;

import java.util.Objects;

public record StackFrameProxy(StackFrame frame, DebugPanel debugPanel) {

    public StackFrameProxy(StackFrame frame, DebugPanel debugPanel) {
        this.frame = Objects.requireNonNull(frame);
        this.debugPanel = debugPanel;
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("<html>");
        final Method method = frame.getMethod();
        if (method == null)
            stringBuilder.append("<b>-</b>");
        else {
            final String className = method.getClassName();
            if (className.isEmpty())
                stringBuilder.append(getRelativeFilePath());
            else
                stringBuilder.append(className);
            stringBuilder.append("::<b>")
                         .append(method.getSignature()).append("</b>");
        }
        stringBuilder.append("<font color='gray'>: ").append(frame.getPosition().firstLine());
        stringBuilder.append("</font></html>>");
        return stringBuilder.toString();
    }

    private String getRelativeFilePath() {
        final FileMetaInfo fileMetaInfo = debugPanel.getControl().getMetaInfo().getFileMetaInfo(frame.getPosition().fileId());
        return fileMetaInfo.getRelativeFilePath();
    }
}
