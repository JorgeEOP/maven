package de.unibwm.inf2.bugvis.gui.console;

import javax.swing.BoundedRangeModel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

public class AutoScroller {

    private final JScrollBar verticalBar;

    private final Timer timer;
    private final Timer retryTimer;

    private volatile boolean followTail = true;
    private volatile boolean pending = false;
    private volatile boolean internalScroll = false;

    public AutoScroller(JScrollPane scrollPane) {
        this.verticalBar = scrollPane.getVerticalScrollBar();

        this.timer = new Timer(40, e -> flush());
        this.timer.setRepeats(false);

        this.retryTimer = new Timer(60, e -> retry());
        this.retryTimer.setRepeats(false);

        verticalBar.addAdjustmentListener(e -> {
            if (internalScroll)
                return;

            BoundedRangeModel m = verticalBar.getModel();
            boolean atBottom = isAtBottom(m);

            if (e.getValueIsAdjusting()) {
                if (!atBottom)
                    followTail = false;
            }
            else if (atBottom)
                followTail = true;
        });
    }

    public void onModelChanged() {
        if (!followTail)
            return;
        pending = true;
        if (!timer.isRunning())
            timer.start();
    }

    public void setFollowTail(boolean followTail) {
        this.followTail = followTail;
        if (followTail) {
            pending = true;
            if (!timer.isRunning())
                timer.start();
        }
    }

    public boolean isFollowingTail() {return followTail;}

    private void flush() {
        if (!pending || !followTail)
            return;
        pending = false;
        scrollNow();
        if (!retryTimer.isRunning())
            retryTimer.start();
    }

    private void retry() {
        if (!followTail)
            return;
        scrollNow();
    }

    private void scrollNow() {
        SwingUtilities.invokeLater(() -> {
            try {
                internalScroll = true;
                BoundedRangeModel m = verticalBar.getModel();
                m.setValue(m.getMaximum());
            }
            finally {
                internalScroll = false;
            }
        });
    }

    private boolean isAtBottom(BoundedRangeModel m) {return m.getValue() + m.getExtent() >= m.getMaximum() - 8;}
}