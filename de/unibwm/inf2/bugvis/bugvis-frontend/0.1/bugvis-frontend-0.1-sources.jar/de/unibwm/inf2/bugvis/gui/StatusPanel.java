package de.unibwm.inf2.bugvis.gui;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.text.MessageFormat;

public class StatusPanel extends JPanel {

    private static final String BLACK = "black";
    private static final String GREEN = "green";
    private static final String RED = "red";
    private static final String EXECUTION_FINISHED = "Execution finished.";
    private static final String EXECUTION_NOT_FINISHED = "Execution not finished.";
    private static final String EXCEPTION_STOPPED_EXECUTION = "Exception stopped execution.";
    private static final String FONT_COLOR = "<font color=''{0}''>{1}</font>";

    private final JLabel statusLabel;
    private final JLabel commandLabel;

    public StatusPanel() {
        setLayout(new BorderLayout());
        statusLabel = new JLabel(" ");
        commandLabel = new JLabel("Command: 0 / 0");

        this.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, Color.BLACK));
        add(statusLabel, BorderLayout.WEST);
        add(commandLabel, BorderLayout.EAST);
    }

    public void updateCommandLabel(int current, int count, boolean finished, boolean exception) {
        commandLabel.setText(MessageFormat.format("<html>Command: {0} / {1} ({2})</html>",
                                                  current, count, getMessage(finished, exception)));
    }

    private String getMessage(boolean finished, boolean exception) {
        if (exception) return colorString(RED, EXCEPTION_STOPPED_EXECUTION);
        if (finished) return colorString(GREEN, EXECUTION_FINISHED);
        return colorString(BLACK, EXECUTION_NOT_FINISHED);
    }

    private String colorString(String color, String text) {return MessageFormat.format(FONT_COLOR, color, text);}

    public void setStatus(String status) {statusLabel.setText(status);}
}
