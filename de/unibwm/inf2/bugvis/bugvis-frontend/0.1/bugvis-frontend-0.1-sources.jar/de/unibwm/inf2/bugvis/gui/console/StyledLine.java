package de.unibwm.inf2.bugvis.gui.console;

import de.unibwm.inf2.bugvis.model.history.OutputStreamCmd.OutputType;

public record StyledLine(String text, OutputType outputType) {}
