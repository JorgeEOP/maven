package de.unibwm.inf2.bugvis.gui.codeview;

import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.gui.DebugPanel;
import de.unibwm.inf2.bugvis.gui.rsyntaxtextarea.MetaInfoBookmarkedTextEditorPane;
import de.unibwm.inf2.bugvis.instr.metainfo.FileMetaInfo;
import de.unibwm.inf2.bugvis.model.Breakpoint;
import de.unibwm.inf2.bugvis.model.LineBreakpoint;
import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.StackFrame;
import de.unibwm.inf2.bugvis.model.value.Value;
import org.fife.ui.rsyntaxtextarea.FileLocation;
import org.fife.ui.rsyntaxtextarea.SyntaxConstants;
import org.fife.ui.rtextarea.Gutter;
import org.fife.ui.rtextarea.RTextArea;
import org.fife.ui.rtextarea.RTextScrollPane;

import javax.swing.ImageIcon;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.ToolTipManager;
import javax.swing.text.BadLocationException;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/**
 * A code view panel that displays and manages source code files during debugging.
 * <p>
 * This class extends {@link JTabbedPane} and provides functionality for:
 * <ul>
 *     <li>Opening source code files</li>
 *     <li>Displaying syntax-highlighted code</li>
 *     <li>Managing breakpoints and highlighting lines</li>
 * </ul>
 * It listens for breakpoint-related events and updates the UI accordingly.
 * </p>
 */
public class CodeView extends JTabbedPane {
    private static final Logger LOGGER = System.getLogger(CodeView.class.getName());
    private static final ImageIcon BOOKMARK_ICON = new ImageIcon(CodeView.class.getResource("/img/bp-icon.png"));
    private static final Color HIGHLIGHT_COLOR = Color.yellow;
    private static final Color INTERMEDIATE_COLOR = new Color(224, 224, 224);
    private static final Cursor HAND_CURSOR = Cursor.getPredefinedCursor(Cursor.HAND_CURSOR);
    private static final Cursor DEFAULT_CURSOR = Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR);

    private final DebugControl control;
    private final DebugPanel debugPanel;
    private final Highlighter lineHighlighter = new LineHighlighter(this, HIGHLIGHT_COLOR);
    private final Highlighter instructionHighlighter = new RangeHighlighter(this, HIGHLIGHT_COLOR);
    private final Highlighter intermediateHighlighter = new RangeHighlighter(this, INTERMEDIATE_COLOR);
    private final Map<Integer, RTextScrollPane> paneMap = new HashMap<>();

    private Highlighter highlighter = lineHighlighter;

    /**
     * Constructs a {@code CodeView} instance.
     *
     * @param control The debug control managing breakpoints and execution.
     */
    public CodeView(DebugControl control, DebugPanel debugPanel) {
        this.control = control;
        this.debugPanel = debugPanel;
    }

    // SRC FILE ///////////////////////////////////////////////////////////////

    /**
     * Opens a source file in the code editor.
     *
     * @param fileMetaInfo The metadata information of the file to be opened.
     */
    public void openFile(FileMetaInfo fileMetaInfo) {
        if (!paneMap.containsKey(fileMetaInfo.getFileId()))
            displaySrc(fileMetaInfo);
        final RTextScrollPane currentPane = paneMap.get(fileMetaInfo.getFileId());
        if (currentPane != null)
            setSelectedComponent(currentPane);
    }

    /**
     * Checks whether a file exists and is readable.
     *
     * @param src The file to check.
     * @return {@code true} if the file exists and is readable, {@code false} otherwise.
     */
    private static boolean isReadableFile(File src) {
        return src.isFile() && src.canRead();
    }

    /**
     * Loads and displays a source file in the editor.
     *
     * @param fileMetaInfo The metadata information of the file.
     */
    private void displaySrc(FileMetaInfo fileMetaInfo) {
        final File src = new File(control.getOptions().getOriginalSourceDirectory(),
                                  fileMetaInfo.getRelativeFilePath());
        if (!isReadableFile(src))
            return;
        final FileLocation fileLocation = FileLocation.create(src);
        final MetaInfoBookmarkedTextEditorPane txtArea;
        try {
            txtArea = new MetaInfoBookmarkedTextEditorPane(RTextArea.INSERT_MODE, false, fileLocation, fileMetaInfo);
        }
        catch (IOException e) {
            LOGGER.log(Level.INFO, e);
            return;
        }
        ToolTipManager.sharedInstance().registerComponent(txtArea);
        txtArea.setEditable(false);
        txtArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_JAVA);
        txtArea.setHighlightCurrentLine(false);
        final RTextScrollPane scrollPane = new RTextScrollPane(txtArea);
        scrollPane.setIconRowHeaderEnabled(true);
        final Gutter gutter = scrollPane.getGutter();
        gutter.setBookmarkingEnabled(true);
        gutter.setBookmarkIcon(BOOKMARK_ICON);
        addTab(src.getName(), scrollPane);
        paneMap.put(fileMetaInfo.getFileId(), scrollPane);
        addBookmarks(txtArea, fileMetaInfo);
        txtArea.addBookmarkHandler((a, l, b) -> toggleBookmark(fileMetaInfo, l, b));
        txtArea.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                final int offset = txtArea.viewToModel2D(e.getPoint());
                final StackFrame stackFrame = debugPanel.getSelectedStackFrame();
                final int fileId = stackFrame.getPosition().fileId();
                for (Entry<Position, Value> entry : stackFrame.getIntermediateResults().entrySet())
                    if (offsetInPosition(fileId, entry.getKey(), txtArea, offset) && entry.getValue() != null) {
                        debugPanel.selectInVisualization(entry.getValue().getObject());
                        return;
                    }
            }
        });
        txtArea.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                final int offset = txtArea.viewToModel2D(e.getPoint());
                final StackFrame stackFrame = debugPanel.getSelectedStackFrame();
                final int fileId = stackFrame.getPosition().fileId();
                for (Entry<Position, Value> entry : stackFrame.getIntermediateResults().entrySet())
                    if (offsetInPosition(fileId, entry.getKey(), txtArea, offset) && entry.getValue() != null) {
                        txtArea.setCursor(HAND_CURSOR);
                        return;
                    }
                txtArea.setCursor(DEFAULT_CURSOR);
            }
        });
    }

    // BOOKMARKS ///////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Toggles a breakpoint at a specified line.
     *
     * @param fileMetaInfo  The metadata of the file where the breakpoint is set.
     * @param line          The line number of the breakpoint.
     * @param breakpointSet {@code true} to add a breakpoint, {@code false} to remove it.
     */
    private void toggleBookmark(FileMetaInfo fileMetaInfo, int line, boolean breakpointSet) {
        final Breakpoint bp = new LineBreakpoint(fileMetaInfo.getFileId(), line + 1);
        if (breakpointSet)
            control.addBreakpoint(bp);
        else
            control.removeBreakpoint(bp);
    }

    /**
     * Adds existing breakpoints to the text editor.
     *
     * @param txtArea      The text editor pane.
     * @param fileMetaInfo The metadata of the file.
     */
    private void addBookmarks(MetaInfoBookmarkedTextEditorPane txtArea, FileMetaInfo fileMetaInfo) {
        for (Breakpoint bp : control.getBreakpoints())
            if (bp.getFileId() == fileMetaInfo.getFileId())
                txtArea.setBookmark(bp.getLine() - 1, true);
    }

    /**
     * Sets or removes a breakpoint.
     *
     * @param bp  The breakpoint tag.
     * @param add {@code true} to add a breakpoint, {@code false} to remove it.
     */
    public void setBookmark(Breakpoint bp, boolean add) {
        final RTextScrollPane scrollPane = paneMap.get(bp.getFileId());
        if (scrollPane == null) return;
        final MetaInfoBookmarkedTextEditorPane textArea = (MetaInfoBookmarkedTextEditorPane) scrollPane.getTextArea();
        if (textArea != null)
            textArea.setBookmark(bp.getLine() - 1, add);
    }

// HIGHLIGHTING ///////////////////////////////////////////////////////////

    /**
     * Opens/selects the source code corresponding to the given position and
     * highlights the given position, iff the source code could be opened/selected.
     *
     * @param frame The given Stackframe.
     */
    public void openFileAndHighlight(StackFrame frame) {
        removeAllProgressHighlights();
        removeAllIntermediateHighlights();
        final Position position = frame.getPosition();
        final RTextScrollPane pane = openCurrentFile(position.fileId());
        if (pane != null) {
            setSelectedComponent(pane);
            highlightIntermediateResults(frame);
            setIntermediateTooltips(frame);
            highlighter.setHighlight(position);
            scrollToHighlight(pane, position);
        }
    }

    private void setIntermediateTooltips(StackFrame frame) {
        final int fileId = frame.getPosition().fileId();
        final RTextScrollPane pane = paneMap.get(fileId);
        if (pane != null) {
            final RTextArea textArea = pane.getTextArea();
            textArea.setToolTipSupplier((tArea, e) -> {
                final int offset = tArea.viewToModel2D(e.getPoint());
                for (Entry<Position, Value> entry : frame.getIntermediateResults().entrySet())
                    if (offsetInPosition(fileId, entry.getKey(), tArea, offset) && entry.getValue() != null)
                        return String.format("%s", entry.getValue().getObject());
                return null;
            });
        }
    }

    private boolean offsetInPosition(int fileId, Position position, RTextArea textArea, int offset) {
        if (fileId != position.fileId()) return false;
        try {
            final int startOffset = textArea.getLineStartOffset(position.firstLine() - 1) + position.firstCol() - 1;
            final int endOffset = textArea.getLineStartOffset(position.lastLine() - 1) + position.lastCol();
            LOGGER.log(Level.DEBUG, "start: {0}, end: {1}, offset: {2}", startOffset, endOffset, offset);
            return startOffset <= offset && offset <= endOffset;
        }
        catch (BadLocationException e) {return false;}
    }

    /**
     * Removes all line highlights from the displayed source files.
     */
    public void removeAllProgressHighlights() {
        for (int fileId : paneMap.keySet())
            highlighter.clearHighlight(fileId);
    }

    public void removeAllIntermediateHighlights() {
        for (int fileId : paneMap.keySet())
            intermediateHighlighter.clearHighlight(fileId);
    }

    private RTextScrollPane openCurrentFile(int fileId) {
        if (fileId < 0) return null;
        if (!paneMap.containsKey(fileId))
            displaySrc(control.getMetaInfo().getFileMetaInfo(fileId));
        return paneMap.get(fileId);
    }

    /**
     * Adds grey highlights to intermediate results of the current Stackframe.
     *
     * @param frame The given Stackframe.
     */
    private void highlightIntermediateResults(StackFrame frame) {
        for (Position position : frame.getIntermediateResults().keySet())
            intermediateHighlighter.addHighlight(position);
    }

    /**
     * Scrolls the given code tab to the given Position.
     *
     * @param pane the given code tab.
     * @param pos  the given Position.
     */
    private void scrollToHighlight(RTextScrollPane pane, Position pos) {
        try {
            final int y = pane.getTextArea().yForLine(pos.firstLine() - 1);
            final int height = pane.getViewport().getHeight();
            LOGGER.log(Level.DEBUG, "scrolling: yForLine={0}, height={1}", y, height);
            SwingUtilities.invokeLater(() -> pane.getVerticalScrollBar().setValue(y - height / 2));
        }
        catch (BadLocationException e) {
            LOGGER.log(Level.INFO, e);
        }
    }

    /**
     * Returns if the given Position is in the currently selected code tab.
     *
     * @param pos the given Position.
     * @return true, if the given Position is in the currently selected code tab, false otherwise.
     */
    public boolean positionInSelectedTab(Position pos) {
        return getSelectedComponent() == paneMap.get(pos.fileId());
    }

    /**
     * Updates the current position while StepwiseVisualization is active.
     * This method does not select the code tab of the given Position.
     *
     * @param position the given Position.
     */
    public void updateHighlightInStepwiseVisualization(Position position) {
        // do highlighting and scrolling after all pending AWT events
        // to make sure that the source code pane is already visible.
        highlighter.setHighlight(position);
    }

    public boolean isInstructionHighlighting() {return highlighter == instructionHighlighter;}

    public void setInstructionHighlighting(boolean instructionHighlighting) {
        if (instructionHighlighting != (highlighter == instructionHighlighter)) {
            removeAllProgressHighlights();
            highlighter = instructionHighlighting ? instructionHighlighter : lineHighlighter;
            debugPanel.openFileAndHighlight();
        }
    }

    public Map<Integer, RTextScrollPane> getPaneMap() {
        return Collections.unmodifiableMap(paneMap);
    }
}
