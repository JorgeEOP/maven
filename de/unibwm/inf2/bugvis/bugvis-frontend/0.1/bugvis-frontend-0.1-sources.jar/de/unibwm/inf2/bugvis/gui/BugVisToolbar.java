package de.unibwm.inf2.bugvis.gui;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JToolBar;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class BugVisToolbar extends JToolBar {
    protected static final Logger LOGGER = System.getLogger(DebugToolBar.class.getName());
    protected final List<Component> componentList = new ArrayList<>();

    /**
     * Returns an ImageIcon, or null if the path was invalid.
     */
    public static Icon createImageIcon(String path) {
        final URL imgURL = DebugToolBar.class.getResource(path);
        if (imgURL != null)
            return new ImageIcon(imgURL);
        LOGGER.log(Level.WARNING, "Couldn't find file: {0}", path);
        return null;
    }

    /**
     * Creates a JButton with the specified name and action, adds it to the given panel,
     * and tracks it in the internal button list.
     *
     * @param name           the text displayed on the button.
     * @param iconPath
     * @param actionListener the ActionListener to be invoked when the button is pressed.
     */
    public void addButton(String name, String iconPath, ActionListener actionListener) {
        final Icon icon = iconPath == null ? null : BugVisToolbar.createImageIcon(iconPath);
        JButton button = icon == null ? new JButton(name) : new JButton(icon);
        if (icon != null)
            button.setToolTipText(name);
        add(button);
        componentList.add(button);
        button.addActionListener(actionListener);
    }

    /**
     * Enables or disables all registered components.
     *
     * @param enable {@code true} to enable the buttons; {@code false} to disable them.
     */
    public void enableControl(boolean enable) {
        for (Component component : componentList)
            component.setEnabled(enable);
    }
}
