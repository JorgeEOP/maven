package de.unibwm.inf2.bugvis.gui.breakpoints;

import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.instr.metainfo.FileMetaInfo;

import javax.swing.BoxLayout;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowSorter.SortKey;
import javax.swing.SortOrder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

import static java.awt.Color.RED;
import static java.awt.Color.WHITE;
import static java.util.Comparator.comparing;

public class BreakpointDialog extends JDialog {
    static final String DELETE = "Delete";
    private final DebugControl control;
    private final BreakpointTableModel tableModel;
    private JTable table;

    public BreakpointDialog(Frame owner, DebugControl control) {
        super(owner);
        this.control = control;
        tableModel = new BreakpointTableModel(control);

        setTitle("Breaktpoints");
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        initGui();
        pack();
        setLocationRelativeTo(owner);
        control.addControlListener(tableModel);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                control.removeControlListener(tableModel);
            }
        });
        setVisible(true);
    }

    private void initGui() {
        setLayout(new BorderLayout(5, 5));

        add(createBreakPointPanel(), BorderLayout.NORTH);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        table = new JTable(tableModel);
        table.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        TableRowSorter<BreakpointTableModel> sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);
        sorter.setSortKeys(List.of(new SortKey(0, SortOrder.ASCENDING),
                                   new SortKey(1, SortOrder.ASCENDING)));
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        table.getColumnModel().getColumn(1).setMaxWidth(100);
        table.getColumnModel().getColumn(2).setMaxWidth(100);

        final TableColumn column = table.getColumnModel().getColumn(2);
        column.setCellRenderer(new ButtonRenderer());
        column.setCellEditor(new ButtonEditor());

        JScrollPane listScrollPane = new JScrollPane(table);
        panel.add(listScrollPane);
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        addButton(buttonPanel, "Delete all Breakpoints", e -> tableModel.clearBreakpoints());
        panel.add(buttonPanel, BorderLayout.SOUTH);
        add(panel, BorderLayout.CENTER);
    }

    private JPanel createBreakPointPanel() {
        JPanel breakpointPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        final BreakpointFile[] list = control.getMetaInfo().getFileMetaInfo().stream()
                                             .map(BreakpointFile::new)
                                             .sorted(comparing(BreakpointFile::getFilePath))
                                             .toArray(BreakpointFile[]::new);
        JComboBox<BreakpointFile> breakpointBox = new JComboBox<>(list);
        breakpointPanel.add(breakpointBox);
        JTextField breakpointLine = new JTextField("", 15);
        breakpointLine.setToolTipText("Breakpoint lines");
        breakpointLine.getDocument().addDocumentListener(new BreakpointInputFieldListener(breakpointLine));
        breakpointPanel.add(breakpointLine);
        addButton(breakpointPanel, "Set Breakpoint", e -> addBreakpoints(breakpointBox, breakpointLine.getText()));
        return breakpointPanel;
    }

    /**
     * If selectedItem is not null, the method picks all breakpoint-lines from lines
     * depends on path and passes the breakpoint-lines as and Integer to the Controller
     *
     * @param breakpointBox Contains the P
     * @param lines         String from JTextField
     */
    private void addBreakpoints(JComboBox<BreakpointFile> breakpointBox, String lines) {
        final BreakpointFile item = (BreakpointFile) breakpointBox.getSelectedItem();
        if (item == null) return;
        for (String line : lines.split(","))
            if (!line.isEmpty()) {
                final int l = Integer.parseInt(line.trim());
                if (item.fileMetaInfo.inBreakpointRange(l))
                    tableModel.addBreakpoint(item.getFileId(), l);
            }
    }

    /**
     * Creating a JButton with a ActionListener
     * and adding to the container and the jButtonList
     *
     * @param panel          The JPanel, which the button is added to.
     * @param name           Name of the JButton
     * @param actionListener ActionListener with an actionevent
     */
    private void addButton(JPanel panel, String name, ActionListener actionListener) {
        JButton button = new JButton(name);
        panel.add(button);
        button.addActionListener(actionListener);
    }

    private record BreakpointInputFieldListener(JTextField textField) implements DocumentListener {
        private static final String REGEX = "[0-9, ]*";

        @Override
        public void changedUpdate(DocumentEvent e) {
            update();
        }

        @Override
        public void removeUpdate(DocumentEvent e) {
            update();
        }

        @Override
        public void insertUpdate(DocumentEvent e) {
            update();
        }

        private void update() {
            textField.setBackground(textField.getText().matches(REGEX) ? WHITE : RED);
        }
    }

    private static class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setText(BreakpointDialog.DELETE);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            return this;
        }
    }

    private class ButtonEditor extends DefaultCellEditor {
        private final JButton button;
        private int row;

        public ButtonEditor() {
            super(new JCheckBox());
            button = new JButton(BreakpointDialog.DELETE);
            button.setOpaque(true);
            button.addActionListener(this::delete);
        }

        private void delete(ActionEvent e) {
            // Remove the row when button is clicked
            if (table.isEditing())
                table.getCellEditor().stopCellEditing();
            tableModel.removeRow(row);
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.row = row;
            return button;
        }

        @Override
        public Object getCellEditorValue() {
            return BreakpointDialog.DELETE;
        }
    }

    private static class BreakpointFile {
        final int fileId;
        final String filePath;
        final FileMetaInfo fileMetaInfo;

        public BreakpointFile(FileMetaInfo fileMetaInfo) {
            this.fileId = fileMetaInfo.getFileId();
            this.filePath = fileMetaInfo.getRelativeFilePath();
            this.fileMetaInfo = fileMetaInfo;
        }

        public int getFileId() {return fileId;}

        public FileMetaInfo getFileMetaInfo() {return fileMetaInfo;}

        public String getFilePath() {return filePath;}

        @Override
        public String toString() {
            return filePath;
        }
    }
}
