package de.unibwm.inf2.bugvis.gui.stackframe;

import de.unibwm.inf2.bugvis.model.Variable;
import de.unibwm.inf2.bugvis.model.value.ReferenceValue;

import javax.swing.tree.TreeNode;
import java.util.Comparator;
import java.util.List;

import static java.lang.String.format;
import static java.lang.System.identityHashCode;

public class VariableNode extends InnerNode {
    private final List<Variable> variables;
    private final Object object;

    VariableNode(String name, ReferenceValue object, TreeNode parent) {
        super(object,
              format("%s0x%x<font color='gray'> (%s)</font>", name, identityHashCode(object), object.getClazz().getSimpleName()),
              parent);
        this.variables = List.copyOf(object.getFields());
        this.object = object.getObject();
    }

    @Override
    public int getChildCount() {return variables.size();}

    void fill(List<TreeNode> children) {
        variables.stream()
                 .sorted(Comparator.comparing(Variable::getName))
                 .forEach(v -> children.add(createNode(v)));
    }

    private TreeNode createNode(Variable variable) {
        if (variable.getValue() == null)
            return new Leaf(variable.getName() + ":" + variable.getType() + "=null", this);
        return variable.getValue().accept(new TreeNodeValueVisitor(variable, this));
    }

    public Object getObject() {return object;}
}
