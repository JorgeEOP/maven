package de.unibwm.inf2.bugvis.gui.codeview;

import de.unibwm.inf2.bugvis.model.Position;
import org.fife.ui.rtextarea.RTextArea;
import org.fife.ui.rtextarea.RTextScrollPane;

import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter.DefaultHighlightPainter;
import java.awt.Color;

public class RangeHighlighter extends Highlighter {

    private final DefaultHighlightPainter highlightPainter;

    public RangeHighlighter(CodeView codeView, Color highlightColor) {
        super(codeView);
        highlightPainter = new DefaultHighlightPainter(highlightColor);
    }

    protected Object localHighlight(Position pos) throws BadLocationException {
        final RTextScrollPane pane = getPane(pos.fileId());
        final RTextArea textArea = pane.getTextArea();
        final int startOffset = textArea.getLineStartOffset(pos.firstLine() - 1) + pos.firstCol() - 1;
        final int endOffset = textArea.getLineStartOffset(pos.lastLine() - 1) + pos.lastCol();
        return textArea.getHighlighter().addHighlight(startOffset, endOffset, highlightPainter);
    }

    protected void localRemove(int fileId, Object tag) {
        final RTextScrollPane pane = getPane(fileId);
        pane.getTextArea().getHighlighter().removeHighlight(tag);
    }
}
