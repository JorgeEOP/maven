package de.unibwm.inf2.bugvis.gui.visulization;

import java.util.List;

public record IncomingEdge(List<String> labels, int hash) {}
