package de.unibwm.inf2.bugvis.gui.stackframe;

public interface ToolTipAble {
    String getToolTipText();
}
