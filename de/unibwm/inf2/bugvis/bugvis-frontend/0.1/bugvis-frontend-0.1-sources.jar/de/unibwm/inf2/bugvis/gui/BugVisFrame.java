package de.unibwm.inf2.bugvis.gui;

import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.control.events.BreakpointEvent;
import de.unibwm.inf2.bugvis.control.events.ControlEventListener;
import de.unibwm.inf2.bugvis.control.events.DebugeeStateEvent;
import de.unibwm.inf2.bugvis.gui.breakpoints.BreakpointDialog;
import de.unibwm.inf2.bugvis.gui.visulization.VisualizationFrame;
import de.unibwm.inf2.bugvis.instr.metainfo.FileMetaInfo;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.WindowConstants;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.lang.System.Logger;

import static de.unibwm.inf2.bugvis.control.events.DebugeeStateEvent.PAUSED;
import static java.lang.System.Logger.Level.WARNING;
import static java.util.Comparator.comparing;

public class BugVisFrame extends JFrame implements ControlEventListener {
    private static final Logger LOGGER = System.getLogger(BugVisFrame.class.getName());
    private static final String TITLE = "BugVis";

    private final DebugPanel debugPanel;
    private final DebugToolBar debugToolBar;
    private final DebugControl control;
    private final StatusPanel statusPanel;

    private VisualizationFrame visualizationFrame;

    public BugVisFrame(DebugControl control) {
        super(TITLE);
        this.control = control;
        statusPanel = new StatusPanel();
        debugPanel = new DebugPanel(this, control);
        debugToolBar = new DebugToolBar(this, debugPanel);
        control.addControlListener(this);
        setPreferredSize(new Dimension(1280, 960));
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        setLayout(new BorderLayout());
        createMenuBar();

        add(debugToolBar, BorderLayout.NORTH);

        add(debugPanel, BorderLayout.CENTER);

        add(statusPanel, BorderLayout.SOUTH);
    }

    private void createMenuBar() {
        final JMenuBar menuBar = new JMenuBar();

        final JMenu fileMenu = new JMenu("File");
        control.getMetaInfo().getFileMetaInfo().stream()
               .sorted(comparing(FileMetaInfo::getRelativeFilePath))
               .forEach(fmi -> {
                   final JMenuItem openFileMenuItem = new JMenuItem("Open " + fmi.getRelativeFilePath());
                   openFileMenuItem.addActionListener(a -> debugPanel.getCodeView().openFile(fmi));
                   fileMenu.add(openFileMenuItem);
               });
        fileMenu.addSeparator();
        final JMenuItem quitMenuItem = new JMenuItem("Quit");
        quitMenuItem.addActionListener(a -> System.exit(0));
        fileMenu.add(quitMenuItem);
        menuBar.add(fileMenu);

        final JMenu breakpointMenu = new JMenu("Run");
        final JMenuItem breakpointDialogMenuItem = new JMenuItem("Breakpoints...");
        breakpointDialogMenuItem.addActionListener(e -> new BreakpointDialog(this, control));
        breakpointMenu.add(breakpointDialogMenuItem);
        menuBar.add(breakpointMenu);

        final JMenu viewMenu = new JMenu("View");
        menuBar.add(viewMenu);

        setJMenuBar(menuBar);
    }

    /**
     * Runs the specified runnable on the AWT event thread.
     */
    private static void invoke(Runnable runnable) {
        if (SwingUtilities.isEventDispatchThread())
            runnable.run();
        else
            SwingUtilities.invokeLater(runnable);
    }

    @Override
    public void receivedEvent(BreakpointEvent event) {
        debugPanel.getCodeView().setBookmark(event.breakpoint(), event.add());
    }

    @Override
    public void receivedEvent(DebugeeStateEvent event) {
        invoke(() -> {
            debugToolBar.enableControl(event == PAUSED);
            debugPanel.updateDebugeeState(event);
            statusPanel.setStatus(event == PAUSED ? "Debugee paused" : "Debugee running");
        });
    }

    public static void initUI() {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            UIManager.put("List.font", new Font("Dialog", Font.PLAIN, 12));
        }
        catch (UnsupportedLookAndFeelException | ClassNotFoundException | InstantiationException |
               IllegalAccessException e) {
            LOGGER.log(WARNING, e.getMessage(), e);
        }
    }

    public DebugPanel getDebugPanel() {
        return debugPanel;
    }

    public DebugToolBar getDebugToolBar() {
        return debugToolBar;
    }

    public VisualizationFrame getVisualizationFrame() {return visualizationFrame;}

    public void setVisualizationFrame(VisualizationFrame visualizationFrame) {
        this.visualizationFrame = visualizationFrame;
    }

    public StatusPanel getStatusPanel() {return statusPanel;}

    public DebugControl getControl() {
        return control;
    }
}
