package de.unibwm.inf2.bugvis.gui.visulization;

import de.unibwm.inf2.bugvis.control.events.SelectEventListener;
import de.unibwm.inf2.bugvis.gui.BugVisToolbar;
import de.unibwm.inf2.bugvis.model.notification.visualize.VisualizeEventListener;

import javax.swing.JPanel;

public abstract class VisualizationPane extends JPanel implements VisualizeEventListener, SelectEventListener {
    protected boolean bigStepVisualizations = true;

    public boolean getBigStepVisualizations() {
        return bigStepVisualizations;
    }

    public void setBigStepVisualizations(boolean bigStepVisualizations) {
        this.bigStepVisualizations = bigStepVisualizations;
    }

    public abstract void addControls(BugVisToolbar toolBar);
}
