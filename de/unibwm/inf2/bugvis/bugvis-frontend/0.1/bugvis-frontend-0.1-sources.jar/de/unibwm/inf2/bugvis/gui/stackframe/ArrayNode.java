package de.unibwm.inf2.bugvis.gui.stackframe;

import de.unibwm.inf2.bugvis.model.value.ArrayValue;
import de.unibwm.inf2.bugvis.model.value.Value;

import javax.swing.tree.TreeNode;
import java.util.List;

class ArrayNode extends InnerNode {
    private final ArrayValue array;

    ArrayNode(String text, ArrayValue array, TreeNode parent) {
        super(array, text, parent);
        this.array = array;
    }

    @Override
    public int getChildCount() {
        return array.getLength();
    }

    @Override
    public String toString() {
        return "<html>" + text + "array[" + array.getLength() + "]</html>";
    }

    void fill(List<TreeNode> children) {
        for (Value data : array.getComponentMirrorObjects())
            children.add(createNode(children.size(), data));
    }

    private TreeNode createNode(int count, Value data) {
        //TODO needs more beautiful representations
        if (data == null)
            return new Leaf(count + ": null", this);
        return data.accept(new TreeNodeValueVisitor(null, ArrayNode.this) {
            @Override
            protected String prefix() {return count + ": ";}
        });
    }
}
