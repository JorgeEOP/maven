package de.unibwm.inf2.bugvis.gui.rsyntaxtextarea;

import org.fife.ui.rsyntaxtextarea.FileLocation;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextAreaEditorKit;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextAreaUI;
import org.fife.ui.rsyntaxtextarea.RSyntaxUtilities;
import org.fife.ui.rsyntaxtextarea.TextEditorPane;
import org.fife.ui.rtextarea.Gutter;
import org.fife.ui.rtextarea.GutterIconInfo;
import org.fife.ui.rtextarea.IconRowHeader;
import org.fife.ui.rtextarea.RTextArea;
import org.fife.ui.rtextarea.RTextAreaUI;

import javax.swing.text.BadLocationException;
import javax.swing.text.EditorKit;
import javax.swing.text.JTextComponent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * A specialized extension of {@link TextEditorPane} that provides support for managing
 * bookmarks within a text editor.
 * <p>
 * This class allows users to toggle, check, and retrieve bookmarks within the text document.
 * Bookmarks are visual indicators placed in the gutter of the editor and can be used
 * for quick navigation.
 * </p>
 *
 * @see TextEditorPane
 * @see RSyntaxUtilities#getGutter(RTextArea)
 * @see Gutter
 * @see GutterIconInfo
 */
public class BookmarkedTextEditorPane extends TextEditorPane {

    /**
     * List of registered bookmark handlers.
     */
    private final List<BookmarkHandler> bookmarkHandlers = new ArrayList<>();

    /**
     * Internal flag to indicate when bookmarks are modified programmatically.
     */
    private boolean manualAccess;

    /**
     * Creates a new instance of the editor pane with default settings.
     */
    public BookmarkedTextEditorPane() {
    }

    /**
     * Creates a new instance of the editor pane with a specified text mode.
     *
     * @param textMode The text mode (e.g., {@link TextEditorPane#INSERT_MODE}).
     */
    public BookmarkedTextEditorPane(int textMode) {
        super(textMode);
    }

    /**
     * Creates a new instance of the editor pane with a specified text mode and word wrap setting.
     *
     * @param textMode        The text mode.
     * @param wordWrapEnabled {@code true} to enable word wrap, {@code false} otherwise.
     */
    public BookmarkedTextEditorPane(int textMode, boolean wordWrapEnabled) {
        super(textMode, wordWrapEnabled);
    }

    /**
     * Creates a new instance of the editor pane with a specified text mode, word wrap setting, and file location.
     *
     * @param textMode        The text mode.
     * @param wordWrapEnabled {@code true} to enable word wrap, {@code false} otherwise.
     * @param loc             The file location to be loaded.
     * @throws IOException If an error occurs while loading the file.
     */
    public BookmarkedTextEditorPane(int textMode, boolean wordWrapEnabled, FileLocation loc) throws IOException {
        super(textMode, wordWrapEnabled, loc);
    }

    /**
     * Creates a new instance of the editor pane with a specified text mode, word wrap setting, file location,
     * and default encoding.
     *
     * @param textMode        The text mode.
     * @param wordWrapEnabled {@code true} to enable word wrap, {@code false} otherwise.
     * @param loc             The file location to be loaded.
     * @param defaultEnc      The default encoding for the file.
     * @throws IOException If an error occurs while loading the file.
     */
    public BookmarkedTextEditorPane(int textMode, boolean wordWrapEnabled, FileLocation loc, String defaultEnc) throws IOException {
        super(textMode, wordWrapEnabled, loc, defaultEnc);
    }

    /**
     * Adds a {@link BookmarkHandler} to receive notifications when bookmarks are toggled.
     *
     * @param handler The bookmark handler to add.
     */
    public void addBookmarkHandler(BookmarkHandler handler) {
        bookmarkHandlers.add(handler);
    }

    /**
     * Removes a previously registered {@link BookmarkHandler}.
     *
     * @param handler The bookmark handler to remove.
     */
    public void removeBookmarkHandler(BookmarkHandler handler) {
        bookmarkHandlers.remove(handler);
    }

    /**
     * Determines whether a bookmark is allowed at a given line.
     * <p>
     * By default, this method returns {@code true}. Subclasses can override this method to
     * implement custom bookmark restrictions.
     * </p>
     *
     * @param line The line number (0-based).
     * @return {@code true} if a bookmark can be placed at the given line, otherwise {@code false}.
     */
    public boolean isBookmarkAllowed(int line) {
        return true;
    }

    /**
     * Sets or removes a bookmark at the specified line.
     * <p>
     * This method toggles the bookmark state at the given line without calling
     * {@link #isBookmarkAllowed(int)} to check if bookmarking is permitted.
     * </p>
     *
     * @param line  The line number (0-based).
     * @param value {@code true} to set a bookmark, {@code false} to remove it.
     * @return {@code true} if the bookmark state changed, {@code false} otherwise.
     */
    public boolean setBookmark(int line, boolean value) {
        if (isBookmarked(line) == value) return false;
        final Gutter gutter = RSyntaxUtilities.getGutter(this);
        try {
            manualAccess = true;
            final boolean hasBeenSet = gutter.toggleBookmark(line);
            if (hasBeenSet != value)
                throw new IllegalStateException("Unable to toggle bookmark at line " + line);
        }
        catch (BadLocationException e) {
            return false;
        }
        finally {
            manualAccess = false;
        }
        return true;
    }

    /**
     * Checks if a bookmark exists at the specified line.
     *
     * @param line The line number (0-based).
     * @return {@code true} if a bookmark is present at the given line, otherwise {@code false}.
     */
    public boolean isBookmarked(int line) {
        try {
            final int offset = getLineStartOffset(line);
            final Gutter gutter = RSyntaxUtilities.getGutter(this);
            final GutterIconInfo[] bookmarks = gutter.getBookmarks();
            return Stream.of(bookmarks).anyMatch(i -> i.getMarkedOffset() == offset);
        }
        catch (BadLocationException e) {
            return false;
        }
    }

    /**
     * Returns a stream of all bookmarked lines.
     *
     * @return An {@link IntStream} of bookmarked line numbers.
     */
    public IntStream getBookmarksStream() {
        final Gutter gutter = RSyntaxUtilities.getGutter(this);
        final GutterIconInfo[] bookmarks = gutter.getBookmarks();
        return Stream.of(bookmarks).mapToInt(this::line);
    }

    /**
     * Returns a list of all bookmarked lines.
     *
     * @return A {@link List} of bookmarked line numbers.
     */
    public List<Integer> getBookmarks() {
        final Gutter gutter = RSyntaxUtilities.getGutter(this);
        final GutterIconInfo[] bookmarks = gutter.getBookmarks();
        return Stream.of(bookmarks).map(this::line).toList();
    }

    /**
     * Converts a {@link GutterIconInfo} object to a corresponding line number.
     *
     * @param info The {@link GutterIconInfo} object.
     * @return The corresponding line number, or -1 if an error occurs.
     */
    private int line(GutterIconInfo info) {
        try {
            return getLineOfOffset(info.getMarkedOffset());
        }
        catch (BadLocationException e) {
            return -1;
        }
    }

    @Override
    protected RTextAreaUI createRTextAreaUI() {
        return new RSyntaxTextAreaUI(this) {
            @Override
            public EditorKit getEditorKit(JTextComponent tc) {
                return DEFAULT_KIT;
            }
        };
    }

    private static final EditorKit DEFAULT_KIT = new RSyntaxTextAreaEditorKit() {
        @Override
        public IconRowHeader createIconRowHeader(RTextArea textArea) {
            return new IconRowHeader(textArea) {
                @Override
                public boolean toggleBookmark(int line) throws BadLocationException {
                    final BookmarkedTextEditorPane textArea = (BookmarkedTextEditorPane) this.textArea;
                    if (textArea.manualAccess)
                        return super.toggleBookmark(line);
                    if (!textArea.isBookmarkAllowed(line)) return false;
                    final boolean bookmarkSet = super.toggleBookmark(line);
                    for (BookmarkHandler handler : textArea.bookmarkHandlers)
                        handler.bookmarkToggled(textArea, line, bookmarkSet);
                    return bookmarkSet;
                }
            };
        }
    };
}
