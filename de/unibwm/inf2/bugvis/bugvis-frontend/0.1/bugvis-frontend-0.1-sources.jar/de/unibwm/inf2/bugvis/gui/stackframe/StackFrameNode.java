package de.unibwm.inf2.bugvis.gui.stackframe;

import de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple;
import de.unibwm.inf2.bugvis.model.Field;
import de.unibwm.inf2.bugvis.model.StackFrame;
import de.unibwm.inf2.bugvis.model.Variable;
import de.unibwm.inf2.bugvis.model.value.ReferenceValue;
import de.unibwm.inf2.bugvis.model.value.Value;

import javax.swing.tree.TreeNode;
import java.lang.System.Logger;
import java.util.Comparator;
import java.util.List;

import static java.lang.String.format;
import static java.lang.System.identityHashCode;

public class StackFrameNode extends InnerNode {
    private static final Logger LOGGER = System.getLogger(StackFrameNode.class.getName());
    public static final String STACKFRAME = "Stackframe:";

    private final List<Variable> variables;
    private final Value receiverParameter;
    private final StackFrame frame;

    public StackFrameNode(StackFrame frame) {
        super(STACKFRAME, STACKFRAME, null);
        this.variables = frame.getLocalVariables();
        this.receiverParameter = frame.getReceiverParameter();
        this.frame = frame;
    }

    @Override
    public int getChildCount() {
        return variables.size() + (receiverParameter != null ? 1 : 0);
    }

    void fill(List<TreeNode> children) {
        if (receiverParameter != null)
            addThis(children);
        variables.stream()
                 .sorted(Comparator.comparing(Variable::getName))
                 .forEach(v -> children.add(createNode(v)));
    }

    private void addThis(List<TreeNode> children) {
        final ReferenceValue referenceValue = frame.getCallStack().getState()
                                                   .getMirrorObject(new ObjectClassTuple(receiverParameter.getObject()))
                                                   .asReferenceValue();
        children.add(new InnerNode(referenceValue,
                                   format("<b>this</b>=0x%x<font color='gray'> (%s)</font>",
                                          identityHashCode(referenceValue),
                                          referenceValue.getClazz().getSimpleName()),
                                   this) {
            @Override
            void fill(List<TreeNode> children) {
                referenceValue.getFields().stream().sorted(Comparator.comparing(Field::getIdentifier)).forEach(a -> children.add(createNode(a)));
            }

            @Override
            public int getChildCount() {
                return referenceValue.getFields().size();
            }
        });
    }

    private TreeNode createNode(Variable variable) {
        if (variable.getValue() == null)
            return new Leaf(variable.getName() + ":" + variable.getType() + "=null", this);
        return variable.getValue().accept(new TreeNodeValueVisitor(variable, this));
    }
}
