package de.unibwm.inf2.bugvis.gui.visulization;

import com.yworks.yfiles.geometry.InsetsD;
import com.yworks.yfiles.graph.IGraph;
import com.yworks.yfiles.graph.INode;
import com.yworks.yfiles.graph.styles.ShapeNodeShape;
import com.yworks.yfiles.graph.styles.ShapeNodeStyle;
import com.yworks.yfiles.graph.styles.ShinyPlateNodeStyle;
import com.yworks.yfiles.view.GraphComponent;
import com.yworks.yfiles.view.Pen;
import com.yworks.yfiles.view.input.CommandAction;
import com.yworks.yfiles.view.input.ICommand;
import de.unibwm.inf2.bugvis.gui.BugVisToolbar;
import de.unibwm.inf2.bugvis.model.Shape;

import javax.swing.Action;
import javax.swing.JComponent;
import java.awt.Paint;

public abstract class AbstractYFilesVisualizationPane extends VisualizationPane {
    public abstract GraphComponent getGraphComponent();

    public abstract void computeLayout();

    public IGraph getGraph() {return getGraphComponent().getGraph();}

    @Override
    public void addControls(BugVisToolbar toolBar) {
        toolBar.addSeparator();
        toolBar.add(createCommandButtonAction("/img/plus.png", ICommand.INCREASE_ZOOM, null, getGraphComponent()));
        toolBar.add(createCommandButtonAction("/img/zoom-original.png", ICommand.ZOOM, 1, getGraphComponent()));
        toolBar.add(createCommandButtonAction("/img/minus.png", ICommand.DECREASE_ZOOM, null, getGraphComponent()));
        toolBar.add(createCommandButtonAction("/img/fit.png", ICommand.FIT_GRAPH_BOUNDS, null, getGraphComponent()));
        toolBar.addSeparator();
        toolBar.addButton("Relayout", "/img/layout.png", e -> computeLayout());
    }

    private Action createCommandButtonAction(String icon, ICommand command, Object parameter, JComponent target) {
        Action action = new CommandAction(command, parameter, target);
        action.putValue(Action.SHORT_DESCRIPTION, command.getName());
        action.putValue(Action.SMALL_ICON, BugVisToolbar.createImageIcon(icon));
        return action;
    }

    public void setStyle(INode node, Shape shape, double thickness, Paint foregroundPaint, Paint backgroundPaint) {
        switch (shape) {
            case FANCY5 -> getGraph().setStyle(node, createFancyNodeStyle(5., foregroundPaint));
            case FANCY20 -> getGraph().setStyle(node, createFancyNodeStyle(20., foregroundPaint));
            default -> getGraph().setStyle(node, createShapeStyle(shape, thickness, foregroundPaint, backgroundPaint));
        }
    }

    private ShapeNodeStyle createShapeStyle(Shape shape, double thickness, Paint foregroundPaint, Paint backgroundPaint) {
        final ShapeNodeStyle style = new ShapeNodeStyle();
        setShape(shape, style);
        style.setPen(new Pen(foregroundPaint, thickness));
        style.setPaint(backgroundPaint);
        return style;
    }

    private static void setShape(Shape shape, ShapeNodeStyle style) {
        style.setShape(switch (shape) {
            case CIRCLE -> {
                style.setKeepingIntrinsicAspectRatioEnabled(true);
                yield ShapeNodeShape.ELLIPSE;
            }
            case DIAMOND -> ShapeNodeShape.DIAMOND;
            case ELLIPSE -> ShapeNodeShape.ELLIPSE;
            case FAT_ARROW_RIGHT -> ShapeNodeShape.FAT_ARROW;
            case FAT_ARROW_LEFT -> ShapeNodeShape.FAT_ARROW2;
            case HEXAGON -> ShapeNodeShape.HEXAGON;
            case HEXAGON2 -> ShapeNodeShape.HEXAGON2;
            case OCTAGON -> ShapeNodeShape.OCTAGON;
            case PILL -> ShapeNodeShape.PILL;
            case RECTANGLE -> ShapeNodeShape.RECTANGLE;
            case ROUND_RECTANGLE -> ShapeNodeShape.ROUND_RECTANGLE;
            case SHEARED_RECTANGLE -> ShapeNodeShape.SHEARED_RECTANGLE;
            case SHEARED_RECTANGLE2 -> ShapeNodeShape.SHEARED_RECTANGLE2;
            case STAR5 -> ShapeNodeShape.STAR5;
            case STAR5_UP -> ShapeNodeShape.STAR5_UP;
            case STAR6 -> ShapeNodeShape.STAR6;
            case STAR8 -> ShapeNodeShape.STAR8;
            case TRAPEZ -> ShapeNodeShape.TRAPEZ;
            case TRAPEZ2 -> ShapeNodeShape.TRAPEZ2;
            case TRIANGLE -> ShapeNodeShape.TRIANGLE;
            case TRIANGLE2 -> ShapeNodeShape.TRIANGLE2;
            case FANCY5, FANCY20 -> throw new IllegalArgumentException("fancy style not allowed for shapes");
        });
    }

    protected ShinyPlateNodeStyle createFancyNodeStyle(double radius, Paint paint) {
        final ShinyPlateNodeStyle style = new ShinyPlateNodeStyle();
        style.setInsets(new InsetsD(0.0));
        style.setPaint(paint);
        style.setRadius(radius);
        style.setShadowDrawingEnabled(true);
        return style;
    }
}
