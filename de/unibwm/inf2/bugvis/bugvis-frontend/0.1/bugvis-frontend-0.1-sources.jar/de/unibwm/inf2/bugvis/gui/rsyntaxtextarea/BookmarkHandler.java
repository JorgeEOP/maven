package de.unibwm.inf2.bugvis.gui.rsyntaxtextarea;

/**
 * Interface for handling bookmark toggle events in a text editor.
 */
public interface BookmarkHandler {

    /**
     * Called when a bookmark is toggled in the text editor.
     *
     * @param textArea    The {@link BookmarkedTextEditorPane} where the bookmark is toggled.
     * @param line        The line number where the bookmark is set or removed (0-based index).
     * @param bookmarkSet {@code true} if the bookmark is set, {@code false} if removed.
     */
    void bookmarkToggled(BookmarkedTextEditorPane textArea, int line, boolean bookmarkSet);
}
