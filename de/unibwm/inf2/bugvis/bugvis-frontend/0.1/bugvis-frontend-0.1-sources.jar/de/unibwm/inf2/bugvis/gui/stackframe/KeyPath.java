package de.unibwm.inf2.bugvis.gui.stackframe;

import javax.swing.tree.TreePath;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

class KeyPath {
    final List<Object> keys;

    KeyPath(TreePath path) {
        keys = new ArrayList<>(path.getPathCount());
        for (Object n : path.getPath()) {
            if (n instanceof InnerNode innerNode)
                keys.add(innerNode.getKey());
        }
    }

    @Override
    public boolean equals(Object o) {
        if (o == this) return true;
        if (o instanceof KeyPath keyPath)
            return Objects.equals(keys, keyPath.keys);
        return false;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(keys);
    }

    @Override
    public String toString() {
        return "KeyPath{" + keys + '}';
    }
}
