package de.unibwm.inf2.bugvis.gui.stackframe;

import de.unibwm.inf2.bugvis.model.Variable;
import de.unibwm.inf2.bugvis.model.value.ArrayValue;
import de.unibwm.inf2.bugvis.model.value.ListValue;
import de.unibwm.inf2.bugvis.model.value.MapValue;
import de.unibwm.inf2.bugvis.model.value.NullValue;
import de.unibwm.inf2.bugvis.model.value.PrimitiveValue;
import de.unibwm.inf2.bugvis.model.value.ReferenceValue;
import de.unibwm.inf2.bugvis.model.value.ValueVisitor;
import de.unibwm.inf2.bugvis.model.value.VoidValue;
import de.unibwm.inf2.bugvis.model.value.WrappedValue;

import javax.swing.tree.TreeNode;

public class TreeNodeValueVisitor implements ValueVisitor<TreeNode> {

    public final Variable variable;
    private final TreeNode parent;

    public TreeNodeValueVisitor(Variable variable, TreeNode parent) {
        this.variable = variable;
        this.parent = parent;
    }

    @Override
    public TreeNode visit(ArrayValue v) {return new ArrayNode(prefix(), v, parent);}

    @Override
    public TreeNode visit(ListValue v) {return new ListNode(prefix(), v, parent);}

    @Override
    public TreeNode visit(MapValue v) {return new MapNode(prefix(), v, parent);}

    @Override
    public TreeNode visit(NullValue v) {return new Leaf(prefix() + "null", parent);}

    @Override
    public TreeNode visit(ReferenceValue v) {
        return switch (v.getObject()) {
            case String s -> new StringNode(prefix(), s, parent);
            default -> new VariableNode(prefix(), v, parent);
        };
    }

    @Override
    public TreeNode visit(VoidValue v) {throw new IllegalStateException();}

    @Override
    public TreeNode visit(WrappedValue v) {return new Leaf(prefix() + v.getObject(), parent);}

    @Override
    public TreeNode visit(PrimitiveValue v) {return new Leaf(prefix() + v.getObject(), parent);}

    protected String prefix() {
        return "<b>" + variable.getName() + "</b><font color='gray'>: " + variable.getType() + "</font>=";
    }
}
