package de.unibwm.inf2.bugvis.gui.stackframe;

import de.unibwm.inf2.bugvis.model.Field;
import de.unibwm.inf2.bugvis.model.ProgramState;

import javax.swing.tree.TreeNode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StaticFieldNode extends InnerNode {
    private static final String STATIC_FIELDS = "Static fields";
    private final Map<Class<?>, List<Field>> staticFieldMap = new HashMap<>();

    public StaticFieldNode(ProgramState state) {
        super(STATIC_FIELDS, STATIC_FIELDS, null);
        for (Field f : state.getStaticFields())
            staticFieldMap.computeIfAbsent(f.getDeclaringClass(), k -> new ArrayList<>()).add(f);
    }

    @Override
    public int getChildCount() {
        return staticFieldMap.size();
    }

    void fill(List<TreeNode> children) {
        staticFieldMap.keySet().stream()
                      .sorted(Comparator.comparing(Class::getName))
                      .forEach(k -> children.add(new ClassNode(k, staticFieldMap.get(k), this)));
    }
}
