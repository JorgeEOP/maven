package de.unibwm.inf2.bugvis.gui.codeview;

import de.unibwm.inf2.bugvis.model.Position;
import org.fife.ui.rtextarea.RTextScrollPane;

import javax.swing.text.BadLocationException;
import java.awt.Color;

public class LineHighlighter extends Highlighter {

    private final Color highlightColor;

    public LineHighlighter(CodeView codeView, Color highlightColor) {
        super(codeView);
        this.highlightColor = highlightColor;
    }

    protected Object localHighlight(Position position) throws BadLocationException {
        final RTextScrollPane pane = getPane(position.fileId());
        return pane.getTextArea().addLineHighlight(position.firstLine() - 1, highlightColor);
    }

    protected void localRemove(int fileId, Object tag) {
        final RTextScrollPane pane = getPane(fileId);
        pane.getTextArea().removeLineHighlight(tag);
    }
}
