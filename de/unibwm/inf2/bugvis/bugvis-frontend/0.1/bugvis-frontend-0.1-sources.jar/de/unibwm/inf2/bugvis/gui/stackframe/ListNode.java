package de.unibwm.inf2.bugvis.gui.stackframe;

import de.unibwm.inf2.bugvis.model.value.ListValue;
import de.unibwm.inf2.bugvis.model.value.Value;

import javax.swing.tree.TreeNode;
import java.util.List;

public class ListNode extends InnerNode {
    private final ListValue list;

    ListNode(String text, ListValue list, TreeNode parent) {
        super(list, text, parent);
        this.list = list;
    }

    void fill(List<TreeNode> children) {
        for (Value data : list.getComponentMirrorObjects())
            children.add(createNode(children.size(), data));
    }

    private TreeNode createNode(int count, Value data) {
        if (data == null)
            return new Leaf(count + ": null", this);
        return data.accept(new TreeNodeValueVisitor(null, ListNode.this) {
            @Override
            protected String prefix() {return count + ": ";}
        });
    }

    /**
     *
     * @return
     */
    public Object getValue() {
        return list;
    }

    /**
     *
     * @return
     */
    @Override
    public int getChildCount() {
        return list.getLength();
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "<html>" + text + getListOriginalName() + "[" + list.getLength() + "]</html>";
    }

    /**
     *
     * @return
     */
    private String getListOriginalName() {
        return list.getClazz().getSimpleName().replace("Facade", "");
    }
}
