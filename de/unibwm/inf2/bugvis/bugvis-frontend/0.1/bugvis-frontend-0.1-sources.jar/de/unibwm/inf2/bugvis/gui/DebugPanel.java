package de.unibwm.inf2.bugvis.gui;

import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.control.events.DebugeeStateEvent;
import de.unibwm.inf2.bugvis.control.events.SelectEvent;
import de.unibwm.inf2.bugvis.gui.codeview.CodeView;
import de.unibwm.inf2.bugvis.gui.console.Console;
import de.unibwm.inf2.bugvis.gui.stackframe.ExpandMemory;
import de.unibwm.inf2.bugvis.gui.stackframe.IntermediateResultsNode;
import de.unibwm.inf2.bugvis.gui.stackframe.StackFrameNode;
import de.unibwm.inf2.bugvis.gui.stackframe.StaticFieldNode;
import de.unibwm.inf2.bugvis.gui.stackframe.ToolTipJTree;
import de.unibwm.inf2.bugvis.gui.stackframe.VariableNode;
import de.unibwm.inf2.bugvis.gui.visulization.VisualizationFrame;
import de.unibwm.inf2.bugvis.gui.visulization.VisualizationPane;
import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.StackFrame;
import de.unibwm.inf2.bugvis.model.history.History;
import de.unibwm.inf2.bugvis.model.notification.console.ConsoleAddOutputEvent;
import de.unibwm.inf2.bugvis.model.notification.console.ConsoleEventListener;
import de.unibwm.inf2.bugvis.model.notification.console.ConsoleRemOutputEvent;
import de.unibwm.inf2.bugvis.model.notification.position.PositionEvent;
import de.unibwm.inf2.bugvis.model.notification.position.PositionEventListener;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTree;
import javax.swing.ListSelectionModel;
import javax.swing.ToolTipManager;
import javax.swing.event.ListSelectionEvent;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;
import java.awt.BorderLayout;
import java.lang.System.Logger;
import java.util.concurrent.CountDownLatch;

import static de.unibwm.inf2.bugvis.control.events.DebugeeStateEvent.PAUSED;
import static de.unibwm.inf2.bugvis.control.events.DebugeeStateEvent.WAITING_FOR_INPUT;
import static java.lang.System.Logger.Level.INFO;

/**
 * A panel that integrates multiple debugging views, including the call stack, stack frames,
 * static fields, and the code editor.
 * <p>
 * The {@code DebugPanel} organizes and displays relevant debugging information, such as:
 * <ul>
 *     <li>A call stack view</li>
 *     <li>A stack frame view</li>
 *     <li>Static field information</li>
 *     <li>A syntax-highlighted source code editor</li>
 * </ul>
 * It listens for debugger state updates and refreshes the views accordingly.
 * </p>
 */
public class DebugPanel extends JPanel {
    private static final Logger LOGGER = System.getLogger(DebugPanel.class.getName());

    private final DebugControl control;
    private final CodeView codeView;
    private final DefaultListModel<StackFrameProxy> listModel = new DefaultListModel<>();
    private final JList<StackFrameProxy> callStackList = new JList<>(listModel);
    private final JTree stackFrameTree = new ToolTipJTree(new DefaultTreeModel(null));
    private final JTree staticFieldsTree = new JTree(new DefaultTreeModel(null));
    private final JTree intermediateTree = new ToolTipJTree(new DefaultTreeModel(null));
    private final BugVisFrame bugVisFrame;
    private final Console console;

    /**
     * Constructs a new {@code DebugPanel} with the specified debug control and source directory.
     *
     * @param control The debug control managing the debugging session.
     */
    DebugPanel(BugVisFrame bugVisFrame, DebugControl control) {
        LOGGER.log(INFO, "DebugView started with {0} and srcDir={1}",
                   control, control.getOptions().getOriginalSourceDirectory().getAbsoluteFile());
        setLayout(new BorderLayout());
        this.control = control;
        this.bugVisFrame = bugVisFrame;
        control.getState().addPositionEventListener(positionEventListener);
        control.getState().addConsoleEventListener(consoleEventListener);
        codeView = new CodeView(control, this);
        console = new Console(control);
        add(initContent());
    }

    /**
     * Configures the tree cell renderer for stack frames and static fields.
     * This method customizes the tree appearance.
     *
     * @return A {@link DefaultTreeCellRenderer} instance with customized settings.
     */
    private static DefaultTreeCellRenderer configureTreeCellRenderer() {
        DefaultTreeCellRenderer renderer = new DefaultTreeCellRenderer();
        renderer.setLeafIcon(null);
        renderer.setOpenIcon(null);
        renderer.setClosedIcon(null);
        return renderer;
    }

    /**
     * Initializes and creates the UI components for the debug panel.
     *
     * @return The root component of the debug panel.
     */
    private JComponent initContent() {
        initTrees();

        callStackList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        callStackList.addListSelectionListener(this::updateHighlighting);
        callStackList.addListSelectionListener(this::updateStackFrame);
        callStackList.setLayoutOrientation(JList.VERTICAL);

        JScrollPane callStackScrollPane = new JScrollPane(callStackList);
        callStackScrollPane.setBorder(BorderFactory.createTitledBorder("Call Stack"));
        final JTabbedPane variablesTabbedPane = createVariablesTabbedPane();
        JSplitPane stackSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, variablesTabbedPane, callStackScrollPane);
        stackSplitPane.setResizeWeight(0.5);

        JSplitPane codeConsoleSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, codeView, console);
        codeConsoleSplitPane.setResizeWeight(0.8);
        JSplitPane mainSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, stackSplitPane, codeConsoleSplitPane);
        mainSplitPane.setResizeWeight(0.3);
        return mainSplitPane;
    }

    /**
     * Initializes the trees used to display stack frames and static fields.
     */
    private void initTrees() {
        final DefaultTreeCellRenderer renderer = configureTreeCellRenderer();
        initTree(staticFieldsTree, renderer);
        initTree(stackFrameTree, renderer);
        initTree(intermediateTree, renderer);
        ToolTipManager.sharedInstance().registerComponent(stackFrameTree);
        ToolTipManager.sharedInstance().registerComponent(intermediateTree);
    }

    private void initTree(JTree tree, DefaultTreeCellRenderer renderer) {
        tree.setRootVisible(false);
        tree.setShowsRootHandles(true);
        tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        tree.setCellRenderer(renderer);
        tree.addTreeSelectionListener(e -> {
            if (e.getPath().getLastPathComponent() instanceof VariableNode variableNode)
                selectInVisualization(variableNode.getObject());
        });
    }

    /**
     * Creates and configures the tabbed pane containing variable-related views.
     *
     * @return The tabbed pane with static fields and stack frame views.
     */
    private JTabbedPane createVariablesTabbedPane() {
        JTabbedPane variablesTabbedPane = new JTabbedPane();
        JScrollPane staticFieldsScrollPane = new JScrollPane(staticFieldsTree);
        variablesTabbedPane.add("Static Fields", staticFieldsScrollPane);
        JScrollPane stackFrameScrollPane = new JScrollPane(stackFrameTree);
        variablesTabbedPane.add("Stack Frame", stackFrameScrollPane);
        variablesTabbedPane.setSelectedIndex(1);
        JScrollPane intermediateScrollPane = new JScrollPane(intermediateTree);
        variablesTabbedPane.add("Intermediate Results", intermediateScrollPane);
        return variablesTabbedPane;
    }

    /**
     * Updates the debug panel when the debugee's state changes.
     *
     * @param state The new state of the debugee.
     */
    public void updateDebugeeState(DebugeeStateEvent state) {
        LOGGER.log(INFO, "DebugView notified: state={0}", state);
        if (state == PAUSED || state == WAITING_FOR_INPUT) {
            createCallStack();
            updateStaticFields();
            updateCommandState();
        }
        if (state == WAITING_FOR_INPUT)
            console.highlightInput();
    }

    private void updateCommandState() {
        final History history = control.getHistory();
        final int undoCount = history.getUndoCommandSize();
        final int redoCount = history.getRedoCommandSize();
        final boolean finished = control.isDebugeeFinished();
        final boolean exception = control.isDebugeeException();
        bugVisFrame.getStatusPanel().updateCommandLabel(undoCount, undoCount + redoCount, finished, exception);
    }

    /**
     * Updates the static fields tree to reflect the current state of the debug session.
     */
    private void updateStaticFields() {
        final ExpandMemory expanded = new ExpandMemory(staticFieldsTree);
        StaticFieldNode root = new StaticFieldNode(control.getState());
        staticFieldsTree.setModel(new DefaultTreeModel(root));
        expanded.expandPaths();
    }

    /**
     * Creates and populates the call stack list.
     */
    private void createCallStack() {
        listModel.clear();
        for (StackFrame frame : control.getCallStack())
            listModel.addElement(new StackFrameProxy(frame, this));
        if (listModel.isEmpty())
            codeView.removeAllProgressHighlights();
        else
            callStackList.setSelectedIndex(0);
    }

    /**
     * Updates the highlighting of the text area based on the selected call stack frame.
     * If the source file is not opened, it creates a new tab for it.
     *
     * @param e The selection event.
     */
    private void updateHighlighting(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting()) openFileAndHighlight();
    }

    public void openFileAndHighlight() {
        final int index = callStackList.getSelectedIndex();
        if (index >= 0)
            codeView.openFileAndHighlight(listModel.get(index).frame());
    }

    /**
     * Updates the stack frame tree when a stack frame is selected in the call stack.
     * The nodes in the stack frame will be shown expanded if the user clicked on them previously.
     *
     * @param e The selection event.
     */
    private void updateStackFrame(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) return;
        final int index = callStackList.getSelectedIndex();
        if (index >= 0) {
            final StackFrameProxy proxy = listModel.get(index);
            final StackFrameNode stackNode = new StackFrameNode(proxy.frame());

            final ExpandMemory expanded = new ExpandMemory(stackFrameTree);
            stackFrameTree.setModel(new DefaultTreeModel(stackNode));
            expanded.expandPaths();

            final ExpandMemory intermediateTreeExpanded = new ExpandMemory(intermediateTree);
            final IntermediateResultsNode intermediateRoot = new IntermediateResultsNode(proxy.frame());
            intermediateTree.setModel(new DefaultTreeModel(intermediateRoot));
            intermediateTreeExpanded.expandPaths();
        }
    }

    public void selectInVisualization(Object object) {
        final SelectEvent event = new SelectEvent(System.identityHashCode(object));
        control.notifyListeners(event);
    }

    public DebugControl getControl() {
        return control;
    }

    public CodeView getCodeView() {
        return codeView;
    }

    public StackFrame getSelectedStackFrame() {
        return callStackList.getModel().getElementAt(callStackList.getSelectedIndex()).frame();
    }

    // VisualizationEventListener //////////////////////////////////////////////////////////////////////////////////////

    private final ConsoleEventListener consoleEventListener = new ConsoleEventListener() {
        @Override
        public void receivedEvent(ConsoleAddOutputEvent event, CountDownLatch count) {
            console.addText(event.getText(), event.getOutputType());
            count.countDown();
        }

        @Override
        public void receivedEvent(ConsoleRemOutputEvent event, CountDownLatch count) {
            console.deleteTextAtEnd(event.getText());
            count.countDown();
        }
    };

    private final PositionEventListener positionEventListener = new PositionEventListener() {
        @Override
        public void receivedEvent(PositionEvent event, CountDownLatch count) {
            // update position
            final VisualizationFrame visualizationFrame = bugVisFrame.getVisualizationFrame();
            if (visualizationFrame != null) {
                final VisualizationPane visualizationPane = visualizationFrame.getVisualizationPane();
                if (visualizationPane != null && !visualizationPane.getBigStepVisualizations()) {
                    final Position position = event.getPosition();
                    if (codeView.positionInSelectedTab(position))
                        codeView.updateHighlightInStepwiseVisualization(position);
                }
            }
            count.countDown();
        }
    };
}
