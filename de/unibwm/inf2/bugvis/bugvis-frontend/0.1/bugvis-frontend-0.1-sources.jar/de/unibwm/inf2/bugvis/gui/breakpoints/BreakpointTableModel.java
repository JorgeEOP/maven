package de.unibwm.inf2.bugvis.gui.breakpoints;

import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.control.events.BreakpointEvent;
import de.unibwm.inf2.bugvis.control.events.ControlEventListener;
import de.unibwm.inf2.bugvis.control.events.DebugeeStateEvent;
import de.unibwm.inf2.bugvis.instr.metainfo.FileMetaInfo;
import de.unibwm.inf2.bugvis.model.Breakpoint;
import de.unibwm.inf2.bugvis.model.LineBreakpoint;

import javax.swing.JButton;
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

/**
 * A table model for managing breakpoints in a debug session.
 * <p>
 * This model stores breakpoints and provides functionality for:
 * <ul>
 *     <li>Adding new breakpoints</li>
 *     <li>Removing existing breakpoints</li>
 *     <li>Clearing all breakpoints</li>
 *     <li>Listening to breakpoint-related events</li>
 * </ul>
 * It extends {@link AbstractTableModel} to integrate with a Swing table component.
 * </p>
 */
class BreakpointTableModel extends AbstractTableModel implements ControlEventListener {

    /**
     * Column name for action buttons in the table.
     */
    public static final String ACTION = "Action";
    /**
     * Column name for class names in the table.
     */
    public static final String CLASS = "Class";
    /**
     * Column name for line numbers in the table.
     */
    public static final String LINE = "Line";

    private final DebugControl control;
    private final List<Breakpoint> breakpoints = new ArrayList<>();

    /**
     * Constructs a {@code BreakpointTableModel} and loads existing breakpoints.
     *
     * @param control The debug control managing breakpoints.
     */
    public BreakpointTableModel(DebugControl control) {
        this.control = control;
        breakpoints.addAll(control.getBreakpoints());
    }

    /**
     * Adds a new breakpoint to the table.
     *
     * @param fileId The file id where the breakpoint is set.
     * @param line   The line number where the breakpoint is set.
     */
    public void addBreakpoint(int fileId, int line) {
        final Breakpoint bp = new LineBreakpoint(fileId, line);
        control.addBreakpoint(bp);
        if (breakpoints.contains(bp)) return;
        breakpoints.add(bp);
        fireTableRowsInserted(breakpoints.size() - 1, breakpoints.size() - 1);
    }

    /**
     * Removes a breakpoint at a specified row.
     *
     * @param row The index of the row to be removed.
     */
    public void removeRow(int row) {
        final Breakpoint bp = breakpoints.remove(row);
        fireTableRowsDeleted(row, row);
        if (bp != null)
            control.removeBreakpoint(bp);
    }

    /**
     * Clears all breakpoints from the table and notifies the breakpoint handler.
     */
    public void clearBreakpoints() {
        final int size = breakpoints.size();
        breakpoints.clear();
        fireTableRowsDeleted(0, size - 1);
        control.clearBreakpoints();
    }

    /**
     * Checks if a cell in the table is editable.
     *
     * @param row    The row index.
     * @param column The column index.
     * @return {@code true} if the cell is in the "Action" column, otherwise {@code false}.
     */
    @Override
    public boolean isCellEditable(int row, int column) {
        return column == 2; // Only the "Action" column is editable
    }

    /**
     * Returns the number of rows in the table.
     *
     * @return The number of breakpoints in the model.
     */
    @Override
    public int getRowCount() {
        return breakpoints.size();
    }

    /**
     * Returns the number of columns in the table.
     *
     * @return The number of columns (3: Class, Line, Action).
     */
    @Override
    public int getColumnCount() {
        return 3;
    }

    /**
     * Retrieves the value of a specific cell in the table.
     *
     * @param rowIndex    The row index.
     * @param columnIndex The column index.
     * @return The value at the specified position, or {@code null} if out of bounds.
     */
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if (rowIndex < 0 || rowIndex >= breakpoints.size())
            return null;
        return switch (columnIndex) {
            case 0 -> ppp(breakpoints.get(rowIndex).getFileId());
            case 1 -> breakpoints.get(rowIndex).getLine();
            case 2 -> ACTION;
            default -> null;
        };
    }

    private String ppp(int fileId) {
        final FileMetaInfo fileMetaInfo = control.getMetaInfo().getFileMetaInfo(fileId);
        return fileMetaInfo == null ? "<missing file>" : fileMetaInfo.getRelativeFilePath();
    }

    /**
     * Retrieves the column name based on the column index.
     *
     * @param column The column index.
     * @return The name of the column.
     */
    @Override
    public String getColumnName(int column) {
        return switch (column) {
            case 0 -> CLASS;
            case 1 -> LINE;
            case 2 -> ACTION;
            default -> null;
        };
    }

    /**
     * Returns the class type for a specific column.
     *
     * @param columnIndex The column index.
     * @return The class type of the column.
     */
    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return switch (columnIndex) {
            case 0 -> String.class;
            case 1 -> Integer.class;
            case 2 -> JButton.class;
            default -> null;
        };
    }

    /**
     * Handles a {@link BreakpointEvent} by adding or removing the breakpoint to the table.
     *
     * @param event The event containing the added ore removed breakpoint.
     */
    @Override
    public void receivedEvent(BreakpointEvent event) {
        if (event.add()) {
            if (breakpoints.contains(event.breakpoint())) return;
            breakpoints.add(event.breakpoint());
            fireTableRowsInserted(breakpoints.size() - 1, breakpoints.size() - 1);
        }
        else {
            final int row = breakpoints.indexOf(event.breakpoint());
            if (row >= 0)
                removeRow(row);
        }
    }

    @Override
    public void receivedEvent(DebugeeStateEvent event) {
        // do nothing
    }
}
