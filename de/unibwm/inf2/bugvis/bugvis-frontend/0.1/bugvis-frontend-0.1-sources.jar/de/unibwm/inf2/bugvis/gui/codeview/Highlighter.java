package de.unibwm.inf2.bugvis.gui.codeview;

import de.unibwm.inf2.bugvis.model.Position;
import org.fife.ui.rtextarea.RTextScrollPane;

import javax.swing.SwingUtilities;
import javax.swing.text.BadLocationException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.HashMap;
import java.util.Map;

public abstract class Highlighter {
    private static final Logger LOGGER = System.getLogger(Highlighter.class.getName());
    private final Map<Integer, Map<Position, Object>> filePositionTagMap = new HashMap<>();
    private final CodeView codeView;

    protected Highlighter(CodeView codeView) {this.codeView = codeView;}

    public void addHighlight(Position position) {invoke(() -> innerAddHighlight(position));}

    private void innerAddHighlight(Position position) {
        final int fileId = position.fileId();
        final Map<Position, Object> positionTagMap = getPositionTagMap(fileId);
        if (positionTagMap.containsKey(position)) return;

        try {
            final Object tag = localHighlight(position);
            positionTagMap.put(position, tag);
        }
        catch (BadLocationException e) {
            LOGGER.log(Level.INFO, e);
        }
    }

    public void setHighlight(Position position) {invoke(() -> innerSetHighlight(position));}

    private void innerSetHighlight(Position position) {
        final int fileId = position.fileId();
        final Map<Position, Object> positionTagMap = getPositionTagMap(fileId);
        if (!positionTagMap.containsKey(position) || positionTagMap.size() != 1) {
            innerClearHighlight(fileId);
            innerAddHighlight(position);
        }
    }

    public void clearHighlight(int fileId) {invoke(() -> innerClearHighlight(fileId));}

    private void innerClearHighlight(int fileId) {
        final Map<Position, Object> positionTagMap = getPositionTagMap(fileId);
        for (Map.Entry<Position, Object> entry : positionTagMap.entrySet())
            innerRemove(entry.getKey());
        filePositionTagMap.computeIfAbsent(fileId, k -> new HashMap<>()).clear();
    }

    public void removeHighlight(Position position) {
        invoke(() -> {
            innerRemove(position);
            filePositionTagMap.computeIfAbsent(position.fileId(), k -> new HashMap<>()).remove(position);
        });
    }

    private void innerRemove(Position position) {
        final int fileId = position.fileId();
        final Map<Position, Object> positionTagMap = getPositionTagMap(fileId);
        final Object tag = positionTagMap.get(position);
        if (tag != null)
            localRemove(fileId, tag);
    }

    private void invoke(Runnable runnable) {SwingUtilities.invokeLater(runnable);}

    private Map<Position, Object> getPositionTagMap(int fileId) {
        return filePositionTagMap.computeIfAbsent(fileId, k -> new HashMap<>());
    }

    protected RTextScrollPane getPane(int fileId) {return codeView.getPaneMap().get(fileId);}

    protected abstract Object localHighlight(Position pos) throws BadLocationException;

    protected abstract void localRemove(int fileId, Object tag);
}
