package de.unibwm.inf2.bugvis.gui.stackframe;

import de.unibwm.inf2.bugvis.model.Field;

import javax.swing.tree.TreeNode;
import java.util.Comparator;
import java.util.List;

public class ClassNode extends InnerNode {

    private final List<Field> fields;

    public ClassNode(Class<?> clazz, List<Field> fields, TreeNode parent) {
        super(clazz, clazz.getName(), parent);
        this.fields = fields;
    }

    @Override
    public int getChildCount() {return fields.size();}

    @Override
    void fill(List<TreeNode> children) {
        fields.stream()
              .sorted(Comparator.comparing(Field::getIdentifier))
              .forEach(a -> children.add(createNode(a)));
    }

    private TreeNode createNode(Field field) {
        if (field.getValue() == null)
            return new Leaf(field.getName() + ":" + field.getType() + "=null", this);
        return field.getValue().accept(new TreeNodeValueVisitor(field, this));
    }
}
