package de.unibwm.inf2.bugvis.gui.stackframe;

import de.unibwm.inf2.bugvis.model.value.MapValue;
import de.unibwm.inf2.bugvis.model.value.Value;

import javax.swing.tree.TreeNode;
import java.util.List;
import java.util.Map;

import static java.lang.String.format;

/**
 * A MapNode displays a Java object that implements the interface Map.
 * For each element of the map, a node will be created which contains the overview of the element as
 * well as the values of the key and value of the map-element.
 */
public class MapNode extends InnerNode {
    private final MapValue map;

    MapNode(String text, MapValue map, TreeNode parent) {
        super(map, text, parent);
        this.map = map;
    }

    void fill(List<TreeNode> children) {
        Map<Value, Value> mirrorObjects = map.getComponentMirrorObjects();
        mirrorObjects.forEach((k, v) -> children.add(createOverviewNode(k, v)));
    }

    /**
     * Creates an Overview Node which holds the description of the Map-element that is being displayed.
     * It is an inner node which contains the keys and values of the map as children nodes.
     *
     * @param key   key of the map
     * @param value value of the map
     * @return A new InnerNode object which contains the information of one element in the map.
     */
    private InnerNode createOverviewNode(Value key, Value value) {
        final StringBuilder sb = new StringBuilder();

        if (key.isNullValue())
            sb.append("null");
        else
            sb.append(key.getObject().toString());

        if (value.isNullValue())
            sb.append(" : null");
        else
            sb.append(" : " + value.getObject().toString());

        final String overviewString = format("<font color='gray'> %s </font>", sb);

        MapNode that = this;
        return new InnerNode(key, overviewString, that) {
            private final int nodes = 2;

            @Override
            void fill(List<TreeNode> children) {
                children.add(createNode("key", key));
                children.add(createNode("value", value));
            }

            /**
             * Returns the number of child nodes this Node has. In the case of a InnerNode which is part of a
             * MapNode, the number of children should be equal to two, i.e., one key-child, one value-child.
             *
             * @return The number of children of this InnerNode.
             */
            @Override
            public int getChildCount() {
                return nodes;
            }
        };
    }

    /**
     * Creates a simple TreeNode with a specified {@code prefix} a {@code value}
     *
     * @param prefix text to use as a prefix.
     * @param value  value to display.
     * @return
     */
    private TreeNode createNode(String prefix, Value value) {
        if (value == null)
            return new Leaf(null + " : null", this);

        return value.accept(new TreeNodeValueVisitor(null, this) {
            @Override
            protected String prefix() {
                return "<font color='gray'>" + prefix + "</font>" + ": ";
            }
        });
    }

    /**
     *
     * @return
     */
    public Object getValue() {
        return map;
    }

    /**
     * Returns the size of the map containing the mirror objects in the {@code map} value
     *
     * @return
     */
    @Override
    public int getChildCount() {
        return map.getSize();
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        //TODO: Mark oder Kim fragen worum es geht?
        return "<html>" + text + getMapOriginalName() + "</html>";
    }

    /**
     * It replaces the string <i>Facade</i> from the simple name of a class.
     *
     * @return the simple name of a class without the string <i>Facade</i>
     */
    private String getMapOriginalName() {
        return map.getClazz().getSimpleName().replace("Facade", "");
    }
}
