package de.unibwm.inf2.bugvis.gui.stackframe;

import javax.swing.tree.TreeNode;
import java.util.Collections;
import java.util.Enumeration;
import java.util.NoSuchElementException;

class Leaf implements TreeNode {
    private final String text;
    private final TreeNode parent;

    Leaf(String text, TreeNode parent) {
        this.text = text;
        this.parent = parent;
    }

    @Override
    public TreeNode getChildAt(int childIndex) {
        return null;
    }

    @Override
    public int getChildCount() {
        throw new NoSuchElementException();
    }

    @Override
    public TreeNode getParent() {
        return parent;
    }

    @Override
    public int getIndex(TreeNode node) {
        return -1;
    }

    @Override
    public boolean getAllowsChildren() {
        return false;
    }

    @Override
    public boolean isLeaf() {
        return true;
    }

    @Override
    public Enumeration<? extends TreeNode> children() {
        return Collections.emptyEnumeration();
    }

    @Override
    public String toString() {return "<html>" + text + "</html>";}
}
