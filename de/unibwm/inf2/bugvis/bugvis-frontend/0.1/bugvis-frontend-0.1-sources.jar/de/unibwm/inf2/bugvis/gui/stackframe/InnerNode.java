package de.unibwm.inf2.bugvis.gui.stackframe;

import javax.swing.tree.TreeNode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

abstract class InnerNode implements TreeNode {
    final String text;
    private final TreeNode parent;
    private final Object key;
    private List<TreeNode> children;

    InnerNode(Object key, String text, TreeNode parent) {
        this.text = text;
        this.key = key;
        this.parent = parent;
    }

    abstract void fill(List<TreeNode> children);

    public Object getKey() {
        return key;
    }

    @Override
    public TreeNode getChildAt(int childIndex) {
        expand();
        return children.get(childIndex);
    }

    @Override
    public TreeNode getParent() {
        return parent;
    }

    @Override
    public int getIndex(TreeNode node) {
        expand();
        return children.indexOf(node);
    }

    @Override
    public boolean getAllowsChildren() {
        return true;
    }

    @Override
    public boolean isLeaf() {
        return false;
    }

    @Override
    public Enumeration<? extends TreeNode> children() {
        expand();
        return Collections.enumeration(children);
    }

    @Override
    public String toString() {return "<html>" + text + "</html>";}

    private void expand() {
        if (children != null) return;
        children = new ArrayList<>(getChildCount());
        fill(children);
    }
}
