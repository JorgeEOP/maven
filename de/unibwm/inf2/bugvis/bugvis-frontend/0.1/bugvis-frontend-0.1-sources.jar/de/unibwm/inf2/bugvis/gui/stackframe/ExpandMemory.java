package de.unibwm.inf2.bugvis.gui.stackframe;

import javax.swing.JTree;
import javax.swing.tree.TreePath;
import java.util.HashSet;
import java.util.Set;

public class ExpandMemory {
    private final JTree stackFrameTree;
    private final Set<KeyPath> expanded = new HashSet<>();

    public ExpandMemory(JTree tree) {
        this.stackFrameTree = tree;
        for (int i = 0; i < stackFrameTree.getRowCount(); i++) {
            final TreePath path = stackFrameTree.getPathForRow(i);
            if (stackFrameTree.isExpanded(path))
                expanded.add(new KeyPath(path));
        }
    }

    /**
     * For all the rows in the {@code stackFrameTree}, it expands each row if it exists in the
     * {@code expandedNodes} dictionary and its value is set to true.
     */
    public void expandPaths() {
        for (int i = 0; i < stackFrameTree.getRowCount(); i++) {
            final TreePath path = stackFrameTree.getPathForRow(i);
            if (expanded.contains(new KeyPath(path)))
                stackFrameTree.expandPath(path);
        }
    }
}
