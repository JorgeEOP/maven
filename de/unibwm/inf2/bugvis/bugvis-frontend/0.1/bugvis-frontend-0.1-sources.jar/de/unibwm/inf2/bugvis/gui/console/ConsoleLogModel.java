package de.unibwm.inf2.bugvis.gui.console;

import de.unibwm.inf2.bugvis.model.history.OutputStreamCmd.OutputType;

import javax.swing.AbstractListModel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ConsoleLogModel extends AbstractListModel<StyledLine> {
    private final Object lock = new Object();
    private final ArrayList<LineData> lines = new ArrayList<>();

    private final Map<Integer, StyledLine> cache = new LinkedHashMap<>(256, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<Integer, StyledLine> eldest) {return size() > 2000;}
    };

    private final Timer eventTimer;
    private int changedFrom = Integer.MAX_VALUE;
    private int changedTo = -1;
    private int addedFrom = Integer.MAX_VALUE;
    private int addedTo = -1;

    public ConsoleLogModel() {
        eventTimer = new Timer(25, e -> flushPendingEvents());
        eventTimer.setRepeats(false);
    }

    @Override
    public int getSize() {
        synchronized (lock) {
            return lines.size();
        }
    }

    @Override
    public StyledLine getElementAt(int index) {
        synchronized (lock) {
            if (index < 0 || index >= lines.size())
                return new StyledLine("", OutputType.DEFAULT);

            StyledLine cached = cache.get(index);
            if (cached != null)
                return cached;

            LineData line = lines.get(index);
            StyledLine styled = new StyledLine(line.materialize(), line.type);
            cache.put(index, styled);
            return styled;
        }
    }

    public void appendChunk(StyledLine chunk) {
        if (chunk == null || chunk.text() == null || chunk.text().isEmpty())
            return;

        int localChanged = -1;
        int localAddedFrom = -1;
        int localAddedTo = -1;

        synchronized (lock) {
            String s = chunk.text();
            OutputType type = chunk.outputType();

            int pos = 0;
            boolean firstSegment = true;

            while (pos < s.length()) {
                int nl = s.indexOf('\n', pos);
                boolean hasNl = nl >= 0;
                String segment = hasNl ? s.substring(pos, nl) : s.substring(pos);

                boolean appendToLast =
                        firstSegment &&
                        !lines.isEmpty() &&
                        lines.getLast().open &&
                        lines.getLast().type == type;

                if (appendToLast) {
                    LineData last = lines.getLast();
                    if (!segment.isEmpty())
                        last.addPart(segment);
                    last.open = !hasNl;
                    localChanged = lines.size() - 1;
                }
                else if (!segment.isEmpty() || hasNl) {
                    LineData line = new LineData(type);
                    if (!segment.isEmpty())
                        line.addPart(segment);
                    line.open = !hasNl;
                    lines.add(line);

                    int idx = lines.size() - 1;
                    if (localAddedFrom == -1)
                        localAddedFrom = idx;
                    localAddedTo = idx;
                }

                pos = hasNl ? nl + 1 : s.length();
                firstSegment = false;
            }

            int invalidateFrom = Integer.MAX_VALUE;
            if (localChanged >= 0) invalidateFrom = Math.min(invalidateFrom, localChanged);
            if (localAddedFrom >= 0) invalidateFrom = Math.min(invalidateFrom, localAddedFrom);
            if (invalidateFrom != Integer.MAX_VALUE)
                cacheRemoveAboveIndex(invalidateFrom);

            if (localChanged >= 0) {
                changedFrom = Math.min(changedFrom, localChanged);
                changedTo = Math.max(changedTo, localChanged);
            }
            if (localAddedFrom >= 0) {
                addedFrom = Math.min(addedFrom, localAddedFrom);
                addedTo = Math.max(addedTo, localAddedTo);
            }
        }

        scheduleFlush();
    }

    public void appendChunks(List<StyledLine> chunks) {
        if (chunks == null || chunks.isEmpty())
            return;
        for (StyledLine chunk : chunks)
            appendChunk(chunk);
    }

    public void truncateTailChars(int charCount) {
        if (charCount <= 0)
            return;

        int removedFrom = -1;
        int removedTo = -1;
        int changedLine = -1;

        synchronized (lock) {
            if (lines.isEmpty())
                return;

            int remaining = charCount;

            while (remaining > 0 && !lines.isEmpty()) {
                int lastIndex = lines.size() - 1;
                LineData last = lines.get(lastIndex);

                if (remaining >= last.length) {
                    remaining -= last.length;
                    lines.remove(lastIndex);

                    if (removedFrom == -1) {
                        removedFrom = lastIndex;
                        removedTo = lastIndex;
                    }
                    else
                        removedFrom = lastIndex;
                }
                else {
                    last.removeTailChars(remaining);
                    last.open = true;
                    changedLine = lastIndex;
                    remaining = 0;
                }
            }

            if (lines.isEmpty())
                cache.clear();
            else {
                int invalidateFrom = Integer.MAX_VALUE;
                if (changedLine >= 0) invalidateFrom = Math.min(invalidateFrom, changedLine);
                if (removedFrom >= 0) invalidateFrom = Math.min(invalidateFrom, removedFrom);
                if (invalidateFrom != Integer.MAX_VALUE)
                    cacheRemoveAboveIndex(invalidateFrom);
            }

            if (!lines.isEmpty())
                lines.getLast().open = true;

            changedFrom = Integer.MAX_VALUE;
            changedTo = -1;
            addedFrom = Integer.MAX_VALUE;
            addedTo = -1;
        }

        stopPendingTimer();

        if (removedFrom >= 0) {
            final int rf = removedFrom;
            final int rt = removedTo;
            runOnEdt(() -> fireIntervalRemoved(this, rf, rt));
        }

        if (changedLine >= 0) {
            final int cl = changedLine;
            runOnEdt(() -> fireContentsChanged(this, cl, cl));
        }
    }

    public void truncateToLines(int newLineCount) {
        if (newLineCount < 0)
            newLineCount = 0;

        int removedFrom;
        int removedTo;

        synchronized (lock) {
            int oldSize = lines.size();
            if (newLineCount >= oldSize)
                return;

            while (lines.size() > newLineCount)
                lines.removeLast();

            if (!lines.isEmpty())
                lines.getLast().open = true;

            cacheRemoveAboveIndex(newLineCount);

            removedFrom = newLineCount;
            removedTo = oldSize - 1;

            changedFrom = Integer.MAX_VALUE;
            changedTo = -1;
            addedFrom = Integer.MAX_VALUE;
            addedTo = -1;
        }

        stopPendingTimer();

        final int rf = removedFrom;
        final int rt = removedTo;
        runOnEdt(() -> fireIntervalRemoved(this, rf, rt));
    }

    private void cacheRemoveAboveIndex(int index) {cache.keySet().removeIf(i -> i >= index);}

    public void clear() {
        int oldSize;

        synchronized (lock) {
            oldSize = lines.size();
            if (oldSize == 0)
                return;

            lines.clear();
            cache.clear();

            changedFrom = Integer.MAX_VALUE;
            changedTo = -1;
            addedFrom = Integer.MAX_VALUE;
            addedTo = -1;
        }

        stopPendingTimer();

        final int last = oldSize - 1;
        runOnEdt(() -> fireIntervalRemoved(this, 0, last));
    }

    public int getLineCount() {
        synchronized (lock) {
            return lines.size();
        }
    }

    public boolean isLastLineOpen() {
        synchronized (lock) {
            return !lines.isEmpty() && lines.getLast().open;
        }
    }

    public int getTotalCharCount() {
        synchronized (lock) {
            int total = 0;
            for (LineData line : lines)
                total += line.length;
            return total;
        }
    }

    private void scheduleFlush() {
        if (SwingUtilities.isEventDispatchThread()) {
            if (!eventTimer.isRunning())
                eventTimer.start();
        }
        else
            SwingUtilities.invokeLater(() -> {
                if (!eventTimer.isRunning()) {
                    eventTimer.start();
                }
            });
    }

    private void stopPendingTimer() {
        if (SwingUtilities.isEventDispatchThread())
            eventTimer.stop();
        else
            SwingUtilities.invokeLater(eventTimer::stop);
    }

    private void flushPendingEvents() {
        int cf;
        int ct;
        int af;
        int at;

        synchronized (lock) {
            cf = changedFrom;
            ct = changedTo;
            af = addedFrom;
            at = addedTo;

            changedFrom = Integer.MAX_VALUE;
            changedTo = -1;
            addedFrom = Integer.MAX_VALUE;
            addedTo = -1;
        }

        if (cf <= ct)
            fireContentsChanged(this, cf, ct);
        if (af <= at)
            fireIntervalAdded(this, af, at);
    }

    private void runOnEdt(Runnable r) {
        if (SwingUtilities.isEventDispatchThread())
            r.run();
        else
            SwingUtilities.invokeLater(r);
    }

    private static final class LineData {
        final OutputType type;
        final ArrayList<String> parts = new ArrayList<>();
        int length;
        boolean open = true;

        LineData(OutputType type) {this.type = type;}

        void addPart(String s) {
            if (s == null || s.isEmpty())
                return;
            parts.add(s);
            length += s.length();
        }

        void removeTailChars(int count) {
            int remaining = count;

            while (remaining > 0 && !parts.isEmpty()) {
                int lastIdx = parts.size() - 1;
                String last = parts.get(lastIdx);

                if (remaining >= last.length()) {
                    remaining -= last.length();
                    length -= last.length();
                    parts.remove(lastIdx);
                }
                else {
                    int keep = last.length() - remaining;
                    parts.set(lastIdx, last.substring(0, keep));
                    length -= remaining;
                    remaining = 0;
                }
            }
        }

        String materialize() {
            if (parts.isEmpty()) return "";
            if (parts.size() == 1) return parts.getFirst();

            StringBuilder sb = new StringBuilder(length);
            for (String p : parts)
                sb.append(p);
            return sb.toString();
        }
    }
}