package de.unibwm.inf2.bugvis.gui.stackframe;

import javax.swing.tree.TreeNode;

import static java.lang.String.format;

public class StringNode extends Leaf implements ToolTipAble {
    private final String string;

    StringNode(String name, String string, TreeNode parent) {
        super(format("%s\"%s\"<font color='gray'> (String)</font>", name, (string.length() > 17 ? string.substring(0, 17) + "..." : string)),
              parent);
        this.string = string;
    }

    @Override
    public int getChildCount() {return 0;}

    @Override
    public String getToolTipText() {return string;}
}
