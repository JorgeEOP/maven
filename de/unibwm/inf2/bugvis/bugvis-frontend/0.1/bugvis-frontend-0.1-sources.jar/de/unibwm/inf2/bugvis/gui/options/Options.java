package de.unibwm.inf2.bugvis.gui.options;

import de.unibwm.inf2.bugvis.control.ControlOptions;
import de.unibwm.inf2.bugvis.instr.metainfo.MetaInfo;
import org.kohsuke.args4j.Argument;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;
import org.kohsuke.args4j.ParserProperties;
import org.kohsuke.args4j.spi.RestOfArgumentsHandler;

import java.io.File;
import java.io.IOException;
import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Options implements ControlOptions {
    private static final Logger LOGGER = System.getLogger(Options.class.getName());

    private static final String H_OPT = "-h";
    private static final String LONG_H_OPT = "--help";
    private static final String X_OPT = "-x";
    private static final String LONG_X_OPT = "--external-debugger";
    private static final String S_OPT = "-s";
    private static final String LONG_S_OPT = "--source-dir";
    private static final String M_OPT = "-m";
    private static final String LONG_M_OPT = "--meta-info";
    private static final String DC_OPT = "-dc";
    private static final String LONG_DC_OPT = "--debugeeClass";
    private static final String DS_OPT = "-ds";
    private static final String LONG_DS_OPT = "--debugeeSignature";

    private static final String MAIN = "main(java.lang.String[])";
    private static final File META_INFO_FILE = new File("MetaInfo.json");
    private static final File ORI_SRC = new File("ori-src");

    @Option(name = DC_OPT,
            aliases = {LONG_DC_OPT},
            metaVar = "<debugee class name>",
            required = true,
            usage = "the name of the debugee class.")
    private String debugeeClassName;

    @Option(name = DS_OPT,
            aliases = {LONG_DS_OPT},
            metaVar = "<debugee signature>",
            usage = "the signature of the debugee method, if not main.")
    private String debugeeMethodSignature = MAIN;

    @Option(name = H_OPT,
            aliases = {LONG_H_OPT},
            help = true,
            usage = "prints this help text to the console.")
    private boolean helpOption;

    @Option(name = X_OPT,
            aliases = {LONG_X_OPT},
            usage = "use this when debugging this program, i.e., don't log toString methods.")
    private boolean externalDebuggerMode;

    @Option(name = S_OPT,
            aliases = {LONG_S_OPT},
            metaVar = "<directory>",
            usage = "directory containing the original (i.e., uninstrumented) source code.")
    private File oriSrcDir = ORI_SRC;

    @Option(name = M_OPT,
            aliases = {LONG_M_OPT},
            metaVar = "<json file>",
            usage = "file containing meta info created by the instrumenter.")
    private File metaInfoFile = META_INFO_FILE;

    @Argument(metaVar = "<list of arguments>",
            usage = "arguments passed to the debugee.",
            handler = RestOfArgumentsHandler.class)
    private List<String> arguments = new ArrayList<>();

    private MetaInfo metaInfo;

    public Options(String[] args) {
        ParserProperties props = ParserProperties.defaults()
                                                 .withShowDefaults(false)
                                                 .withUsageWidth(80);
        CmdLineParser parser = new CmdLineParser(this, props);
        try {
            parser.parseArgument(args);
        }
        catch (CmdLineException e) {
            System.out.println(e.getMessage());
            usage(parser);
            System.exit(1);
        }

        final boolean errors = checkOriDir() | checkMetaInfo();
        if (errors || getHelpOption())
            usage(parser);
        if (errors)
            System.exit(1);
    }

    private boolean checkMetaInfo() {
        try {
            metaInfo = MetaInfo.readMetaInfo(metaInfoFile);
        }
        catch (IOException e) {
            System.out.printf("Error reading metainfo file %s: %s%n",
                              metaInfoFile.getAbsolutePath(),
                              e.getMessage());
            return true;
        }
        return false;
    }

    private boolean checkOriDir() {
        if (!oriSrcDir.exists() || !oriSrcDir.isDirectory()) {
            System.out.printf("%s is not a directory.%n", oriSrcDir.getAbsolutePath());
            return true;
        }
        return false;
    }

    private static void usage(CmdLineParser parser) {
        System.out.println("Arguments: [options...] <list of arguments>");
        parser.printUsage(System.out);
        System.out.println();
    }

    public boolean getHelpOption() {return helpOption;}

    @Override
    public boolean getExternalDebuggerMode() {return externalDebuggerMode;}

    @Override
    public File getOriginalSourceDirectory() {return oriSrcDir;}

    @Override
    public MetaInfo getMetaInfo() {return metaInfo;}

    @Override
    public List<String> getArguments() {return Collections.unmodifiableList(arguments);}

    @Override
    public String getDebugeeClassName() {return debugeeClassName;}

    @Override
    public String getDebugeeMethodSignature() {return debugeeMethodSignature;}
}
