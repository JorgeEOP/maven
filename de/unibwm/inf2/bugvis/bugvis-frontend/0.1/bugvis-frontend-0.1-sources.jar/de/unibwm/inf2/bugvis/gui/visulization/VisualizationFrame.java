package de.unibwm.inf2.bugvis.gui.visulization;

import de.unibwm.inf2.bugvis.gui.BugVisFrame;
import de.unibwm.inf2.bugvis.gui.BugVisToolbar;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;

public class VisualizationFrame extends JFrame {
    private static final Logger LOGGER = System.getLogger(VisualizationFrame.class.getName());
    private final BugVisFrame bugVisFrame;
    private VisualizationPane visualizationPane;

    public VisualizationFrame(BugVisFrame bugVisFrame) {
        this.bugVisFrame = bugVisFrame;
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setPreferredSize(new Dimension(800, 600));
        setLocation((int) (bugVisFrame.getLocation().getX() + bugVisFrame.getWidth()),
                    (int) (bugVisFrame.getLocation().getY()));
        setLayout(new BorderLayout());
        addViewMenu();
        bugVisFrame.setVisualizationFrame(this);
    }

    private void addViewMenu() {
        final JMenu viewMenu = findMenu("View");
        if (viewMenu == null) {
            LOGGER.log(Level.WARNING, "No view menu found");
            return;
        }
        final JMenuItem openVisualizationsMenuItem = new JMenuItem("Open visualizations");
        openVisualizationsMenuItem.addActionListener(a -> setVisible(true));
        viewMenu.add(openVisualizationsMenuItem);
    }

    private JMenu findMenu(String name) {
        final JMenuBar menuBar = bugVisFrame.getJMenuBar();
        for (int i = 0; i < menuBar.getMenuCount(); i++) {
            final JMenu menu = menuBar.getMenu(i);
            if (name.equals(menu.getText()))
                return menu;
        }
        return null;
    }

    public VisualizationPane getVisualizationPane() {
        return visualizationPane;
    }

    public void setVisualizationPane(VisualizationPane visualizationPane) {
        if (this.visualizationPane != null)
            throw new IllegalStateException("DefaultVisualizationPane has already been set");
        this.visualizationPane = visualizationPane;
        add(visualizationPane, BorderLayout.CENTER);
        add(createToolBar(), BorderLayout.NORTH);
        bugVisFrame.getControl().getState().getVisualizationState().addListener(visualizationPane);
    }

    private BugVisToolbar createToolBar() {
        final BugVisToolbar toolBar = new BugVisToolbar();
        toolBar.setFloatable(false);
        toolBar.add(createVisualizationControl());
        visualizationPane.addControls(toolBar);
        return toolBar;
    }

    private JComboBox<?> createVisualizationControl() {
        final String[] choices = {"Big Step Visualization", "Stepwise Visualization"};
        final JComboBox<String> comboBox = new JComboBox<>(choices);
        comboBox.setMaximumSize(comboBox.getPreferredSize());
        comboBox.setEditable(false);
        comboBox.setSelectedIndex(visualizationPane.getBigStepVisualizations() ? 0 : 1);
        comboBox.addActionListener(e -> {
            final boolean bigStep = comboBox.getSelectedIndex() == 0;
            visualizationPane.setBigStepVisualizations(bigStep);
        });
        return comboBox;
    }
}
