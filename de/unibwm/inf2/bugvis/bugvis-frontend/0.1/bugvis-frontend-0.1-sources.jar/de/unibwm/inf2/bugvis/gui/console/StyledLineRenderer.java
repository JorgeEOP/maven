package de.unibwm.inf2.bugvis.gui.console;

import javax.swing.DefaultListCellRenderer;
import javax.swing.JLabel;
import javax.swing.JList;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;

public class StyledLineRenderer extends DefaultListCellRenderer {
    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                  boolean isSelected, boolean cellHasFocus) {
        JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        if (value instanceof StyledLine sl) {
            label.setText(sl.text());
            switch (sl.outputType()) {
                case DEFAULT -> {
                    label.setForeground(Color.BLACK);
                    label.setFont(list.getFont().deriveFont(Font.PLAIN));
                }
                case ERROR -> {
                    label.setForeground(Color.RED);
                    label.setFont(list.getFont().deriveFont(Font.PLAIN));
                }
                case INPUT -> {
                    label.setForeground(new Color(0, 128, 0));
                    label.setFont(list.getFont().deriveFont(Font.ITALIC | Font.BOLD));
                }
            }
        }
        return label;
    }
}
