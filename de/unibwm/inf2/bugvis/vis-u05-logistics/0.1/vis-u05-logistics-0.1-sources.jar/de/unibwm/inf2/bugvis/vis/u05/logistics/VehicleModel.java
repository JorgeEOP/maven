package de.unibwm.inf2.bugvis.vis.u05.logistics;

import de.unibwm.inf2.bugvis.model.VisualizationObject;

import java.awt.Color;
import java.util.List;

public class VehicleModel implements VisualizationObject {
    private final String name;
    private final int hashCode;
    private final List<Integer> storages;
    private final Color color;

    public VehicleModel(String name, int hashCode, List<Integer> storages, Color color) {
        this.name = name;
        this.hashCode = hashCode;
        this.storages = storages;
        this.color = color;
    }

    public int getHashCode() {return hashCode;}

    public String getName() {
        return name;
    }

    public List<Integer> getStorages() {return storages;}

    public Color getColor() {return color;}
}
