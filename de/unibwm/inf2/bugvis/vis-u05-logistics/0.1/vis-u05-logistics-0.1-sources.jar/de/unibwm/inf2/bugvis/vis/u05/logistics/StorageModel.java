package de.unibwm.inf2.bugvis.vis.u05.logistics;

import de.unibwm.inf2.bugvis.model.VisualizationObject;

import java.awt.Color;

public class StorageModel implements VisualizationObject {
    private final int hashCode;
    private final Color color;
    private final String name;
    private boolean isFloatStorageModel = false;
    private int intStored;
    private float floatStored;

    public StorageModel(String name, int intStored, int hashCode, Color color) {
        this.hashCode = hashCode;
        this.intStored = intStored;
        this.color = color;
        this.name = name;
    }

    public StorageModel(String name, float floatStored, int hashCode, Color color) {
        isFloatStorageModel = true;
        this.hashCode = hashCode;
        this.floatStored = floatStored;
        this.color = color;
        this.name = name;
    }

    public boolean isFloatStorageModel() {
        return isFloatStorageModel;
    }

    public int getIntStored() {
        return intStored;
    }

    public float getFloatStored() {
        return floatStored;
    }

    public int getHashCode() {
        return hashCode;
    }

    public Color getColor() {
        return color;
    }

    public String getName() {return name;}
}
