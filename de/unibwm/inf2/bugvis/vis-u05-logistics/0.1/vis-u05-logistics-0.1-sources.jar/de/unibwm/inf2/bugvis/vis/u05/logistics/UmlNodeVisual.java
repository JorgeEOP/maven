package de.unibwm.inf2.bugvis.vis.u05.logistics;

import com.yworks.yfiles.geometry.RectD;
import com.yworks.yfiles.view.IRenderContext;
import com.yworks.yfiles.view.IVisual;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

public class UmlNodeVisual implements IVisual {
    private final Color color;
    private final BasicStroke borderStroke;
    private RectD nodeLayout;
    private RectD nameLayout;

    UmlNodeVisual(Color color) {
        nodeLayout = RectD.EMPTY;
        nameLayout = RectD.EMPTY;
        borderStroke = new BasicStroke(2);
        this.color = color;
    }

    private static void adopt(Rectangle2D r, RectD bounds) {
        r.setFrame(bounds.getX(), bounds.getY(), bounds.getWidth(), bounds.getHeight());
    }

    private static void calcArea(RectD nl, RectD ll, Rectangle2D rect) {
        rect.setFrame(nl.getX(), nl.getY() + ll.getY(), nl.getWidth(), ll.getHeight());
    }

    @Override
    public void paint(IRenderContext context, Graphics2D g) {
        var rectangle = new Rectangle2D.Double();
        var graphics = (Graphics2D) g.create();

        // Paint area of the name.
        calcArea(nodeLayout, nameLayout, rectangle);
        graphics.setColor(color);
        graphics.setStroke(borderStroke);
        graphics.draw(rectangle);

        // Paint object rectangle borders.
        adopt(rectangle, nodeLayout);
        graphics.setColor(color);
        graphics.setStroke(borderStroke);
        graphics.draw(rectangle);
    }

    void setNodeLayout(RectD bounds) {
        this.nodeLayout = bounds;
    }

    void setNameLayout(RectD bounds) {
        this.nameLayout = bounds;
    }
}
