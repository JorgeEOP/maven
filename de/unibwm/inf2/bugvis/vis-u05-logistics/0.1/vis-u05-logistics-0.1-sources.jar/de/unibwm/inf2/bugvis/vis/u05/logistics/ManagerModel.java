package de.unibwm.inf2.bugvis.vis.u05.logistics;

import de.unibwm.inf2.bugvis.model.VisualizationObject;

import java.awt.Color;
import java.util.List;

public class ManagerModel implements VisualizationObject {
    private final String name;
    private final int hashCode;
    private final List<Integer> vehicles;
    private final Color color;

    public ManagerModel(String name, int hashCode, List<Integer> vehicles, Color color) {
        this.name = name;
        this.hashCode = hashCode;
        this.vehicles = vehicles;
        this.color = color;
    }

    public String getName() {
        return name;
    }

    public List<Integer> getVehicles() {
        return vehicles;
    }

    public int getHashCode() {
        return hashCode;
    }

    public Color getColor() {return color;}
}
