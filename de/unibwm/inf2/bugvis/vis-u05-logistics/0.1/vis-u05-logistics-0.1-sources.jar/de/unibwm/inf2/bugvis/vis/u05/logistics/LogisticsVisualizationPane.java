package de.unibwm.inf2.bugvis.vis.u05.logistics;

import com.yworks.yfiles.geometry.RectD;
import com.yworks.yfiles.geometry.SizeD;
import com.yworks.yfiles.graph.GraphItemTypes;
import com.yworks.yfiles.graph.IGraph;
import com.yworks.yfiles.graph.ILabel;
import com.yworks.yfiles.graph.INode;
import com.yworks.yfiles.layout.ILayoutAlgorithm;
import com.yworks.yfiles.layout.hierarchic.HierarchicLayout;
import com.yworks.yfiles.view.GraphComponent;
import com.yworks.yfiles.view.input.GraphViewerInputMode;
import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.control.events.SelectEvent;
import de.unibwm.inf2.bugvis.gui.visulization.AbstractYFilesVisualizationPane;
import de.unibwm.inf2.bugvis.model.VisualizationObject;
import de.unibwm.inf2.bugvis.model.notification.visualize.StartVisualizationEvent;
import de.unibwm.inf2.bugvis.model.notification.visualize.StopVisualizationEvent;
import de.unibwm.inf2.bugvis.model.notification.visualize.UpdateVisualizationEvent;
import de.unibwm.inf2.bugvis.model.notification.visualize.VisualizationBigStepEvent;
import de.unibwm.inf2.bugvis.model.notification.visualize.VisualizeEventListener;

import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.lang.System.Logger;
import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.CountDownLatch;

import static java.lang.System.Logger.Level.DEBUG;
import static java.lang.System.Logger.Level.INFO;

public class LogisticsVisualizationPane extends AbstractYFilesVisualizationPane implements VisualizeEventListener {
    private static final Logger LOGGER = System.getLogger(LogisticsVisualizationPane.class.getName());
    private static final int MIN_WIDTH = 30;
    private static final int NODE_SIZE_DELTA = 5;
    private static final int PANE_WIDTH = 100;
    private static final int PANE_HEIGHT = 100;

    // YFiles Components
    private final GraphComponent graphComponent;
    private final ILayoutAlgorithm layoutAlgorithm;
    private final GraphViewerInputMode inputMode;
    // event management
    private final Deque<Runnable> smallStepQueue = new ArrayDeque<>();
    private final EventHandler eventHandler;

    public LogisticsVisualizationPane(DebugControl control) {
        this(control, new HierarchicLayout());
    }

    public LogisticsVisualizationPane(DebugControl control, ILayoutAlgorithm layoutAlgorithm) {
        this.layoutAlgorithm = layoutAlgorithm;

        control.addSelectListener(this);
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(PANE_WIDTH, PANE_HEIGHT));

        graphComponent = new GraphComponent();
        inputMode = initializeInputMode();

        graphComponent.setInputMode(inputMode);
        add(graphComponent, BorderLayout.CENTER);

        final IGraph graph = graphComponent.getGraph();
        graph.addLabelAddedListener((o, e) -> updateNodeSize(e.getItem()));
        graph.addLabelPreferredSizeChangedListener((o, e) -> updateNodeSize(e.getItem()));

        eventHandler = makeEventHandlers(control, graph);
    }

    private static ManagerEventHandler makeEventHandlers(DebugControl control, IGraph graph) {
        final EventHandler lastEventHandler = new LastEventHandler();
        final EventHandler storageEventHandler = new StorageEventHandler(control, graph, lastEventHandler);
        final EventHandler vehicleEventHandler = new VehicleEventHandler(control, graph, storageEventHandler);
        return new ManagerEventHandler(control, graph, vehicleEventHandler);
    }

    private GraphViewerInputMode initializeInputMode() {
        final GraphViewerInputMode input = new GraphViewerInputMode();

        input.setToolTipItems(GraphItemTypes.LABEL_OWNER);
        input.setClickableItems(GraphItemTypes.NODE);
        input.setFocusableItems(GraphItemTypes.NODE);
        input.setSelectableItems(GraphItemTypes.NODE);
        input.setMarqueeSelectableItems(GraphItemTypes.NODE);
        return input;
    }

    private void updateNodeSize(ILabel label) {
        final double width = label.getPreferredSize().getWidth() + NODE_SIZE_DELTA;
        SizeD size = new SizeD(MIN_WIDTH, MIN_WIDTH);
        if (width > MIN_WIDTH) size = new SizeD(width, width);
        if (label.getOwner() instanceof INode node)
            graphComponent.getGraph().setNodeLayout(node, RectD.fromCenter(node.getLayout().getCenter(), size));
    }

    @Override
    public void receivedEvent(StartVisualizationEvent ev, CountDownLatch count) {
        final VisualizationObject vo = ev.getVisualizationObject();
        processSmallStep(() -> invoke(() -> eventHandler.createNode(vo)), count);
    }

    @Override
    public void receivedEvent(StopVisualizationEvent ev, CountDownLatch count) {
        final VisualizationObject vo = ev.getVisualizationObject();
        processSmallStep(() -> invoke(() -> eventHandler.removeNode(vo)), count);
    }

    @Override
    public void receivedEvent(UpdateVisualizationEvent ev, CountDownLatch count) {
        final VisualizationObject newVO = ev.getNewVisualizationObject();
        final VisualizationObject oldVO = ev.getOldVisualizationObject();
        processSmallStep(() -> invoke(() -> eventHandler.updateVisualization(oldVO, newVO)), count);
    }

    @Override
    public void receivedEvent(VisualizationBigStepEvent event, CountDownLatch count) {
        if (smallStepQueue.isEmpty())
            count.countDown();
        else {
            LOGGER.log(INFO, "visualizationBigStepEvent received, start smallStepQueue ...");
            while (!smallStepQueue.isEmpty())
                smallStepQueue.poll().run();
            LOGGER.log(INFO, "... start smallStepQueue finished");
            applyLayout(count);
        }
    }

    private void processSmallStep(Runnable smallStep, CountDownLatch count) {
        if (getBigStepVisualizations()) {
            smallStepQueue.addLast(smallStep);
            count.countDown();
        }
        else {
            while (!smallStepQueue.isEmpty())
                smallStepQueue.poll().run();
            smallStep.run();
            applyLayout(count);
        }
    }

    private void applyLayout(CountDownLatch count) {
        invoke(() -> {
            LOGGER.log(DEBUG, "apply Layout");
            graphComponent.morphLayout(layoutAlgorithm, Duration.of(100, ChronoUnit.MILLIS))
                          .thenRun(count::countDown)
                          .thenRun(() -> LOGGER.log(INFO, "layout applied."));
        });
    }

    @Override
    public void computeLayout() {
        invoke(() -> graphComponent.getGraph().applyLayout(layoutAlgorithm));
    }

    private void invoke(Runnable runnable) {SwingUtilities.invokeLater(runnable);}

    @Override
    public void receivedEvent(SelectEvent event) {
        invoke(() -> select(event));
    }

    private void select(SelectEvent event) {
        for (INode o : eventHandler.allNodes())
            inputMode.setSelected(o, false);
        final INode node = eventHandler.getNode(event.getHashCode());
        inputMode.setSelected(node, true);
    }

    @Override
    public GraphComponent getGraphComponent() {
        return graphComponent;
    }
}
