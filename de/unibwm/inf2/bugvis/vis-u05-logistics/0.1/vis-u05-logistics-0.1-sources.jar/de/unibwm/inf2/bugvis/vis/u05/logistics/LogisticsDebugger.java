package de.unibwm.inf2.bugvis.vis.u05.logistics;

import com.yworks.yfiles.layout.hierarchic.HierarchicLayout;
import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.vis.u05.logistics.plugins.ManagerPlugin;
import de.unibwm.inf2.bugvis.vis.u05.logistics.plugins.StoragePlugin;
import de.unibwm.inf2.bugvis.vis.u05.logistics.plugins.VehiclePlugin;
import de.unibwm.inf2.bugvis.gui.BugVisFrame;
import de.unibwm.inf2.bugvis.gui.options.Options;
import de.unibwm.inf2.bugvis.gui.visulization.VisualizationFrame;

import javax.swing.SwingUtilities;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.System.Logger;
import java.util.logging.LogManager;

import static java.lang.System.Logger.Level.DEBUG;
import static java.lang.System.Logger.Level.ERROR;

public class LogisticsDebugger {
    private static final String LOGGING_PROPERTIES = "app-logging.properties";
    private static final String TITLE = "BugVis (U05: Logistics)";

    static {
        Logger logger;
        try {
            LogManager.getLogManager().readConfiguration(new FileInputStream(LOGGING_PROPERTIES));
            logger = System.getLogger(LogisticsDebugger.class.getName());
            logger.log(DEBUG, "Successfully read logging properties"); //NON-NLS
        }
        catch (IOException e) {
            logger = System.getLogger(LogisticsDebugger.class.getName());
            logger.log(ERROR, e::getMessage);
        }
    }

    public static void main(String[] args) {
        final Options options = new Options(args);
        final DebugControl control = new DebugControl(options);
        control.useDefaultInstrumentationRuntime();
        control.getPluginControl().addPlugin(new ManagerPlugin(), new VehiclePlugin(), new StoragePlugin());
        BugVisFrame.initUI();
        SwingUtilities.invokeLater(() -> {
            final BugVisFrame frame = new BugVisFrame(control);
            frame.setTitle(TITLE);
            frame.pack();
            frame.setVisible(true);
            final VisualizationFrame visFrame = new VisualizationFrame(frame);
            visFrame.setTitle(TITLE + " Visualization");
            final HierarchicLayout layouter = new HierarchicLayout();
            layouter.setIntegratedEdgeLabelingEnabled(true);  // länge der Kanten zu den Labels passt.
            visFrame.setVisualizationPane(new LogisticsVisualizationPane(control, layouter));
            visFrame.pack();
            visFrame.setVisible(true);
            control.runDebugee();
        });
    }
}