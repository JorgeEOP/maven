package de.unibwm.inf2.bugvis.vis.u05.logistics.plugins;

import de.unibwm.inf2.bugvis.control.Plugin;
import de.unibwm.inf2.bugvis.vis.u05.logistics.StorageModel;
import logistics.StorageInterface;
import logistics.storage.FloatStorageInterface;
import logistics.storage.IntStorageInterface;

import java.awt.Color;
import java.lang.System.Logger;

import static java.awt.Color.BLACK;
import static java.awt.Color.RED;

public class StoragePlugin implements Plugin<StorageInterface, StorageModel> {
    private static final Logger LOGGER = System.getLogger(StoragePlugin.class.getName());

    @Override
    public boolean isApplicable(Object object) {
        return (object instanceof IntStorageInterface || object instanceof FloatStorageInterface);
    }

    @Override
    public StorageModel createModel(StorageInterface storage) {
        class Extractor extends Plugin.AbstractExtractor<StorageModel> {
            String name = "";
            int intStored = 0;
            float floatStored = 0f;

            public StorageModel create() {
                extract(() -> {
                    if (storage instanceof IntStorageInterface intStorage)
                        intStored = intStorage.getStored();
                    if (storage instanceof FloatStorageInterface floatStorage)
                        floatStored = floatStorage.getStored();
                });
                extract(() -> name = (storage.getName() != null) ? storage.getName() : "");
                final Color color = getError() ? RED : BLACK;
                if (storage instanceof IntStorageInterface intStorage)
                    return new StorageModel(name, intStored, System.identityHashCode(intStorage), color);
                else if (storage instanceof FloatStorageInterface floatStorage)
                    return new StorageModel(name, floatStored, System.identityHashCode(floatStorage), color);
                else
                    throw new IllegalArgumentException("Storage is not a IntStorageInterface or FloatStorageInterface");
            }
        }

        return new Extractor().create();
    }

    @Override
    public boolean hasToBeDeleted(Object object, String signature) {return false;}
}
