package de.unibwm.inf2.bugvis.vis.u05.logistics.plugins;

import de.unibwm.inf2.bugvis.control.Plugin;
import de.unibwm.inf2.bugvis.vis.u05.logistics.VehicleModel;
import logistics.StorageInterface;
import logistics.VehicleInterface;

import java.awt.Color;
import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.List;

import static java.awt.Color.BLACK;
import static java.awt.Color.RED;

public class VehiclePlugin implements Plugin<VehicleInterface, VehicleModel> {
    public static final String EXCEPTION_OCCURRED = "Unexpected exception occurred";
    private static final Logger LOGGER = System.getLogger(VehiclePlugin.class.getName());

    @Override
    public boolean isApplicable(Object object) {
        return (object instanceof VehicleInterface);
    }

    @Override
    public VehicleModel createModel(VehicleInterface vehicle) {
        class Extractor extends Plugin.AbstractExtractor<VehicleModel> {
            final List<Integer> storages = new ArrayList<>();
            String name = "";

            public VehicleModel create() {
                extract(() -> name = (vehicle.getName() != null) ? vehicle.getName() : "");
                extract(() -> {
                    if (vehicle.getStorages() != null)
                        for (StorageInterface storage : vehicle.getStorages()) {
                            storages.add(System.identityHashCode(storage));
                        }
                    else
                        throw new IllegalArgumentException("Invalid Object");
                });
                final Color color = getError() ? RED : BLACK;
                return new VehicleModel(name, System.identityHashCode(vehicle), storages, color);
            }
        }

        return new Extractor().create();
    }

    @Override
    public boolean hasToBeDeleted(Object object, String signature) {return false;}
}
