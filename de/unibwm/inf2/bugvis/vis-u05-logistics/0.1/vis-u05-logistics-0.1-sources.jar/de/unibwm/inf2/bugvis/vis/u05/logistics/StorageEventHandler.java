package de.unibwm.inf2.bugvis.vis.u05.logistics;

import com.yworks.yfiles.geometry.PointD;
import com.yworks.yfiles.geometry.RectD;
import com.yworks.yfiles.geometry.SizeD;
import com.yworks.yfiles.graph.IGraph;
import com.yworks.yfiles.graph.ILabel;
import com.yworks.yfiles.graph.INode;
import com.yworks.yfiles.graph.labelmodels.FreeNodeLabelModel;
import com.yworks.yfiles.graph.labelmodels.ILabelModelParameter;
import com.yworks.yfiles.graph.styles.DefaultLabelStyle;
import com.yworks.yfiles.graph.styles.HtmlLabelStyle;
import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.model.VisualizationObject;
import de.unibwm.inf2.bugvis.model.value.Value;

import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.lang.System.Logger.Level.DEBUG;
import static java.lang.System.Logger.Level.INFO;

class StorageEventHandler implements EventHandler {
    public static final String STORED = "stored = ";
    public static final String NAME_STRING = "name = ";
    static final Logger LOGGER = System.getLogger(StorageEventHandler.class.getName());
    private static final double PADDING_X = 5d;
    private static final double CLASS_ATTRIBUTE_DISTANCE = 7d;
    private static final double DISTANCE_BETWEEN_ATTRIBUTES = 2d;
    private final IGraph graph;
    // References between StorageInterfaces and INodes
    private final Map<Integer, INode> storagesMap = new HashMap<>();
    private final EventHandler nextEventHandler;
    private final DebugControl control;

    StorageEventHandler(DebugControl control, IGraph graph, EventHandler nextEventHandler) {
        this.control = control;
        this.graph = graph;
        this.nextEventHandler = nextEventHandler;
    }

    @Override
    public void createNode(VisualizationObject visualizationObject) {
        if (visualizationObject instanceof StorageModel sm)
            createStorageNode(sm);
        else
            nextEventHandler.createNode(visualizationObject);
    }

    @Override
    public void updateVisualization(VisualizationObject oldVisualizationObject, VisualizationObject newVisualizationModel) {
        if (oldVisualizationObject instanceof StorageModel oldStorageModel &&
            newVisualizationModel instanceof StorageModel newStorageModel)
            updateStorageVisualization(oldStorageModel, newStorageModel);
        else
            nextEventHandler.updateVisualization(oldVisualizationObject, newVisualizationModel);
    }

    @Override
    public void removeNode(VisualizationObject vo) {
        if (vo instanceof StorageModel sm)
            removeStorageVisualization(sm);
        else
            nextEventHandler.removeNode(vo);
    }

    private void createStorageNode(StorageModel storageModel) {
        LOGGER.log(INFO, "Create Node for StorageModel: ( {0} )", storageModel.getHashCode());
        final INode node = graph.createNode(new RectD(0, 0, 0, 0), new UmlNodeStyle(storageModel.getColor()));
        addAttributeLabels(node, storageModel);
        updateNodeLayout(node);

        storagesMap.put(storageModel.getHashCode(), node);
        LOGGER.log(DEBUG, "Node created. nodesMap::keySet: {0}",
                   storagesMap.keySet().stream().map(System::identityHashCode).toList());
    }

    private void updateStorageVisualization(StorageModel oldStorageModel, StorageModel newStorageModel) {
        LOGGER.log(INFO, "Updating visualization of Storage: ( {0} )", oldStorageModel.getHashCode());
        final INode node = storagesMap.get(oldStorageModel.getHashCode());
        if (node == null)
            throw new IllegalArgumentException("Storage Node does not exist!");
        updateNodeColor(node, newStorageModel);
        removeNodeLabels(node);
        addAttributeLabels(node, newStorageModel);
        final SizeD size = LogisticsPaneRenderer.getNewNodeSize(node);
        final RectD rectD = new RectD(node.getLayout().getX(), node.getLayout().getY(), size.getWidth(), size.getHeight());
        graph.setNodeLayout(node, rectD);
    }

    private void removeStorageVisualization(StorageModel sm) {
        LOGGER.log(INFO, "Remove Node for " + sm.getHashCode());
        final INode iNode = storagesMap.remove(sm.getHashCode());
        if (iNode != null && graph.contains(iNode))
            graph.remove(iNode);
        else
            LOGGER.log(Level.INFO, "Node for given object not found!");
    }

    private void addAttributeLabels(INode node, StorageModel model) {
        final List<String> labels = new ArrayList<>();

        //Object class name
        final Value mirrorObject = control.getState().getMirrorObject(model.getHashCode());
        labels.add("<html><u>" + ": " + mirrorObject.getClazz().getSimpleName() + "</u></html>");

        //Attribute "name" of the Models
        final String name = model.getName();

        labels.add(NAME_STRING + "\"" + name + "\"");

        if (model.isFloatStorageModel()) {
            labels.add(STORED + model.getFloatStored());
        }
        else {
            labels.add(STORED + model.getIntStored());
        }

        addLabelsToNode(node, labels);
    }

    private void updateNodeLayout(INode node) {
        final SizeD size = LogisticsPaneRenderer.getNewNodeSize(node);
        graph.setNodeLayout(node, new RectD(node.getLayout().getX(), node.getLayout().getY(), size.getWidth(), size.getHeight()));
    }

    private void updateNodeColor(INode node, StorageModel model) {
        final UmlNodeStyle style = (UmlNodeStyle) node.getStyle();
        style.setColor(model.getColor());
    }

    private void addLabelsToNode(INode node, List<String> labels) {
        var model = new FreeNodeLabelModel();
        var yOffset = 0d;

        // LayoutRatio: reference point in the node Layout. LayoutOffset: offset of the label. LabelRatio: anchor point of the label
        // Task: Center the objectNameModel
        final ILabelModelParameter objectNameModel = model.createParameter(new PointD(0.5, 0.0), // layoutRatio
                                                                     new PointD(0.0, yOffset), // layoutOffset
                                                                     new PointD(0.5, 0.0)); // labelRatio
        //
        ILabelModelParameter attributeModel;

        // Class Name
        ILabel iLabel = graph.addLabel(node, labels.getFirst(), objectNameModel, new HtmlLabelStyle());

        // Attributes
        yOffset += iLabel.getLayout().getHeight() + CLASS_ATTRIBUTE_DISTANCE;
        for (var i = 1; i < labels.size(); i++) {
            attributeModel = model.createParameter(new PointD(0, 0), new PointD(PADDING_X, yOffset), new PointD(0, 0));
            iLabel = graph.addLabel(node, labels.get(i), attributeModel, new DefaultLabelStyle());
            yOffset += iLabel.getLayout().getHeight() + DISTANCE_BETWEEN_ATTRIBUTES;
        }
    }

    private void removeNodeLabels(INode node) {
        var labels = node.getLabels();
        for (var i = labels.size() - 1; i >= 0; i--) {
            graph.remove(labels.getItem(i));
        }
    }

    @Override
    public INode getNode(int nodeHashCode) {
        final INode node = storagesMap.get(nodeHashCode);
        return (node == null) ? nextEventHandler.getNode(nodeHashCode) : node;
    }

    @Override
    public List<INode> allNodes() {
        final List<INode> nodes = nextEventHandler.allNodes();
        nodes.addAll(storagesMap.values());
        return nodes;
    }
}
