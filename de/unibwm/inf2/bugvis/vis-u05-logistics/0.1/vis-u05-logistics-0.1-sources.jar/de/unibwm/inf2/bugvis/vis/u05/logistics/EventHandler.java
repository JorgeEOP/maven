package de.unibwm.inf2.bugvis.vis.u05.logistics;

import com.yworks.yfiles.graph.INode;
import de.unibwm.inf2.bugvis.model.VisualizationObject;

import java.util.List;

interface EventHandler {
    List<INode> allNodes();

    void createNode(VisualizationObject visualizationObject);

    void updateVisualization(VisualizationObject oldVisualizationModel, VisualizationObject newVisualizationModel);

    void removeNode(VisualizationObject vo);

    INode getNode(int nodeHashCode);
}
