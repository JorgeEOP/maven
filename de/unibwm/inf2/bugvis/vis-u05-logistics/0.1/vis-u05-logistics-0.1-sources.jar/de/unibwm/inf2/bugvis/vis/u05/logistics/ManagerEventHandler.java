package de.unibwm.inf2.bugvis.vis.u05.logistics;

import com.yworks.yfiles.geometry.PointD;
import com.yworks.yfiles.geometry.RectD;
import com.yworks.yfiles.geometry.SizeD;
import com.yworks.yfiles.graph.IEdge;
import com.yworks.yfiles.graph.IGraph;
import com.yworks.yfiles.graph.ILabel;
import com.yworks.yfiles.graph.INode;
import com.yworks.yfiles.graph.labelmodels.EdgePathLabelModel;
import com.yworks.yfiles.graph.labelmodels.EdgeSides;
import com.yworks.yfiles.graph.labelmodels.FreeNodeLabelModel;
import com.yworks.yfiles.graph.labelmodels.ILabelModelParameter;
import com.yworks.yfiles.graph.styles.DefaultLabelStyle;
import com.yworks.yfiles.graph.styles.HtmlLabelStyle;
import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.model.VisualizationObject;
import de.unibwm.inf2.bugvis.model.value.ReferenceValue;
import de.unibwm.inf2.bugvis.model.value.Value;

import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static java.lang.System.Logger.Level.DEBUG;
import static java.lang.System.Logger.Level.INFO;

class ManagerEventHandler implements EventHandler {
    public static final String NAME_STRING = "name = ";
    private static final Logger LOGGER = System.getLogger(ManagerEventHandler.class.getName());
    private static final double PADDING_X = 5d;
    private static final double CLASS_ATTRIBUTE_DISTANCE = 7d;
    private static final double DISTANCE_BETWEEN_ATTRIBUTES = 2d;
    private final IGraph graph;
    // References between ManagerInterfaces and INodes
    private final Map<Integer, INode> managerMap = new HashMap<>();
    private final DebugControl control;
    private final EventHandler nextEventHandler;

    ManagerEventHandler(DebugControl control, IGraph graph, EventHandler nextEventHandler) {
        this.control = control;
        this.graph = graph;
        this.nextEventHandler = nextEventHandler;
    }

    @Override
    public void createNode(VisualizationObject visualizationObject) {
        if (visualizationObject instanceof ManagerModel mm)
            createManagerNode(mm);
        else
            nextEventHandler.createNode(visualizationObject);
    }

    @Override
    public void updateVisualization(VisualizationObject oldVisualizationModel, VisualizationObject newVisualizationModel) {
        if (oldVisualizationModel instanceof ManagerModel oldManagerModel &&
            newVisualizationModel instanceof ManagerModel newManagerModel)
            updateManagerVisualization(oldVisualizationModel, oldManagerModel, newManagerModel);
        else
            nextEventHandler.updateVisualization(oldVisualizationModel, newVisualizationModel);
    }

    @Override
    public void removeNode(VisualizationObject vo) {
        if (vo instanceof ManagerModel managerModel)
            removeManagerVisualization(managerModel);
        else
            nextEventHandler.removeNode(vo);
    }

    private void createManagerNode(ManagerModel managerModel) {
        LOGGER.log(INFO, "Create Node for ManagerModel: ( {0} )", managerModel);
        final INode node = graph.createNode(new RectD(0, 0, 0, 0), new UmlNodeStyle(managerModel.getColor()));
        addAttributeLabels(node, managerModel);
        updateNodeLayout(node);

        managerMap.put(managerModel.getHashCode(), node);
        LOGGER.log(DEBUG, "Node created. nodesMap::keySet: {0}",
                   managerMap.keySet().stream().map(System::identityHashCode).toList());
    }

    private void updateManagerVisualization(VisualizationObject oldVisualizationModel, ManagerModel oldManagerModel, ManagerModel newManagerModel) {
        LOGGER.log(INFO, "Updating visualization of Manager with id: ( {0} )", oldVisualizationModel.getHashCode());
        final INode node = managerMap.get(oldVisualizationModel.getHashCode());
        if (node == null)
            throw new IllegalArgumentException("Manager Node does not exist!");
        updateNodeColor(node, newManagerModel);
        removeNodeLabels(node);
        addAttributeLabels(node, newManagerModel);
        updateNodeLayout(node);
        updateRelationships(oldManagerModel, newManagerModel);
    }

    private void removeManagerVisualization(ManagerModel managerModel) {
        LOGGER.log(INFO, "Remove Node for " + managerModel.getHashCode());
        final INode iNode = managerMap.remove(managerModel.getHashCode());
        if (iNode != null && graph.contains(iNode))
            graph.remove(iNode);
        else
            LOGGER.log(Level.INFO, "Node for given object not found!");
    }

    private void updateRelationships(ManagerModel oldManagerModel, ManagerModel newManagerModel) {
        final List<Integer> oldVehicles = new ArrayList<>(oldManagerModel.getVehicles());
        final List<Integer> newVehicles = new ArrayList<>(newManagerModel.getVehicles());

        // alle alte Kanten entfernen.
        oldVehicles.forEach(v -> {
            var mNode = managerMap.get(newManagerModel.getHashCode());
            var vNode = nextEventHandler.getNode(v);

            final IEdge edge = graph.getEdge(mNode, vNode);
            if (edge != null)
                graph.remove(edge);
        });

        // füge alle neue Beziehungen hinzu
        newVehicles.forEach(v -> {
            var managerNode = managerMap.get(newManagerModel.getHashCode());
            var vehicleNode = nextEventHandler.getNode(v);
            final IEdge edge = graph.createEdge(managerNode, vehicleNode, UmlEdgeStyle.createUmlEdgeStyle());
            setEdgeLabel(edge, newManagerModel);
        });
    }

    private void setEdgeLabel(IEdge edge, ManagerModel model) {
        final Value mirrorObject = control.getState().getMirrorObject(model.getHashCode());
        String varName = "";

        if (mirrorObject.getObject() != null) {
            var fields = ((ReferenceValue) mirrorObject).getFields();
            for (var field : fields) {
                if (Objects.equals(field.getType(), "List<Vehicle&gt"))
                    varName = field.getName();
            }
        }

        final EdgePathLabelModel labelParameter = new EdgePathLabelModel(0, 0, 0, true, EdgeSides.ABOVE_EDGE);
        graph.addLabel(edge, varName, labelParameter.createDefaultParameter(), new DefaultLabelStyle());
    }

    private void addAttributeLabels(INode node, ManagerModel model) {
        final List<String> labels = new ArrayList<>();

        //Object class name
        final Value mirrorObject = control.getState().getMirrorObject(model.getHashCode());
        labels.add("<html><u>" + ": " + mirrorObject.getClazz().getSimpleName() + "</u></html>");

        //Attribute "name" of the Models
        final String name = model.getName();

        labels.add(NAME_STRING + "\"" + name + "\"");
        addLabelsToNode(node, labels);
    }

    private void updateNodeLayout(INode node) {
        final SizeD size = LogisticsPaneRenderer.getNewNodeSize(node);
        graph.setNodeLayout(node, new RectD(node.getLayout().getX(), node.getLayout().getY(), size.getWidth(), size.getHeight()));
    }

    private void updateNodeColor(INode node, ManagerModel model) {
        final UmlNodeStyle style = (UmlNodeStyle) node.getStyle();
        style.setColor(model.getColor());
    }

    private void addLabelsToNode(INode node, List<String> labels) {
        var model = new FreeNodeLabelModel();
        var yOffset = 0d;

        // LayoutRatio: reference point in the node Layout. LayoutOffset: offset of the label. LabelRatio: anchor point of the label
        // Task: Center the objectNameModel
        final ILabelModelParameter objectNameModel = model.createParameter(new PointD(0.5, 0.0), // layoutRatio
                                                                           new PointD(0.0, yOffset), // layoutOffset
                                                                           new PointD(0.5, 0.0)); // labelRatio
        //
        ILabelModelParameter attributeModel;

        // Class Name
        ILabel iLabel = graph.addLabel(node, labels.getFirst(), objectNameModel, new HtmlLabelStyle());

        // Attributes
        yOffset += iLabel.getLayout().getHeight() + CLASS_ATTRIBUTE_DISTANCE;
        for (var i = 1; i < labels.size(); i++) {
            attributeModel = model.createParameter(new PointD(0, 0), new PointD(PADDING_X, yOffset), new PointD(0, 0));
            iLabel = graph.addLabel(node, labels.get(i), attributeModel, new DefaultLabelStyle());
            yOffset += iLabel.getLayout().getHeight() + DISTANCE_BETWEEN_ATTRIBUTES;
        }
    }

    private void removeNodeLabels(INode node) {
        var labels = node.getLabels();
        for (var i = labels.size() - 1; i >= 0; i--) {
            graph.remove(labels.getItem(i));
        }
    }

    @Override
    public INode getNode(int nodeHashCode) {
        final INode node = managerMap.get(nodeHashCode);
        return (node == null) ? nextEventHandler.getNode(nodeHashCode) : node;
    }

    @Override
    public List<INode> allNodes() {
        final List<INode> nodes = nextEventHandler.allNodes();
        nodes.addAll(managerMap.values());
        return nodes;
    }
}
