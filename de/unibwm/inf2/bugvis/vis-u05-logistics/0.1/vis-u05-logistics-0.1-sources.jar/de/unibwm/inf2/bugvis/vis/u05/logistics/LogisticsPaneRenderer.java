package de.unibwm.inf2.bugvis.vis.u05.logistics;

import com.yworks.yfiles.geometry.SizeD;
import com.yworks.yfiles.graph.ILabel;
import com.yworks.yfiles.graph.INode;

class LogisticsPaneRenderer {
    static final double X_NODE_PADDING = 10.0;
    static final double Y_NODE_PADDING = 10.0;

    private LogisticsPaneRenderer() {
        //Do not instantiate
    }

    // Man muss die richtige Große des Knotes berechnen. Das heißt, die minimale Große um alle Attribute sowie Methoden
    // im Knoten hineinzupassen.
    public static SizeD getNewNodeSize(INode node) {
        var layout = node.getLayout();

        // Top left of the node
        var minX = layout.getX();
        var minY = layout.getY();
        // Max values for x and y of the node
        var maxX = 0d;
        var maxY = 0d;

        var labels = node.getLabels();
        for (ILabel label : labels) {
            var labelLayout = label.getLayout();
            maxX = Math.max(maxX, labelLayout.getAnchorX() + labelLayout.getWidth());
            maxY = labelLayout.getAnchorY();  //bottom left
        }

        return new SizeD(maxX - minX + X_NODE_PADDING, maxY - minY + Y_NODE_PADDING);
    }
}
