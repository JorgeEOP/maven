package de.unibwm.inf2.bugvis.vis.u05.logistics.plugins;

import de.unibwm.inf2.bugvis.control.Plugin;
import de.unibwm.inf2.bugvis.vis.u05.logistics.ManagerModel;
import logistics.ManagerInterface;
import logistics.VehicleInterface;

import java.awt.Color;
import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.List;

import static java.awt.Color.BLACK;
import static java.awt.Color.RED;

public class ManagerPlugin implements Plugin<ManagerInterface, ManagerModel> {
    private static final Logger LOGGER = System.getLogger(ManagerPlugin.class.getName());

    @Override
    public boolean isApplicable(Object object) {
        return object instanceof ManagerInterface;
    }

    @Override
    public ManagerModel createModel(ManagerInterface manager) {
        class Extractor extends AbstractExtractor<ManagerModel> {
            final List<Integer> vehicles = new ArrayList<>();
            String name = "";

            public ManagerModel create() {
                extract(() -> name = (manager.getName() != null) ? manager.getName() : "");
                extract(() -> {
                    if (manager.getVehicles() != null) {
                        for (VehicleInterface vehicle : manager.getVehicles()) {
                            vehicles.add(System.identityHashCode(vehicle));
                        }
                    }
                    else
                        throw new IllegalArgumentException("Invalid Object");
                });
                final Color color = getError() ? RED : BLACK;
                return new ManagerModel(name, System.identityHashCode(manager), vehicles, color);
            }
        }

        return new Extractor().create();
    }

    @Override
    public boolean hasToBeDeleted(Object object, String signature) {return false;}
}
