package de.unibwm.inf2.bugvis.vis.u05.logistics;

import com.yworks.yfiles.graph.styles.ArcEdgeStyle;
import com.yworks.yfiles.graph.styles.IArrow;
import com.yworks.yfiles.view.Pen;

import java.awt.Color;

public class UmlEdgeStyle {
    private static final Color EDGE_COLOR = Color.BLACK;

    private UmlEdgeStyle() {}

    public static ArcEdgeStyle createUmlEdgeStyle() {
        final ArcEdgeStyle arcEdgeStyle = new ArcEdgeStyle();
        arcEdgeStyle.setPen(createEdgePen());
        arcEdgeStyle.setTargetArrow(IArrow.TRIANGLE);
        return arcEdgeStyle;
    }

    private static Pen createEdgePen() {
        final Pen edgePen = new Pen();
        edgePen.setPaint(EDGE_COLOR);
        edgePen.setThickness(2);
        return edgePen;
    }
}
