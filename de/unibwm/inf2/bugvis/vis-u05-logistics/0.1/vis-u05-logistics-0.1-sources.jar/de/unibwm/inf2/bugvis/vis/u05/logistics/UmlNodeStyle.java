package de.unibwm.inf2.bugvis.vis.u05.logistics;

import com.yworks.yfiles.geometry.RectD;
import com.yworks.yfiles.graph.ILabel;
import com.yworks.yfiles.graph.INode;
import com.yworks.yfiles.graph.styles.AbstractNodeStyle;
import com.yworks.yfiles.view.IRenderContext;
import com.yworks.yfiles.view.IVisual;

import java.awt.Color;

public class UmlNodeStyle extends AbstractNodeStyle {

    private Color color;

    UmlNodeStyle(Color color) {
        this.color = color;
    }

    @Override
    protected IVisual createVisual(IRenderContext iRenderContext, INode node) {
        var layout = new RectD(node.getLayout().getTopLeft(), node.getLayout().toSizeD());

        var visual = new UmlNodeVisual(color);
        visual.setNodeLayout(layout);

        ILabel labelLayout = node.getLabels().first();
        var maxY = labelLayout.getLayout().getHeight();  //bottom left
        visual.setNameLayout(new RectD(0, 0, 0, maxY));

        return visual;
    }

    public void setColor(Color color) {
        this.color = color;
    }
}
