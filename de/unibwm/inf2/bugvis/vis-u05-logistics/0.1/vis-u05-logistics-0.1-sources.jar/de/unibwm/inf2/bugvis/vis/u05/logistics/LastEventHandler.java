package de.unibwm.inf2.bugvis.vis.u05.logistics;

import com.yworks.yfiles.graph.INode;
import de.unibwm.inf2.bugvis.model.VisualizationObject;

import java.util.ArrayList;
import java.util.List;

public class LastEventHandler implements EventHandler {
    @Override
    public List<INode> allNodes() {
        return new ArrayList<>();
    }

    @Override
    public void createNode(VisualizationObject vo) {
        throw new UnsupportedOperationException("Unsupported event type: " + vo);
    }

    @Override
    public void updateVisualization(VisualizationObject oldVO, VisualizationObject newVO) {
        throw new UnsupportedOperationException("Unsupported event type: " + oldVO);
    }

    @Override
    public void removeNode(VisualizationObject vo) {
        throw new UnsupportedOperationException("Unsupported event type: " + vo);
    }

    @Override
    public INode getNode(int nodeHashCode) {
        throw new UnsupportedOperationException("Non existent node " + nodeHashCode);
    }
}
