package logistics.storage;

import logistics.quantities.IntUnit;
import logistics.quantities.NeedCollector;

public class IntStorage implements IntStorageInterface {
    private final IntUnit unit;
    private final int max;
    private final String name;
    private int stored;

    public IntStorage(String name, int stored, IntUnit unit, int max) {
        if (stored < 0)
            throw new IllegalArgumentException("negative stored " + unit + ": " + stored);
        if (max < 0)
            throw new IllegalArgumentException("negative max " + unit + ": " + max);
        this.unit = unit;
        this.stored = Math.min(max, stored);
        this.max = max;
        this.name = name;
    }

    public IntUnit getUnit() {
        return unit;
    }

    public int getStored() {
        return stored;
    }

    public int getMax() {
        return max;
    }

    public int consume(int amount) {
        if (amount < 0)
            throw new IllegalArgumentException("negative " + unit + " consume of " + amount + " not allowed");
        final int result = Math.min(amount, stored);
        stored -= result;
        return result;
    }

    public void fillUp() {
        stored = max;
    }

    public void fill(int amount) {
        if (amount < 0)
            throw new IllegalArgumentException("negative " + unit + " fill of " + amount + " not allowed");
        stored = Math.min(max, stored + amount);
    }

    public void reportNeed(NeedCollector collector) {
        collector.add(max - stored, unit);
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "storage with " + stored + " of " + max + " " + unit;
    }
}
