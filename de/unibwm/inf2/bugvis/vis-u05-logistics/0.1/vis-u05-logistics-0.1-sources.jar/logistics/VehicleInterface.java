package logistics;

import java.util.List;

public interface VehicleInterface {
    String getName();

    List<StorageInterface> getStorages();
}
