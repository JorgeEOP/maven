package logistics.storage;

import logistics.quantities.FloatUnit;
import logistics.quantities.NeedCollector;

public class FloatStorage implements FloatStorageInterface {
    private final FloatUnit unit;
    private final float max;
    private final String name;
    private float stored;

    public FloatStorage(String name, float stored, FloatUnit unit, float max) {
        if (stored < 0)
            throw new IllegalArgumentException("negative " + unit + ": " + stored);
        if (max < 0)
            throw new IllegalArgumentException("negative max " + unit + ": " + max);
        this.unit = unit;
        this.stored = Math.min(max, stored);
        this.max = max;
        this.name = name;
    }

    public FloatUnit getUnit() {
        return unit;
    }

    public float getStored() {
        return stored;
    }

    public float getMax() {
        return max;
    }

    public float consume(float amount) {
        if (amount < 0)
            throw new IllegalArgumentException("negative " + unit + " consume of " + amount + " not allowed");
        final float result = Math.min(amount, stored);
        stored -= result;
        return result;
    }

    public void fillUp() {
        stored = max;
    }

    public void fill(float amount) {
        if (amount < 0)
            throw new IllegalArgumentException("negative " + unit + " fill of " + amount + " not allowed");
        stored = Math.min(max, stored + amount);
    }

    public void reportNeed(NeedCollector collector) {
        collector.add(max - stored, unit);
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "storage with " + stored + " of " + max + " " + unit;
    }
}
