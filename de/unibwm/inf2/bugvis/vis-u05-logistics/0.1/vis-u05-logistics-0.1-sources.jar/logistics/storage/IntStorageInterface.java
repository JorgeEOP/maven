package logistics.storage;

import logistics.StorageInterface;

public interface IntStorageInterface extends StorageInterface {
    int getStored();
}
