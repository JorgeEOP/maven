package logistics;

public interface StorageInterface {
    String getName();
}
