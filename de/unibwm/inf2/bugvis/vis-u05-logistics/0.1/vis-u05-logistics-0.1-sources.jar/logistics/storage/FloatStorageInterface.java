package logistics.storage;

import logistics.StorageInterface;

public interface FloatStorageInterface extends StorageInterface {
    float getStored();
}
