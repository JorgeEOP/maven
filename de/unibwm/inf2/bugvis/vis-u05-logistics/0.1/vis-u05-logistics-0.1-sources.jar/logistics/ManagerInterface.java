package logistics;

import java.util.List;

public interface ManagerInterface {
    String getName();

    List<VehicleInterface> getVehicles();
}
