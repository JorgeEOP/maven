package logistics.quantities;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class NeedCollector {
    private final Map<FloatUnit, Float> floatNeeded = new HashMap<>();
    private final Map<IntUnit, Integer> intNeeded = new HashMap<>();

    public void add(int amount, IntUnit unit) {
        final Integer needed = intNeeded.get(unit);
        intNeeded.put(unit, needed == null ? amount : needed + amount);
    }

    public void add(float amount, FloatUnit unit) {
        final Float needed = floatNeeded.get(unit);
        floatNeeded.put(unit, needed == null ? amount : needed + amount);
    }

    public void show() {
        for (Entry<IntUnit, Integer> entry : intNeeded.entrySet())
            System.out.printf("- %d %s%n", entry.getValue(), entry.getKey());
        for (Entry<FloatUnit, Float> entry : floatNeeded.entrySet())
            System.out.printf("- %.2f %s%n", entry.getValue(), entry.getKey());
    }

    public int getNeed(IntUnit unit) {
        final Integer needed = intNeeded.get(unit);
        return needed == null ? 0 : needed;
    }

    public float getNeed(FloatUnit unit) {
        final Float needed = floatNeeded.get(unit);
        return needed == null ? 0 : needed;
    }
}
