package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.VisualizationObject;
import de.unibwm.inf2.bugvis.model.notification.visualize.StartVisualizationEvent;
import de.unibwm.inf2.bugvis.model.notification.visualize.StopVisualizationEvent;

public class StopVisualizationCmd extends Command {

    private final Object object;
    private final VisualizationObject oldVisualizationObject;

    public StopVisualizationCmd(ProgramState state, Object object) {
        super(state);
        this.object = object;
        this.oldVisualizationObject = state.getVisualizationState().get(System.identityHashCode(object));
    }

    @Override
    protected void localExecute() {
        getState().getVisualizationState().remove(System.identityHashCode(object));
        StopVisualizationEvent event = new StopVisualizationEvent(oldVisualizationObject);
        getState().getVisualizationState().notifyListeners(event);
    }

    @Override
    protected void localUndo() {
        getState().getVisualizationState().add(oldVisualizationObject);
        StartVisualizationEvent event = new StartVisualizationEvent(oldVisualizationObject);
        getState().getVisualizationState().notifyListeners(event);
    }

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
