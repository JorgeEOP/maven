package de.unibwm.inf2.bugvis.model.notification.debugee;

public interface DebugeeEvent {
    void notifyListeners(DebugeeEventListener listener);
}
