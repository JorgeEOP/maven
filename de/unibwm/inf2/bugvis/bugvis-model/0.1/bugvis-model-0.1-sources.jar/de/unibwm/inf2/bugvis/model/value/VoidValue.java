package de.unibwm.inf2.bugvis.model.value;

/**
 * Represents no value.
 */
public class VoidValue extends Value {
    public static final VoidValue INSTANCE = new VoidValue();

    private VoidValue() {
        super(null, void.class);
    }

    @Override
    public String toString() {
        return "VoidValue{}";
    }

    @Override
    public VoidValue asVoidValue() {return this;}

    @Override
    public boolean isVoidValue() {return true;}

    public void accept(ValueVoidVisitor visitor) {visitor.visit(this);}

    public <R> R accept(ValueVisitor<R> visitor) {return visitor.visit(this);}
}
