package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.value.ArrayValue;
import de.unibwm.inf2.bugvis.model.value.Value;

/**
 * Represents an AssignVariableCommand
 */
public class AssignArrayCmd extends PositionCommand {
    /**
     * variable whose value is being changed
     */
    private final ArrayValue array;
    /**
     * index of the assigned array component
     */
    private final int idx;
    /**
     * old value
     */
    private final Value oldValue;
    /**
     * new value
     */
    private final Value newValue;

    /**
     * Creates a new AssignVarCmd with the given frame, variable and new value
     */
    public AssignArrayCmd(ProgramState state, Position position, boolean isFirstInLine, ArrayValue array, int idx, Value newValue) {
        super(state, position, isFirstInLine);
        this.array = array;
        this.idx = idx;
        this.oldValue = array.get(idx);
        this.newValue = newValue;
    }

    @Override
    protected void localExecute() {
        array.set(idx, newValue);
    }

    @Override
    protected void localUndo() {
        array.set(idx, oldValue);
    }

    public ArrayValue getArray() {return array;}

    public int getIndex() {return idx;}

    public Value getNewValue() {return newValue;}

    public Value getOldValue() {return oldValue;}

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
