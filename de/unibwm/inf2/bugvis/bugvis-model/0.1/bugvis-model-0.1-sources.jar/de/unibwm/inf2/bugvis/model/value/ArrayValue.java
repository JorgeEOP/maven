package de.unibwm.inf2.bugvis.model.value;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * A debug representation of an array.
 */
public class ArrayValue extends Value {

    /**
     * components of the array.
     */
    private final List<Value> componentMirrorObjects;

    /**
     * Creates a debug representation for an arbitrary array with the given debug representations of the components.
     */
    public ArrayValue(Object obj, List<Value> componentMirrorObjects) {
        super(obj, obj.getClass());
        Objects.requireNonNull(obj);
        this.componentMirrorObjects = componentMirrorObjects;
    }

    public Value get(int idx) {return componentMirrorObjects.get(idx);}

    public void set(int idx, Value value) {componentMirrorObjects.set(idx, value);}

    /**
     * Returns the number of components in this debug representation of an array.
     *
     * @return the number of components in this debug representation of an array.
     */
    public int getLength() {return this.componentMirrorObjects.size();}

    public List<Value> getComponentMirrorObjects() {
        return Collections.unmodifiableList(componentMirrorObjects);
    }

    /**
     * Returns a string representation of this {@link ArrayValue}.
     *
     * @return a string representation of this {@link ArrayValue}.
     */
    @Override
    public String toString() {
        return "ArrayValue{size=" + getLength() + ", components=" + componentMirrorObjects + "}";
    }

    @Override
    public ArrayValue asArrayValue() {return this;}

    @Override
    public boolean isArrayValue() {return true;}

    public void accept(ValueVoidVisitor visitor) {visitor.visit(this);}

    public <R> R accept(ValueVisitor<R> visitor) {return visitor.visit(this);}
}
