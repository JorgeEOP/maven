package de.unibwm.inf2.bugvis.model.notification.debugee;

import de.unibwm.inf2.bugvis.model.FieldIdentifier;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.DEBUG;

public class FieldAssignmentEvent implements DebugeeEvent {
    private static final Logger LOGGER = System.getLogger(FieldAssignmentEvent.class.getName());

    private final Object object;
    private final FieldIdentifier identifier;

    public FieldAssignmentEvent(Object object, FieldIdentifier identifier) {
        this.object = object;
        this.identifier = identifier;
    }

    @Override
    public void notifyListeners(DebugeeEventListener listener) {
        LOGGER.log(DEBUG, () -> "notify " + listener);
        listener.receivedEvent(this);
        LOGGER.log(DEBUG, () -> "listener was notified " + listener);
    }

    public FieldIdentifier getIdentifier() {return identifier;}

    public Object getObject() {return object;}
}
