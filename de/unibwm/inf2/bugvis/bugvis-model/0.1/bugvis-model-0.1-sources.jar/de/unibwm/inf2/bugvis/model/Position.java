package de.unibwm.inf2.bugvis.model;

import java.util.Comparator;

/**
 * Creates a position specified by the given parameters
 *
 * @param fileId    file id, see {@link de.unibwm.inf2.bugvis.instr.metainfo.MetaInfo}
 * @param firstLine first line
 * @param firstCol  first column of the first line
 * @param lastLine  last line
 * @param lastCol   last column of the last line
 */
public record Position(int fileId, int firstLine, int firstCol, int lastLine,
                       int lastCol) {

    public static final Comparator<Position> COMPARATOR = Comparator.comparing(Position::fileId)
                                                                    .thenComparing(Position::firstLine)
                                                                    .thenComparing(Position::firstCol)
                                                                    .thenComparing(Position::lastLine)
                                                                    .thenComparing(Position::lastCol);

    /**
     * Creates a position specified by the given parameters
     *
     * @param line     first and last line
     * @param firstCol first column of the line
     * @param lastCol  last column of the line
     */
    public Position(int line, int firstCol, int lastCol) {
        this(-1, line, firstCol, line, lastCol);
    }

    /**
     * @return a string representation of this position
     */
    @Override
    public String toString() {
        return "Position{" + firstLine +
               ":" + firstCol +
               " - " + lastLine +
               ":" + lastCol + '}';
    }
}
