package de.unibwm.inf2.bugvis.model;

import java.util.Collections;
import java.util.Iterator;
import java.util.NoSuchElementException;

/// Represents a callStack of a target
public class CallStack implements Iterable<StackFrame> {
    public final StackFrame baseFrame = new StackFrame(this,
                                                       new Method("dummy", Object.class, -1),
                                                       new Position(-1, -1, -1));
    private final ProgramState state;
    private StackFrame currentFrame = baseFrame;

    public CallStack(ProgramState state) {this.state = state;}

    public void setCurrentFrame(StackFrame frame) {
        if ((frame == null || frame.getParent() != currentFrame) &&
            (currentFrame == null || currentFrame.getParent() != frame))
            throw new IllegalArgumentException("Illegal stack frame " + frame);
        currentFrame = frame;
    }

    public String getClassName() {return currentFrame == null ? "" : currentFrame.getMethod().getClassName();}

    public StackFrame getCurrentFrame() {return currentFrame;}

    public ProgramState getState() {return state;}

    @Override
    public String toString() {
        StackFrame fr = currentFrame;
        StringBuilder str = new StringBuilder();
        while (fr != null && fr != baseFrame) {
            str.append(fr);
            fr = fr.getParent();
        }
        return str.toString();
    }

    @Override
    public Iterator<StackFrame> iterator() {
        if (currentFrame == baseFrame)
            return Collections.singletonList(baseFrame).iterator();
        return new Iterator<>() {
            StackFrame frame = currentFrame;

            @Override
            public boolean hasNext() {return frame != null && frame != baseFrame;}

            @Override
            public StackFrame next() {
                if (frame == null) throw new NoSuchElementException();
                StackFrame next = frame;
                frame = frame.getParent();
                return next;
            }
        };
    }
}
