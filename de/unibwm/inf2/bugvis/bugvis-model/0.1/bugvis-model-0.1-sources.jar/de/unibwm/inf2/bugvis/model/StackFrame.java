package de.unibwm.inf2.bugvis.model;

import de.unibwm.inf2.bugvis.instr.runtime.Parameter;
import de.unibwm.inf2.bugvis.model.value.Value;
import de.unibwm.inf2.bugvis.model.value.VoidValue;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Represents the StackFrame of a target
 */
public class StackFrame {
    /**
     * stackFrame by which this stackFrame was created
     */
    private final StackFrame parent;
    /**
     * The depth of this stack frame in the call stack
     */
    private final int depth;
    /**
     * callStack this frame is part of
     */
    private final CallStack callStack;
    /**
     * method of which a call is represented by this stackFrame
     */
    private final Method method;
    /**
     * local variable array of this stackFrame
     */
    private final Map<String, Variable> localVariables = new HashMap<>();

    private final Map<Position, Value> intermediateResults = new HashMap<>();
    /**
     * currentPosition of this stackFrame in the target
     */
    private Position position;
    /**
     * Field for the return value.
     */
    private Value returnValue = VoidValue.INSTANCE;
    /**
     * Field for the receiver parameter.
     */
    private Value receiverParameter = null;

    /**
     * Creates a new stackFrame with the given parameters
     *
     * @param callStack the stackFrame should belong to
     * @param method    of which a call is represented by this stackFrame
     * @param position  the current position in the original code.
     */
    public StackFrame(CallStack callStack, Method method, Position position) {
        this.callStack = callStack;
        this.parent = callStack.getCurrentFrame();
        this.method = method;
        this.position = position;
        this.depth = parent == null ? 0 : parent.depth + 1;
    }

    /**
     * Returns the depth of this stack frame in the call stack. Each stack frame (except the base frame)
     * has a positive depth.
     */
    public int getDepth() {
        return depth;
    }

    /**
     * Adds a given local Variable to the local variable array of this stackFrame
     *
     * @param localVariable The new local {@link de.unibwm.inf2.bugvis.model.Variable}.
     */
    public void addLocalVariable(Variable localVariable) {
        localVariables.put(localVariable.getName(), localVariable);
    }

    /**
     * Removes a local {@link de.unibwm.inf2.bugvis.model.Variable}.
     *
     * @param name The variable's name.
     */
    public void removeLocalVariable(String name) {
        localVariables.remove(name);
    }

    /**
     * Sets the return variable of this stackFrame to the given variable.
     *
     * @param value The new return value.
     */
    public void setReturn(Value value) {
        returnValue = value;
    }

    /**
     * Sets the position of this stackFrame to a given position
     *
     * @param position of the target
     */
    public void setPosition(Position position) {
        this.position = position;
    }

    /**
     * @param name
     * @return the local variable with the given name
     */
    public Variable getLocalVariable(String name) {
        return localVariables.get(name);
    }

    /**
     * @return the stackFrame by which this one was created
     */
    public StackFrame getParent() {
        return parent;
    }

    /**
     * @return the how many-th instance of this method is represented by this stackFrame
     */
    public int getMethodInstance() {
        int ctr = 0;
        StackFrame sf = this;
        while (sf != null) {
            ctr = (sf.getMethod().equals(this.method)) ? ctr + 1 : ctr;
            sf = sf.getParent();
        }
        return ctr;
    }

    /**
     * @return the method of this stackFrame
     */
    public Method getMethod() {
        return method;
    }

    /**
     * @return the local variable array of this stackFrame
     */
    public List<Variable> getLocalVariables() {
        return List.copyOf(localVariables.values());
    }

    /**
     * Returns the receiver parameter. Null if not set.
     *
     * @return the receiver parameter. Null if not set.
     */
    public Value getReceiverParameter() {return receiverParameter;}

    /**
     * Sets the receiver parameter of this Stackframe.
     *
     * @param receiverParameter The receiver Parameter to be set.
     */
    public void setReceiverParameter(Value receiverParameter) {
        this.receiverParameter = receiverParameter;
    }

    /**
     * @return the callStack containing this stackFrame
     */
    public CallStack getCallStack() {
        return callStack;
    }

    /**
     * @return the currentPosition of this stackFrame
     */
    public Position getPosition() {
        return position;
    }

    /**
     * @return a string representation of this stackFrame
     */
    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append("\n\tStackFrame{ method= ")
           .append(method)
           .append(" - ")
           .append(getMethodInstance())
           .append(" -, position= {")
           .append(position)
           .append("}, \n\t\tlocalVars= { ");
        for (Variable v : localVariables.values())
            str.append("\n\t\t\t").append(v);
        str.append("}}");

        return str.toString();
    }

    /**
     * Add parameters to this {@link de.unibwm.inf2.bugvis.model.StackFrame}.
     *
     * @param parameters The new {@link de.unibwm.inf2.bugvis.instr.runtime.Parameter}.
     */
    public void addParameters(List<Parameter> parameters) {
        for (Parameter p : parameters) {
            final Value mirrorObject = getCallStack().getState().getMirrorObject(p);
            final Variable v = new Variable(VarKind.ORDINARY_PARAMETER, p.getParamType(), p.getName(), mirrorObject);
            addLocalVariable(v);
        }
    }

    public void addIntermediateResult(Position position, Value mirrorObject) {
        intermediateResults.put(position, mirrorObject);
    }

    public void removeIntermediateResult(Position position) {intermediateResults.remove(position);}

    public Map<Position, Value> getIntermediateResults() {
        return Collections.unmodifiableMap(intermediateResults);
    }
}
