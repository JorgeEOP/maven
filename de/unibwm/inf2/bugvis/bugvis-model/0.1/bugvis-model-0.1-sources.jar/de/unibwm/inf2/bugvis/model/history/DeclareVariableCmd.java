package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.Variable;

/**
 * Represents a DeclareVariableCommand
 */
public class DeclareVariableCmd extends PositionCommand {
    /**
     * newly created variable
     */
    private final Variable variable;

    /**
     * Creates a new DeclareVarCmd with the given frame and new variable
     *
     * @param variable
     */
    public DeclareVariableCmd(ProgramState state, Position position, boolean isFirstInLine, Variable variable) {
        super(state, position, isFirstInLine);
        this.variable = variable;
    }

    /**
     * Adds the variable to this stackFrame
     */
    @Override
    protected void localExecute() {
        getState().getCallStack().getCurrentFrame().addLocalVariable(variable);
    }

    /**
     * Removes the variable of this stackFrame
     */
    @Override
    protected void localUndo() {
        getState().getCallStack().getCurrentFrame().removeLocalVariable(variable.getName());
    }

    public Variable getVariable() {return variable;}

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
