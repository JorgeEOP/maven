package de.unibwm.inf2.bugvis.model;

public interface VisualizationObject {
    /**
     *
     * @return the original {@code VisualizationObject}
     */
    int getHashCode();

}
