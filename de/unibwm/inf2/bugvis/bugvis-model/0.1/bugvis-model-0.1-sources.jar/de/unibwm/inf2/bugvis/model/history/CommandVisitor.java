package de.unibwm.inf2.bugvis.model.history;

public interface CommandVisitor<R> {
    R visit(AssignArrayCmd cmd);

    R visit(AssignFieldCmd cmd);

    R visit(AssignStaticFieldCmd cmd);

    R visit(AssignVariableCmd cmd);

    R visit(CreateObjectCmd cmd);

    R visit(DeclareFieldCmd cmd);

    R visit(DeclareStaticFieldCmd cmd);

    R visit(DeclareVariableCmd cmd);

    R visit(EnterFrameCmd cmd);

    R visit(ExitFrameCmd cmd);

    R visit(IntermediateResultCmd cmd);

    R visit(OutputStreamCmd cmd);

    R visit(PositionCommand cmd);

    R visit(ReceiverParameterCmd cmd);

    R visit(ReturnCmd cmd);

    R visit(StartVisualizationCmd cmd);

    R visit(StopVisualizationCmd cmd);

    R visit(UpdateVisualizationCmd cmd);

    R visit(ModifiedListCmd cmd);

    R visit(ModifiedMapCmd cmd);
}
