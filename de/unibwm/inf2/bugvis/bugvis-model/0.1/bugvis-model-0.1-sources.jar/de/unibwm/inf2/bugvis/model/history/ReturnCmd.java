package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.StackFrame;
import de.unibwm.inf2.bugvis.model.value.Value;
import de.unibwm.inf2.bugvis.model.value.VoidValue;

/**
 * Represents a ReturnCommand
 */
public class ReturnCmd extends PositionCommand {

    /**
     * Return Value
     */
    private final Value value;

    /**
     * Creates a ReturnCmd with the given return value for the parent of the current frame
     *
     * @param value return value.
     */
    public ReturnCmd(ProgramState state, Position position, boolean isFirstInLine, Value value) {
        super(state, position, isFirstInLine);
        this.value = value;
    }

    /**
     * Sets this return as return variable of this frame
     */
    @Override
    protected void localExecute() {
        final StackFrame parentFrame = getState().getCallStack().getCurrentFrame().getParent();
        if (parentFrame != null)
            parentFrame.setReturn(value);
    }

    /**
     * Removes tje return variable of this frame
     */
    @Override
    protected void localUndo() {
        final StackFrame parentFrame = getState().getCallStack().getCurrentFrame().getParent();
        if (parentFrame != null)
            parentFrame.setReturn(VoidValue.INSTANCE);
    }

    public Value getValue() {return value;}

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
