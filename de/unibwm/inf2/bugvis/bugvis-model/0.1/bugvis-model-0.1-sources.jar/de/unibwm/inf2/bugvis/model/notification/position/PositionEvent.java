package de.unibwm.inf2.bugvis.model.notification.position;

import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.notification.SynchronizedEvent;

import java.util.concurrent.CountDownLatch;

public class PositionEvent implements SynchronizedEvent<PositionEventListener> {
    Position position;

    public PositionEvent(Position position) {this.position = position;}

    public Position getPosition() {return position;}

    public void notifyListeners(PositionEventListener listener, CountDownLatch count) {
        listener.receivedEvent(this, count);
    }

    @Override
    public String toString() {return this.getClass().getSimpleName();}
}
