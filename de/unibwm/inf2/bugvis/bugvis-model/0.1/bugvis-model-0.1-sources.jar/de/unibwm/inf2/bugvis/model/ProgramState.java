package de.unibwm.inf2.bugvis.model;

import de.unibwm.inf2.bugvis.instr.facades.CollectionFacade;
import de.unibwm.inf2.bugvis.instr.facades.MapFacade;
import de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple;
import de.unibwm.inf2.bugvis.model.history.CreateObjectCmd;
import de.unibwm.inf2.bugvis.model.history.History;
import de.unibwm.inf2.bugvis.model.notification.SynchronizedEvent;
import de.unibwm.inf2.bugvis.model.notification.SynchronizedEventListener;
import de.unibwm.inf2.bugvis.model.notification.console.ConsoleEvent;
import de.unibwm.inf2.bugvis.model.notification.console.ConsoleEventListener;
import de.unibwm.inf2.bugvis.model.notification.debugee.DebugeeEvent;
import de.unibwm.inf2.bugvis.model.notification.debugee.DebugeeEventListener;
import de.unibwm.inf2.bugvis.model.notification.debugee.ObjectCreationEvent;
import de.unibwm.inf2.bugvis.model.notification.position.PositionEvent;
import de.unibwm.inf2.bugvis.model.notification.position.PositionEventListener;
import de.unibwm.inf2.bugvis.model.value.ArrayValue;
import de.unibwm.inf2.bugvis.model.value.ListValue;
import de.unibwm.inf2.bugvis.model.value.MapValue;
import de.unibwm.inf2.bugvis.model.value.NullValue;
import de.unibwm.inf2.bugvis.model.value.PrimitiveValue;
import de.unibwm.inf2.bugvis.model.value.ReferenceValue;
import de.unibwm.inf2.bugvis.model.value.Value;
import de.unibwm.inf2.bugvis.model.value.WrappedValue;

import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.function.Function;

import static java.lang.System.Logger.Level.INFO;

/// Represents a program state containing state information about a target.
public class ProgramState {
    private static final Logger LOGGER = System.getLogger(ProgramState.class.getName());

    /// Map which stores translator functions for specific classes to support the creation of mirror objects.
    private static final Map<Class<?>, Function<Object, Value>> TRANSLATOR_MAP = new HashMap<>();

    static {
        TRANSLATOR_MAP.put(boolean.class, o -> new PrimitiveValue(o, boolean.class));
        TRANSLATOR_MAP.put(char.class, o -> new PrimitiveValue(o, char.class));
        TRANSLATOR_MAP.put(byte.class, o -> new PrimitiveValue(o, byte.class));
        TRANSLATOR_MAP.put(short.class, o -> new PrimitiveValue(o, short.class));
        TRANSLATOR_MAP.put(int.class, o -> new PrimitiveValue(o, int.class));
        TRANSLATOR_MAP.put(long.class, o -> new PrimitiveValue(o, long.class));
        TRANSLATOR_MAP.put(float.class, o -> new PrimitiveValue(o, float.class));
        TRANSLATOR_MAP.put(double.class, o -> new PrimitiveValue(o, double.class));

        TRANSLATOR_MAP.put(Boolean.class, WrappedValue::new);
        TRANSLATOR_MAP.put(Character.class, WrappedValue::new);
        TRANSLATOR_MAP.put(Byte.class, WrappedValue::new);
        TRANSLATOR_MAP.put(Short.class, WrappedValue::new);
        TRANSLATOR_MAP.put(Integer.class, WrappedValue::new);
        TRANSLATOR_MAP.put(Long.class, WrappedValue::new);
        TRANSLATOR_MAP.put(Float.class, WrappedValue::new);
        TRANSLATOR_MAP.put(Double.class, WrappedValue::new);
    }

    private final History history = new History();
    private final CallStack callStack;

    /// tracks the currently visualized objects
    private final VisualizationState visualizationState = new VisualizationState(this);

    /// maps object -> mirror object
    private final Map<Object, Value> mirrorObjects = new IdentityHashMap<>();

    /// maps `identityHashcode(object)` -> mirror object
    private final Map<Integer, Value> mirrorObjectsById = new HashMap<>();

    /// representation for all static vars of a target
    private final Map<FieldIdentifier, Field> staticFields = new HashMap<>();

    private final List<DebugeeEventListener> debugeeEventListeners = new ArrayList<>();
    private final List<PositionEventListener> positionEventListeners = new ArrayList<>();
    private final List<ConsoleEventListener> consoleEventListeners = new ArrayList<>();

    public ProgramState() {callStack = new CallStack(this);}

    // Mirror objects //////////////////////////////////////////////////////////////////////////////////////////////////

    public Value getMirrorObject(int identityHashcode) {
        if (identityHashcode == 0) return NullValue.INSTANCE;
        return mirrorObjectsById.get(identityHashcode);
    }

    /// @param objectClassTuple the object as [de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple]
    /// @return the debug representation of a given object
    public Value getMirrorObject(ObjectClassTuple objectClassTuple) {
        final Object object = objectClassTuple.getObject();
        if (object == null) {
            LOGGER.log(Level.INFO, "null value");
            return NullValue.INSTANCE;
        }
        final Class<?> clazz = objectClassTuple.getClazz();
        if (clazz.isPrimitive()) {
            final PrimitiveValue primitiveValue = new PrimitiveValue(object, clazz);
            LOGGER.log(Level.INFO, () -> "primitiveValue: " + primitiveValue);
            return primitiveValue;
        }
        if (mirrorObjects.containsKey(object))
            return mirrorObjects.get(object);
        return createMirrorObject(objectClassTuple);
    }

    /// Creates a mirror object for a given [java.lang.Object] and puts it into the [#mirrorObjects].
    ///
    /// @param objectClassTuple An object as [de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple],
    /// @return the new mirror object of the given object.
    /// @see #getMirrorObject(de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple)
    private Value createMirrorObject(ObjectClassTuple objectClassTuple) {
        final Class<?> clazz = objectClassTuple.getClazz();
        final Object object = objectClassTuple.getObject();
        Value mirrorObject;

        if (clazz.isArray())
            mirrorObject = new ArrayValue(object, mirrorComponents(object));
        else if (CollectionFacade.class.isAssignableFrom(clazz))
            mirrorObject = new ListValue(object, mirrorElements((Collection<?>) object));
        else if (MapFacade.class.isAssignableFrom(clazz))
            mirrorObject = new MapValue(object, mirrorEntries((Map<?, ?>) object));
        else {
            final Function<Object, Value> translator = TRANSLATOR_MAP.getOrDefault(clazz, ReferenceValue::new);
            mirrorObject = translator.apply(object);
        }

        final Position position = this.callStack.getCurrentFrame().getPosition();
        CreateObjectCmd command = new CreateObjectCmd(this, position, false, object, mirrorObject);
        command.execute();
        history.addCommand(command);
        LOGGER.log(INFO, "mirrorObject: {0}", command);
        notifyListeners(new ObjectCreationEvent(object));
        return mirrorObject;
    }

    private List<Value> mirrorComponents(Object object) {
        final int length = Array.getLength(object);
        final List<Value> mirrors = new ArrayList<>(length);
        for (int i = 0; i < length; i++)
            mirrors.add(getMirrorObject(new ObjectClassTuple(Array.get(object, i))));
        return mirrors;
    }

    public List<Value> mirrorElements(Collection<?> collection) {
        final List<Value> mirrors = new ArrayList<>(collection.size());
        for (Object element : collection)
            mirrors.add(getMirrorObject(new ObjectClassTuple(element)));
        return mirrors;
    }

    public Map<Value, Value> mirrorEntries(Map<?, ?> map) {
        final Map<Value, Value> mirrors = HashMap.newHashMap(map.size());
        map.forEach((key, value) -> mirrors.put(
                getMirrorObject(new ObjectClassTuple(key)),
                getMirrorObject(new ObjectClassTuple(value)))
        );
        return mirrors;
    }

    public void putMirrorObject(Object key, Value value) {
        mirrorObjects.put(key, value);
        mirrorObjectsById.put(System.identityHashCode(key), value);
    }

    public void removeMirrorObject(Object key) {
        mirrorObjects.remove(key);
        mirrorObjectsById.remove(System.identityHashCode(key));
    }

    // Static fields ///////////////////////////////////////////////////////////////////////////////////////////////////

    public Field getStaticField(FieldIdentifier id) {
        return staticFields.get(id);
    }

    public void addStaticField(Field field) {
        staticFields.put(field.getIdentifier(), field);
    }

    public void removeStaticField(FieldIdentifier identifier) {
        staticFields.remove(identifier);
    }

    public List<Field> getStaticFields() {
        return new ArrayList<>(staticFields.values());
    }

    // Getter //////////////////////////////////////////////////////////////////////////////////////////////////////////

    public History getHistory() {
        return history;
    }

    public CallStack getCallStack() {
        return callStack;
    }

    public VisualizationState getVisualizationState() {return visualizationState;}

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append("ProgramState{ currentClass=").append(callStack.getClassName()).append("\n\tstaticVars: ");
        List<String> sFieldStrings = staticFields.values()
                                                 .stream()
                                                 .sorted(Comparator.comparing(a -> a.getDeclaringClass().getName()))
                                                 .map(Field::toString)
                                                 .toList();
        str.append("\n\t\t")
           .append(String.join(", ", sFieldStrings));
        str.append("\n\tcallStack: ").append(callStack).append("\n\tmirrorObjects: ").append(mirrorObjects.size()).append("\n}");
        return str.toString();
    }

    // Listener ////////////////////////////////////////////////////////////////////////////////////////////////////////

    public void addDebugeeEventListener(DebugeeEventListener listener) {debugeeEventListeners.add(listener);}

    public void removeDebugeeEventListener(DebugeeEventListener listener) {debugeeEventListeners.remove(listener);}

    public void notifyListeners(DebugeeEvent event) {debugeeEventListeners.forEach(event::notifyListeners);}

    public void addConsoleEventListener(ConsoleEventListener listener) {consoleEventListeners.add(listener);}

    public void removeConsoleListener(ConsoleEventListener listener) {consoleEventListeners.remove(listener);}

    public void notifyListeners(ConsoleEvent event) {notifyListeners(consoleEventListeners, event);}

    public void addPositionEventListener(PositionEventListener listener) {positionEventListeners.add(listener);}

    public void removePositionEventListener(PositionEventListener listener) {positionEventListeners.remove(listener);}

    public void notifyListeners(PositionEvent event) {notifyListeners(positionEventListeners, event);}

    <E extends SynchronizedEvent<L>, L extends SynchronizedEventListener<E>> void notifyListeners(List<L> listeners, E event) {
        if (listeners.isEmpty()) return;
        CountDownLatch allTerminated = new CountDownLatch(listeners.size());
        listeners.forEach(listener -> event.notifyListeners(listener, allTerminated));
        try {
            LOGGER.log(INFO, "notify listeners for {0}", event);
            allTerminated.await();
            LOGGER.log(INFO, "all listeners notified");
        }
        catch (InterruptedException e) {
            LOGGER.log(Level.ERROR, "await was interrupted", e);
            throw new RuntimeException(e);
        }
    }
}
