package de.unibwm.inf2.bugvis.model.notification.console;

import de.unibwm.inf2.bugvis.model.notification.SynchronizedEventListener;

import java.util.concurrent.CountDownLatch;

public interface ConsoleEventListener extends SynchronizedEventListener<ConsoleEvent> {
    void receivedEvent(ConsoleAddOutputEvent event, CountDownLatch count);

    void receivedEvent(ConsoleRemOutputEvent event, CountDownLatch count);
}
