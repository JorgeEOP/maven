package de.unibwm.inf2.bugvis.model.notification.visualize;

import de.unibwm.inf2.bugvis.model.VisualizationObject;

import java.util.concurrent.CountDownLatch;

public class StopVisualizationEvent implements VisualizeEvent {
    private final VisualizationObject visualizationObject;

    public StopVisualizationEvent(VisualizationObject visualizationObject) {
        this.visualizationObject = visualizationObject;
    }

    public VisualizationObject getVisualizationObject() {return visualizationObject;}

    @Override
    public void notifyListeners(VisualizeEventListener listener, CountDownLatch count) {
        listener.receivedEvent(this, count);
    }

    @Override
    public String toString() {return this.getClass().getSimpleName();}
}
