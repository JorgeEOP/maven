package de.unibwm.inf2.bugvis.model.notification.debugee;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.DEBUG;

public class ArrayAssignmentEvent implements DebugeeEvent {
    private static final Logger LOGGER = System.getLogger(ArrayAssignmentEvent.class.getName());

    private final Object object;
    private final int index;

    public ArrayAssignmentEvent(Object object, int index) {
        this.index = index;
        this.object = object;
    }

    @Override
    public void notifyListeners(DebugeeEventListener listener) {
        LOGGER.log(DEBUG, () -> "notify " + listener);
        listener.receivedEvent(this);
        LOGGER.log(DEBUG, () -> "listener was notified " + listener);
    }

    public int getIndex() {return index;}

    public Object getObject() {return object;}
}
