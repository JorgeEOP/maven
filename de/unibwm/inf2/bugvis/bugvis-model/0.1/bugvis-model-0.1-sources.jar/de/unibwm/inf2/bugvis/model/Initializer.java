package de.unibwm.inf2.bugvis.model;

public class Initializer extends Method {

    public Initializer(Class<?> parentClass, int fileId) {
        super("initializer", parentClass, fileId);
    }

    @Override
    public String toString() {
        return "Initializer{" +
               "class: " + getClassName() +
               ", fileId: " + getFileId() +
               "}";
    }
}
