package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.VisualizationObject;
import de.unibwm.inf2.bugvis.model.notification.visualize.StartVisualizationEvent;
import de.unibwm.inf2.bugvis.model.notification.visualize.StopVisualizationEvent;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.INFO;

public class StartVisualizationCmd extends Command {
    private static final Logger LOGGER = System.getLogger(StartVisualizationCmd.class.getName());

    private final VisualizationObject visualizationObject;

    public StartVisualizationCmd(ProgramState state, VisualizationObject visualizationObject) {
        super(state);
        this.visualizationObject = visualizationObject;
    }

    @Override
    protected void localExecute() {
        LOGGER.log(INFO, "Starting visualization of {0}", visualizationObject);
        getState().getVisualizationState().add(visualizationObject);
        final StartVisualizationEvent event = new StartVisualizationEvent(visualizationObject);
        getState().getVisualizationState().notifyListeners(event);
    }

    @Override
    protected void localUndo() {
        getState().getVisualizationState().remove(visualizationObject.getHashCode());
        final StopVisualizationEvent event = new StopVisualizationEvent(visualizationObject);
        getState().getVisualizationState().notifyListeners(event);
    }

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}

    public VisualizationObject getVisualizationObject() {return visualizationObject;}
}
