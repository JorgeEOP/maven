package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.VisualizationObject;
import de.unibwm.inf2.bugvis.model.notification.visualize.UpdateVisualizationEvent;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.DEBUG;

public class UpdateVisualizationCmd extends Command {
    private static final Logger LOGGER = System.getLogger(UpdateVisualizationCmd.class.getName());

    private final VisualizationObject newVisualizationObject;
    private final VisualizationObject oldVisualizationObject;

    public UpdateVisualizationCmd(ProgramState state, VisualizationObject newVisualizationObject) {
        super(state);
        this.newVisualizationObject = newVisualizationObject;
        LOGGER.log(DEBUG, () -> "new generic object: " + newVisualizationObject);
        this.oldVisualizationObject = state.getVisualizationState().get(newVisualizationObject.getHashCode());
        LOGGER.log(DEBUG, () -> "old generic object: " + oldVisualizationObject);
    }

    @Override
    protected void localExecute() {
        getState().getVisualizationState().add(newVisualizationObject);
        UpdateVisualizationEvent event = new UpdateVisualizationEvent(oldVisualizationObject, newVisualizationObject);
        getState().getVisualizationState().notifyListeners(event);
    }

    @Override
    protected void localUndo() {
        getState().getVisualizationState().add(oldVisualizationObject);
        UpdateVisualizationEvent event = new UpdateVisualizationEvent(newVisualizationObject, oldVisualizationObject);
        getState().getVisualizationState().notifyListeners(event);
    }

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
