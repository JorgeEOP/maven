package de.unibwm.inf2.bugvis.model.value;

/**
 * Represents a null reference.
 */
public class NullValue extends Value {

    public static final NullValue INSTANCE = new NullValue();

    private NullValue() {
        super(null, void.class);
    }

    @Override
    public String toString() {
        return "NullValue{object=null}";
    }

    @Override
    public NullValue asNullValue() {return this;}

    @Override
    public boolean isNullValue() {return true;}

    public void accept(ValueVoidVisitor visitor) {visitor.visit(this);}

    public <R> R accept(ValueVisitor<R> visitor) {return visitor.visit(this);}
}