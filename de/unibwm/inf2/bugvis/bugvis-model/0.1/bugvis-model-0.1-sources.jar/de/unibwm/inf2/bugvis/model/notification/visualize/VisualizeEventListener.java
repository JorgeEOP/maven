package de.unibwm.inf2.bugvis.model.notification.visualize;

import de.unibwm.inf2.bugvis.model.notification.SynchronizedEventListener;

import java.util.concurrent.CountDownLatch;

public interface VisualizeEventListener extends SynchronizedEventListener<VisualizeEvent> {

    void receivedEvent(StartVisualizationEvent event, CountDownLatch count);

    void receivedEvent(StopVisualizationEvent event, CountDownLatch count);

    void receivedEvent(UpdateVisualizationEvent event, CountDownLatch count);

    void receivedEvent(VisualizationBigStepEvent event, CountDownLatch count);
}
