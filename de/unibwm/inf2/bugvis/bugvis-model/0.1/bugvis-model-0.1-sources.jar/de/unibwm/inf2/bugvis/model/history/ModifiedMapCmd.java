package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.value.MapValue;
import de.unibwm.inf2.bugvis.model.value.Value;

import java.util.Map;

public class ModifiedMapCmd extends Command {
    private final MapValue mapObject;
    private final Map<Value, Value> oldValue;
    private final Map<Value, Value> newValue;

    public ModifiedMapCmd(ProgramState state, Value mapObj, Map<Value, Value> newValue) {
        super(state);
        this.mapObject = (MapValue) mapObj;
        this.oldValue = this.mapObject.getComponentMirrorObjects();
        this.newValue = newValue;
    }

    /**
     *
     */
    @Override
    protected void localExecute() {
        mapObject.setComponentMirrorObjects(newValue);
    }

    /**
     *
     */
    @Override
    protected void localUndo() {
        mapObject.setComponentMirrorObjects(oldValue);
    }

    /**
     *
     * @param visitor
     */
    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    /**
     *
     * @param visitor
     * @param <R>
     * @return
     */
    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}