package de.unibwm.inf2.bugvis.model.notification;

public interface SynchronizedEventListener<E extends SynchronizedEvent> {}
