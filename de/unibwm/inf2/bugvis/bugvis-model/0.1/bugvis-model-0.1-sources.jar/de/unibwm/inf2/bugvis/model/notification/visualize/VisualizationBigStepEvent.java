package de.unibwm.inf2.bugvis.model.notification.visualize;

import java.util.concurrent.CountDownLatch;

/**
 * An event indicating that a visualization big step (consisting of smaller steps) has been taken.
 */
public enum VisualizationBigStepEvent implements VisualizeEvent {
    INSTANCE;

    @Override
    public void notifyListeners(VisualizeEventListener listener, CountDownLatch count) {
        listener.receivedEvent(this, count);
    }

    @Override
    public String toString() {return this.getClass().getSimpleName();}
}
