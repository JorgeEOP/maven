package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.ProgramState;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Command {
    private final ProgramState state;
    private final List<Command> subCommands = new ArrayList<>();

    protected Command(ProgramState state) {this.state = state;}

    /**
     * Executes the commands specific action
     */
    public void execute() {
        localExecute();
        subCommands.forEach(Command::execute);
    }

    /**
     * Undos the commands specific action
     */
    public void undo() {
        subCommands.forEach(Command::undo);
        localUndo();
    }

    protected abstract void localExecute();

    protected abstract void localUndo();

    protected ProgramState getState() {return state;}

    public void addSubCommand(Command subCommand) {subCommands.add(subCommand);}

    public void removeSubCommand(Command subCommand) {subCommands.remove(subCommand);}

    public List<Command> getSubCommands() {return Collections.unmodifiableList(subCommands);}

    public abstract void accept(CommandVoidVisitor visitor);

    public abstract <R> R accept(CommandVisitor<R> visitor);
}
