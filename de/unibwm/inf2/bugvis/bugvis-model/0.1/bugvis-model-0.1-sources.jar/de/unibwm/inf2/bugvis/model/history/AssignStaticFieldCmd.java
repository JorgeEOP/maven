package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.Field;
import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.value.Value;

/**
 * Represents an AssignVariableCommand
 */
public class AssignStaticFieldCmd extends PositionCommand {
    /**
     * field whose value is being changed
     */
    private final Field field;
    /**
     * old value
     */
    private final Value oldValue;
    /**
     * new value
     */
    private final Value newValue;

    /**
     * Creates a new AssignVarCmd with the given frame, variable and new value
     *
     * @param field
     * @param newValue
     */
    public AssignStaticFieldCmd(ProgramState state, Position position, boolean isFirstInLine, Field field, Value newValue) {
        super(state, position, isFirstInLine);
        this.field = field;
        this.oldValue = field.getValue();
        this.newValue = newValue;
    }

    /**
     * Sets the value of the variable to the new value
     */
    @Override
    protected void localExecute() {
        field.setValue(newValue);
    }

    /**
     * Resets the value of the variable to the previous value
     */
    @Override
    protected void localUndo() {
        field.setValue(oldValue);
    }

    public Field getField() {return field;}

    public Value getNewValue() {return newValue;}

    public Value getOldValue() {return oldValue;}

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
