package de.unibwm.inf2.bugvis.model.value;

public interface ValueVoidVisitor {

    void visit(ArrayValue v);

    void visit(ListValue v);

    void visit(MapValue v);

    void visit(NullValue v);

    void visit(PrimitiveValue v);

    void visit(ReferenceValue v);

    void visit(VoidValue v);

    void visit(WrappedValue v);
}
