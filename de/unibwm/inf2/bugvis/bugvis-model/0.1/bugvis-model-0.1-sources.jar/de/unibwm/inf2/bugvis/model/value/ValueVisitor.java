package de.unibwm.inf2.bugvis.model.value;

public interface ValueVisitor<R> {

    R visit(ArrayValue v);

    R visit(MapValue v);

    R visit(ListValue v);

    R visit(NullValue v);

    R visit(PrimitiveValue v);

    R visit(ReferenceValue v);

    R visit(VoidValue v);

    R visit(WrappedValue v);
}
