package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.value.ListValue;
import de.unibwm.inf2.bugvis.model.value.Value;

import java.util.List;

public class ModifiedListCmd extends Command {
    private final ListValue listObj;
    private final List<Value> oldValue;
    private final List<Value> newValue;

    public ModifiedListCmd(ProgramState state, Value listObj, List<Value> newValue) {
        super(state);
        this.listObj = (ListValue) listObj;
        this.oldValue = this.listObj.getComponentMirrorObjects();
        this.newValue = newValue;
    }

    @Override
    protected void localExecute() {
        listObj.setComponentMirrorObjects(newValue);
    }

    @Override
    protected void localUndo() {
        listObj.setComponentMirrorObjects(oldValue);
    }

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
