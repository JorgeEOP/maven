package de.unibwm.inf2.bugvis.model.notification.position;

import de.unibwm.inf2.bugvis.model.notification.SynchronizedEventListener;

import java.util.concurrent.CountDownLatch;

public interface PositionEventListener extends SynchronizedEventListener<PositionEvent> {
    void receivedEvent(PositionEvent event, CountDownLatch count);
}
