package de.unibwm.inf2.bugvis.model.value;

/**
 * A debug representation of a primitive value.
 */
public class PrimitiveValue extends Value {

    public PrimitiveValue(Object obj, Class<?> clazz) {
        super(obj, clazz);
    }

    /**
     * Returns a string representation of this {@link PrimitiveValue}.
     *
     * @return a string representation of this {@link PrimitiveValue}.
     */
    @Override
    public String toString() {
        return "PrimitiveValue{value=" + getObject() + "}";
    }

    @Override
    public PrimitiveValue asPrimitiveValue() {return this;}

    @Override
    public boolean isPrimitiveValue() {return true;}

    public void accept(ValueVoidVisitor visitor) {visitor.visit(this);}

    public <R> R accept(ValueVisitor<R> visitor) {return visitor.visit(this);}
}
