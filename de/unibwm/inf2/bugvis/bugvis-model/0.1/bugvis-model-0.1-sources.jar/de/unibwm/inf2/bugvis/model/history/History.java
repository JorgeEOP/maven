package de.unibwm.inf2.bugvis.model.history;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.function.Predicate;

/**
 * Represents the history used as controller class of the command-pattern
 */
public class History {
    /**
     * all commands which have been executed to this point of time
     */
    private final Deque<PositionCommand> undoCommands = new ArrayDeque<>();
    /**
     * all commands which have been undone to this point of time
     */
    private final Deque<PositionCommand> redoCommands = new ArrayDeque<>();

    private PositionCommand pendingCommand;

    /**
     * Adds a new command to the commands list
     *
     * @param command which is added
     */
    public void addCommand(PositionCommand command) {
        if (!redoCommands.isEmpty())
            throw new IllegalStateException("adding command with redo commands on stack");
        undoCommands.addLast(command);
    }

    /**
     * @return the string representation of the history
     */
    @Override
    public String toString() {
        CommandToStringVisitor cmd2StringVisitor = new CommandToStringVisitor();
        StringBuilder str = new StringBuilder();
        str.append("History{\nUndo-Commands:");
        int ctr = 0;
        for (PositionCommand cmd : undoCommands)
            str.append("\n\tUndo ")
               .append(ctr++)
               .append(": ")
               .append(cmd.accept(cmd2StringVisitor));
        str.append("\n_____\npending Command:\n\t");
        str.append(pendingCommand.accept(cmd2StringVisitor));
        str.append("\n_____\nRedo-Commands:");
        ctr = 0;
        for (PositionCommand cmd : redoCommands)
            str.append("\n\tRedo ")
               .append(ctr++)
               .append(": ")
               .append(cmd.accept(cmd2StringVisitor));
        str.append("\n}");
        return str.toString();
    }

    /**
     * Redos commands until either there are no more redo commands
     * or the specified control requests a stop. In the latter case, the method
     * returns true, otherwise false.
     *
     * @param stopRequest a predicate that checks whether redo shall be stopped after executing a command
     * @return true if a stop has been requested by the specified debug control,
     * and false otherwise.
     */
    public boolean redo(Predicate<PositionCommand> stopRequest) {
        while (!redoCommands.isEmpty()) {
            final PositionCommand cmd = redoCommands.removeFirst();
            undoCommands.addLast(cmd);
            cmd.execute();
            final PositionCommand next = getNext();
            next.updatePosition();
            if (stopRequest.test(next))
                return true;
        }
        return false;
    }

    private PositionCommand getNext() {
        final PositionCommand next;
        if (!redoCommands.isEmpty())
            next = redoCommands.peekFirst();
        else
            next = pendingCommand;
        return next;
    }

    /**
     * Undos commands until either there is no undo command left
     * or the specified predicate requests a stop. Note that the command
     * that satisfies the specified predicate is not undone.
     *
     * @param stopRequest a predicate that checks whether undo shall be stopped before executing a command
     */
    public void undo(Predicate<PositionCommand> stopRequest) {
        if (undoCommands.isEmpty()) return;
        do {
            final PositionCommand cmd = undoCommands.removeLast();
            redoCommands.addFirst(cmd);
            cmd.undo();
            cmd.updatePosition();
        }
        while (continueUndo(stopRequest));
    }

    /**
     * Determines whether the undo process should continue.
     * <p>
     * The undo process continues if there are still commands in the undo stack
     * and the predicate does not signal to stop before executing the next command.
     * In other words, if the undo stack is not empty and the last command in the
     * stack does not satisfy the stop request predicate, the undo process continues.
     *
     * @param stopRequest a predicate that checks whether undo shall be stopped before executing a command
     * @return {@code true} if there is at least one more command to potentially undo and the predicate returns {@code false}
     * for the next command; {@code false} otherwise.
     */
    private boolean continueUndo(Predicate<PositionCommand> stopRequest) {
        return !undoCommands.isEmpty() && !stopRequest.test(redoCommands.getFirst());
    }

    /**
     * Adds a subcommand to the last command in the undo command list.
     *
     * @param cmd the subcommand to be added
     * @throws java.util.NoSuchElementException if the undo command list is empty
     */
    public void addSubCommandToLastCommand(Command cmd) {
        undoCommands.getLast().addSubCommand(cmd);
    }

    public void setPendingCommand(PositionCommand pendingCommand) {this.pendingCommand = pendingCommand;}

    public int getUndoCommandSize() {return undoCommands.size();}

    public int getRedoCommandSize() {return redoCommands.size();}
}
