package de.unibwm.inf2.bugvis.model.notification.console;

import de.unibwm.inf2.bugvis.model.notification.SynchronizedEvent;

import java.util.concurrent.CountDownLatch;

public interface ConsoleEvent extends SynchronizedEvent<ConsoleEventListener> {
    void notifyListeners(ConsoleEventListener listener, CountDownLatch count);
}
