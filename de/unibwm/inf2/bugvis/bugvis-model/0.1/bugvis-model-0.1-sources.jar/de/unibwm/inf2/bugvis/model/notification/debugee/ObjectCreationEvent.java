package de.unibwm.inf2.bugvis.model.notification.debugee;

public class ObjectCreationEvent implements DebugeeEvent {

    private final Object object;

    public ObjectCreationEvent(Object object) {this.object = object;}

    @Override
    public void notifyListeners(DebugeeEventListener listener) {listener.receivedEvent(this);}

    public Object getObject() {return object;}
}
