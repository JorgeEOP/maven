package de.unibwm.inf2.bugvis.model.notification.visualize;

import de.unibwm.inf2.bugvis.model.notification.SynchronizedEvent;

import java.util.concurrent.CountDownLatch;

public interface VisualizeEvent extends SynchronizedEvent<VisualizeEventListener> {
    void notifyListeners(VisualizeEventListener listener, CountDownLatch count);
}
