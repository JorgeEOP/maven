package de.unibwm.inf2.bugvis.model;

public class Method {
    private final String signature;
    private final Class<?> clazz;
    private final int fileId;

    public Method(String signature, Class<?> clazz, int fileId) {
        this.signature = signature;
        this.clazz = clazz;
        this.fileId = fileId;
    }

    public String getSignature() {
        return signature;
    }

    public String getClassName() {
        return clazz.getSimpleName();
    }

    public int getFileId() {
        return fileId;
    }

    /**
     * @return string representation of this method
     */
    @Override
    public String toString() {
        return "Method{" +
               "signature='" + signature +
               "', class=" + clazz +
               ", fileId=" + fileId +
               "}";
    }
}
