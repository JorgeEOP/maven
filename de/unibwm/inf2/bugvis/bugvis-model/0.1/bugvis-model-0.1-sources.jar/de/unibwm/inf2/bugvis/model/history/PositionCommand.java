package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.notification.position.PositionEvent;

/**
 * Interface for all commands used for the command-pattern
 */
public class PositionCommand extends Command {
    private final Position position;
    private final boolean isFirstInLine;

    public PositionCommand(ProgramState state, Position position, boolean isFirstInLine) {
        super(state);
        this.position = position;
        this.isFirstInLine = isFirstInLine;
    }

    public void updatePosition() {
        getState().getCallStack().getCurrentFrame().setPosition(position);
        getState().notifyListeners(new PositionEvent(position));
    }

    public Position getPosition() {return position;}

    public boolean isFirstInLine() {return isFirstInLine;}

    @Override
    protected void localExecute() {
        // This Command only updates the position, other commands extend this behavior by overriding this method.
    }

    @Override
    protected void localUndo() {
        // This Command only updates the position, other commands extend this behavior by overriding this method.
    }

    public boolean alwaysContinue() {return false;}

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
