package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.Field;
import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.ProgramState;

/**
 * Represents a DeclareStaticCommand
 */
public class DeclareStaticFieldCmd extends PositionCommand {

    /**
     * newly created variable
     */
    private final Field field;

    /**
     * Creates a new DeclareStaticCmd of a given frame, new variable and the class which the variable is static of
     *
     * @param field
     */
    public DeclareStaticFieldCmd(ProgramState state, Position position, boolean isFirstInLine, Field field) {
        super(state, position, isFirstInLine);
        this.field = field;
    }

    /**
     * Adds the static variable to the programState
     */
    @Override
    protected void localExecute() {
        getState().addStaticField(field);
    }

    /**
     * Removes the static variable of the programState
     */
    @Override
    protected void localUndo() {
        getState().removeStaticField(field.getIdentifier());
    }

    public Field getField() {return field;}

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
