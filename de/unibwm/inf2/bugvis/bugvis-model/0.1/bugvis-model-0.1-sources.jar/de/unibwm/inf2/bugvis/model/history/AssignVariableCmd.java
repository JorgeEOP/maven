package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.Variable;
import de.unibwm.inf2.bugvis.model.value.Value;

/**
 * Represents an AssignVariableCommand
 */
public class AssignVariableCmd extends PositionCommand {
    /**
     * variable whose value is being changed
     */
    private final Variable variable;
    /**
     * old value
     */
    private final Value oldValue;
    /**
     * new value
     */
    private final Value newValue;

    /**
     * Creates a new AssignVarCmd with the given frame, variable and new value
     *
     * @param variable
     * @param newValue
     */
    public AssignVariableCmd(ProgramState state, Position position, boolean isFirstInLine, Variable variable, Value newValue) {
        super(state, position, isFirstInLine);
        this.variable = variable;
        this.oldValue = variable.getValue();
        this.newValue = newValue;
    }

    /**
     * Sets the value of the variable to the new value
     */
    @Override
    protected void localExecute() {
        variable.setValue(newValue);
    }

    /**
     * Resets the value of the variable to the previous value
     */
    @Override
    protected void localUndo() {
        variable.setValue(oldValue);
    }

    public Variable getVariable() {return variable;}

    public Value getNewValue() {return newValue;}

    public Value getOldValue() {return oldValue;}

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
