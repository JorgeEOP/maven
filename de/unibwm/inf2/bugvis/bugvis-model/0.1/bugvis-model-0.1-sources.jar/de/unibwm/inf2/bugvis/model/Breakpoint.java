package de.unibwm.inf2.bugvis.model;

public interface Breakpoint {
    /**
     * Returns the file id of this {@link de.unibwm.inf2.bugvis.model.Breakpoint}.
     *
     * @return the file id of this {@link de.unibwm.inf2.bugvis.model.Breakpoint}.
     */
    int getFileId();

    /**
     * Returns the line number of this {@link de.unibwm.inf2.bugvis.model.Breakpoint}.
     *
     * @return the line number of this {@link de.unibwm.inf2.bugvis.model.Breakpoint}.
     */
    int getLine();
}
