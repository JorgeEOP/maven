package de.unibwm.inf2.bugvis.model.value;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;

public class MapValue extends Value {
    /**
     * Components of the map.
     */
    private Map<Value, Value> componentMirrorObjects;

    /**
     * Creates a debug representation for an object that extends map with the given debug representations of the components.
     */
    public MapValue(Object obj, Map<Value, Value> componentMirrorObjects) {
        super(obj, obj.getClass());
        Objects.requireNonNull(obj);
        this.componentMirrorObjects = componentMirrorObjects;
    }

    /**
     * Returns the number of components in this debug representation of a map.
     *
     * @return the number of components in this debug representation of a map.
     */
    public int getSize() {return componentMirrorObjects.size();}

    /**
     * Returns a View of the component mirror objects of this map.
     *
     * @return the mirror objects as an unmodifiable map
     */
    public Map<Value, Value> getComponentMirrorObjects() {
        return Collections.unmodifiableMap(componentMirrorObjects);
    }

    /**
     *
     * @param componentMirrorObjects the mirror objects that make this map
     */
    public void setComponentMirrorObjects(Map<Value, Value> componentMirrorObjects) {
        this.componentMirrorObjects = componentMirrorObjects;
    }

    /**
     * Returns a string representation of this {@link MapValue}.
     *
     * @return a string representation of this {@link MapValue}.
     */
    @Override
    public String toString() {
        return "MapValue{size=" + getSize() + ", components=" + componentMirrorObjects + "}";
    }

    /**
     *
     * @return
     */
    @Override
    public MapValue asMapValue() {return this;}

    /**
     *
     * @return
     */
    @Override
    public boolean isMapValue() {return true;}

    /**
     *
     * @param visitor
     */
    public void accept(ValueVoidVisitor visitor) {visitor.visit(this);}

    /**
     *
     * @param visitor
     * @param <R>
     * @return
     */
    public <R> R accept(ValueVisitor<R> visitor) {return visitor.visit(this);}
}
