package de.unibwm.inf2.bugvis.model.value;

/**
 * A debug representation of a wrapped value.
 */
public class WrappedValue extends Value {

    public WrappedValue(Object obj) {
        super(obj, obj.getClass());
    }

    /**
     * Returns a string representation of this {@link WrappedValue}.
     *
     * @return a string representation of this {@link WrappedValue}.
     */
    @Override
    public String toString() {
        return "WrappedValue{value=" + getObject() + "}";
    }

    @Override
    public WrappedValue asWrappedValue() {return this;}

    @Override
    public boolean isWrappedValue() {return true;}

    @Override
    public void accept(ValueVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(ValueVisitor<R> visitor) {return visitor.visit(this);}
}
