package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.CallStack;
import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.StackFrame;

/**
 * Represents an ExitFrameCommand
 */
public class ExitFrameCmd extends PositionCommand {

    private StackFrame savedFrame;

    public ExitFrameCmd(ProgramState state, Position position, boolean isFirstInLine) {
        super(state, position, isFirstInLine);
    }

    /**
     * Removes thisFrame of the callStack
     */
    @Override
    protected void localExecute() {
        final CallStack callStack = getState().getCallStack();
        savedFrame = callStack.getCurrentFrame();
        callStack.setCurrentFrame(savedFrame.getParent());
    }

    /**
     * Re-adds thisFrame to the callStack
     */
    @Override
    protected void localUndo() {
        getState().getCallStack().setCurrentFrame(savedFrame);
    }

    public StackFrame getSavedFrame() {return savedFrame;}

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
