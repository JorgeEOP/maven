package de.unibwm.inf2.bugvis.model.value;

public class UnknownFieldException extends RuntimeException {
    public UnknownFieldException(String message) {super(message);}
}
