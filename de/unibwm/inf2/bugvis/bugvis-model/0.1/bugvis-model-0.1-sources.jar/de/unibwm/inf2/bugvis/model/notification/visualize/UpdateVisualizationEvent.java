package de.unibwm.inf2.bugvis.model.notification.visualize;

import de.unibwm.inf2.bugvis.model.VisualizationObject;

import java.util.concurrent.CountDownLatch;

public class UpdateVisualizationEvent implements VisualizeEvent {

    private final VisualizationObject newVisualizationObject;
    private final VisualizationObject oldVisualizationObject;

    public UpdateVisualizationEvent(VisualizationObject oldVisualizationObject, VisualizationObject newVisualizationObject) {
        this.newVisualizationObject = newVisualizationObject;
        this.oldVisualizationObject = oldVisualizationObject;
    }

    public VisualizationObject getNewVisualizationObject() {return newVisualizationObject;}

    public VisualizationObject getOldVisualizationObject() {return oldVisualizationObject;}

    @Override
    public void notifyListeners(VisualizeEventListener listener, CountDownLatch count) {
        listener.receivedEvent(this, count);
    }

    @Override
    public String toString() {return this.getClass().getSimpleName();}
}
