package de.unibwm.inf2.bugvis.model.history;

public interface CommandVoidVisitor {
    void visit(AssignArrayCmd cmd);

    void visit(AssignFieldCmd cmd);

    void visit(AssignStaticFieldCmd cmd);

    void visit(AssignVariableCmd cmd);

    void visit(CreateObjectCmd cmd);

    void visit(DeclareFieldCmd cmd);

    void visit(DeclareStaticFieldCmd cmd);

    void visit(DeclareVariableCmd cmd);

    void visit(EnterFrameCmd cmd);

    void visit(ExitFrameCmd cmd);

    void visit(IntermediateResultCmd cmd);

    void visit(OutputStreamCmd cmd);

    void visit(PositionCommand cmd);

    void visit(ReceiverParameterCmd cmd);

    void visit(ReturnCmd cmd);

    void visit(StartVisualizationCmd cmd);

    void visit(StopVisualizationCmd cmd);

    void visit(UpdateVisualizationCmd cmd);

    void visit(ModifiedListCmd cmd);

    void visit(ModifiedMapCmd cmd);
}
