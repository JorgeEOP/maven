package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple;
import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.value.Value;

public class IntermediateResultCmd extends PositionCommand {
    private final Value mirrorObject;

    public IntermediateResultCmd(ProgramState state, Position position, boolean isFirstInLine, ObjectClassTuple value) {
        super(state, position, isFirstInLine);
        this.mirrorObject = state.getMirrorObject(value);
    }

    @Override
    protected void localExecute() {
        getState().getCallStack().getCurrentFrame().addIntermediateResult(getPosition(), mirrorObject);
    }

    @Override
    protected void localUndo() {
        getState().getCallStack().getCurrentFrame().removeIntermediateResult(getPosition());
    }

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
