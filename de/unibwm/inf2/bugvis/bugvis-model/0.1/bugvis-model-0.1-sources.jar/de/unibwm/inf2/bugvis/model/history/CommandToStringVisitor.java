package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.Field;
import de.unibwm.inf2.bugvis.model.StackFrame;
import de.unibwm.inf2.bugvis.model.Variable;

public class CommandToStringVisitor implements CommandVisitor<String> {
    @Override
    public String visit(AssignArrayCmd cmd) {
        return "AssignArrayCommand{" + cmd.getPosition() + " - changed " + cmd.getArray() + " at index " +
               cmd.getIndex() + "\n\t\tfrom " + cmd.getOldValue() + "\n\t\tto " + cmd.getNewValue() + "\n\t}" +
               printSubcommands(cmd);
    }

    @Override
    public String visit(AssignFieldCmd cmd) {
        final Field field = cmd.getField();
        return "AssignFieldCommand{" + cmd.getPosition() + " - changed " + field.getVarKinds() + " " + field.getType() + " '" +
               field.getName() + "' " + field.getValue() + ":\n\t\t\tto: " + cmd.getMirrorObject() +
               "\n\t\t\t" + cmd.getOldValue() + "\n\t\t\t" + cmd.getNewValue() + "\n\t}" + printSubcommands(cmd);
    }

    @Override
    public String visit(AssignStaticFieldCmd cmd) {
        final Field field = cmd.getField();
        return "AssignStaticFieldCommand{" + cmd.getPosition() + " - changed " + field.getVarKinds() + " " + field.getType() +
               " '" + field.getName() + "'" + " | static of " + field.getDeclaringClass().getName() +
               ":\n\t\t\t" + cmd.getOldValue() + "\n\t\t\t" + cmd.getNewValue() + "\n\t}" + printSubcommands(cmd);
    }

    @Override
    public String visit(AssignVariableCmd cmd) {
        final Variable variable = cmd.getVariable();
        return "AssignVarCommand{" + cmd.getPosition() + " - changed " + variable.getVarKinds() +
               " " + variable.getType() + " '" + variable.getName() + "'" + ":\n\t\t\t" +
               cmd.getOldValue() + "\n\t\t\t" + cmd.getNewValue() + "}" + printSubcommands(cmd);
    }

    @Override
    public String visit(CreateObjectCmd cmd) {
        return "CreateObjectCommand{" + cmd.getPosition() + " - declared {(DObject) " + cmd.getMirrorObject().getClazz() +
               "} }" + printSubcommands(cmd);
    }

    @Override
    public String visit(DeclareFieldCmd cmd) {
        final Field field = cmd.getField();
        return "DeclareFieldCmd{" + cmd.getPosition() + " - declared " + field.getVarKinds() + " " + field.getType() + " '" +
               field.getName() + "' " + field.getValue() + ":\n\t\t\tto: " + cmd.getMirrorObject() + "\n\t}" +
               printSubcommands(cmd);
    }

    @Override
    public String visit(DeclareStaticFieldCmd cmd) {
        final Field field = cmd.getField();
        return "DeclareStaticFieldCommand{" + cmd.getPosition() + " - of " + field.getDeclaringClass() + "\n\t\tdeclared " +
               field.getVarKinds() + " " + field.getType() + " '" + field.getName() + "'\n\t}" + printSubcommands(cmd);
    }

    @Override
    public String visit(DeclareVariableCmd cmd) {
        final Variable variable = cmd.getVariable();
        return "DeclareVariableCommand{" + cmd.getPosition() + " - declared " + variable.getVarKinds() +
               " " + variable.getType() + " " + variable.getName() + " - }" + printSubcommands(cmd);
    }

    @Override
    public String visit(EnterFrameCmd cmd) {
        StringBuilder str = new StringBuilder();
        final StackFrame nestedFrame = cmd.getNestedFrame();
        str.append("EnterStackFrameCommand{")
           .append(cmd.getPosition());
        if (nestedFrame != null)
            str.append(" ")
               .append(nestedFrame.getMethod().getSignature()).append("}");
        else
            str.append(" null}");
        str.append(printSubcommands(cmd));
        return str.toString();
    }

    @Override
    public String visit(ExitFrameCmd cmd) {
        StringBuilder str = new StringBuilder();
        final StackFrame savedFrame = cmd.getSavedFrame();
        str.append("ExitStackFrameCommand{")
           .append(cmd.getPosition());
        if (savedFrame != null)
            str.append(" ")
               .append(savedFrame.getMethod().getSignature())
               .append("}");
        else
            str.append(" null}");
        str.append(printSubcommands(cmd));
        return str.toString();
    }

    @Override
    public String visit(IntermediateResultCmd cmd) {
        return "IntermediateResultCommand{" + cmd.getPosition() + "}" + printSubcommands(cmd);
    }

    @Override
    public String visit(OutputStreamCmd cmd) {
        return "OutputStreamCommand{outputType=" + cmd.getOutputType() + ", content='" + cmd.getContent() + "'" + "}" +
               printSubcommands(cmd);
    }

    @Override
    public String visit(PositionCommand cmd) {
        return "PositionCommand{" + cmd.getPosition() + "}" + printSubcommands(cmd);
    }

    @Override
    public String visit(ReceiverParameterCmd cmd) {
        return "ReceiverParameterCommand{" + cmd.getPosition() + " set " + cmd.getReceiverParameter() + "}" +
               printSubcommands(cmd);
    }

    @Override
    public String visit(ReturnCmd cmd) {
        return "SetReturnCommand{" + cmd.getPosition() + " set " + cmd.getValue() + "}" + printSubcommands(cmd);
    }

    @Override
    public String visit(StartVisualizationCmd cmd) {
        // TODO: what to to?
        return "StartVisualizationCmd{}" + printSubcommands(cmd);
    }

    @Override
    public String visit(StopVisualizationCmd cmd) {
        // TODO: what to to?
        return "StopVisualizationCmd{}" + printSubcommands(cmd);
    }

    @Override
    public String visit(UpdateVisualizationCmd cmd) {
        // TODO: what to to?
        return "UpdateVisualizationCmd{}" + printSubcommands(cmd);
    }

    @Override
    public String visit(ModifiedListCmd cmd) {
        return "ModifiedListCmd";
    }

    @Override
    public String visit(ModifiedMapCmd cmd) {
        return "ModifiedMapCmd";
    }

    private String printSubcommands(Command cmd) {
        StringBuilder sb = new StringBuilder();
        for (Command subCmd : cmd.getSubCommands())
            sb.append("\n\t\t").append(subCmd.accept(this));
        return sb.toString();
    }
}
