package de.unibwm.inf2.bugvis.model;

import java.util.List;

/**
 * Represents the different kinds, which can be used to set specific properties to a variable
 */
public enum VarKind {

    /**
     * Represents the key-word this
     */
    THIS,
    /**
     * Represents the modifier final
     */
    FINAL,
    /**
     * Indicates that a variable is a parameter
     */
    PARAMETER,
    /**
     * Indicates that a variable is a field
     */
    FIELD,
    /**
     * Represents the modifier static
     */
    STATIC;

    public static final List<VarKind> ORDINARY_PARAMETER = List.of(PARAMETER);
    public static final List<VarKind> RECEIVER_PARAMETER = List.of(THIS, PARAMETER);
}
