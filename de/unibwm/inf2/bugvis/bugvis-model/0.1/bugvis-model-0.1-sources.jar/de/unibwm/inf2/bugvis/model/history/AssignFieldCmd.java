package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.Field;
import de.unibwm.inf2.bugvis.model.FieldIdentifier;
import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.value.ReferenceValue;
import de.unibwm.inf2.bugvis.model.value.Value;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.DEBUG;

/**
 * Represents an AssignFieldCmd
 */
public class AssignFieldCmd extends PositionCommand {
    private static final Logger LOGGER = System.getLogger(AssignFieldCmd.class.getName());
    /**
     * target object whose attributes are being changed
     */
    private final ReferenceValue mirrorObject;
    /**
     * Field
     */
    private final Field field;
    /**
     * new value
     */
    private final Value newValue;
    /**
     * old value
     */
    private final Value oldValue;

    /**
     * Creates an AssignFieldCmd with the given target object and new field representation
     *
     * @param mirrorObject
     * @param identifier
     * @param value
     */
    public AssignFieldCmd(ProgramState state, Position position, boolean isFirstInLine, ReferenceValue mirrorObject,
                          FieldIdentifier identifier, Value value) {
        super(state, position, isFirstInLine);
        LOGGER.log(DEBUG, () -> "creating AssignFieldCmd for object " +
                                System.identityHashCode(mirrorObject.getObject()) +
                                " and field " + identifier);
        this.mirrorObject = mirrorObject;
        this.field = mirrorObject.getField(identifier);
        this.oldValue = field.getValue();
        this.newValue = value;
    }

    /**
     * Sets the field to the new value
     */
    @Override
    protected void localExecute() {
        LOGGER.log(DEBUG, () -> "executing AssignFieldCmd");
        field.setValue(newValue);
        LOGGER.log(DEBUG, () -> "executed AssignFieldCmd");
    }

    /**
     * Sets the field to the previous value or removes the field if it was not yet existing before.
     */
    @Override
    protected void localUndo() {
        LOGGER.log(DEBUG, () -> "undo AssignFieldCmd");
        field.setValue(oldValue);
        LOGGER.log(DEBUG, () -> "undo completed AssignFieldCmd");
    }

    public ReferenceValue getMirrorObject() {return mirrorObject;}

    public Field getField() {return field;}

    public Value getNewValue() {return newValue;}

    public Value getOldValue() {return oldValue;}

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
