package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.Field;
import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.value.ReferenceValue;

/**
 * Represents an DeclareFieldCmd
 */
public class DeclareFieldCmd extends PositionCommand {
    /**
     * target object whose attributes are being changed
     */
    private final ReferenceValue mirrorObject;
    /**
     * new field
     */
    private final Field field;

    /**
     * Creates an AssignFieldCmd with the given target object and new field representation
     *
     * @param mirrorObject
     * @param field
     */
    public DeclareFieldCmd(ProgramState state, Position position, boolean isFirstInLine, ReferenceValue mirrorObject, Field field) {
        super(state, position, isFirstInLine);
        this.mirrorObject = mirrorObject;
        this.field = field;
    }

    /**
     * Sets the field to the new value
     */
    @Override
    protected void localExecute() {
        mirrorObject.setField(field);
    }

    /**
     * Sets the field to the previous value or removes the field if it was not yet existing before.
     */
    @Override
    protected void localUndo() {
        mirrorObject.removeField(field.getIdentifier());
    }

    public ReferenceValue getMirrorObject() {return mirrorObject;}

    public Field getField() {return field;}

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
