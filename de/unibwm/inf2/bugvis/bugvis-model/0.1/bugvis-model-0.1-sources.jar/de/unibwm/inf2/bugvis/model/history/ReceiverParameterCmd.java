package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.value.Value;

public class ReceiverParameterCmd extends PositionCommand {

    /**
     * Receiver Parameter
     */
    private final Value receiverParameter;

    /**
     * Creates a ReceiverParameterCmd with the current frame and given value
     *
     * @param receiverParameter receiver parameter value.
     */
    public ReceiverParameterCmd(ProgramState state, Position position, boolean isFirstInLine, Value receiverParameter) {
        super(state, position, isFirstInLine);
        this.receiverParameter = receiverParameter;
    }

    @Override
    protected void localExecute() {
        getState().getCallStack().getCurrentFrame().setReceiverParameter(receiverParameter);
    }

    @Override
    protected void localUndo() {
        getState().getCallStack().getCurrentFrame().setReceiverParameter(null);
    }

    public Value getReceiverParameter() {return receiverParameter;}

    @Override
    public boolean alwaysContinue() {return true;}

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
