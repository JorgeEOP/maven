package de.unibwm.inf2.bugvis.model.notification;

import java.util.concurrent.CountDownLatch;

public interface SynchronizedEvent<T extends SynchronizedEventListener> {
    void notifyListeners(T listener, CountDownLatch count);
}
