package de.unibwm.inf2.bugvis.model.notification.debugee;

import de.unibwm.inf2.bugvis.model.FieldIdentifier;

public class StaticFieldAssignmentEvent implements DebugeeEvent {

    private final FieldIdentifier identifier;

    public StaticFieldAssignmentEvent(FieldIdentifier identifier) {this.identifier = identifier;}

    @Override
    public void notifyListeners(DebugeeEventListener listener) {listener.receivedEvent(this);}

    public FieldIdentifier getIdentifier() {return identifier;}
}
