package de.unibwm.inf2.bugvis.model.notification.console;

import de.unibwm.inf2.bugvis.model.history.OutputStreamCmd.OutputType;

import java.util.concurrent.CountDownLatch;

public class ConsoleAddOutputEvent implements ConsoleEvent {

    private final String text;
    private final OutputType outputType;

    public ConsoleAddOutputEvent(String text, OutputType outputType) {
        this.text = text;
        this.outputType = outputType;
    }

    public String getText() {return text;}

    public OutputType getOutputType() {return outputType;}

    @Override
    public void notifyListeners(ConsoleEventListener listener, CountDownLatch count) {
        listener.receivedEvent(this, count);
    }

    @Override
    public String toString() {return this.getClass().getSimpleName();}
}
