package de.unibwm.inf2.bugvis.model;

import de.unibwm.inf2.bugvis.model.notification.visualize.VisualizeEvent;
import de.unibwm.inf2.bugvis.model.notification.visualize.VisualizeEventListener;

import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.lang.System.Logger.Level.INFO;

/**
 * Manages the state of visualizations and notifies registered listeners about visualization events.
 * <p>
 * This class maintains a mapping between original objects and their corresponding visual representations,
 * and provides methods to add, retrieve, and remove visualizations. It also supports registering listeners
 * that are notified when a visualization event occurs.
 */
public class VisualizationState {
    private static final Logger LOGGER = System.getLogger(VisualizationState.class.getName());

    private final ProgramState state;
    private final Map<Integer, VisualizationObject> visualizations = new HashMap<>();
    private final List<VisualizeEventListener> listeners = new ArrayList<>();

    public VisualizationState(ProgramState state) {this.state = state;}

    /**
     * Registers a new listener to receive visualization events.
     *
     * @param listener the VisualizeEventListener to be added.
     */
    public void addListener(VisualizeEventListener listener) {
        listeners.add(listener);
    }

    /**
     * Removes a previously registered visualization event listener.
     *
     * @param listener the VisualizeEventListener to be removed.
     */
    public void removeListener(VisualizeEventListener listener) {
        listeners.remove(listener);
    }

    /**
     * Notifies all registered listeners of a visualization event.
     * <p>
     * This method triggers the notification on all listeners concurrently and waits until all listeners have completed
     * processing the event. If the waiting is interrupted, an error is logged and a RuntimeException is thrown.
     *
     * @param event the VisualizeEvent to be dispatched to the listeners.
     */
    public void notifyListeners(VisualizeEvent event) {
        state.notifyListeners(listeners, event);
    }

    /**
     * Retrieves the visual representation corresponding to the given original object.
     *
     * @param hashCode the original object whose visualization is to be retrieved.
     * @return the VisualizationObject representing the visualization, or {@code null} if no visualization exists.
     */
    public VisualizationObject get(int hashCode) {
        VisualizationObject visualizationObject = visualizations.get(hashCode);
        LOGGER.log(INFO, "Visualization_object: " + visualizationObject);
        return visualizationObject;
    }

    /**
     * Adds a new visual representation to the state.
     * <p>
     * The visualization is associated with its original object, which is obtained from the given {@link VisualizationObject}.
     *
     * @param object the VisualizationObject representing the visualization to be added.
     */
    public void add(VisualizationObject object) {
        visualizations.put(object.getHashCode(), object);
    }

    /**
     * Removes the visual representation corresponding to the given object from the state.
     *
     * @param hashCode the VisualizationObject representing the visualization to be removed.
     */
    public void remove(int hashCode) {
        visualizations.remove(hashCode);
    }

    /**
     * Checks if a visual representation is present.
     *
     * @param hashCode The underlying object of the visualization
     * @return True if a visualization exists for the given object, false otherwise.
     */
    public boolean contains(int hashCode) {return visualizations.containsKey(hashCode);}
}
