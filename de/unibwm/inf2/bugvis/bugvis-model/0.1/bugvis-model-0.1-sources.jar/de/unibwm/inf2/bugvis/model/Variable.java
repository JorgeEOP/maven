package de.unibwm.inf2.bugvis.model;

import de.unibwm.inf2.bugvis.model.value.NullValue;
import de.unibwm.inf2.bugvis.model.value.Value;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a variable
 */
public class Variable {

    /**
     * list containing all {@link de.unibwm.inf2.bugvis.model.VarKind}s of this variable.
     */
    private final List<VarKind> varKinds = new ArrayList<>();

    /**
     * name of the class of the variable
     */
    private final String type;

    /**
     * name of the variable
     */
    private final String name;

    /**
     * debug representation of the value stored in this variable
     */
    private Value value;

    /**
     * Creates a new variable with the given parameters.
     *
     * @param varKinds {@link de.unibwm.inf2.bugvis.model.VarKind}s of the variable.
     * @param type     class of the variable.
     * @param name     {@link de.unibwm.inf2.bugvis.model.Variable} name.
     * @param value    debug representation of the value stored in this variable.
     */
    public Variable(List<VarKind> varKinds, String type, String name, Value value) {
        this.varKinds.addAll(varKinds);
        this.type = type;
        this.name = name;
        this.value = value;
    }

    /**
     * Creates a new variable with the given parameters and value = {@link de.unibwm.inf2.bugvis.model.value.VoidValue}.
     *
     * @param varKinds {@link de.unibwm.inf2.bugvis.model.VarKind}s of the variable.
     * @param type     name of the class of the variable.
     * @param name     {@link de.unibwm.inf2.bugvis.model.Variable} name.
     */
    public Variable(List<VarKind> varKinds, String type, String name) {
        this(varKinds, type, name, NullValue.INSTANCE);
    }

    /**
     * Sets the debug representation of the value of this variable.
     *
     * @param value debug representation of the value stored in this variable.
     */
    public void setValue(Value value) {
        this.value = value;
    }

    /**
     * Returns the name of this variable.
     *
     * @return the name of this variable.
     */
    public String getName() {return name;}

    /**
     * Returns the debug representation of the value of this variable.
     *
     * @return the debug representation of the value of this variable.
     */
    public Value getValue() {return value;}

    /**
     * Returns the {@link de.unibwm.inf2.bugvis.model.VarKind}s of this variable.
     *
     * @return the {@link de.unibwm.inf2.bugvis.model.VarKind}s of this variable.
     */
    public List<VarKind> getVarKinds() {return varKinds;}

    /**
     * Returns the name of the class of this variable.
     *
     * @return the name of the class of this variable.
     */
    public String getType() {
        return type.replace(">", "&gt");
    }

    /**
     * Returns a string representation of this variable.
     *
     * @return a string representation of this variable.
     */
    @Override
    public String toString() {
        return "Variable{[" + String.join(", ", varKinds.stream().map(VarKind::toString).toList()) +
               "] " + type + " " + name + "}";
    }
}
