package de.unibwm.inf2.bugvis.model;

import java.util.Comparator;

/**
 * Identifier for an attribute.
 * <br>
 *
 * @param declaringClass The class which declared this attribute.
 * @param name           The name of the attribute.
 */
public record FieldIdentifier(Class<?> declaringClass, String name)
        implements Comparable<FieldIdentifier> {

    public static final Comparator<FieldIdentifier> COMPARATOR = Comparator
            .comparing(FieldIdentifier::className).thenComparing(FieldIdentifier::name);

    @Override
    public int compareTo(FieldIdentifier other) {return COMPARATOR.compare(this, other);}

    private static String className(FieldIdentifier identifier) {return identifier.declaringClass.getName();}
}
