package de.unibwm.inf2.bugvis.model.value;

/**
 * Represents an object of any kind for a {@link de.unibwm.inf2.bugvis.model.ProgramState}.
 */
public abstract class Value {

    /**
     * The original object.
     */
    private final Object object;
    private final Class<?> clazz;

    /**
     * @param object the original object.
     */
    protected Value(Object object, Class<?> clazz) {
        this.object = object;
        this.clazz = clazz;
    }

    /**
     * Returns the original value (object), which is mirrored by this instance.
     *
     * @return the original value (object), which is mirrored by this instance.
     */
    public Object getObject() {return object;}

    public Class<?> getClazz() {return clazz;}

    /**
     * Returns a string representation of this mirror object.
     *
     * @return a string representation of this mirror object.
     */
    @Override
    public String toString() {
        return "Value{object=" + object + "}";
    }

    public ArrayValue asArrayValue() {throw new ClassCastException();}

    public ListValue asListValue() {throw new ClassCastException();}

    public MapValue asMapValue() {throw new ClassCastException();}

    public NullValue asNullValue() {throw new ClassCastException();}

    public PrimitiveValue asPrimitiveValue() {throw new ClassCastException();}

    public ReferenceValue asReferenceValue() {throw new ClassCastException();}

    public VoidValue asVoidValue() {throw new ClassCastException();}

    public WrappedValue asWrappedValue() {throw new ClassCastException();}

    public boolean isArrayValue() {return false;}

    public boolean isListValue() {return false;}

    public boolean isMapValue() {return false;}

    public boolean isNullValue() {return false;}

    public boolean isPrimitiveValue() {return false;}

    public boolean isReferenceValue() {return false;}

    public boolean isVoidValue() {return false;}

    public boolean isWrappedValue() {return false;}

    public abstract void accept(ValueVoidVisitor visitor);

    public abstract <R> R accept(ValueVisitor<R> visitor);
}
