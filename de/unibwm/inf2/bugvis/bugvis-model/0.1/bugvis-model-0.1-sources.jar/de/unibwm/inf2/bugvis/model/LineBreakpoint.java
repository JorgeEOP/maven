package de.unibwm.inf2.bugvis.model;

/**
 * Represents a line breakpoint, which allows to interrupt the program execution.
 */
public class LineBreakpoint implements Breakpoint {
    private final int fileId;
    private final int line;

    /**
     * Creates a line breakpoint with given file id and line.
     *
     * @param fileId ID of the file in which the breakpoint is placed
     * @param line   Line of this file in which the breakpoint is placed
     */
    public LineBreakpoint(int fileId, int line) {
        this.fileId = fileId;
        this.line = line;
    }

    @Override
    public int getFileId() {return fileId;}

    @Override
    public int getLine() {return line;}

    @Override
    public String toString() {return fileId + ":" + line;}

    @Override
    public int hashCode() {return fileId * 31 + line * 7;}

    @Override
    public boolean equals(Object o) {
        if (o == null) return false;
        if (o == this) return true;
        if (o instanceof LineBreakpoint other) {
            if (!other.canEqual(this)) return false;
            return fileId == other.fileId && line == other.line;
        }
        return false;
    }

    public boolean canEqual(Object o) {return o instanceof LineBreakpoint;}
}
