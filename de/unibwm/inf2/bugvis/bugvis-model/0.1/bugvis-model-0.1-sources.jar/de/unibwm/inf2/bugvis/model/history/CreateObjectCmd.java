package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.Position;
import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.value.Value;

/**
 * Represents a CreateObjectCommand
 */
public class CreateObjectCmd extends PositionCommand {

    /**
     * Object being represented
     */
    private final Object object;

    /**
     * Representing object
     */
    private final Value mirrorObject;

    /**
     * Creates a CreateObjectCmd with the given frame, object and representing object
     *
     * @param object
     * @param mirrorObject
     */
    public CreateObjectCmd(ProgramState state, Position position, boolean isFirstInLine, Object object, Value mirrorObject) {
        super(state, position, isFirstInLine);
        this.object = object;
        this.mirrorObject = mirrorObject;
    }

    /**
     * Adds the pair of object and representing object to debVals of programState
     */
    @Override
    protected void localExecute() {
        getState().putMirrorObject(object, mirrorObject);
    }

    /**
     * Removes the pair of object and representing object of debVals of programState
     */
    @Override
    protected void localUndo() {
        getState().removeMirrorObject(object);
    }

    public Value getMirrorObject() {return mirrorObject;}

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
