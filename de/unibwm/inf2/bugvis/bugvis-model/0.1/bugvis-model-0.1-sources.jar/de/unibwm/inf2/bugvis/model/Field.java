package de.unibwm.inf2.bugvis.model;

import de.unibwm.inf2.bugvis.model.value.Value;

import java.util.List;

/**
 * Represents an attribute and extends a {@link de.unibwm.inf2.bugvis.model.Variable}.
 * <br />
 * The attribute needs to know in which class it was declared.
 */
public class Field extends Variable {

    private final FieldIdentifier identifier;

    public Field(List<VarKind> varKinds, String type, String name, Value value, Class<?> declaringClass) {
        super(varKinds, type, name, value);
        this.identifier = new FieldIdentifier(declaringClass, name);
    }

    /**
     * Returns the class in which this attribute was declared.
     *
     * @return the class in which this attribute was declared.
     */
    public Class<?> getDeclaringClass() {return identifier.declaringClass();}

    public FieldIdentifier getIdentifier() {return identifier;}

    /**
     * Returns a string representation of this attribute.
     *
     * @return a string representation of this attribute.
     */
    @Override
    public String toString() {
        return "Field{[" + String.join(", ", getVarKinds().stream().map(VarKind::toString).toList()) + "] " +
               //getDeclaringClass().getName() + ": " + getType() + " " + getName() + " = " + getValue() + "}";
               getDeclaringClass().getName() + ": " + getType() + " " + getName() + "}";
    }
}
