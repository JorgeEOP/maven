package de.unibwm.inf2.bugvis.model.notification.debugee;

public interface DebugeeEventListener {

    void receivedEvent(ArrayAssignmentEvent arrayAssignmentEvent);

    void receivedEvent(FieldAssignmentEvent fieldAssignmentEvent);

    void receivedEvent(FacadeModifiedEvent facadeModifiedEvent);

    void receivedEvent(FrameEnteredEvent frameEnteredEvent);

    void receivedEvent(ObjectCreationEvent objectCreationEvent);

    void receivedEvent(StaticFieldAssignmentEvent staticFieldAssignmentEvent);
}
