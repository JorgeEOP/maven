package de.unibwm.inf2.bugvis.model.notification.debugee;

import java.lang.System.Logger;
import java.util.Objects;

import static java.lang.System.Logger.Level.DEBUG;

public class FacadeModifiedEvent implements DebugeeEvent {
    private static final Logger LOGGER = System.getLogger(FacadeModifiedEvent.class.getName());

    private final Object facade;

    public FacadeModifiedEvent(Object facade) {
        Objects.requireNonNull(facade);
        this.facade = facade;
    }

    @Override
    public void notifyListeners(DebugeeEventListener listener) {
        LOGGER.log(DEBUG, () -> "notify " + listener);
        listener.receivedEvent(this);
        LOGGER.log(DEBUG, () -> "listener was notified " + listener);
    }

    public Object getFacade() {return facade;}
}
