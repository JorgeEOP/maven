package de.unibwm.inf2.bugvis.model.value;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * A debug representation of a List.
 */
public class ListValue extends Value {

    /**
     * components of the list.
     */
    private List<Value> componentMirrorObjects;

    /**
     * Creates a debug representation for an object that extends list with the given debug representations of the components.
     */
    public ListValue(Object obj, List<Value> componentMirrorObjects) {
        super(obj, obj.getClass());
        Objects.requireNonNull(obj);
        this.componentMirrorObjects = componentMirrorObjects;
    }

    /**
     * Returns the number of components in this debug representation of a list.
     *
     * @return the number of components in this debug representation of a list.
     */
    public int getLength() {return componentMirrorObjects.size();}

    /**
     *
     * @return
     */
    public List<Value> getComponentMirrorObjects() {
        return Collections.unmodifiableList(componentMirrorObjects);
    }

    /**
     *
     * @param componentMirrorObjects
     */
    public void setComponentMirrorObjects(List<Value> componentMirrorObjects) {
        this.componentMirrorObjects = componentMirrorObjects;
    }

    /**
     * Returns a string representation of this {@link ListValue}.
     *
     * @return a string representation of this {@link ListValue}.
     */
    @Override
    public String toString() {
        return "ListValue{size=" + getLength() + ", components=" + componentMirrorObjects + "}";
    }

    /**
     *
     * @return
     */
    @Override
    public ListValue asListValue() {return this;}

    /**
     *
     * @return
     */
    @Override
    public boolean isListValue() {return true;}

    /**
     *
     * @param visitor
     */
    public void accept(ValueVoidVisitor visitor) {visitor.visit(this);}

    /**
     *
     * @param visitor
     * @param <R>
     * @return
     */
    public <R> R accept(ValueVisitor<R> visitor) {return visitor.visit(this);}
}
