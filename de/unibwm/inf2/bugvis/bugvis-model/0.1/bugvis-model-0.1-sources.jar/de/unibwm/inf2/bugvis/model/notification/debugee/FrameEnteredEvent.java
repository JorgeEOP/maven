package de.unibwm.inf2.bugvis.model.notification.debugee;

import de.unibwm.inf2.bugvis.instr.runtime.ObjectClassTuple;

public class FrameEnteredEvent implements DebugeeEvent {

    private final Object receiverParameter;
    private final String signature;

    public FrameEnteredEvent(ObjectClassTuple receiverParameter, String signature) {
        this.receiverParameter = receiverParameter != null ? receiverParameter.getObject() : null;
        this.signature = signature;
    }

    @Override
    public void notifyListeners(DebugeeEventListener listener) {listener.receivedEvent(this);}

    public Object getReceiverParameter() {return receiverParameter;}

    public String getSignature() {return signature;}
}
