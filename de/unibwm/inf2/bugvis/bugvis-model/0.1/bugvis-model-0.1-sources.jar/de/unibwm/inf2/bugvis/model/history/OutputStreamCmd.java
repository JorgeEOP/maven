package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.notification.console.ConsoleAddOutputEvent;
import de.unibwm.inf2.bugvis.model.notification.console.ConsoleRemOutputEvent;

public class OutputStreamCmd extends Command {
    public enum OutputType {DEFAULT, ERROR, INPUT}

    private final String content;
    private final OutputType outputType;

    public OutputStreamCmd(ProgramState state, String content, OutputType outputType) {
        super(state);
        this.content = content;
        this.outputType = outputType;
    }

    @Override
    protected void localExecute() {
        getState().notifyListeners(new ConsoleAddOutputEvent(content, outputType));
    }

    @Override
    protected void localUndo() {
        getState().notifyListeners(new ConsoleRemOutputEvent(content, outputType));
    }

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}

    public OutputType getOutputType() {return outputType;}

    public String getContent() {return content;}
}
