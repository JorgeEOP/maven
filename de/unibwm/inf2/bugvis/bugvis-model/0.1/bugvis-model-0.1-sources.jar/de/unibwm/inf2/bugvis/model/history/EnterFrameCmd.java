package de.unibwm.inf2.bugvis.model.history;

import de.unibwm.inf2.bugvis.model.ProgramState;
import de.unibwm.inf2.bugvis.model.StackFrame;

/**
 * Represents an EnterFrameCommand
 */
public class EnterFrameCmd extends PositionCommand {

    private final StackFrame nestedFrame;

    /**
     * Creates a new EnterFrameCmd with the given frame
     *
     * @param nestedFrame
     */
    public EnterFrameCmd(ProgramState state, StackFrame nestedFrame) {
        super(state, nestedFrame.getPosition(), true);
        this.nestedFrame = nestedFrame;
    }

    @Override
    public void updatePosition() {
        // new StackFrame has its own position
    }

    /**
     * Adds thisFrame to the callStack
     */
    @Override
    protected void localExecute() {
        getState().getCallStack().setCurrentFrame(nestedFrame);
    }

    /**
     * Removes thisFrame of the callStack
     */
    @Override
    protected void localUndo() {
        getState().getCallStack().setCurrentFrame(nestedFrame.getParent());
    }

    public StackFrame getNestedFrame() {return nestedFrame;}

    @Override
    public boolean alwaysContinue() {return true;}

    @Override
    public void accept(CommandVoidVisitor visitor) {visitor.visit(this);}

    @Override
    public <R> R accept(CommandVisitor<R> visitor) {return visitor.visit(this);}
}
