package de.unibwm.inf2.bugvis.model.value;

import de.unibwm.inf2.bugvis.model.Field;
import de.unibwm.inf2.bugvis.model.FieldIdentifier;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * A debug representation of an arbitrary object.
 */
public class ReferenceValue extends Value {

    /**
     * list containing all debug representations of the attributes.
     */
    private final Map<FieldIdentifier, Field> fields = new HashMap<>();

    /**
     * Creates a new VObject with the given attributes.
     *
     * @param object the mirrored object.
     */
    public ReferenceValue(Object object) {
        super(object, object.getClass());
        Objects.requireNonNull(object);
    }

    /**
     * Sets the given {@link de.unibwm.inf2.bugvis.model.Variable} as new field.
     * If there is already a field with the same name, this field
     * will be replaced by the new one
     *
     * @param field the debug representation of a field.
     */
    public void setField(Field field) {
        fields.put(field.getIdentifier(), field);
    }

    /**
     * Remove all debug representations of attributes with the given name.
     */
    public void removeField(FieldIdentifier identifier) {
        fields.remove(identifier);
    }

    /**
     * Returns the mirror object of an attribute with the given name, if it exists, otherwise null.
     *
     * @return the debug representation of an attribute with the given name, if it exists, otherwise null.
     * @throws de.unibwm.inf2.bugvis.model.value.UnknownFieldException if the given {@link de.unibwm.inf2.bugvis.model.FieldIdentifier} is unknown.
     */
    public Field getField(FieldIdentifier identifier) {
        if (!fields.containsKey(identifier))
            throw new UnknownFieldException("Field '%s' of Object '%s' not found."
                                                    .formatted(identifier.name(), System.identityHashCode(getObject())));
        return fields.get(identifier);
    }

    public List<Field> getFields() {
        return List.copyOf(fields.values());
    }

    /**
     * Returns a string representation of this {@link ReferenceValue}.
     *
     * @return a string representation of this {@link ReferenceValue}.
     */
    @Override
    public String toString() {
        return "ReferenceValue{object=" + System.identityHashCode(getObject()) + ", attributes=" + fields + '}';
    }

    @Override
    public ReferenceValue asReferenceValue() {return this;}

    @Override
    public boolean isReferenceValue() {return true;}

    public void accept(ValueVoidVisitor visitor) {visitor.visit(this);}

    public <R> R accept(ValueVisitor<R> visitor) {return visitor.visit(this);}
}
