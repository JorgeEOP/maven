package de.unibwm.inf2.bugvis.instr.translation;

import com.github.javaparser.ast.nodeTypes.NodeWithParameters;
import com.github.javaparser.resolution.declarations.ResolvedMethodLikeDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedParameterDeclaration;

import java.util.ArrayList;
import java.util.List;

public record NameType(String name, String type) {

    public static List<NameType> fromNodeWithParameters(NodeWithParameters<?> node) {
        return node.getParameters().stream().map(p -> new NameType(p.getNameAsString(), p.getTypeAsString())).toList();
    }

    public static List<NameType> fromResolvedMethodLikeDeclaration(ResolvedMethodLikeDeclaration rmld) {
        List<NameType> nts = new ArrayList<>();
        for (int i = 0; i < rmld.getNumberOfParams(); ++i) {
            ResolvedParameterDeclaration rpd = rmld.getParam(i);
            nts.add(new NameType(rpd.getName(), rpd.describeType()));
        }
        return nts;
    }
}