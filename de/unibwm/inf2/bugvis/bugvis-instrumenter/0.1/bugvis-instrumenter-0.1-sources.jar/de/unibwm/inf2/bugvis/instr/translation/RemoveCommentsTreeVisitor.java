package de.unibwm.inf2.bugvis.instr.translation;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.comments.Comment;
import com.github.javaparser.ast.visitor.TreeVisitor;

public class RemoveCommentsTreeVisitor extends TreeVisitor {

    @Override
    public void process(Node node) {
        node.removeComment();
        while (!node.getOrphanComments().isEmpty()) {
            Comment comment = node.getOrphanComments().getFirst();
            node.removeOrphanComment(comment);
        }
    }
}
