package de.unibwm.inf2.bugvis.instr.translation.stmt;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.stmt.BlockStmt;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.DEBUG;

public class BlockStmtTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(BlockStmtTranslator.class.getName());
    private final TranslationVisitor tv;
    private final BlockStmt bs;
    private final Object arg;

    public BlockStmtTranslator(TranslationVisitor translationVisitor, BlockStmt blockStmt, Object arg) {
        LOGGER.log(DEBUG, () -> "creating BlockStmtTranslator (" + blockStmt + ", " + arg + ")");
        this.tv = translationVisitor;
        this.bs = blockStmt;
        this.arg = arg;
    }

    @Override
    public Node translate() {
        BlockStmt newBlockStmt = new BlockStmt();
        translateBlockStmt(bs, newBlockStmt, arg);
        copyCommentsAndData(bs, newBlockStmt);
        return newBlockStmt;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {
        return this.tv;
    }

    @Override
    public Runtime getRuntime() {return Runtime.STATEMENT_RUNTIME;}
}
