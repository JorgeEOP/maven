package de.unibwm.inf2.bugvis.instr.translation;

public enum Runtime {
    DECLARATION_RUNTIME(NodeTranslatorConstants.DECL_RUNTIME_GETTER),
    EXPRESSION_RUNTIME(NodeTranslatorConstants.EXPR_RUNTIME_GETTER),
    STATEMENT_RUNTIME(NodeTranslatorConstants.STMT_RUNTIME_GETTER);

    public static final String BUG_VIS_INSTR = NodeTranslatorConstants.BUG_VIS_INSTR;

    private final String methodName;

    Runtime(String methodName) {this.methodName = methodName;}

    public String getMethodName() {return methodName;}
}
