package de.unibwm.inf2.bugvis.instr;

import com.github.javaparser.ast.CompilationUnit;
import de.unibwm.inf2.bugvis.instr.metainfo.FileMetaInfo;

import java.time.Duration;
import java.time.LocalTime;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public class FileInstrumenterResult {
    private final boolean successful;
    private final Target target;
    private final LocalTime startTime;
    private final LocalTime endTime;
    private final Duration duration;

    private final CompilationUnit compilationUnit;
    private final FileMetaInfo fileMetaInfo;
    private final Map<String, Set<String>> instrClassMethodMap;

    private final Exception exception;

    public FileInstrumenterResult(Target target,
                                  LocalTime startTime,
                                  LocalTime endTime,
                                  CompilationUnit compilationUnit,
                                  FileMetaInfo fileMetaInfo,
                                  Map<String, Set<String>> instrClassMethodMap) {
        this(true, target, startTime, endTime, compilationUnit, fileMetaInfo, instrClassMethodMap, null);
    }

    public FileInstrumenterResult(Target target,
                                  LocalTime startTime,
                                  LocalTime endTime,
                                  Exception exception) {
        this(false, target, startTime, endTime, null, null, null, exception);
    }

    private FileInstrumenterResult(boolean successful,
                                   Target target,
                                   LocalTime startTime,
                                   LocalTime endTime,
                                   CompilationUnit compilationUnit,
                                   FileMetaInfo fileMetaInfo,
                                   Map<String, Set<String>> instrClassMethodMap,
                                   Exception exception) {
        this.successful = successful;
        this.target = target;
        this.startTime = startTime;
        this.endTime = endTime;
        this.duration = Duration.between(startTime, endTime);
        this.compilationUnit = compilationUnit;
        this.fileMetaInfo = fileMetaInfo;
        this.instrClassMethodMap = instrClassMethodMap;
        this.exception = exception;
    }

    public boolean isSuccessful() {return successful;}

    public Target getTarget() {return target;}

    public LocalTime getStartTime() {return startTime;}

    public LocalTime getEndTime() {return endTime;}

    public Duration getDuration() {return duration;}

    public Optional<CompilationUnit> getCompilationUnit() {return Optional.ofNullable(compilationUnit);}

    public Optional<FileMetaInfo> getFileMetaInfo() {return Optional.ofNullable(fileMetaInfo);}

    public Optional<Map<String, Set<String>>> getInstrClassMethodMap() {return Optional.ofNullable(instrClassMethodMap);}

    public Optional<Exception> getException() {return Optional.ofNullable(exception);}
}