package de.unibwm.inf2.bugvis.instr.translation.stmt;

import com.github.javaparser.Range;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.LambdaExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.NullLiteralExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ReturnStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.type.Type;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.lang.System.Logger.Level.DEBUG;

public class ReturnStmtTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(ReturnStmtTranslator.class.getName());

    private final ReturnStmt rs;
    private final TranslationVisitor tv;
    private final Expression expression;
    private final Object arg;

    public ReturnStmtTranslator(TranslationVisitor translationVisitor, ReturnStmt returnStmt, Object arg) {
        LOGGER.log(DEBUG, () -> "creating ReturnStmtTranslator (" + returnStmt + ", " + arg + ")");
        this.tv = translationVisitor;
        this.rs = returnStmt;
        this.expression = returnStmt.getExpression().orElse(null);
        this.arg = arg;
    }

    @Override
    public Statement translate() {
        BlockStmt codeBlock = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));

        final ReturnStmt r = new ReturnStmt();
        copyCommentsAndData(rs, r);

        final List<Expression> list = new ArrayList<>();

        if (expression == null)
            codeBlock.addStatement(makeMethodCall(getReturnRange(rs), getRuntime(), RETURN_WITHOUT_VALUE, list));
        else if (expression.isNullLiteralExpr()) {
            list.add(value(new NullLiteralExpr()));
            codeBlock.addStatement(makeMethodCall(getReturnRange(rs), getRuntime(), RETURN_VALUE, list));
            r.setExpression(new NullLiteralExpr());
        }
        else {
            final Optional<LambdaExpr> optionalLambdaExpr = rs.findAncestor(LambdaExpr.class);
            String varName;
            if (optionalLambdaExpr.isPresent())
                varName = storeResult(codeBlock, tv.translateNode(expression, arg));
            else {
                Type type = applyFacades(rs.findAncestor(MethodDeclaration.class).get().getType());
                varName = storeResult(codeBlock, tv.translateNode(expression, type), type);
            }
            list.add(value(new NameExpr(varName)));
            codeBlock.addStatement(makeMethodCall(getReturnRange(rs), getRuntime(), RETURN_VALUE, list));
            r.setExpression(new NameExpr(varName));
        }

        codeBlock.getStatements().add(r);
        return null;
    }

    private Range getReturnRange(ReturnStmt returnStmt) {
        return returnStmt.getRange().map(range -> Range.range(range.begin, range.begin.right(5)))
                         .orElse(UNDEFINED_RANGE);
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {
        return tv;
    }

    @Override
    public Runtime getRuntime() {return Runtime.STATEMENT_RUNTIME;}
}
