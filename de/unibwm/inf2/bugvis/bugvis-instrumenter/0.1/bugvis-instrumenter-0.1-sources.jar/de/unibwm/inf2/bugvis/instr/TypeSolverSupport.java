package de.unibwm.inf2.bugvis.instr;

import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JarTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JavaParserTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;

import java.io.File;
import java.io.IOException;
import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static java.lang.System.Logger.Level.ERROR;

public class TypeSolverSupport {
    private static final Logger LOGGER = System.getLogger(TypeSolverSupport.class.getName());

    private InstrumenterOptions options;

    public TypeSolverSupport(InstrumenterOptions options) {this.options = options;}

    public CombinedTypeSolver getTypeSolver() {
        CombinedTypeSolver typeSolver = new CombinedTypeSolver();
        createPathTypeSolvers(options.getPathTypeSolverFiles()).forEach(typeSolver::add);
        createJarTypeSolvers(options.getJarTypeSolverFiles()).forEach(typeSolver::add);
        if (options.isReflectionTypeSolver()) typeSolver.add(new ReflectionTypeSolver());
        return typeSolver;
    }

    private List<JavaParserTypeSolver> createPathTypeSolvers(Set<File> pathTypeSolverFiles) {
        List<JavaParserTypeSolver> pathTypeSolvers = new ArrayList<>();
        for (File f : pathTypeSolverFiles)
            pathTypeSolvers.add(new JavaParserTypeSolver(f));
        return pathTypeSolvers;
    }

    private List<JarTypeSolver> createJarTypeSolvers(Set<File> jarTypeSolverFiles) {
        List<JarTypeSolver> jarTypeSolvers = new ArrayList<>();
        for (File f : jarTypeSolverFiles)
            try {
                jarTypeSolvers.add(new JarTypeSolver(f));
            }
            catch (IOException e) {
                e.printStackTrace();
                LOGGER.log(ERROR, "Failed to load jar type solver: {0}", f);
            }
        return jarTypeSolvers;
    }
}
