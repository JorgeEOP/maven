package de.unibwm.inf2.bugvis.instr.translation.body;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.CallableDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.body.ReceiverParameter;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.FieldAccessExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.ReferenceType;
import com.github.javaparser.ast.type.TypeParameter;
import de.unibwm.inf2.bugvis.instr.translation.NameType;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.util.ArrayList;
import java.util.List;

public interface MethodLikeTranslator extends NodeTranslator {

    record MethodLikeComponents(NodeList<Modifier> modifiers,
                                SimpleName name,
                                NodeList<Parameter> parameters,
                                ReceiverParameter receiverParameter,
                                NodeList<ReferenceType> thrownExceptions,
                                NodeList<TypeParameter> typeParameters,
                                NodeList<AnnotationExpr> annotations) {}

    default <M extends CallableDeclaration<?>> MethodLikeComponents translateMethodLikeComponents(CallableDeclaration<M> cd) {
        final TranslationVisitor tv = getTranslationVisitor();
        return new MethodLikeComponents(tv.translateList(cd.getModifiers()),
                                        tv.translateNode(cd.getName()),
                                        applyFacades(tv.translateList(cd.getParameters())),
                                        tv.translateNode(cd.getReceiverParameter()),
                                        tv.translateList(cd.getThrownExceptions()),
                                        tv.translateList(cd.getTypeParameters()),
                                        tv.translateList(cd.getAnnotations()));
    }

    default NodeList<Parameter> applyFacades(NodeList<Parameter> parameters) {
        parameters.forEach(this::applyFacades);
        return parameters;
    }

    default void applyFacades(Parameter p) {
        if (p.getType().isClassOrInterfaceType()) {
            final ClassOrInterfaceType oldCoit = p.getType().asClassOrInterfaceType();
            if (FACADE_MAP.containsKey(oldCoit.getNameAsString())) {
                final ClassOrInterfaceType newCoit = StaticJavaParser.parseClassOrInterfaceType(FACADE_MAP.get(oldCoit.getNameAsString()));
                oldCoit.getTypeArguments().ifPresent(newCoit::setTypeArguments);
                p.setType(newCoit);
            }
        }
    }

    default MethodCallExpr params(List<NameType> nts, boolean isAttribute) {
        List<Expression> parameters = new ArrayList<>();
        for (NameType nt : nts)
            if (isAttribute)
                parameters.add(parameter(nt.type(), nt.name(), new FieldAccessExpr(new ThisExpr(), nt.name())));
            else
                parameters.add(parameter(nt.type(), nt.name()));

        return makeMethodCallWithoutInitParams(FQCN_LIST, METHOD_OF, parameters);
    }
}
