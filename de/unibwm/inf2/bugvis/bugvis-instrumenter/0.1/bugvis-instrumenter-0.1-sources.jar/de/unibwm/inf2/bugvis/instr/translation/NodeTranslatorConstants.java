package de.unibwm.inf2.bugvis.instr.translation;

import com.github.javaparser.Position;
import com.github.javaparser.Range;

import java.util.Map;

public interface NodeTranslatorConstants {

    String FQCN_LIST = "java.util.List";
    String JAVA_LANG_OBJECT = "java.lang.Object";

    String METHOD_OF = "of";

    String THIS = "this";

    // Runtime
    String RUNTIME_PACKAGE_NAME = "de.unibwm.inf2.bugvis.instr.runtime";
    String FACADE_PACKAGE_IMPORT = "de.unibwm.inf2.bugvis.instr.facades.*";
    String BUG_VIS_INSTR = "BugVisInstr";
    String FQCN_BUG_VIS_INSTR = RUNTIME_PACKAGE_NAME + "." + BUG_VIS_INSTR;
    String DECL_RUNTIME_GETTER = "getDeclRuntime";
    String EXPR_RUNTIME_GETTER = "getExprRuntime";
    String STMT_RUNTIME_GETTER = "getStmtRuntime";
    String GET_HIST_LISTENER = "getHistListener";
    String METHOD_V = "v";
    String METHOD_P = "p";

    // ConstructorDeclaration
    String INITIALIZER_CLASS = "_InitializerClass";
    String CONSTRUCTOR_CALL = "constructorCall";
    String CONSTRUCTOR_RESULT = "constructorResult";
    String CONSTRUCTOR_ENTERED = "constructorEntered";
    String LEAVING_CONSTRUCTOR = "leavingConstructor";
    // LambdaExpr
    String LAMBDA_ENTERED = "lambdaEntered";
    String LEAVING_LAMBDA = "leavingLambda";
    // MethodDeclaration
    String METHOD_ENTERED = "methodEntered";
    String LEAVING_METHOD = "leavingMethod";
    String STATIC_METHOD_ENTERED = "staticMethodEntered";
    String LEAVING_STATIC_METHOD = "leavingStaticMethod";
    // InitializerDeclaration
    String INITIALIZER_ENTERED = "initializerEntered";
    String LEAVING_INITIALIZER = "leavingInitializer";
    String STATIC_INITIALIZER_ENTERED = "staticInitializerEntered";
    String LEAVING_STATIC_INITIALIZER = "leavingStaticInitializer";
    // MethodCallExpr
    String CALL_INSTANCE_METHOD = "callInstanceMethod";
    String CALL_STATIC_METHOD = "callStaticMethod";
    String RETURNED = "returned";
    String RETURNED_VALUE = "returnedValue";
    // ObjectCreationExpr
    String OBJECT_CREATION = "objectCreation";
    String OBJECT_CREATION_RESULT = "objectCreationResult";
    // ReturnStmt
    String RETURN_VALUE = "returnValue";
    String RETURN_WITHOUT_VALUE = "returnWithoutValue";
    // YieldStmt
    String YIELD_VALUE = "yieldValue";
    // Field
    String FIELD_ACCESS = "fieldAccess";
    String FIELD_INITIALIZER = "fieldInitializer";
    String FIELD_ASSIGNMENT = "fieldAssignment";
    String FIELD_DECLARATION = "fieldDeclaration";
    String STATIC_FIELD_ASSIGNMENT = "staticFieldAssignment";
    String STATIC_FIELD_DECLARATION = "staticFieldDeclaration";
    // Variable
    String VARIABLE_ASSIGNMENT = "variableAssignment";
    String VARIABLE_DECLARATION = "variableDeclaration";
    // Access and Operations
    String ARRAY_ACCESS = "arrayAccess";
    String ARRAY_ASSIGNMENT = "arrayAssignment";
    String BINARY_OPERATION = "binaryOperation";
    String INSTANCE_OF_OPERATION = "instanceOfOperation";
    String UNARY_OPERATION = "unaryOperation";
    String UNARY_PREFIX_OPERATION = "unaryPrefixOperation";
    String UNARY_POSTFIX_OPERATION = "unaryPostfixOperation";
    // SwitchEntry
    String CASE_ENTERED = "caseEntered";
    String CASE_LEAVING = "caseLeaving";

    Range UNDEFINED_RANGE = new Range(new Position(-1, -1), new Position(-1, -1));

    Map<String, String> FACADE_MAP = Map.of(
            "ArrayList", "ArrayListFacade",
            "LinkedList", "LinkedListFacade",
            "HashSet", "HashSetFacade",
            "HashMap", "HashMapFacade"
    );
}
