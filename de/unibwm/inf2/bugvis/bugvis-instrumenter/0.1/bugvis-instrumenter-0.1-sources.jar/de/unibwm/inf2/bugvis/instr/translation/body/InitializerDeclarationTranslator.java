package de.unibwm.inf2.bugvis.instr.translation.body;

import com.github.javaparser.Range;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.InitializerDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.ClassExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import de.unibwm.inf2.bugvis.instr.translation.AnonymousClassInfo;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class InitializerDeclarationTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(InitializerDeclarationTranslator.class.getName());

    private final TranslationVisitor tv;
    private final InitializerDeclaration id;

    public InitializerDeclarationTranslator(TranslationVisitor translationVisitor, InitializerDeclaration initializer) {
        LOGGER.log(Level.DEBUG, () -> "creating InitializerDeclarationTranslator (" + initializer + ")");
        this.tv = translationVisitor;
        this.id = initializer;
    }

    @Override
    public Node translate() {

        BlockStmt body = new BlockStmt();
        // TODO: korrekte Klasse herausfinden
        final List<Expression> parameters = new ArrayList<>();
        if (id.isStatic()) {
            final String fullyQualifiedClassName = getFullyQualifiedClassName();
            ClassOrInterfaceType classOrInterfaceType = StaticJavaParser.parseClassOrInterfaceType(fullyQualifiedClassName);
            parameters.add(new ClassExpr(classOrInterfaceType));
        }
        else
            parameters.add(value(new ThisExpr()));
        body.addStatement(makeMethodCall(getInitializerStartRange(id), getRuntime(), getEnterMethodName(), parameters));
        translateBlockStmt(id.getBody(), body);
        body.addStatement(makeMethodCall(blockEndRange(id), getRuntime(), getLeavingMethodName(), List.of()));
        NodeList<AnnotationExpr> annotations = tv.translateList(id.getAnnotations());
        InitializerDeclaration r = new InitializerDeclaration(id.getTokenRange().orElse(null), id.isStatic(), body);
        r.setAnnotations(annotations);
        copyCommentsAndData(id, r);
        return r;
    }

    private Range getInitializerStartRange(InitializerDeclaration init) {
        return init.getRange().map(r -> r.withEnd(r.begin.right(init.isStatic() ? 7 : 0)))
                   .orElse(UNDEFINED_RANGE);
    }

    private String getEnterMethodName() {
        return id.isStatic() ? STATIC_INITIALIZER_ENTERED : INITIALIZER_ENTERED;
    }

    private String getLeavingMethodName() {
        return id.isStatic() ? LEAVING_STATIC_INITIALIZER : LEAVING_INITIALIZER;
    }

    private String getFullyQualifiedClassName() {
        String fullyQualifiedClassName = "";

        Optional<Node> parentNodeOptional = id.getParentNode();
        if (parentNodeOptional.isEmpty())
            throw new IllegalStateException("'" + id + "' has no parent node.");
        Node parentNode = parentNodeOptional.get();
        LOGGER.log(Level.DEBUG, "parent: " + parentNode.getClass());

        if (parentNode instanceof TypeDeclaration<?> typeDeclaration) {
            Optional<String> fullyQualifiedNameOptional = typeDeclaration.getFullyQualifiedName();
            if (fullyQualifiedNameOptional.isPresent())
                fullyQualifiedClassName = fullyQualifiedNameOptional.get();
            else
                throw new IllegalStateException("no fully qualified name found.");
        }
        else if (parentNode instanceof ObjectCreationExpr) {
            if (tv.getAnonymousClassStack().isEmpty())
                throw new IllegalStateException("anonymousClassStack is empty");
            AnonymousClassInfo anonymousClassInfo = tv.getAnonymousClassStack().peek();
            if (anonymousClassInfo == null) throw new IllegalStateException("anonymousClassInfo is null");
            fullyQualifiedClassName = anonymousClassInfo.getParentClassName();
        }
        else
            throw new IllegalStateException(String.format("The type (%s) of the parent node of '%s' is not supported.",
                                                          parentNode.getClass(), id));
        LOGGER.log(Level.DEBUG, "fullyQualifiedClassName: " + fullyQualifiedClassName);
        return fullyQualifiedClassName;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.DECLARATION_RUNTIME;}
}
