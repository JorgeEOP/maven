package de.unibwm.inf2.bugvis.instr.translation;

import java.util.List;

public record ClassInfo(String fullyQualifiedClassName, boolean anon, List<Integer> anonClassIds) {}
