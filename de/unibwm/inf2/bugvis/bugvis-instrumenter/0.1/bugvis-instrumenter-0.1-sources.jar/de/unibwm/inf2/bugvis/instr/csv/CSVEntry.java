package de.unibwm.inf2.bugvis.instr.csv;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CSVEntry {
    private final List<String> data = new ArrayList<>();

    public CSVEntry addData(byte data) {return this.addData(Byte.toString(data));}

    public CSVEntry addData(short data) {return this.addData(Short.toString(data));}

    public CSVEntry addData(int data) {return this.addData(Integer.toString(data));}

    public CSVEntry addData(long data) {return this.addData(Long.toString(data));}

    public CSVEntry addData(float data) {return this.addData(Float.toString(data));}

    public CSVEntry addData(double data) {return this.addData(Double.toString(data));}

    public CSVEntry addData(boolean data) {return this.addData(Boolean.toString(data));}

    public CSVEntry addData(char data) {return this.addData(Character.toString(data));}

    public CSVEntry addData(Object data) {
        this.data.add(data.toString());
        return this;
    }

    public String getData(int index) {return data.get(index);}

    public void clear() {this.data.clear();}

    public List<String> getData() {return Collections.unmodifiableList(data);}

    public String toString(String delimiter) {return String.join(delimiter, data);}
}
