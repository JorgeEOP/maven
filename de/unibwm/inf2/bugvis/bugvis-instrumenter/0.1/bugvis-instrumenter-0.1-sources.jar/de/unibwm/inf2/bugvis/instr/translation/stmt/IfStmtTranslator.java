package de.unibwm.inf2.bugvis.instr.translation.stmt;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.stmt.Statement;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.PatternExprVisitor;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.List;

import static java.lang.System.Logger.Level.DEBUG;

public class IfStmtTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(IfStmtTranslator.class.getName());

    private final TranslationVisitor tv;
    private final IfStmt is;
    private final Expression condition;
    private final Statement thenStmt;
    private final Statement elseStmt;

    public IfStmtTranslator(TranslationVisitor translationVisitor, IfStmt ifStmt) {
        LOGGER.log(DEBUG, () -> "creating IfStmtTranslator (" + ifStmt + ")");
        this.tv = translationVisitor;
        this.is = ifStmt;
        this.condition = ifStmt.getCondition();
        this.thenStmt = ifStmt.getThenStmt();
        this.elseStmt = ifStmt.getElseStmt().orElse(null);
    }

    @Override
    public Node translate() {
        final BlockStmt outerBlock = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));
        PatternExprVisitor patternExprVisitor = new PatternExprVisitor(outerBlock, tv);
        condition.accept(patternExprVisitor, null);
        LOGGER.log(Level.TRACE, patternExprVisitor.getThenStmtList().toString());

        BlockStmt block = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));

        final String conditionVarName = storeResult(block, tv.translateNode(condition));

        BlockStmt thenBlock = createBlock(patternExprVisitor.getThenStmtList(), thenStmt);
        if (elseStmt != null) {
            BlockStmt elseBlock = createBlock(patternExprVisitor.getElseStmtList(), elseStmt);

            IfStmt r = new IfStmt(is.getTokenRange().orElse(null), new NameExpr(conditionVarName), thenBlock, elseBlock);
            copyCommentsAndData(is, r);
            return r;
        }

        IfStmt r = new IfStmt(is.getTokenRange().orElse(null), new NameExpr(conditionVarName), thenBlock, null);
        copyCommentsAndData(is, r);
        return r;
    }

    private BlockStmt createBlock(List<Expression> previousStmt, Statement originalStmt) {
        BlockStmt blockStmt;
        if (originalStmt.isBlockStmt())
            blockStmt = tv.translateNode(originalStmt.asBlockStmt());
        else {
            blockStmt = new BlockStmt();
            tv.getBlockStack().push(blockStmt);
            Statement newStatement = tv.translateNode(originalStmt);
            if (newStatement != null) blockStmt.addStatement(newStatement);
            tv.getBlockStack().pop();
        }
        for (Expression expr : previousStmt)
            blockStmt.addStatement(0, expr);
        return blockStmt;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.STATEMENT_RUNTIME;}
}
