package de.unibwm.inf2.bugvis.instr.translation;

public class InstrumentationException extends RuntimeException {

    public InstrumentationException() {}

    public InstrumentationException(String message) {
        super(message);
    }

    public InstrumentationException(String message, Throwable cause) {
        super(message, cause);
    }

    public InstrumentationException(Throwable cause) {
        super(cause);
    }

    public InstrumentationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
