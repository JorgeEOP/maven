package de.unibwm.inf2.bugvis.instr.translation.stmt;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.expr.BooleanLiteralExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.UnaryExpr;
import com.github.javaparser.ast.expr.UnaryExpr.Operator;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.BreakStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.ForStmt;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.stmt.WhileStmt;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.PatternExprVisitor;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.DEBUG;

public class ForStmtTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(ForStmtTranslator.class.getName());
    private final TranslationVisitor tv;
    private final ForStmt fs;

    public ForStmtTranslator(TranslationVisitor translationVisitor, ForStmt forStmt) {
        LOGGER.log(DEBUG, () -> "creating ForStmtTranslator (" + forStmt + ")");
        this.tv = translationVisitor;
        this.fs = forStmt;
    }

    @Override
    public Node translate() {
        BlockStmt additionalBlock = new BlockStmt();
        tv.getBlockStack().push(additionalBlock);

        for (Expression expr : fs.getInitialization()) {
            Expression translated = tv.translateNode(expr);
            // TODO: necessary?
            if (translated != null && !translated.isNameExpr())
                additionalBlock.addStatement(new ExpressionStmt(translated));
        }

        final BlockStmt blockStmt = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));
        PatternExprVisitor patternExprVisitor = new PatternExprVisitor(blockStmt, tv);
        fs.getCompare().ifPresent(c -> c.accept(patternExprVisitor, null));

        BlockStmt body = new BlockStmt();
        tv.getBlockStack().push(body);

        Expression forCondition = tv.translateNode(fs.getCompare());
        String varName = storeResult(body, forCondition != null ? forCondition : new BooleanLiteralExpr(true));
        Expression condition = new UnaryExpr(new NameExpr(varName), Operator.LOGICAL_COMPLEMENT);
        IfStmt ifStmt = new IfStmt(condition, new BreakStmt(), null);
        body.addStatement(ifStmt);
        for (Expression expr : patternExprVisitor.getThenStmtList())
            body.addStatement(expr);

        if (fs.getBody().isBlockStmt()) {
            BlockStmt oldBlock = fs.getBody().asBlockStmt();
            translateBlockStmt(oldBlock, body);
        }
        else {
            tv.getBlockStack().push(body);
            Statement statement = tv.translateNode(fs.getBody());
            if (statement != null) body.addStatement(statement);
            tv.getBlockStack().pop();
        }

        for (Expression expr : fs.getUpdate()) {
            Expression updateExpression = tv.translateNode(expr);
            if (!updateExpression.isNameExpr()
                && !updateExpression.isFieldAccessExpr()
                && !updateExpression.isArrayAccessExpr())
                body.addStatement(new ExpressionStmt(updateExpression));
        }

        tv.getBlockStack().pop();

        WhileStmt newWhileStmt = new WhileStmt(new BooleanLiteralExpr(true), body);
        copyCommentsAndData(fs, newWhileStmt);
        additionalBlock.addStatement(newWhileStmt);

        tv.getBlockStack().pop();
        return additionalBlock;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.STATEMENT_RUNTIME;}
}
