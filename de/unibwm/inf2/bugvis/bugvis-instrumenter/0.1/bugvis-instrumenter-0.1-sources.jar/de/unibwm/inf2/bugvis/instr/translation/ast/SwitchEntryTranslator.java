package de.unibwm.inf2.bugvis.instr.translation.ast;

import com.github.javaparser.Range;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.SwitchExpr;
import com.github.javaparser.ast.nodeTypes.NodeWithStatements;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.stmt.SwitchEntry;
import com.github.javaparser.ast.stmt.SwitchEntry.Type;
import com.github.javaparser.ast.stmt.TryStmt;
import com.github.javaparser.ast.stmt.YieldStmt;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.List;
import java.util.Optional;

import static java.lang.System.Logger.Level.DEBUG;

public class SwitchEntryTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(SwitchEntryTranslator.class.getName());

    private final TranslationVisitor tv;
    private final SwitchEntry se;

    public SwitchEntryTranslator(TranslationVisitor translationVisitor, SwitchEntry switchEntry) {
        LOGGER.log(DEBUG, () -> "creating SwitchEntryTranslator (" + switchEntry + ")");
        this.tv = translationVisitor;
        this.se = switchEntry;
    }

    @Override
    public Node translate() {
        Optional<Node> parentNodeOptional = se.getParentNode();
        if (parentNodeOptional.isEmpty()) throw new IllegalStateException("unknown parent");
        boolean isSwitchExpr = parentNodeOptional.get() instanceof SwitchExpr;

        Expression guard = tv.translateNode(se.getGuard());
        NodeList<Expression> labels = tv.translateList(se.getLabels());
        String labelString = replaceQuotationMarks(makeLabelString(se.getLabels()));

        final BlockStmt tryBlock = new BlockStmt();
        tryBlock.addStatement(makeMethodCall(getSwitchEntryRange(se), getRuntime(), CASE_ENTERED,
                                             new NodeList<>(new StringLiteralExpr(labelString))));
        if (isSwitchExpr && se.getType() == Type.EXPRESSION) {
            final Expression yieldExpr = se.getStatement(0).asExpressionStmt().getExpression();
            tv.getBlockStack().push(tryBlock);
            final String varName = storeResult(tryBlock, tv.translateNode(yieldExpr));
            final YieldStmt yieldStmt = new YieldStmt(yieldExpr.getTokenRange().orElse(null), new NameExpr(varName));
            List<Expression> list = List.of(value(new NameExpr(varName)));
            tryBlock.addStatement(makeMethodCall(getYieldRange(yieldStmt), getRuntime(), YIELD_VALUE, list));
            tryBlock.addStatement(yieldStmt);
            tv.getBlockStack().pop();
        }
        else {
            NodeWithStatements<?> nodeWithStatements = se;
            if (se.getType() == Type.BLOCK
                && !se.isEmpty()
                && se.getStatement(0).isBlockStmt())
                nodeWithStatements = se.getStatement(0).asBlockStmt();
            translateBlockStmt(nodeWithStatements, tryBlock);
        }

        final BlockStmt finallyBlock = new BlockStmt();
        finallyBlock.addStatement(makeMethodCall(getSwitchEntryRange(se), getRuntime(), CASE_LEAVING,
                                                 new NodeList<>(new StringLiteralExpr(labelString))));
        final TryStmt tryStmt = new TryStmt(tryBlock, new NodeList<>(), finallyBlock);

        Statement stmt = tryStmt;
        if (se.getType() != Type.STATEMENT_GROUP) stmt = new BlockStmt(new NodeList<>(tryStmt));
        Type type = se.getType() == Type.STATEMENT_GROUP ? Type.STATEMENT_GROUP : Type.BLOCK;
        return new SwitchEntry(se.getTokenRange().orElse(null), labels, type, new NodeList<>(stmt), se.isDefault(), guard);
    }

    private Range getSwitchEntryRange(SwitchEntry switchEntry) {
        return switchEntry.getRange().map(r -> Range.range(r.begin, r.begin.right(3)))
                          .orElse(UNDEFINED_RANGE);
    }

    private Range getYieldRange(YieldStmt yieldStmt) {
        return yieldStmt.getRange().map(r -> Range.range(r.begin, r.begin.right(4)))
                        .orElse(UNDEFINED_RANGE);
    }

    private String makeLabelString(NodeList<Expression> labels) {
        if (labels.isEmpty()) return "default";
        return String.join(", ", labels.stream().map(Expression::toString).toList());
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.STATEMENT_RUNTIME;}
}
