package de.unibwm.inf2.bugvis.instr.translation.expr;

import com.github.javaparser.Range;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.expr.ClassExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.NullLiteralExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.Type;
import com.github.javaparser.ast.type.VarType;
import com.github.javaparser.resolution.declarations.ResolvedConstructorDeclaration;
import com.github.javaparser.resolution.types.ResolvedReferenceType;
import com.github.javaparser.resolution.types.ResolvedType;
import com.github.javaparser.symbolsolver.javaparsermodel.declarations.JavaParserAnonymousClassDeclaration;
import de.unibwm.inf2.bugvis.instr.translation.AnonymousClassInfo;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.lang.System.Logger.Level.DEBUG;

public class ObjectCreationExprTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(ObjectCreationExprTranslator.class.getName());

    private final TranslationVisitor tv;
    private final ObjectCreationExpr oce;
    private final ResolvedConstructorDeclaration resolved;
    private final Type type;

    public ObjectCreationExprTranslator(TranslationVisitor translationVisitor, ObjectCreationExpr objectCreationExpr, Object arg) {
        LOGGER.log(DEBUG, () -> "creating ObjectCreationExprTranslator (" + objectCreationExpr + ")");
        this.tv = translationVisitor;
        this.oce = objectCreationExpr;
        this.resolved = objectCreationExpr.resolve();
        if (arg instanceof Type typeArg) type = typeArg;
        else this.type = null;
    }

    @Override
    public Node translate() {
        BlockStmt blockStmt = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));

        String className = resolved.declaringType().getQualifiedName();
        String signature = resolved.getSignature();
        // Diss: im Falle einer Interface-Implementierung ist der declaring Type eine anonyme Klasse mit kryptischem
        //       Namen. Das ist wahrscheinlich eine Eigenschaft vom JavaParser, dann muss die nächste SuperClass (das
        //       Interface) geholt und genutzt werden. Sowohl für den Klassenname, als auch für die Signatur.
        if (resolved.declaringType() instanceof JavaParserAnonymousClassDeclaration jpacd) {
            Optional<ResolvedReferenceType> superClassOptional = jpacd.getSuperClass();
            if (superClassOptional.isPresent()) {
                ResolvedReferenceType superClass = superClassOptional.get();
                className = superClass.getQualifiedName();
                signature = className.replaceAll("[a-zA-Z0-9]+\\.", "") + "()";
            }
            else throw new IllegalStateException("superclass not available!");
        }

        // Diss: generic localType arguments are parsed and stored with the localType.
        //       For a generic ObjectCreationExpr see
        //       https://docs.oracle.com/javase/specs/jls/se15/html/jls-15.html#jls-15.9 and
        //       Issue: https://github.com/javaparser/javaparser/issues/4162
        NodeList<Type> typeArguments = tv.translateList(oce.getTypeArguments().orElse(null));

        Expression scope = tv.translateNode(oce.getScope());
        if (scope != null) scope = new NameExpr(storeResult(blockStmt, scope));

        List<String> argNames = translateArguments(blockStmt, oce.getArguments());

        // Announce ObjectCreationCall
        final List<Expression> list = new ArrayList<>();
        list.add(new ClassExpr(parseType(className)));
        list.add(new StringLiteralExpr(signature));
//        list.addAll(argNameExpr(argNames));
        if (!argNames.isEmpty()) list.add(announcementParams(argNames));
        blockStmt.addStatement(makeMethodCall(range(oce), getRuntime(), OBJECT_CREATION, list));

        NodeList<Expression> arguments = new NodeList<>(argNameExpr(argNames));
        ObjectCreationExpr r = new ObjectCreationExpr(oce.getTokenRange().orElse(null),
                                                      scope, oce.getType().clone(), typeArguments,
                                                      arguments, null);

        final Optional<NodeList<BodyDeclaration<?>>> anonymousClassBody = oce.getAnonymousClassBody();
        if (anonymousClassBody.isPresent()) translateClassBody(r, anonymousClassBody.get());

        copyCommentsAndData(oce, r);
        Type localType = new VarType();
        if (FACADE_MAP.containsKey(oce.getType().clone().getNameAsString())) {
            ClassOrInterfaceType coit = StaticJavaParser.parseClassOrInterfaceType(FACADE_MAP.get(oce.getType().clone().getNameAsString()));
            oce.getType().getTypeArguments().ifPresent(coit::setTypeArguments);
            NodeList<Expression> argumentList = new NodeList<>(r, makeMethodCallWithoutInitParams(BUG_VIS_INSTR, GET_HIST_LISTENER, List.of()));
            r = new ObjectCreationExpr(null, null, coit, typeArguments, argumentList, null);
            if (this.type != null && this.type.isClassOrInterfaceType()) {
                ClassOrInterfaceType localCoit = coit.clone();
                this.type.asClassOrInterfaceType().getTypeArguments().ifPresent(localCoit::setTypeArguments);
                localType = localCoit;
            }
            else localType = coit.clone();
        }
        else if (this.type != null) localType = this.type;

        String resultName = storeResult(blockStmt, r, localType);
        blockStmt.addStatement(makeMethodCall(range(oce), getRuntime(), OBJECT_CREATION_RESULT,
                                              List.of(value(new NameExpr(resultName)))));

        return new NameExpr(resultName);
    }

    private Range range(ObjectCreationExpr expr) {
        final Optional<Range> optionalRange = expr.getRange();
        final Optional<Range> optionalTypeRange = expr.getType().getRange();
        if (optionalRange.isPresent() && optionalTypeRange.isPresent())
            return optionalRange.get().withEnd(optionalTypeRange.get().end);
        return UNDEFINED_RANGE;
    }

    private void translateClassBody(ObjectCreationExpr r, NodeList<BodyDeclaration<?>> anonymousClassBody) {
        final AnonymousClassInfo anonymousClassInfo = getAnonymousClassInfo();
        tv.getAnonymousClassStack().push(anonymousClassInfo);
        tv.addInstrType(anonymousClassInfo.getName());
        // Type stack update for FieldDeclarationTranslator
        tv.getTypeStack().push(new ObjectCreationTypeDeclaration(r));
        r.getAnonymousClassBody().ifPresent(l -> l.addAll(tv.translateList(anonymousClassBody)));
        tv.getTypeStack().pop();
        tv.getAnonymousClassStack().pop();
    }

    private AnonymousClassInfo getAnonymousClassInfo() {
        if (tv.getAnonymousClassStack().isEmpty()) return firstAnonymousClassInfo();
        else return nextAnonymousClassInfo(tv.getAnonymousClassStack().peek());
    }

    private AnonymousClassInfo firstAnonymousClassInfo() {
        Optional<TypeDeclaration> typeDeclarationOptional = oce.findAncestor(TypeDeclaration.class);
        if (typeDeclarationOptional.isEmpty())
            throw new IllegalStateException("parent type declaration not detectable");
        TypeDeclaration<?> typeDeclaration = typeDeclarationOptional.get();
        Optional<String> fullyQualifiedNameOptional = typeDeclaration.getFullyQualifiedName();
        if (fullyQualifiedNameOptional.isEmpty())
            throw new IllegalStateException("fully qualified name not resolvable");
        return new AnonymousClassInfo(fullyQualifiedNameOptional.get(), 1);
    }

    private AnonymousClassInfo nextAnonymousClassInfo(AnonymousClassInfo currentAnonymousClassInfo) {
        if (currentAnonymousClassInfo == null) throw new IllegalStateException("anonymousClassInfo == null!");
        List<Integer> ids = new ArrayList<>(currentAnonymousClassInfo.getIds());
        currentAnonymousClassInfo.increaseChildCount();
        ids.add(currentAnonymousClassInfo.getChildCount());
        return new AnonymousClassInfo(currentAnonymousClassInfo.getParentClassName(), ids);
    }

    // TODO: Test
    private List<String> translateArguments(BlockStmt blockStmt, NodeList<Expression> arguments) {
        List<String> paramNames = new ArrayList<>();
        for (Expression arg : arguments)
            if (arg.isNullLiteralExpr()) paramNames.add(null);
            else {
                Type type = getParameterType(arg);
                paramNames.add(storeResult(blockStmt, tv.translateNode(arg, type), type.clone()));
            }
        return paramNames;
    }

    /**
     * This method determines the type of the variable in which the instrumented argument gets capsulated.
     * <p>
     * Rules:
     * <ol>
     * <li>Default case is the type of the parameter.</li>
     * <li>If the parameter type is a type variable, we choose the argument type.</li>
     * <li>If the parameter type contains a type variable, we choose the argument type.</li>
     * <li>If the parameter type contains a wildcard, wo choose the argument type.</li>
     * <li>If the parameter type contains type parameters, but the argument type does no, we choose the argument type.</li>
     * <li>If the parameter is variadic and the argument pos is greater than the last param pos, we choose the argument type.</li>
     * <li>If the argument type is a union type, we choose {@link java.lang.Throwable}.</li>
     * </ol>
     *
     * @param arg the current argument
     * @return the type of the variable in which the instrumented argument gets capsulated
     */
    private Type getParameterType(Expression arg) {
        final int numberOfParams = resolved.getNumberOfParams();
        final int lastParamIndex = numberOfParams - 1;
        final int argumentPos = oce.getArgumentPosition(arg);

        final boolean isVariadic = resolved.getParam(lastParamIndex).isVariadic();
        if (isVariadic && argumentPos >= lastParamIndex)
            return parseType(arg.calculateResolvedType().describe());

        final ResolvedType paramType = resolved.getParam(argumentPos).getType();
        final ResolvedType argType = arg.calculateResolvedType();

        // Param: TypeVariable or type with TypeVariable - Arg: *
        if (containsTypeVariablesOrWildcards(paramType)) {
            if (argType.isNull()) return parseType("var");
            return parseType(argType.describe());
        }

        if (paramType.isReferenceType()) {
            final ResolvedReferenceType paramRefType = paramType.asReferenceType();

            // Param: type with TypeParameters - Arg: type without TypeParameters => argType
            if (!paramRefType.typeParametersMap().isEmpty()
                && argType.isReferenceType() && argType.asReferenceType().typeParametersMap().isEmpty())
                return parseType(argType.describe());

            if (argType.isUnionType()) // UnionType: IOException | SQLException
                return parseType("Throwable");
        }

        return parseType(paramType.describe());
    }

    private List<Expression> argNameExpr(List<String> argNames) {
        return argNames.stream().map(arg -> arg == null ? new NullLiteralExpr() : new NameExpr(arg)).toList();
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.EXPRESSION_RUNTIME;}
}
