package de.unibwm.inf2.bugvis.instr.translation.body;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.modules.ModuleDeclaration;
import com.github.javaparser.ast.modules.ModuleRequiresDirective;
import com.github.javaparser.ast.nodeTypes.NodeWithName;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.Comparator;

import static java.lang.System.Logger.Level.DEBUG;

public class CompilationUnitTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(CompilationUnitTranslator.class.getName());

    private static final Name INSTR_MODULE = StaticJavaParser.parseName(RUNTIME_PACKAGE_NAME);

    private final TranslationVisitor tv;
    private final CompilationUnit cu;

    public CompilationUnitTranslator(TranslationVisitor translationVisitor, CompilationUnit cu) {
        LOGGER.log(DEBUG, () -> "creating CompilationUnitTranslator (" + cu + ")");
        this.tv = translationVisitor;
        this.cu = cu;
    }

    @Override
    public Node translate() {
        NodeList<ImportDeclaration> imports = tv.translateList(cu.getImports(), null);
        ModuleDeclaration module = tv.translateNode(cu.getModule(), null);
        PackageDeclaration packageDeclaration = tv.translateNode(cu.getPackageDeclaration(), null);
        CompilationUnit r = new CompilationUnit(cu.getTokenRange().orElse(null), packageDeclaration, imports, new NodeList<>(), module);
        getTranslationVisitor().setCompilationUnit(r);
        NodeList<TypeDeclaration<?>> types = tv.translateList(cu.getTypes(), null);
        r.setTypes(types);
        cu.getStorage().ifPresent(s -> r.setStorage(s.getPath(), s.getEncoding()));
        copyCommentsAndData(cu, r);

        // Add import to runtime iff this compilation unit is not a module-info.java-file.
        if (module == null) addImports(r);
            // Iff this compilation unit is a module-info.java-file, add requires directive.
        else module.addDirective(new ModuleRequiresDirective(new NodeList<>(), INSTR_MODULE));

        // TODO: modify sort to differentiate between normal and static imports
        r.getImports().sort(Comparator.comparing(NodeWithName::getNameAsString));

        return r;
    }

    private static void addImports(CompilationUnit r) {
        r.addImport(FQCN_BUG_VIS_INSTR);
        r.addImport(FACADE_PACKAGE_IMPORT);
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {
        return tv;
    }

    @Override
    public Runtime getRuntime() {return Runtime.DECLARATION_RUNTIME;}
}
