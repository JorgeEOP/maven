package de.unibwm.inf2.bugvis.instr;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.printer.DefaultPrettyPrinter;
import com.github.javaparser.printer.Printer;
import com.github.javaparser.printer.configuration.DefaultConfigurationOption;
import com.github.javaparser.printer.configuration.DefaultPrinterConfiguration;
import com.github.javaparser.printer.configuration.Indentation;
import com.github.javaparser.printer.configuration.PrinterConfiguration;
import com.github.javaparser.resolution.TypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import de.unibwm.inf2.bugvis.instr.metainfo.FileMetaInfo;
import de.unibwm.inf2.bugvis.instr.translation.RemoveCommentsTreeVisitor;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.System.Logger;
import java.time.LocalTime;

import static com.github.javaparser.printer.configuration.DefaultPrinterConfiguration.ConfigOption.INDENTATION;
import static com.github.javaparser.printer.configuration.Indentation.IndentType.SPACES;
import static java.lang.System.Logger.Level.ERROR;

public class FileInstrumenter {
    private static final Logger LOGGER = System.getLogger(FileInstrumenter.class.getName());
    private static final String FILE_SEPARATOR = "/";
    private static final Printer PRETTY_PRINTER = initPrettyPrinter();

    private final CombinedTypeSolver typeSolver;
    private final boolean removeComments;

    private static Printer initPrettyPrinter() {
        final PrinterConfiguration conf = new DefaultPrinterConfiguration();
        final Indentation indentation = new Indentation(SPACES, 4);
        conf.addOption(new DefaultConfigurationOption(INDENTATION, indentation));
        return new DefaultPrettyPrinter(conf);
    }

    public FileInstrumenter(CombinedTypeSolver typeSolver, boolean removeComments) {
        this.typeSolver = typeSolver;
        this.removeComments = removeComments;
    }

    public FileInstrumenterResult instrument(Target target) {
        FileInstrumenterResult result = instrumentFile(target, typeSolver);
        if (result.isSuccessful()) {
            final String prettyPrintedContent = PRETTY_PRINTER.print(result.getCompilationUnit().get());
            try {writeJavaFile(target.instrumented(), prettyPrintedContent);}
            catch (IOException e) {LOGGER.log(ERROR, e);}
        }
        return result;
    }

    private FileInstrumenterResult instrumentFile(Target target, TypeSolver typeSolver) {
        final File file = target.original();
        final LocalTime startTime = LocalTime.now();
        try {
            final CompilationUnit compilationUnit = StaticJavaParser.parse(file);
            if (removeComments) {
                RemoveCommentsTreeVisitor rctv = new RemoveCommentsTreeVisitor();
                rctv.visitPreOrder(compilationUnit);
            }
            final FileMetaInfo fileMetaInfo = new FileMetaInfo(getMetaInfoFileName(target.relativePath(), file));
            final TranslationVisitor translationVisitor = new TranslationVisitor(typeSolver, fileMetaInfo);
            final CompilationUnit instrumented = translationVisitor.translateNode(compilationUnit);
            return new FileInstrumenterResult(target, startTime, LocalTime.now(), instrumented,
                                              fileMetaInfo, translationVisitor.getInstrClassMethodMap());
        }
        catch (Exception exception) {return new FileInstrumenterResult(target, startTime, LocalTime.now(), exception);}
    }

    private static String getMetaInfoFileName(String relativePath, File file) {
        return relativePath.isEmpty() ? file.getName() : relativePath + FILE_SEPARATOR + file.getName();
    }

    private void writeJavaFile(File path, String content) throws IOException {
        final File parentDirectory = path.getParentFile();
        parentDirectory.mkdirs();
        try (FileWriter fw = new FileWriter(path)) {
            fw.write(content);
        }
    }
}
