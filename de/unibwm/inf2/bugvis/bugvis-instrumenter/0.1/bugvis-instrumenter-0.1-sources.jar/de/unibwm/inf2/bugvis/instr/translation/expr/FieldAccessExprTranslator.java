package de.unibwm.inf2.bugvis.instr.translation.expr;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.expr.ClassExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.FieldAccessExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.type.Type;
import com.github.javaparser.resolution.declarations.ResolvedFieldDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedValueDeclaration;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.List;

import static java.lang.System.Logger.Level.DEBUG;

public class FieldAccessExprTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(FieldAccessExprTranslator.class.getName());

    private final TranslationVisitor tv;
    private final FieldAccessExpr fae;
    private final Expression scope;

    public FieldAccessExprTranslator(TranslationVisitor translationVisitor, FieldAccessExpr fieldAccessExpr, Object arg) {
        LOGGER.log(DEBUG, () -> "creating FieldAccessExprTranslator (" + fieldAccessExpr + "), range: " + fieldAccessExpr.getRange().get());
        this.tv = translationVisitor;
        this.fae = fieldAccessExpr;
        this.scope = fieldAccessExpr.getScope();
    }

    @Override
    public Node translate() {
        final NodeList<Type> typeArguments = tv.translateList(
                fae.getTypeArguments().orElse(null));
        if (scope == null) throw new IllegalStateException("scope is null");
        final ResolvedValueDeclaration resolved = fae.resolve();
        if (resolved == null) throw new IllegalStateException("resolved is null");

        Expression instrScope = scope.clone();
        if (resolved.isField()) {
            Expression objectOrClass;
            final ResolvedFieldDeclaration resolvedField = resolved.asField();
            String declaringClass = resolvedField.declaringType().getQualifiedName();

            if (resolvedField.isStatic())
                objectOrClass = new ClassExpr(parseType(declaringClass));
            else if (scope.isThisExpr())
                objectOrClass = value(scope.clone());
            else if (scope.isSuperExpr())
                objectOrClass = value(new ThisExpr(scope.asSuperExpr().getTypeName().orElse(null)));
            else {
                Type scopeType = parseType(scope.calculateResolvedType().describe());
                final BlockStmt blockStmt = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));
                String varName = storeResult(blockStmt, tv.translateNode(scope, scopeType), scopeType);
                instrScope = new NameExpr(varName);
                objectOrClass = value(new NameExpr(varName));
            }
            getCurrentBlock().ifPresent(b -> b.addStatement(
                    makeMethodCall(fae, getRuntime(), FIELD_ACCESS, List.of(
                            objectOrClass,
                            new StringLiteralExpr(fae.getNameAsString()),
                            new ClassExpr(parseType(declaringClass))))));
        }

        FieldAccessExpr r = new FieldAccessExpr(fae.getTokenRange().orElse(null),
                                                instrScope,
                                                typeArguments,
                                                fae.getName().clone());
        copyCommentsAndData(fae, r);

        return r;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.EXPRESSION_RUNTIME;}
}
