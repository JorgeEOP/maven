package de.unibwm.inf2.bugvis.instr.translation.body;

import com.github.javaparser.Position;
import com.github.javaparser.Range;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.AssignExpr.Operator;
import com.github.javaparser.ast.expr.BooleanLiteralExpr;
import com.github.javaparser.ast.expr.CastExpr;
import com.github.javaparser.ast.expr.ClassExpr;
import com.github.javaparser.ast.expr.DoubleLiteralExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.IntegerLiteralExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.NullLiteralExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ReturnStmt;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.PrimitiveType;
import com.github.javaparser.ast.type.Type;
import de.unibwm.inf2.bugvis.instr.translation.AnonymousClassInfo;
import de.unibwm.inf2.bugvis.instr.translation.InstrumentationException;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.lang.System.Logger.Level.DEBUG;

public class FieldDeclarationTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(FieldDeclarationTranslator.class.getName());

    private final TranslationVisitor tv;
    private final FieldDeclaration fd;

    public FieldDeclarationTranslator(TranslationVisitor translationVisitor, FieldDeclaration fd) {
        LOGGER.log(DEBUG, () -> "creating FieldDeclarationTranslator (" + fd + ")");
        this.tv = translationVisitor;
        this.fd = fd;
    }

    @Override
    public Node translate() {
        TypeDeclaration<?> containingType = getCurrentType();
        TypeDeclaration<?> initializerType = containingType;

        String fullyQualifiedClassName = "";
        List<Integer> anonClassIds = List.of();
        boolean fieldIsStatic = fd.isStatic();
        boolean fieldIsInInterface = false;
        boolean anonClass = false;

        Optional<Node> parentNodeOptional = fd.getParentNode();
        if (parentNodeOptional.isEmpty())
            throw new IllegalStateException("'" + fd + "' has no parent node.");
        Node parentNode = parentNodeOptional.get();

        if (parentNode instanceof TypeDeclaration<?> typeDeclaration) {
            Optional<String> fullyQualifiedNameOptional = typeDeclaration.getFullyQualifiedName();
            if (fullyQualifiedNameOptional.isPresent())
                fullyQualifiedClassName = fullyQualifiedNameOptional.get();
            else if (typeDeclaration.isClassOrInterfaceDeclaration() && typeDeclaration.asClassOrInterfaceDeclaration().isLocalClassDeclaration()) {
                ClassOrInterfaceDeclaration classOrInterfaceDeclaration = typeDeclaration.asClassOrInterfaceDeclaration();
                fullyQualifiedClassName = classOrInterfaceDeclaration.getNameAsString();
            }

            if (typeDeclaration.isClassOrInterfaceDeclaration())
                fieldIsInInterface = typeDeclaration.asClassOrInterfaceDeclaration().isInterface();
            else if (typeDeclaration.isRecordDeclaration()) {
                // TODO: notwendig?
            }
            else if (typeDeclaration.isAnnotationDeclaration()) {
                Optional<Range> optionalRange = fd.getRange();
                if (optionalRange.isEmpty()) throw new IllegalStateException("FieldDeclaration without range");
                Position begin = optionalRange.get().begin;
                String initializerClassName = INITIALIZER_CLASS + "_" + begin.line + "_" + begin.column;
                NodeList<Modifier> modifiers = new NodeList<>(List.of(Modifier.abstractModifier()));
                ConstructorDeclaration constructor = new ConstructorDeclaration(
                        new NodeList<>(List.of(Modifier.privateModifier())), initializerClassName);
                NodeList<BodyDeclaration<?>> members = new NodeList<>(constructor);
                initializerType = new ClassOrInterfaceDeclaration(modifiers, new NodeList<>(), false,
                                                                  new SimpleName(initializerClassName),
                                                                  new NodeList<>(), new NodeList<>(), new NodeList<>(),
                                                                  new NodeList<>(), members);
                fieldIsStatic = true;
                fieldIsInInterface = true;
            }
            else if (typeDeclaration.isEnumDeclaration()) {
                // TODO: notwendig?
            }
            else
                throw new InstrumentationException(typeDeclaration.getClass() + " unknown class for TypeDeclaration.");
        }
        // TODO: see MethodDeclarationTranslator!
        else if (parentNode instanceof ObjectCreationExpr) {
            if (tv.getAnonymousClassStack().isEmpty())
                throw new IllegalStateException("anonymousClassStack is empty");
            AnonymousClassInfo anonymousClassInfo = tv.getAnonymousClassStack().peek();
            if (anonymousClassInfo == null) throw new IllegalStateException("anonymousClassInfo is null");
            fullyQualifiedClassName = anonymousClassInfo.getParentClassName();
            anonClassIds = anonymousClassInfo.getIds();
            anonClass = true;
        }
        else
            throw new IllegalStateException(String.format("The type (%s) of the parent node of '%s' is not supported.",
                                                          parentNode.getClass(), fd));

        ClassOrInterfaceType classOrInterfaceType = StaticJavaParser.parseClassOrInterfaceType(fullyQualifiedClassName);

        for (VariableDeclarator vd : fd.getVariables()) {
            NodeList<AnnotationExpr> annotations = tv.translateList(fd.getAnnotations());
            NodeList<Modifier> modifiers = tv.translateList(fd.getModifiers());
            modifiers.remove(Modifier.finalModifier());

            // fieldInitializer
            String methodName = FIELD_INITIALIZER + vd.getName();
            NodeList<Modifier> methodModifiers = new NodeList<>();
            methodModifiers.add(Modifier.privateModifier());

            if (fieldIsStatic || fieldIsInInterface) methodModifiers.add(Modifier.staticModifier());

            Type type = applyFacades(tv.translateNode(vd.getType()));

            // initializer Method
            MethodDeclaration initializerMethod = new MethodDeclaration(methodModifiers, methodName, type, new NodeList<>());
            BlockStmt body = new BlockStmt();
            tv.getBlockStack().push(body);
            if (fieldIsStatic || fieldIsInInterface)
                body.addStatement(makeMethodCall(fd, getRuntime(), STATIC_INITIALIZER_ENTERED,
                                                 List.of(new ClassExpr(classOrInterfaceType.clone()))));
            // instrumented initializer
            final Expression defaultValue = getDefaultValue(type.clone());
            Expression expr;
            if (vd.getInitializer().isPresent())
                expr = tv.translateNode(vd.getInitializer(), type.clone());
            else expr = defaultValue;

            String varName = storeResult(body, expr, type.clone());

            // declareField
            List<Expression> declParams = new ArrayList<>();
            addParams(fieldIsStatic, fieldIsInInterface, anonClass, declParams, classOrInterfaceType, anonClassIds);
            declParams.add(new StringLiteralExpr(vd.getNameAsString()));
            declParams.add(new StringLiteralExpr(vd.getTypeAsString()));
            declParams.add(value(defaultValue.clone()));
            // add declaring class for non-static fields in non-anonymous classes
            if (!fieldIsStatic && !anonClass) declParams.add(new ClassExpr(classOrInterfaceType));
            body.addStatement(makeMethodCall(getNameRange(vd), getRuntime(),
                                             fieldIsStatic ? STATIC_FIELD_DECLARATION : FIELD_DECLARATION,
                                             new NodeList<>(declParams)));

            if (!fieldIsInInterface)
                body.addStatement(new AssignExpr(new NameExpr(vd.getName()), new NameExpr(varName), Operator.ASSIGN));

            // setField
            List<Expression> setParams = new ArrayList<>();
            addParams(fieldIsStatic, fieldIsInInterface, anonClass, setParams, classOrInterfaceType, anonClassIds);
            setParams.add(new StringLiteralExpr(vd.getNameAsString()));
            setParams.add(value(new NameExpr(varName)));
            if (!fieldIsStatic && !anonClass) setParams.add(new ClassExpr(classOrInterfaceType));
            body.addStatement(makeMethodCall(getAssignmentRange(vd), getRuntime(),
                                             fieldIsStatic ? STATIC_FIELD_ASSIGNMENT : FIELD_ASSIGNMENT,
                                             new NodeList<>(setParams)));

            if (fieldIsStatic || fieldIsInInterface)
                body.addStatement(makeMethodCall(fd, getRuntime(), LEAVING_STATIC_INITIALIZER, List.of()));
            // return var
            body.addStatement(new ReturnStmt(new NameExpr(varName)));
            initializerMethod.setBody(body);

            // Variable Declarator
            Expression initializeExpr;
            if (containingType != initializerType) // in case of AnnotationDeclaration:
                initializeExpr = new MethodCallExpr(new NameExpr(initializerType.getName()), methodName);
            else initializeExpr = new MethodCallExpr(methodName);

            SimpleName name = tv.translateNode(vd.getName());
            VariableDeclarator newVd = new VariableDeclarator(type, name, initializeExpr);
            NodeList<VariableDeclarator> vars = new NodeList<>();
            vars.add(newVd);
            FieldDeclaration fieldDeclaration = new FieldDeclaration(modifiers, annotations, vars);
            copyCommentsAndData(fd, fieldDeclaration);
            containingType.addMember(fieldDeclaration);

            initializerType.addMember(initializerMethod);

            tv.getBlockStack().pop();
        }

        // in case of AnnotationDeclaration:
        if (containingType != initializerType) containingType.addMember(initializerType);

        // Return nothing (null). All declarations have to be added to the typeStack top element.
        return null;
    }

    private void addParams(boolean fieldIsStatic, boolean fieldIsInInterface, boolean anonClass,
                           List<Expression> params, ClassOrInterfaceType classOrInterfaceType,
                           List<Integer> anonClassId) {
        if (fieldIsStatic || fieldIsInInterface || anonClass)
            params.add(new ClassExpr(classOrInterfaceType));
        if (anonClass)
            params.add(makeMethodCallWithoutInitParams(FQCN_LIST, METHOD_OF, new ArrayList<>(
                    anonClassId.stream().map(IntegerLiteralExpr::new).toList())));
        if (!fieldIsStatic && !fieldIsInInterface) params.add(value(new ThisExpr()));
    }

    private Expression getDefaultValue(Type type) {
        if (type.isPrimitiveType())
            return switch (type.asPrimitiveType().getType()) {
                case BYTE -> new CastExpr(PrimitiveType.byteType(), new IntegerLiteralExpr("0"));
                case SHORT -> new CastExpr(PrimitiveType.shortType(), new IntegerLiteralExpr("0"));
                case CHAR -> new CastExpr(PrimitiveType.charType(), new IntegerLiteralExpr("0"));
                case INT -> new IntegerLiteralExpr("0");
                case LONG -> new CastExpr(PrimitiveType.longType(), new IntegerLiteralExpr("0"));
                case FLOAT -> new DoubleLiteralExpr("0f");
                case DOUBLE -> new DoubleLiteralExpr(0);
                case BOOLEAN -> new BooleanLiteralExpr(false);
            };
        return new NullLiteralExpr();
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.DECLARATION_RUNTIME;}
}
