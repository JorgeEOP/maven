package de.unibwm.inf2.bugvis.instr.translation.expr;

import com.github.javaparser.Range;
import com.github.javaparser.ast.DataKey;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.AssignExpr.Operator;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.InstanceOfExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.type.ReferenceType;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.List;

import static java.lang.System.Logger.Level.DEBUG;

public class InstanceOfExprTranslator implements NodeTranslator {
    public static final DataKey<String> VAR_NAME = new DataKey<>() {};
    private static final Logger LOGGER = System.getLogger(InstanceOfExprTranslator.class.getName());

    private final TranslationVisitor tv;
    private final InstanceOfExpr ioe;

    public InstanceOfExprTranslator(TranslationVisitor translationVisitor, InstanceOfExpr instanceOfExpr, Object arg) {
        LOGGER.log(DEBUG, () -> "creating InstanceOfExprTranslator (" + instanceOfExpr + ")");
        this.tv = translationVisitor;
        this.ioe = instanceOfExpr;
    }

    @Override
    public Node translate() {
        BlockStmt block = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));
        Expression expression = tv.translateNode(ioe.getExpression());

        if (ioe.containsData(VAR_NAME)) {
            final String varName = ioe.getData(VAR_NAME);
            block.addStatement(new ExpressionStmt(
                    new AssignExpr(new NameExpr(varName), expression.clone(), Operator.ASSIGN)));
            expression = new NameExpr(varName);
        }

        ReferenceType type = tv.translateNode(ioe.getType());
        InstanceOfExpr r = new InstanceOfExpr(ioe.getTokenRange().orElse(null), expression, type, null);
        copyCommentsAndData(ioe, r);

        String name = storeResult(block, r, parseType("boolean"));
        block.addStatement(makeMethodCall(getRange(ioe), getRuntime(), INSTANCE_OF_OPERATION,
                                          List.of(new StringLiteralExpr(ioe.getExpression().toString()),
                                                  new StringLiteralExpr(type.asString()),
                                                  value(new NameExpr(name)))));
        return new NameExpr(name);
    }

    private Range getRange(InstanceOfExpr expr) {
        return getRangeBetween(expr.getExpression(), expr.getType());
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.EXPRESSION_RUNTIME;}
}
