package de.unibwm.inf2.bugvis.instr;

import de.unibwm.inf2.bugvis.instr.metainfo.FileMetaInfo;
import de.unibwm.inf2.bugvis.instr.metainfo.MetaInfo;

import java.io.File;
import java.io.IOException;
import java.lang.System.Logger;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import static java.lang.System.Logger.Level.ERROR;

public class MetaInfoSupport {
    private static final Logger LOGGER = System.getLogger(MetaInfoSupport.class.getName());

    private MetaInfoSupport() {}

    static void writeMetaInfo(File metaInfoFile, MetaInfo metaInfo) {
        try {
            MetaInfo.writeMetaInfo(metaInfo, metaInfoFile);
        }
        catch (IOException e) {
            e.printStackTrace();
            LOGGER.log(ERROR, e.getMessage());
        }
    }

    static void updateMetaInfo(MetaInfo metaInfo, FileInstrumenterResult result) {
        final Optional<FileMetaInfo> fileMetaInfoOptional = result.getFileMetaInfo();
        if (fileMetaInfoOptional.isPresent()) {
            metaInfo.add(fileMetaInfoOptional.get());
            final Optional<Map<String, Set<String>>> instrClassMethodMapOptional = result.getInstrClassMethodMap();
            if (instrClassMethodMapOptional.isPresent())
                for (Entry<String, Set<String>> e : instrClassMethodMapOptional.get().entrySet())
                    for (String s : e.getValue())
                        metaInfo.addInstrMethod(e.getKey(), s);
        }
    }
}
