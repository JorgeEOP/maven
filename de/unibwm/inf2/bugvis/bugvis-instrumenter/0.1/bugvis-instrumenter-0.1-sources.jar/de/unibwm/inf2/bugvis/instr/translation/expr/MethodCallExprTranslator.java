package de.unibwm.inf2.bugvis.instr.translation.expr;

import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.expr.ClassExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.FieldAccessExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.NullLiteralExpr;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.type.Type;
import com.github.javaparser.ast.type.VarType;
import com.github.javaparser.resolution.MethodUsage;
import com.github.javaparser.resolution.UnsolvedSymbolException;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedReferenceTypeDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedValueDeclaration;
import com.github.javaparser.resolution.types.ResolvedReferenceType;
import com.github.javaparser.resolution.types.ResolvedType;
import com.github.javaparser.symbolsolver.javaparsermodel.JavaParserFacade;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.lang.System.Logger.Level.DEBUG;

public class MethodCallExprTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(MethodCallExprTranslator.class.getName());

    private final TranslationVisitor tv;
    private final MethodCallExpr mce;
    private final ResolvedMethodDeclaration resolved;
    private final Type type;

    public MethodCallExprTranslator(TranslationVisitor translationVisitor, MethodCallExpr methodCallExpr, Object arg) {
        LOGGER.log(DEBUG, () -> "creating MethodCallExprTranslator (" + methodCallExpr + ")");
        this.tv = translationVisitor;
        this.mce = methodCallExpr;
        this.resolved = methodCallExpr.resolve();
        LOGGER.log(DEBUG, () -> "resolved: " + resolved);
        if (arg instanceof Type typeArg) this.type = typeArg;
        else this.type = null;
    }

    public boolean isStatic() {return resolved.isStatic();}

    private String getMethod() {return isStatic() ? CALL_STATIC_METHOD : CALL_INSTANCE_METHOD;}

    @Override
    public Expression translate() {
        BlockStmt blockStmt = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));

        // Instrument Scope
        Expression scope = instrumentScope();

        // Instrument Parameters
        List<String> argNames = translateArguments(blockStmt, mce.getArguments());

        final ClassExpr classExpr = getClassExpr();

        announceMethodCall(scope, classExpr, argNames, blockStmt);

        final List<Expression> returnArgList = new ArrayList<>();
        if (isStatic()) returnArgList.add(classExpr.clone());
        else if (scope == null || scope.isSuperExpr()) returnArgList.add(value(new ThisExpr()));
        else returnArgList.add(value(scope));

        // MethodCallExpr
        // - void Method
        if (resolved.getReturnType().isVoid()) {
            blockStmt.addStatement(createNewMethodCall(argNames, scope));
            blockStmt.addStatement(makeMethodCall(mce.getName(), getRuntime(), RETURNED, returnArgList));
            return null;
        }
        // - non-void Method
        else {
            Type localType = new VarType();
            if (this.type != null && !this.type.isVoidType()) localType = this.type;
            final String variableName = storeResult(blockStmt, createNewMethodCall(argNames, scope), localType);
            returnArgList.add(value(new NameExpr(variableName)));
            blockStmt.addStatement(makeMethodCall(mce.getName(), getRuntime(), RETURNED_VALUE, returnArgList));
            return new NameExpr(variableName);
        }
    }

    private void announceMethodCall(Expression scope, ClassExpr classExpr, List<String> argNames, BlockStmt blockStmt) {
        final List<Expression> list = new ArrayList<>();
        if (!isStatic()) {
            if (scope == null) list.add(value(new ThisExpr()));
            else if (scope.isSuperExpr()) {
                list.add(value(new ThisExpr()));
                list.add(classExpr);
            }
            else list.add(value(scope));
        }
        else list.add(classExpr);
        list.add(new StringLiteralExpr(resolved.getSignature()));
        if (!argNames.isEmpty()) list.add(announcementParams(argNames));
        blockStmt.addStatement(makeMethodCall(mce.getName(), getRuntime(), getMethod(), list));
    }

    private ClassExpr getClassExpr() {
        final ResolvedReferenceTypeDeclaration declaringType = resolved.declaringType();
        String classQualifiedName = declaringType.getQualifiedName();
        if (classQualifiedName.contains("-")) {
            List<ResolvedReferenceType> ancestorList = declaringType.asReferenceType().getAncestors();
            LOGGER.log(DEBUG, ancestorList::toString);
            classQualifiedName = ancestorList.getFirst().describe();
        }
        return new ClassExpr(parseType(classQualifiedName));
    }

    private Expression instrumentScope() {
        final Optional<Expression> optionalScope = mce.getScope();
        if (optionalScope.isEmpty()) return null;
        final Expression scope = optionalScope.get();
        if (scope.isFieldAccessExpr()) {
            final FieldAccessExpr fieldAccessExpr = scope.asFieldAccessExpr();
            try {
                final ResolvedValueDeclaration resolve = fieldAccessExpr.resolve();
                LOGGER.log(DEBUG, () -> "resolved field access expression: " + resolve);
                return tv.translateNode(mce.getScope());
            }
            catch (UnsolvedSymbolException e) {
                LOGGER.log(DEBUG, () -> "field access expression could not be solved: " + e);
                return scope.clone();
            }
        }
        return tv.translateNode(mce.getScope());
    }

    private MethodCallExpr createNewMethodCall(List<String> argNames, Expression scope) {
        SimpleName name = mce.getName().clone();
        NodeList<Type> typeArguments = tv.translateList(mce.getTypeArguments().orElse(null));
        final NodeList<Expression> params = new NodeList<>();
        params.addAll(argNameExpr(argNames));
        MethodCallExpr r = new MethodCallExpr(scope, typeArguments, name, params);
        copyCommentsAndData(mce, r);
        return r;
    }

    // TODO: Test
    private List<String> translateArguments(BlockStmt blockStmt, NodeList<Expression> arguments) {
        List<String> paramNames = new ArrayList<>();
        if (!arguments.isEmpty()) {
            JavaParserFacade jpf = JavaParserFacade.get(tv.getTypeSolver());
            MethodUsage methodUsage;
            try {
                methodUsage = jpf.solveMethodAsUsage(mce);
            }
            catch (UnsupportedOperationException e) {
                throw new RuntimeException("solveMethodAsUsage in MethodCallExprTranslator failed!", e);
            }
            for (Expression arg : arguments) {
                LOGGER.log(DEBUG, () -> "current arg: " + arg);
                if (arg.isNullLiteralExpr()) paramNames.add(null);
                else {
                    Type type = applyFacades(getParameterType(arg, methodUsage));
                    paramNames.add(storeResult(blockStmt, tv.translateNode(arg, type), type.clone()));
                }
            }
        }
        return paramNames;
    }

    /**
     * This method determines the type of the variable in which the instrumented argument gets capsulated.
     * <p>
     * Rules:
     * <ol>
     * <li>Default case is the type of the parameter.</li>
     * <li>If the parameter type is a type variable, we choose the argument type.</li>
     * <li>If the parameter type contains a type variable, we choose the argument type.</li>
     * <li>If the parameter type contains a wildcard, wo choose the argument type.</li>
     * <li>If the parameter type contains type parameters, but the argument type does no, we choose the argument type.</li>
     * <li>If the parameter is variadic and the argument pos is greater than the last param pos, we choose the argument type.</li>
     * </ol>
     *
     * @param arg         the current argument
     * @param methodUsage the method usage, used for variadic parameters
     * @return the type of the variable in which the instrumented argument gets capsulated
     */
    private Type getParameterType(Expression arg, MethodUsage methodUsage) {
        final int numberOfParams = resolved.getNumberOfParams();
        final int lastParamIndex = numberOfParams - 1;
        final int argumentPos = mce.getArgumentPosition(arg);

        ResolvedType paramType = resolved.getParam(Math.min(argumentPos, lastParamIndex)).getType();
        ResolvedType argType = arg.calculateResolvedType();

        final boolean isVariadic = resolved.getParam(lastParamIndex).isVariadic();
        if (isVariadic && argumentPos >= lastParamIndex) {
            LOGGER.log(DEBUG, "parameter is variadic and argumentPos >= lastParamIndex");
            return handleVariadicParam(arg, argumentPos, lastParamIndex, methodUsage);
        }

        // Param: TypeVariable or type with TypeVariable - Arg: *
        if (containsTypeVariablesOrWildcards(paramType)) {
            if (argType.isNull()) return parseType("var");
            return parseType(argType.describe());
        }

        if (paramType.isReferenceType()) {
            final ResolvedReferenceType paramRefType = paramType.asReferenceType();

            // Param: type with TypeParameters - Arg: type without TypeParameters => argType
            if (!paramRefType.typeParametersMap().isEmpty()
                && argType.isReferenceType() && argType.asReferenceType().typeParametersMap().isEmpty())
                return parseType(argType.describe());
        }

        return parseType(paramType.describe());
    }

    // TODO: Test
    // TODO: ist methodUsage notwendig? Oder reicht es wie bei ObjectCreationExpr
    private Type handleVariadicParam(Expression arg, int argumentPos, int lastParamIndex, MethodUsage methodUsage) {
        ResolvedType paramType = resolved.getParam(lastParamIndex).getType();
        ResolvedType methUsageParamType = methodUsage.getParamType(lastParamIndex);
        ResolvedType methUsageParamComponentType = methUsageParamType.asArrayType().getComponentType();
        ResolvedType argType = arg.calculateResolvedType();
        boolean isArgArrayType = argType.isArray();

        if (argumentPos > lastParamIndex)
            return parseType(argType.describe());
        if (isArgArrayType && argType.asArrayType().arrayLevel() == paramType.asArrayType().arrayLevel())
            return parseType(argType.describe());
        return parseType(methUsageParamComponentType.describe());
    }

    private List<Expression> argNameExpr(List<String> argNames) {
        return argNames.stream().map(arg -> arg == null ? new NullLiteralExpr() : new NameExpr(arg)).toList();
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.EXPRESSION_RUNTIME;}
}
