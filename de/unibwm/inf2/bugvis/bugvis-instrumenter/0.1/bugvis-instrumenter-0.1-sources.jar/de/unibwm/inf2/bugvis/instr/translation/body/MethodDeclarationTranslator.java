package de.unibwm.inf2.bugvis.instr.translation.body;

import com.github.javaparser.Position;
import com.github.javaparser.Range;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.ClassExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.IntegerLiteralExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.TryStmt;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.Type;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;
import com.github.javaparser.symbolsolver.javaparsermodel.declarations.JavaParserAnonymousClassDeclaration;
import de.unibwm.inf2.bugvis.instr.translation.ClassInfo;
import de.unibwm.inf2.bugvis.instr.translation.NameType;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.lang.System.Logger.Level.DEBUG;

public class MethodDeclarationTranslator implements MethodLikeTranslator {
    private static final Logger LOGGER = System.getLogger(MethodDeclarationTranslator.class.getName());

    private final TranslationVisitor tv;
    private final MethodDeclaration md;
    private final String signature;

    private BlockStmt body;

    public MethodDeclarationTranslator(TranslationVisitor translationVisitor, MethodDeclaration methodDeclaration) {
        LOGGER.log(DEBUG, () -> "creating MethodDeclarationTranslator (" + methodDeclaration + ")");
        this.tv = translationVisitor;
        this.md = methodDeclaration;
        ResolvedMethodDeclaration rmd = methodDeclaration.resolve();
        this.signature = rmd.getSignature();
        String qualifiedName = rmd.declaringType().getQualifiedName();
        if (rmd.declaringType() instanceof JavaParserAnonymousClassDeclaration &&
            !translationVisitor.getAnonymousClassStack().isEmpty())
            qualifiedName = translationVisitor.getAnonymousClassStack().peek().getName();
        translationVisitor.getInstrClassMethodMap().get(qualifiedName).add(signature);
        if (methodDeclaration.isStatic())
            translationVisitor.addStaticMethod(qualifiedName, signature);
    }

    @Override
    public Node translate() {
        md.getBody().ifPresent(b -> setBody(instrumentedBody(b)));

        final MethodLikeComponents result = translateMethodLikeComponents(md);
        final Type type = applyFacades(tv.translateNode(md.getType()));
        final MethodDeclaration r = new MethodDeclaration(md.getTokenRange().orElse(null),
                                                          result.modifiers(),
                                                          result.annotations(),
                                                          result.typeParameters(),
                                                          type,
                                                          result.name(),
                                                          result.parameters(),
                                                          result.thrownExceptions(),
                                                          body,
                                                          result.receiverParameter());
        copyCommentsAndData(md, r);
        return r;
    }

    private BlockStmt instrumentedBody(BlockStmt originalBlockStmt) {
        final BlockStmt newBlockStmt = new BlockStmt();
        final ClassInfo classInfo = getClassInfo(md);
        final boolean staticMethod = md.isStatic();
        final ClassOrInterfaceType type = StaticJavaParser.parseClassOrInterfaceType(classInfo.fullyQualifiedClassName());

        addEnteredInstr(staticMethod, classInfo, type, newBlockStmt);

        final BlockStmt tryBlock = new BlockStmt();
        translateBlockStmt(originalBlockStmt, tryBlock);

        final List<Expression> paramsLeaving = createParams(staticMethod, classInfo, type, true);
        final BlockStmt finallyBlock = new BlockStmt();
        finallyBlock.addStatement(makeMethodCall(blockEndRange(md), getRuntime(), leavingMethodName(staticMethod), paramsLeaving));
        final TryStmt tryStmt = new TryStmt(tryBlock, new NodeList<>(), finallyBlock);

        newBlockStmt.addStatement(tryStmt);

        return newBlockStmt;
    }

    private void addEnteredInstr(boolean staticMethod, ClassInfo classInfo, ClassOrInterfaceType type,
                                 BlockStmt blockStmt) {
        final List<Expression> params = createParams(staticMethod, classInfo, type, false);
        final List<NameType> nts = NameType.fromNodeWithParameters(md);
        if (!nts.isEmpty()) params.add(params(nts, false));
//        listParams(blockStmt, params, false, NameType.fromNodeWithParameters(methodDeclaration));
        blockStmt.addStatement(makeMethodCall(typeAndNameRange(), getRuntime(), enteredMethodName(staticMethod), params));
    }

    private Range typeAndNameRange() {
        final Optional<Range> optionalRange = md.getType().getRange();
        final Optional<Position> end = md.getName().getEnd();
        if (optionalRange.isPresent() && end.isPresent())
            return optionalRange.get().withEnd(end.get());
        return UNDEFINED_RANGE;
    }

    private List<Expression> createParams(boolean staticMethod, ClassInfo classInfo, ClassOrInterfaceType type,
                                          boolean leaving) {
        final List<Expression> params = new ArrayList<>();
        if (staticMethod || classInfo.anon()) params.add(new ClassExpr(type.clone()));
        if (classInfo.anon())
            params.add(makeMethodCallWithoutInitParams(FQCN_LIST, METHOD_OF, new ArrayList<>(
                    classInfo.anonClassIds().stream().map(IntegerLiteralExpr::new).toList())));
        if (!staticMethod) {
            if (leaving) params.add(value(new ThisExpr()));
            else params.add(parameter(type.asString(), THIS, new ThisExpr()));
        }
        params.add(new StringLiteralExpr(signature));
        return params;
    }

    private String enteredMethodName(boolean staticMethod) {return staticMethod ? STATIC_METHOD_ENTERED : METHOD_ENTERED;}

    private String leavingMethodName(boolean staticMethod) {return staticMethod ? LEAVING_STATIC_METHOD : LEAVING_METHOD;}

    private void setBody(BlockStmt body) {this.body = body;}

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.DECLARATION_RUNTIME;}
}
