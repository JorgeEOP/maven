package de.unibwm.inf2.bugvis.instr.translation.stmt;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.expr.BooleanLiteralExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.UnaryExpr;
import com.github.javaparser.ast.expr.UnaryExpr.Operator;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.BreakStmt;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.stmt.WhileStmt;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.PatternExprVisitor;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.DEBUG;

public class WhileStmtTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(WhileStmtTranslator.class.getName());
    private final TranslationVisitor tv;
    private final WhileStmt ws;

    public WhileStmtTranslator(TranslationVisitor translationVisitor, WhileStmt whileStmt) {
        LOGGER.log(DEBUG, () -> "creating WhileStmtTranslator (" + whileStmt + ")");
        this.tv = translationVisitor;
        this.ws = whileStmt;
    }

    @Override
    public Node translate() {
        BlockStmt body = new BlockStmt();
        tv.getBlockStack().push(body);

        final BlockStmt outerBlock = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));
        PatternExprVisitor patternExprVisitor = new PatternExprVisitor(outerBlock, tv);
        ws.getCondition().accept(patternExprVisitor, null);

        String varName = storeResult(body, tv.translateNode(ws.getCondition()));
        Expression condition = new UnaryExpr(new NameExpr(varName), Operator.LOGICAL_COMPLEMENT);
        IfStmt ifStmt = new IfStmt(condition, new BreakStmt(), null);
        body.addStatement(ifStmt);
        for (Expression expr : patternExprVisitor.getThenStmtList())
            body.addStatement(expr);

        if (ws.getBody().isBlockStmt()) {
            BlockStmt oldBlock = ws.getBody().asBlockStmt();
            translateBlockStmt(oldBlock, body);
        }
        else {
            Statement statement = tv.translateNode(ws.getBody());
            if (statement != null) body.addStatement(statement);
        }

        tv.getBlockStack().pop();

        WhileStmt newWhileStmt = new WhileStmt(new BooleanLiteralExpr(true), body);
        copyCommentsAndData(ws, newWhileStmt);

        return newWhileStmt;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.STATEMENT_RUNTIME;}
}
