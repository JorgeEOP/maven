package de.unibwm.inf2.bugvis.instr.translation.expr;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.expr.ArrayAccessExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.type.Type;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.List;

import static java.lang.System.Logger.Level.DEBUG;

public class ArrayAccessExprTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(ArrayAccessExprTranslator.class.getName());

    private final TranslationVisitor tv;
    private final ArrayAccessExpr aae;

    public ArrayAccessExprTranslator(TranslationVisitor translationVisitor, ArrayAccessExpr arrayAccessExpr) {
        LOGGER.log(DEBUG, () -> "creating ArrayAccessExprTranslator (" + arrayAccessExpr + ")");
        this.tv = translationVisitor;
        this.aae = arrayAccessExpr;
    }

    @Override
    public Node translate() {
        BlockStmt blockStmt = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));

        final Expression nameExpr = aae.getName();
        Type arrayType = parseType(nameExpr.calculateResolvedType().describe());
        Expression name = tv.translateNode(nameExpr, arrayType);
        String nameVarName = storeResult(blockStmt, name, arrayType);
        Type indexType = parseType(aae.getIndex().calculateResolvedType().describe());
        String indexVarName = storeResult(blockStmt, tv.translateNode(aae.getIndex(), indexType), indexType);
        ArrayAccessExpr newArrayAccessExpr = new ArrayAccessExpr(aae.getTokenRange().orElse(null),
                                                                 new NameExpr(nameVarName), new NameExpr(indexVarName));
        copyCommentsAndData(aae, newArrayAccessExpr);
        Type type = parseType(aae.calculateResolvedType().describe());
        String arrayAccessVarName = storeResult(blockStmt, newArrayAccessExpr, type);

        blockStmt.addStatement(makeMethodCall(aae.getName(), getRuntime(), ARRAY_ACCESS,
                                              List.of(value(new NameExpr(nameVarName)),
                                                      new NameExpr(indexVarName),
                                                      value(new NameExpr(arrayAccessVarName)))));

        return new ArrayAccessExpr(aae.getTokenRange().orElse(null),
                                   new NameExpr(nameVarName), new NameExpr(indexVarName));
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.EXPRESSION_RUNTIME;}
}
