package de.unibwm.inf2.bugvis.instr;

import de.unibwm.inf2.bugvis.instr.csv.CSVEntry;
import de.unibwm.inf2.bugvis.instr.csv.CSVSupport;

import java.lang.System.Logger;
import java.time.Duration;
import java.time.LocalTime;
import java.util.Set;

import static java.lang.System.Logger.Level.DEBUG;
import static java.lang.System.Logger.Level.ERROR;
import static java.lang.System.Logger.Level.INFO;

public class StatisticsInstrumenter extends Instrumenter {
    private static final Logger LOGGER = System.getLogger(StatisticsInstrumenter.class.getName());
    private static final String CSV_FILE_NAME = "test.csv";
    private static final String FILE_SEPARATOR = "/";
    public static final String DELIMITER = ";";

    private final CSVSupport csvSupport = new CSVSupport(CSV_FILE_NAME, DELIMITER);

    private LocalTime instrumentationStartTime;
    private int counter = 0;

    public StatisticsInstrumenter(InstrumenterOptions options) {super(options);}

    @Override
    protected void beforeInstrumentation(Set<Target> targets) {
        super.beforeInstrumentation(targets);
        instrumentationStartTime = LocalTime.now();
        LOGGER.log(DEBUG, "Targets:\n{0}", targets);
        csvSupport.clear();
        csvSupport.addColumn("ID")
                  .addColumn("Start time")
                  .addColumn("Duration since start")
                  .addColumn("Path")
                  .addColumn("Duration of file")
                  .addColumn("Exception");
        counter = 0;
    }

    @Override
    protected void beforeFileInstrumentation(Target target) {
        super.beforeFileInstrumentation(target);
        ++counter;
        final LocalTime fileStartTime = LocalTime.now();
        csvSupport.newEntry()
                  .addData(counter)
                  .addData(fileStartTime)
                  .addData(Duration.between(instrumentationStartTime, fileStartTime))
                  .addData(target.relativePath() + FILE_SEPARATOR + target.instrumented().getName());
    }

    @Override
    protected void afterFileInstrumentation(FileInstrumenterResult result) {
        super.afterFileInstrumentation(result);
        CSVEntry entry = csvSupport.getLastEntry().addData(result.getDuration());
        String errorMsg = "";
        if (result.isSuccessful())
            LOGGER.log(DEBUG, result.getCompilationUnit().get());
        else {
            final Exception e = result.getException().get();
            errorMsg = e.getMessage() != null ? e.getMessage() : e.toString();
            errorMsg = errorMsg.replace("\n", "").replace(";", "|");
            entry.addData(errorMsg);

            LOGGER.log(ERROR, e.getClass().getName() + ": " + e.getMessage());
            System.out.println("\n--> " + e.getMessage());
            e.printStackTrace();
        }
        System.out.println(entry.toString(DELIMITER));
    }

    @Override
    protected void afterInstrumentation(Set<Target> targets, Set<Target> instrumentedFiles, Set<Target> failedFiles) {
        super.afterInstrumentation(targets, instrumentedFiles, failedFiles);
        csvSupport.write();
        System.out.println(instrumentedFiles.size() + "/" + targets.size());

        LOGGER.log(INFO, "the following targets caused exceptions:\n{0}", failedFiles);
        LOGGER.log(INFO, "{0} of {1} were instrumented successful, {2} of {1} targets caused exceptions",
                   instrumentedFiles.size(), targets.size(), failedFiles.size());
    }
}
