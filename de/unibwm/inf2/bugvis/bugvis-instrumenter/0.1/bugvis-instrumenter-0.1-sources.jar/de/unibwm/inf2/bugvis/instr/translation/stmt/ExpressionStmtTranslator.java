package de.unibwm.inf2.bugvis.instr.translation.stmt;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.LambdaExpr;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.Optional;

import static java.lang.System.Logger.Level.DEBUG;

public class ExpressionStmtTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(ExpressionStmtTranslator.class.getName());

    private final TranslationVisitor tv;
    private final ExpressionStmt es;
    private final Object arg;

    public ExpressionStmtTranslator(TranslationVisitor translationVisitor, ExpressionStmt expressionStmt, Object arg) {
        LOGGER.log(DEBUG, () -> "Creating ExpressionStmtTranslator (" + expressionStmt + ")");
        this.tv = translationVisitor;
        this.es = expressionStmt;
        this.arg = arg;
    }

    @Override
    public Node translate() {
        Expression expression = tv.translateNode(es.getExpression(), arg);

        // ExpressionStmt in LambdaExpr without BlockStmt
        final Optional<Node> optParentNode = es.getParentNode();
        if (optParentNode.isPresent() && optParentNode.get() instanceof LambdaExpr) {
            if (expression == null)
                return null;
            return createExpressionStmt(expression);
        }

        // ExpressionStmt with NameExpr, FieldAccessExpr, ArrayAccessExpr or UnaryExpr is unnecessary.
        if (expression == null
            || expression.isNameExpr()
            || expression.isFieldAccessExpr()
            || expression.isArrayAccessExpr()
            || expression.isUnaryExpr())
            return null;

        // build and return ExpressionStmt
        return createExpressionStmt(expression);
    }

    private ExpressionStmt createExpressionStmt(Expression expression) {
        ExpressionStmt newExpressionStmt = new ExpressionStmt(es.getTokenRange().orElse(null), expression);
        copyCommentsAndData(es, newExpressionStmt);
        return newExpressionStmt;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.STATEMENT_RUNTIME;}
}
