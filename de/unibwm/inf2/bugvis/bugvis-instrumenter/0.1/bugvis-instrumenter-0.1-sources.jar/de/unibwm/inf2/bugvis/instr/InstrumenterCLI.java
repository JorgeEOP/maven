package de.unibwm.inf2.bugvis.instr;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.System.Logger;
import java.util.logging.LogManager;

import static java.lang.System.Logger.Level.DEBUG;
import static java.lang.System.Logger.Level.ERROR;

public class InstrumenterCLI {
    private static final String INFO_LOGGING_PROPERTIES = "logging.properties";
    private static final Logger LOGGER;

    static {
        Logger logger;
        try {
            LogManager.getLogManager().readConfiguration(new FileInputStream(INFO_LOGGING_PROPERTIES));
            logger = System.getLogger(InstrumenterCLI.class.getName());
            logger.log(DEBUG, "Successfully read logging properties"); //NON-NLS
        }
        catch (IOException e) {
            logger = System.getLogger(InstrumenterCLI.class.getName());
            logger.log(ERROR, e::getMessage);
        }
        LOGGER = logger;
    }

    public static void main(String[] args) {
        InstrumenterOptions options = new Options(args);

        LOGGER.log(DEBUG, "files to instrument: {0}", options.getFilesToInstrument());
        LOGGER.log(DEBUG, "files to copy: {0}", options.getFilesToCopy());
        LOGGER.log(DEBUG, "target dir: {0}", options.getTargetDir());
        LOGGER.log(DEBUG, "meta-info path: {0}", options.getMetaInfoFile());
        LOGGER.log(DEBUG, "reflection type solver: {0}", options.isReflectionTypeSolver());
        LOGGER.log(DEBUG, "path type solver dirs: {0}", options.getPathTypeSolverFiles());
        LOGGER.log(DEBUG, "jar type solver files: {0}", options.getJarTypeSolverFiles());
        LOGGER.log(DEBUG, "copy failed: {0}", options.getCopyFailedFiles());
        LOGGER.log(DEBUG, "copy overwrite: {0}", options.getOverwrite());

        LOGGER.log(DEBUG, "start instrumentation");
        new StatisticsInstrumenter(options).instrument();
        LOGGER.log(DEBUG, "instrumentation finished");
    }
}
