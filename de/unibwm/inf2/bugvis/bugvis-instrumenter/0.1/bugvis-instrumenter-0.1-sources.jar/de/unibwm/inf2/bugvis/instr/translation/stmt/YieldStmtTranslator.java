package de.unibwm.inf2.bugvis.instr.translation.stmt;

import com.github.javaparser.Range;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.NullLiteralExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.stmt.YieldStmt;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.List;

import static java.lang.System.Logger.Level.DEBUG;

public class YieldStmtTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(YieldStmtTranslator.class.getName());

    private final YieldStmt ys;
    private final TranslationVisitor tv;
    private final Expression expression;

    public YieldStmtTranslator(TranslationVisitor translationVisitor, YieldStmt yieldStmt) {
        LOGGER.log(DEBUG, () -> "creating YieldStmtTranslator (" + yieldStmt + ")");
        this.tv = translationVisitor;
        this.ys = yieldStmt;
        this.expression = yieldStmt.getExpression();
    }

    @Override
    public Statement translate() {
        BlockStmt codeBlock = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));

        final YieldStmt r = new YieldStmt();
        copyCommentsAndData(ys, r);

        final List<Expression> list = new ArrayList<>();

        if (expression.isNullLiteralExpr()) {
            list.add(value(new NullLiteralExpr()));
            codeBlock.addStatement(makeMethodCall(getYieldRange(ys), getRuntime(), YIELD_VALUE, list));
            r.setExpression(new NullLiteralExpr());
        }
        else {
            final String varName = storeResult(codeBlock, tv.translateNode(expression));
            list.add(value(new NameExpr(varName)));
            codeBlock.addStatement(makeMethodCall(getYieldRange(ys), getRuntime(), YIELD_VALUE, list));
            r.setExpression(new NameExpr(varName));
        }

        codeBlock.getStatements().add(r);
        return null;
    }

    private Range getYieldRange(YieldStmt yieldStmt) {
        return yieldStmt.getRange().map(range -> Range.range(range.begin, range.begin.right(4)))
                        .orElse(UNDEFINED_RANGE);
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {
        return tv;
    }

    @Override
    public Runtime getRuntime() {return Runtime.STATEMENT_RUNTIME;}
}
