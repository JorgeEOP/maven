/*
 * Copyright (C) 2007-2010 Júlio Vilmar Gesser.
 * Copyright (C) 2011, 2013-2024 The JavaParser Team.
 *
 * This file is part of JavaParser.
 *
 * JavaParser can be used either under the terms of
 * a) the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 * b) the terms of the Apache License
 *
 * You should have received a copy of both licenses in LICENCE.LGPL and
 * LICENCE.APACHE. Please refer to those files for details.
 *
 * JavaParser is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 */

package de.unibwm.inf2.bugvis.instr.translation;

import com.github.javaparser.ast.ArrayCreationLevel;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.AnnotationDeclaration;
import com.github.javaparser.ast.body.AnnotationMemberDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.CompactConstructorDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.EnumConstantDeclaration;
import com.github.javaparser.ast.body.EnumDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.InitializerDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.body.ReceiverParameter;
import com.github.javaparser.ast.body.RecordDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.comments.BlockComment;
import com.github.javaparser.ast.comments.JavadocComment;
import com.github.javaparser.ast.comments.LineComment;
import com.github.javaparser.ast.expr.ArrayAccessExpr;
import com.github.javaparser.ast.expr.ArrayCreationExpr;
import com.github.javaparser.ast.expr.ArrayInitializerExpr;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.BinaryExpr;
import com.github.javaparser.ast.expr.BooleanLiteralExpr;
import com.github.javaparser.ast.expr.CastExpr;
import com.github.javaparser.ast.expr.CharLiteralExpr;
import com.github.javaparser.ast.expr.ClassExpr;
import com.github.javaparser.ast.expr.ConditionalExpr;
import com.github.javaparser.ast.expr.DoubleLiteralExpr;
import com.github.javaparser.ast.expr.EnclosedExpr;
import com.github.javaparser.ast.expr.FieldAccessExpr;
import com.github.javaparser.ast.expr.InstanceOfExpr;
import com.github.javaparser.ast.expr.IntegerLiteralExpr;
import com.github.javaparser.ast.expr.LambdaExpr;
import com.github.javaparser.ast.expr.LongLiteralExpr;
import com.github.javaparser.ast.expr.MarkerAnnotationExpr;
import com.github.javaparser.ast.expr.MemberValuePair;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.MethodReferenceExpr;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.NormalAnnotationExpr;
import com.github.javaparser.ast.expr.NullLiteralExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.expr.RecordPatternExpr;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.expr.SingleMemberAnnotationExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.SuperExpr;
import com.github.javaparser.ast.expr.SwitchExpr;
import com.github.javaparser.ast.expr.TextBlockLiteralExpr;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.ast.expr.TypeExpr;
import com.github.javaparser.ast.expr.TypePatternExpr;
import com.github.javaparser.ast.expr.UnaryExpr;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.modules.ModuleDeclaration;
import com.github.javaparser.ast.modules.ModuleExportsDirective;
import com.github.javaparser.ast.modules.ModuleOpensDirective;
import com.github.javaparser.ast.modules.ModuleProvidesDirective;
import com.github.javaparser.ast.modules.ModuleRequiresDirective;
import com.github.javaparser.ast.modules.ModuleUsesDirective;
import com.github.javaparser.ast.stmt.AssertStmt;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.BreakStmt;
import com.github.javaparser.ast.stmt.CatchClause;
import com.github.javaparser.ast.stmt.ContinueStmt;
import com.github.javaparser.ast.stmt.DoStmt;
import com.github.javaparser.ast.stmt.EmptyStmt;
import com.github.javaparser.ast.stmt.ExplicitConstructorInvocationStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.ForEachStmt;
import com.github.javaparser.ast.stmt.ForStmt;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.stmt.LabeledStmt;
import com.github.javaparser.ast.stmt.LocalClassDeclarationStmt;
import com.github.javaparser.ast.stmt.LocalRecordDeclarationStmt;
import com.github.javaparser.ast.stmt.ReturnStmt;
import com.github.javaparser.ast.stmt.SwitchEntry;
import com.github.javaparser.ast.stmt.SwitchStmt;
import com.github.javaparser.ast.stmt.SynchronizedStmt;
import com.github.javaparser.ast.stmt.ThrowStmt;
import com.github.javaparser.ast.stmt.TryStmt;
import com.github.javaparser.ast.stmt.UnparsableStmt;
import com.github.javaparser.ast.stmt.WhileStmt;
import com.github.javaparser.ast.stmt.YieldStmt;
import com.github.javaparser.ast.type.ArrayType;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.IntersectionType;
import com.github.javaparser.ast.type.PrimitiveType;
import com.github.javaparser.ast.type.TypeParameter;
import com.github.javaparser.ast.type.UnionType;
import com.github.javaparser.ast.type.UnknownType;
import com.github.javaparser.ast.type.VarType;
import com.github.javaparser.ast.type.VoidType;
import com.github.javaparser.ast.type.WildcardType;
import com.github.javaparser.ast.visitor.GenericVisitor;
import com.github.javaparser.ast.visitor.Visitable;

import java.util.List;
import java.util.Optional;

public class TalkingEqualsVisitor implements GenericVisitor<Boolean, Visitable> {

    private static final TalkingEqualsVisitor SINGLETON = new TalkingEqualsVisitor();

    public static boolean equals(final Node n, final Node n2) {
        return SINGLETON.nodeEquals(n, n2);
    }

    private TalkingEqualsVisitor() {
        // hide constructor
    }

    /**
     * Check for equality that can be applied to each kind of node,
     * to not repeat it in every method we store that here.
     */
    private boolean commonNodeEquality(Node n, Node n2) {
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            {
                System.out.println("cne n:\n'" + n + "'\nn2:\n'" + n2 + "'");
                return false;
            }
        }
        return nodesEquals(n.getOrphanComments(), n2.getOrphanComments());
    }

    private <T extends Node> boolean nodesEquals(final List<T> nodes1, final List<T> nodes2) {
        if (nodes1 == null) {
            System.out.println("ne1 n:\n'" + nodes1 + "'\nn2:\n'" + nodes2 + "'");
            return nodes2 == null;
        }
        if (nodes2 == null) {
            System.out.println("ne2 n:\n'" + nodes1 + "'\nn2:\n'" + nodes2 + "'");
            return false;
        }
        if (nodes1.size() != nodes2.size()) {
            System.out.println("ne3 n:\n'" + nodes1 + "'\nn2:\n'" + nodes2 + "'");
            return false;
        }
        for (int i = 0; i < nodes1.size(); i++) {
            if (!nodeEquals(nodes1.get(i), nodes2.get(i))) {
                System.out.println("ne4 n:\n'" + nodes1 + "'\nn2:\n'" + nodes2 + "'");
                return false;
            }
        }
        return true;
    }

    private <N extends Node> boolean nodesEquals(NodeList<N> n, NodeList<N> n2) {
        if (n == n2) {
            return true;
        }
        if (n == null || n2 == null) {
            {
                System.out.println("nl1n:\n'" + n + "'\nn2:\n'" + n2 + "'");
                return false;
            }
        }
        if (n.size() != n2.size()) {
            {
                System.out.println("nl2n:\n'" + n + "'\nn2:\n'" + n2 + "'");
                return false;
            }
        }
        for (int i = 0; i < n.size(); i++) {
            if (!nodeEquals(n.get(i), n2.get(i))) {
                {
                    System.out.println("nl3 " + i + ": " + n.get(i).getClass() + " n:\n'" + n + "'\nn2:\n'" + n2 + "'");
                    return false;
                }
            }
        }
        return true;
    }

    private <T extends Node> boolean nodeEquals(final T n, final T n2) {
        if (n == n2) {
            return true;
        }
        if (n == null || n2 == null) {
            {
                System.out.println("t1 n:\n'" + n + "'\nn2:\n'" + n2 + "'");
                return false;
            }
        }
        if (n.getClass() != n2.getClass()) {
            {
                System.out.println("t2 n:\n'" + n + "'\nn2:\n'" + n2 + "'");
                return false;
            }
        }
        if (!commonNodeEquality(n, n2)) {
            {
                System.out.println("t3 n:\n'" + n + "'\nn2:\n'" + n2 + "'");
                return false;
            }
        }
        return n.accept(this, n2);
    }

    private <T extends Node> boolean nodeEquals(final Optional<T> n, final Optional<T> n2) {
        return nodeEquals(n.orElse(null), n2.orElse(null));
    }

    private <T extends Node> boolean nodesEquals(final Optional<NodeList<T>> n, final Optional<NodeList<T>> n2) {
        return nodesEquals(n.orElse(null), n2.orElse(null));
    }

    private boolean objEquals(final Object n, final Object n2) {
        if (n == n2) {
            return true;
        }
        if (n == null || n2 == null) {
            {
                System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
                return false;
            }
        }
        return n.equals(n2);
    }

    @Override
    public Boolean visit(final CompilationUnit n, final Visitable arg) {
        final CompilationUnit n2 = (CompilationUnit) arg;
        if (!nodesEquals(n.getImports(), n2.getImports())) {
            System.out.println("cu1n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getModule(), n2.getModule())) {
            System.out.println("cu2n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getPackageDeclaration(), n2.getPackageDeclaration())) {
            System.out.println("cu3n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getTypes(), n2.getTypes())) {
            System.out.println("cu4n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("cu5n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final PackageDeclaration n, final Visitable arg) {
        final PackageDeclaration n2 = (PackageDeclaration) arg;
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final TypeParameter n, final Visitable arg) {
        final TypeParameter n2 = (TypeParameter) arg;
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getTypeBound(), n2.getTypeBound())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final LineComment n, final Visitable arg) {
        final LineComment n2 = (LineComment) arg;
        if (!objEquals(n.getContent(), n2.getContent())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final BlockComment n, final Visitable arg) {
        final BlockComment n2 = (BlockComment) arg;
        if (!objEquals(n.getContent(), n2.getContent())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ClassOrInterfaceDeclaration n, final Visitable arg) {
        final ClassOrInterfaceDeclaration n2 = (ClassOrInterfaceDeclaration) arg;
        if (!nodesEquals(n.getExtendedTypes(), n2.getExtendedTypes())) {
            System.out.println("1n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getImplementedTypes(), n2.getImplementedTypes())) {
            System.out.println("2n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!objEquals(n.isInterface(), n2.isInterface())) {
            System.out.println("3n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getPermittedTypes(), n2.getPermittedTypes())) {
            System.out.println("4n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getTypeParameters(), n2.getTypeParameters())) {
            System.out.println("5n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getMembers(), n2.getMembers())) {
            System.out.println("6n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getModifiers(), n2.getModifiers())) {
            System.out.println("7n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("8n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("9n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("10n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final EnumDeclaration n, final Visitable arg) {
        final EnumDeclaration n2 = (EnumDeclaration) arg;
        if (!nodesEquals(n.getEntries(), n2.getEntries())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getImplementedTypes(), n2.getImplementedTypes())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getMembers(), n2.getMembers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getModifiers(), n2.getModifiers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final EnumConstantDeclaration n, final Visitable arg) {
        final EnumConstantDeclaration n2 = (EnumConstantDeclaration) arg;
        if (!nodesEquals(n.getArguments(), n2.getArguments())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getClassBody(), n2.getClassBody())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final AnnotationDeclaration n, final Visitable arg) {
        final AnnotationDeclaration n2 = (AnnotationDeclaration) arg;
        if (!nodesEquals(n.getMembers(), n2.getMembers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getModifiers(), n2.getModifiers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final AnnotationMemberDeclaration n, final Visitable arg) {
        final AnnotationMemberDeclaration n2 = (AnnotationMemberDeclaration) arg;
        if (!nodeEquals(n.getDefaultValue(), n2.getDefaultValue())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getModifiers(), n2.getModifiers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getType(), n2.getType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final FieldDeclaration n, final Visitable arg) {
        final FieldDeclaration n2 = (FieldDeclaration) arg;
        if (!nodesEquals(n.getModifiers(), n2.getModifiers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getVariables(), n2.getVariables())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final VariableDeclarator n, final Visitable arg) {
        final VariableDeclarator n2 = (VariableDeclarator) arg;
        if (!nodeEquals(n.getInitializer(), n2.getInitializer())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getType(), n2.getType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ConstructorDeclaration n, final Visitable arg) {
        final ConstructorDeclaration n2 = (ConstructorDeclaration) arg;
        if (!nodeEquals(n.getBody(), n2.getBody())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getModifiers(), n2.getModifiers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getParameters(), n2.getParameters())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getReceiverParameter(), n2.getReceiverParameter())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getThrownExceptions(), n2.getThrownExceptions())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getTypeParameters(), n2.getTypeParameters())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final MethodDeclaration n, final Visitable arg) {
        final MethodDeclaration n2 = (MethodDeclaration) arg;
        if (!nodeEquals(n.getBody(), n2.getBody())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getType(), n2.getType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getModifiers(), n2.getModifiers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getParameters(), n2.getParameters())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getReceiverParameter(), n2.getReceiverParameter())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getThrownExceptions(), n2.getThrownExceptions())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getTypeParameters(), n2.getTypeParameters())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final Parameter n, final Visitable arg) {
        final Parameter n2 = (Parameter) arg;
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!objEquals(n.isVarArgs(), n2.isVarArgs())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getModifiers(), n2.getModifiers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getType(), n2.getType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getVarArgsAnnotations(), n2.getVarArgsAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final InitializerDeclaration n, final Visitable arg) {
        final InitializerDeclaration n2 = (InitializerDeclaration) arg;
        if (!nodeEquals(n.getBody(), n2.getBody())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!objEquals(n.isStatic(), n2.isStatic())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final JavadocComment n, final Visitable arg) {
        final JavadocComment n2 = (JavadocComment) arg;
        if (!objEquals(n.getContent(), n2.getContent())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ClassOrInterfaceType n, final Visitable arg) {
        final ClassOrInterfaceType n2 = (ClassOrInterfaceType) arg;
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getScope(), n2.getScope())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getTypeArguments(), n2.getTypeArguments())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final PrimitiveType n, final Visitable arg) {
        final PrimitiveType n2 = (PrimitiveType) arg;
        if (!objEquals(n.getType(), n2.getType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ArrayType n, final Visitable arg) {
        final ArrayType n2 = (ArrayType) arg;
        if (!nodeEquals(n.getComponentType(), n2.getComponentType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!objEquals(n.getOrigin(), n2.getOrigin())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ArrayCreationLevel n, final Visitable arg) {
        final ArrayCreationLevel n2 = (ArrayCreationLevel) arg;
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getDimension(), n2.getDimension())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final IntersectionType n, final Visitable arg) {
        final IntersectionType n2 = (IntersectionType) arg;
        if (!nodesEquals(n.getElements(), n2.getElements())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final UnionType n, final Visitable arg) {
        final UnionType n2 = (UnionType) arg;
        if (!nodesEquals(n.getElements(), n2.getElements())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final VoidType n, final Visitable arg) {
        final VoidType n2 = (VoidType) arg;
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final WildcardType n, final Visitable arg) {
        final WildcardType n2 = (WildcardType) arg;
        if (!nodeEquals(n.getExtendedType(), n2.getExtendedType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getSuperType(), n2.getSuperType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final UnknownType n, final Visitable arg) {
        final UnknownType n2 = (UnknownType) arg;
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ArrayAccessExpr n, final Visitable arg) {
        final ArrayAccessExpr n2 = (ArrayAccessExpr) arg;
        if (!nodeEquals(n.getIndex(), n2.getIndex())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ArrayCreationExpr n, final Visitable arg) {
        final ArrayCreationExpr n2 = (ArrayCreationExpr) arg;
        if (!nodeEquals(n.getElementType(), n2.getElementType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getInitializer(), n2.getInitializer())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getLevels(), n2.getLevels())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ArrayInitializerExpr n, final Visitable arg) {
        final ArrayInitializerExpr n2 = (ArrayInitializerExpr) arg;
        if (!nodesEquals(n.getValues(), n2.getValues())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final AssignExpr n, final Visitable arg) {
        final AssignExpr n2 = (AssignExpr) arg;
        if (!objEquals(n.getOperator(), n2.getOperator())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getTarget(), n2.getTarget())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getValue(), n2.getValue())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final BinaryExpr n, final Visitable arg) {
        final BinaryExpr n2 = (BinaryExpr) arg;
        if (!nodeEquals(n.getLeft(), n2.getLeft())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!objEquals(n.getOperator(), n2.getOperator())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getRight(), n2.getRight())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final CastExpr n, final Visitable arg) {
        final CastExpr n2 = (CastExpr) arg;
        if (!nodeEquals(n.getExpression(), n2.getExpression())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getType(), n2.getType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ClassExpr n, final Visitable arg) {
        final ClassExpr n2 = (ClassExpr) arg;
        if (!nodeEquals(n.getType(), n2.getType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ConditionalExpr n, final Visitable arg) {
        final ConditionalExpr n2 = (ConditionalExpr) arg;
        if (!nodeEquals(n.getCondition(), n2.getCondition())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getElseExpr(), n2.getElseExpr())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getThenExpr(), n2.getThenExpr())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final EnclosedExpr n, final Visitable arg) {
        final EnclosedExpr n2 = (EnclosedExpr) arg;
        if (!nodeEquals(n.getInner(), n2.getInner())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final FieldAccessExpr n, final Visitable arg) {
        final FieldAccessExpr n2 = (FieldAccessExpr) arg;
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getScope(), n2.getScope())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getTypeArguments(), n2.getTypeArguments())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final InstanceOfExpr n, final Visitable arg) {
        final InstanceOfExpr n2 = (InstanceOfExpr) arg;
        if (!nodeEquals(n.getExpression(), n2.getExpression())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getPattern(), n2.getPattern())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getType(), n2.getType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final StringLiteralExpr n, final Visitable arg) {
        final StringLiteralExpr n2 = (StringLiteralExpr) arg;
        if (!objEquals(n.getValue(), n2.getValue())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final IntegerLiteralExpr n, final Visitable arg) {
        final IntegerLiteralExpr n2 = (IntegerLiteralExpr) arg;
        if (!objEquals(n.getValue(), n2.getValue())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final LongLiteralExpr n, final Visitable arg) {
        final LongLiteralExpr n2 = (LongLiteralExpr) arg;
        if (!objEquals(n.getValue(), n2.getValue())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final CharLiteralExpr n, final Visitable arg) {
        final CharLiteralExpr n2 = (CharLiteralExpr) arg;
        if (!objEquals(n.getValue(), n2.getValue())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final DoubleLiteralExpr n, final Visitable arg) {
        final DoubleLiteralExpr n2 = (DoubleLiteralExpr) arg;
        if (!objEquals(n.getValue(), n2.getValue())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final BooleanLiteralExpr n, final Visitable arg) {
        final BooleanLiteralExpr n2 = (BooleanLiteralExpr) arg;
        if (!objEquals(n.isValue(), n2.isValue())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final NullLiteralExpr n, final Visitable arg) {
        final NullLiteralExpr n2 = (NullLiteralExpr) arg;
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final MethodCallExpr n, final Visitable arg) {
        final MethodCallExpr n2 = (MethodCallExpr) arg;
        if (!nodesEquals(n.getArguments(), n2.getArguments())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getScope(), n2.getScope())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getTypeArguments(), n2.getTypeArguments())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final NameExpr n, final Visitable arg) {
        final NameExpr n2 = (NameExpr) arg;
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ObjectCreationExpr n, final Visitable arg) {
        final ObjectCreationExpr n2 = (ObjectCreationExpr) arg;
        if (!nodesEquals(n.getAnonymousClassBody(), n2.getAnonymousClassBody())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getArguments(), n2.getArguments())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getScope(), n2.getScope())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getType(), n2.getType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getTypeArguments(), n2.getTypeArguments())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final Name n, final Visitable arg) {
        final Name n2 = (Name) arg;
        if (!objEquals(n.getIdentifier(), n2.getIdentifier())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getQualifier(), n2.getQualifier())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final SimpleName n, final Visitable arg) {
        final SimpleName n2 = (SimpleName) arg;
        if (!objEquals(n.getIdentifier(), n2.getIdentifier())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ThisExpr n, final Visitable arg) {
        final ThisExpr n2 = (ThisExpr) arg;
        if (!nodeEquals(n.getTypeName(), n2.getTypeName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final SuperExpr n, final Visitable arg) {
        final SuperExpr n2 = (SuperExpr) arg;
        if (!nodeEquals(n.getTypeName(), n2.getTypeName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final UnaryExpr n, final Visitable arg) {
        final UnaryExpr n2 = (UnaryExpr) arg;
        if (!nodeEquals(n.getExpression(), n2.getExpression())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!objEquals(n.getOperator(), n2.getOperator())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final VariableDeclarationExpr n, final Visitable arg) {
        final VariableDeclarationExpr n2 = (VariableDeclarationExpr) arg;
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getModifiers(), n2.getModifiers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getVariables(), n2.getVariables())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final MarkerAnnotationExpr n, final Visitable arg) {
        final MarkerAnnotationExpr n2 = (MarkerAnnotationExpr) arg;
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final SingleMemberAnnotationExpr n, final Visitable arg) {
        final SingleMemberAnnotationExpr n2 = (SingleMemberAnnotationExpr) arg;
        if (!nodeEquals(n.getMemberValue(), n2.getMemberValue())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final NormalAnnotationExpr n, final Visitable arg) {
        final NormalAnnotationExpr n2 = (NormalAnnotationExpr) arg;
        if (!nodesEquals(n.getPairs(), n2.getPairs())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final MemberValuePair n, final Visitable arg) {
        final MemberValuePair n2 = (MemberValuePair) arg;
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getValue(), n2.getValue())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ExplicitConstructorInvocationStmt n, final Visitable arg) {
        final ExplicitConstructorInvocationStmt n2 = (ExplicitConstructorInvocationStmt) arg;
        if (!nodesEquals(n.getArguments(), n2.getArguments())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getExpression(), n2.getExpression())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!objEquals(n.isThis(), n2.isThis())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getTypeArguments(), n2.getTypeArguments())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final LocalClassDeclarationStmt n, final Visitable arg) {
        final LocalClassDeclarationStmt n2 = (LocalClassDeclarationStmt) arg;
        if (!nodeEquals(n.getClassDeclaration(), n2.getClassDeclaration())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final LocalRecordDeclarationStmt n, final Visitable arg) {
        final LocalRecordDeclarationStmt n2 = (LocalRecordDeclarationStmt) arg;
        if (!nodeEquals(n.getRecordDeclaration(), n2.getRecordDeclaration())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final AssertStmt n, final Visitable arg) {
        final AssertStmt n2 = (AssertStmt) arg;
        if (!nodeEquals(n.getCheck(), n2.getCheck())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getMessage(), n2.getMessage())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final BlockStmt n, final Visitable arg) {
        final BlockStmt n2 = (BlockStmt) arg;
        if (!nodesEquals(n.getStatements(), n2.getStatements())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final LabeledStmt n, final Visitable arg) {
        final LabeledStmt n2 = (LabeledStmt) arg;
        if (!nodeEquals(n.getLabel(), n2.getLabel())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getStatement(), n2.getStatement())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final EmptyStmt n, final Visitable arg) {
        final EmptyStmt n2 = (EmptyStmt) arg;
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ExpressionStmt n, final Visitable arg) {
        final ExpressionStmt n2 = (ExpressionStmt) arg;
        if (!nodeEquals(n.getExpression(), n2.getExpression())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final SwitchStmt n, final Visitable arg) {
        final SwitchStmt n2 = (SwitchStmt) arg;
        if (!nodesEquals(n.getEntries(), n2.getEntries())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getSelector(), n2.getSelector())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final SwitchEntry n, final Visitable arg) {
        final SwitchEntry n2 = (SwitchEntry) arg;
        if (!this.nodeEquals(n.getGuard(), n2.getGuard())) {
            System.out.println("guard:\nn:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!this.objEquals(n.isDefault(), n2.isDefault())) {
            System.out.println("default:\nn:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getLabels(), n2.getLabels())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getStatements(), n2.getStatements())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!objEquals(n.getType(), n2.getType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final BreakStmt n, final Visitable arg) {
        final BreakStmt n2 = (BreakStmt) arg;
        if (!nodeEquals(n.getLabel(), n2.getLabel())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ReturnStmt n, final Visitable arg) {
        final ReturnStmt n2 = (ReturnStmt) arg;
        if (!nodeEquals(n.getExpression(), n2.getExpression())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final IfStmt n, final Visitable arg) {
        final IfStmt n2 = (IfStmt) arg;
        if (!nodeEquals(n.getCondition(), n2.getCondition())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getElseStmt(), n2.getElseStmt())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getThenStmt(), n2.getThenStmt())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final WhileStmt n, final Visitable arg) {
        final WhileStmt n2 = (WhileStmt) arg;
        if (!nodeEquals(n.getBody(), n2.getBody())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getCondition(), n2.getCondition())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ContinueStmt n, final Visitable arg) {
        final ContinueStmt n2 = (ContinueStmt) arg;
        if (!nodeEquals(n.getLabel(), n2.getLabel())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final DoStmt n, final Visitable arg) {
        final DoStmt n2 = (DoStmt) arg;
        if (!nodeEquals(n.getBody(), n2.getBody())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getCondition(), n2.getCondition())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ForEachStmt n, final Visitable arg) {
        final ForEachStmt n2 = (ForEachStmt) arg;
        if (!nodeEquals(n.getBody(), n2.getBody())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getIterable(), n2.getIterable())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getVariable(), n2.getVariable())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ForStmt n, final Visitable arg) {
        final ForStmt n2 = (ForStmt) arg;
        if (!nodeEquals(n.getBody(), n2.getBody())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getCompare(), n2.getCompare())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getInitialization(), n2.getInitialization())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getUpdate(), n2.getUpdate())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ThrowStmt n, final Visitable arg) {
        final ThrowStmt n2 = (ThrowStmt) arg;
        if (!nodeEquals(n.getExpression(), n2.getExpression())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final SynchronizedStmt n, final Visitable arg) {
        final SynchronizedStmt n2 = (SynchronizedStmt) arg;
        if (!nodeEquals(n.getBody(), n2.getBody())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getExpression(), n2.getExpression())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final TryStmt n, final Visitable arg) {
        final TryStmt n2 = (TryStmt) arg;
        if (!nodesEquals(n.getCatchClauses(), n2.getCatchClauses())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getFinallyBlock(), n2.getFinallyBlock())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getResources(), n2.getResources())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getTryBlock(), n2.getTryBlock())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final CatchClause n, final Visitable arg) {
        final CatchClause n2 = (CatchClause) arg;
        if (!nodeEquals(n.getBody(), n2.getBody())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getParameter(), n2.getParameter())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final LambdaExpr n, final Visitable arg) {
        final LambdaExpr n2 = (LambdaExpr) arg;
        if (!nodeEquals(n.getBody(), n2.getBody())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!objEquals(n.isEnclosingParameters(), n2.isEnclosingParameters())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getParameters(), n2.getParameters())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final MethodReferenceExpr n, final Visitable arg) {
        final MethodReferenceExpr n2 = (MethodReferenceExpr) arg;
        if (!objEquals(n.getIdentifier(), n2.getIdentifier())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getScope(), n2.getScope())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getTypeArguments(), n2.getTypeArguments())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final TypeExpr n, final Visitable arg) {
        final TypeExpr n2 = (TypeExpr) arg;
        if (!nodeEquals(n.getType(), n2.getType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ImportDeclaration n, final Visitable arg) {
        final ImportDeclaration n2 = (ImportDeclaration) arg;
        if (!objEquals(n.isAsterisk(), n2.isAsterisk())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!objEquals(n.isStatic(), n2.isStatic())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(NodeList n, Visitable arg) {
        return nodesEquals((NodeList<Node>) n, (NodeList<Node>) arg);
    }

    @Override
    public Boolean visit(final ModuleDeclaration n, final Visitable arg) {
        final ModuleDeclaration n2 = (ModuleDeclaration) arg;
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getDirectives(), n2.getDirectives())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!objEquals(n.isOpen(), n2.isOpen())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ModuleRequiresDirective n, final Visitable arg) {
        final ModuleRequiresDirective n2 = (ModuleRequiresDirective) arg;
        if (!nodesEquals(n.getModifiers(), n2.getModifiers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override()
    public Boolean visit(final ModuleExportsDirective n, final Visitable arg) {
        final ModuleExportsDirective n2 = (ModuleExportsDirective) arg;
        if (!nodesEquals(n.getModuleNames(), n2.getModuleNames())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override()
    public Boolean visit(final ModuleProvidesDirective n, final Visitable arg) {
        final ModuleProvidesDirective n2 = (ModuleProvidesDirective) arg;
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getWith(), n2.getWith())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override()
    public Boolean visit(final ModuleUsesDirective n, final Visitable arg) {
        final ModuleUsesDirective n2 = (ModuleUsesDirective) arg;
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ModuleOpensDirective n, final Visitable arg) {
        final ModuleOpensDirective n2 = (ModuleOpensDirective) arg;
        if (!nodesEquals(n.getModuleNames(), n2.getModuleNames())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final UnparsableStmt n, final Visitable arg) {
        final UnparsableStmt n2 = (UnparsableStmt) arg;
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final ReceiverParameter n, final Visitable arg) {
        final ReceiverParameter n2 = (ReceiverParameter) arg;
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getType(), n2.getType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final VarType n, final Visitable arg) {
        final VarType n2 = (VarType) arg;
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final Modifier n, final Visitable arg) {
        final Modifier n2 = (Modifier) arg;
        if (!objEquals(n.getKeyword(), n2.getKeyword())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final SwitchExpr n, final Visitable arg) {
        final SwitchExpr n2 = (SwitchExpr) arg;
        if (!nodesEquals(n.getEntries(), n2.getEntries())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getSelector(), n2.getSelector())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final YieldStmt n, final Visitable arg) {
        final YieldStmt n2 = (YieldStmt) arg;
        if (!nodeEquals(n.getExpression(), n2.getExpression())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final TextBlockLiteralExpr n, final Visitable arg) {
        final TextBlockLiteralExpr n2 = (TextBlockLiteralExpr) arg;
        if (!objEquals(n.getValue(), n2.getValue())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final TypePatternExpr n, final Visitable arg) {
        final TypePatternExpr n2 = (TypePatternExpr) arg;
        if (!nodesEquals(n.getModifiers(), n2.getModifiers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getType(), n2.getType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(RecordPatternExpr n, Visitable arg) {
        RecordPatternExpr n2 = (RecordPatternExpr) arg;
        if (!this.nodesEquals(n.getModifiers(), n2.getModifiers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        else if (!this.nodesEquals(n.getPatternList(), n2.getPatternList())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        else if (!this.nodeEquals((Node) n.getType(), (Node) n2.getType())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        else if (!this.nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        else
            return true;
    }

    @Override
    public Boolean visit(final RecordDeclaration n, final Visitable arg) {
        final RecordDeclaration n2 = (RecordDeclaration) arg;
        if (!nodesEquals(n.getImplementedTypes(), n2.getImplementedTypes())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getParameters(), n2.getParameters())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getReceiverParameter(), n2.getReceiverParameter())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getTypeParameters(), n2.getTypeParameters())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getMembers(), n2.getMembers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getModifiers(), n2.getModifiers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }

    @Override
    public Boolean visit(final CompactConstructorDeclaration n, final Visitable arg) {
        final CompactConstructorDeclaration n2 = (CompactConstructorDeclaration) arg;
        if (!nodeEquals(n.getBody(), n2.getBody())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getModifiers(), n2.getModifiers())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getName(), n2.getName())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getThrownExceptions(), n2.getThrownExceptions())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getTypeParameters(), n2.getTypeParameters())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodesEquals(n.getAnnotations(), n2.getAnnotations())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        if (!nodeEquals(n.getComment(), n2.getComment())) {
            System.out.println("n:\n'" + n + "'\nn2:\n'" + n2 + "'");
            return false;
        }
        return true;
    }
}
