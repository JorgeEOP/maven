package de.unibwm.inf2.bugvis.instr.translation;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.AnnotationDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.EnumConstantDeclaration;
import com.github.javaparser.ast.body.EnumDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.InitializerDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.RecordDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.expr.ArrayAccessExpr;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.BinaryExpr;
import com.github.javaparser.ast.expr.CastExpr;
import com.github.javaparser.ast.expr.ConditionalExpr;
import com.github.javaparser.ast.expr.FieldAccessExpr;
import com.github.javaparser.ast.expr.InstanceOfExpr;
import com.github.javaparser.ast.expr.LambdaExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.expr.SwitchExpr;
import com.github.javaparser.ast.expr.UnaryExpr;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.ForEachStmt;
import com.github.javaparser.ast.stmt.ForStmt;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.stmt.ReturnStmt;
import com.github.javaparser.ast.stmt.SwitchEntry;
import com.github.javaparser.ast.stmt.SwitchStmt;
import com.github.javaparser.ast.stmt.ThrowStmt;
import com.github.javaparser.ast.stmt.WhileStmt;
import com.github.javaparser.ast.stmt.YieldStmt;
import com.github.javaparser.ast.visitor.CloneVisitor;
import com.github.javaparser.ast.visitor.Visitable;
import com.github.javaparser.resolution.TypeSolver;
import de.unibwm.inf2.bugvis.instr.metainfo.FileMetaInfo;
import de.unibwm.inf2.bugvis.instr.metainfo.LineRange;
import de.unibwm.inf2.bugvis.instr.translation.ast.SwitchEntryTranslator;
import de.unibwm.inf2.bugvis.instr.translation.body.AnnotationDeclarationTranslator;
import de.unibwm.inf2.bugvis.instr.translation.body.ClassOrInterfaceDeclarationTranslator;
import de.unibwm.inf2.bugvis.instr.translation.body.CompilationUnitTranslator;
import de.unibwm.inf2.bugvis.instr.translation.body.ConstructorDeclarationTranslator;
import de.unibwm.inf2.bugvis.instr.translation.body.EnumConstantDeclarationTranslator;
import de.unibwm.inf2.bugvis.instr.translation.body.EnumDeclarationTranslator;
import de.unibwm.inf2.bugvis.instr.translation.body.FieldDeclarationTranslator;
import de.unibwm.inf2.bugvis.instr.translation.body.InitializerDeclarationTranslator;
import de.unibwm.inf2.bugvis.instr.translation.body.MethodDeclarationTranslator;
import de.unibwm.inf2.bugvis.instr.translation.body.RecordDeclarationTranslator;
import de.unibwm.inf2.bugvis.instr.translation.expr.ArrayAccessExprTranslator;
import de.unibwm.inf2.bugvis.instr.translation.expr.AssignExprTranslator;
import de.unibwm.inf2.bugvis.instr.translation.expr.BinaryExprTranslator;
import de.unibwm.inf2.bugvis.instr.translation.expr.CastExprTranslator;
import de.unibwm.inf2.bugvis.instr.translation.expr.ConditionalExprTranslator;
import de.unibwm.inf2.bugvis.instr.translation.expr.FieldAccessExprTranslator;
import de.unibwm.inf2.bugvis.instr.translation.expr.InstanceOfExprTranslator;
import de.unibwm.inf2.bugvis.instr.translation.expr.LambdaExprTranslator;
import de.unibwm.inf2.bugvis.instr.translation.expr.MethodCallExprTranslator;
import de.unibwm.inf2.bugvis.instr.translation.expr.NameExprTranslator;
import de.unibwm.inf2.bugvis.instr.translation.expr.ObjectCreationExprTranslator;
import de.unibwm.inf2.bugvis.instr.translation.expr.SwitchExprTranslator;
import de.unibwm.inf2.bugvis.instr.translation.expr.UnaryExprTranslator;
import de.unibwm.inf2.bugvis.instr.translation.expr.VariableDeclarationExprTranslator;
import de.unibwm.inf2.bugvis.instr.translation.stmt.BlockStmtTranslator;
import de.unibwm.inf2.bugvis.instr.translation.stmt.ExpressionStmtTranslator;
import de.unibwm.inf2.bugvis.instr.translation.stmt.ForEachStmtTranslator;
import de.unibwm.inf2.bugvis.instr.translation.stmt.ForStmtTranslator;
import de.unibwm.inf2.bugvis.instr.translation.stmt.IfStmtTranslator;
import de.unibwm.inf2.bugvis.instr.translation.stmt.ReturnStmtTranslator;
import de.unibwm.inf2.bugvis.instr.translation.stmt.SwitchStmtTranslator;
import de.unibwm.inf2.bugvis.instr.translation.stmt.WhileStmtTranslator;
import de.unibwm.inf2.bugvis.instr.translation.stmt.YieldStmtTranslator;

import java.lang.System.Logger;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static java.lang.System.Logger.Level.DEBUG;

public class TranslationVisitor extends CloneVisitor {
    private static final Logger LOGGER = System.getLogger(TranslationVisitor.class.getName());

    public static final String VAR_PREFIX = "_var";

    private final FileMetaInfo fileMetaInfo;
    private final Deque<TypeDeclaration<?>> typeStack = new ArrayDeque<>();
    private final Deque<BlockStmt> blockStack = new ArrayDeque<>();
    private final Deque<AnonymousClassInfo> anonymousClassStack = new ArrayDeque<>();
    private final TypeSolver typeSolver;
    private final Map<String, Set<String>> instrClassMethodMap = new HashMap<>();

    private int ctr;
    private CompilationUnit compilationUnit;
    private int lineNumber = -1;

    public TranslationVisitor(TypeSolver typeSolver, FileMetaInfo fileMetaInfo) {
        LOGGER.log(DEBUG, () -> "creating TranslationVisitor(" + fileMetaInfo.getRelativeFilePath() + ")");
        this.typeSolver = typeSolver;
        this.fileMetaInfo = fileMetaInfo;
    }

    // AST /////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public Visitable visit(SwitchEntry n, Object arg) {
        return new SwitchEntryTranslator(this, n).translate();
    }

    // BODY ////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public Visitable visit(AnnotationDeclaration n, Object arg) {
        return new AnnotationDeclarationTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(ClassOrInterfaceDeclaration n, Object arg) {
        return new ClassOrInterfaceDeclarationTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(CompilationUnit n, Object arg) {
        return new CompilationUnitTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(ConstructorDeclaration n, Object arg) {
        addBreakpointRange(n.getBody());
        return new ConstructorDeclarationTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(EnumConstantDeclaration n, Object arg) {
        return new EnumConstantDeclarationTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(EnumDeclaration n, Object arg) {
        return new EnumDeclarationTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(FieldDeclaration n, Object arg) {
        return new FieldDeclarationTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(InitializerDeclaration n, Object arg) {
        return new InitializerDeclarationTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(MethodDeclaration n, Object arg) {
        n.getBody().ifPresent(this::addBreakpointRange);
        return new MethodDeclarationTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(RecordDeclaration n, Object arg) {
        return new RecordDeclarationTranslator(this, n).translate();
    }

    // EXPR ////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public Visitable visit(ArrayAccessExpr n, Object arg) {
        return new ArrayAccessExprTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(AssignExpr n, Object arg) {
        return new AssignExprTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(BinaryExpr n, Object arg) {
        return new BinaryExprTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(CastExpr n, Object arg) {
        return new CastExprTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(ConditionalExpr n, Object arg) {
        return new ConditionalExprTranslator(this, n, arg).translate();
    }

    @Override
    public Visitable visit(FieldAccessExpr n, Object arg) {
        return new FieldAccessExprTranslator(this, n, arg).translate();
    }

    @Override
    public Visitable visit(InstanceOfExpr n, Object arg) {
        return new InstanceOfExprTranslator(this, n, arg).translate();
    }

    @Override
    public Visitable visit(LambdaExpr n, Object arg) {
        return new LambdaExprTranslator(this, n, arg).translate();
    }

    @Override
    public Visitable visit(MethodCallExpr n, Object arg) {
        return new MethodCallExprTranslator(this, n, arg).translate();
    }

    @Override
    public Visitable visit(NameExpr n, Object arg) {
        return new NameExprTranslator(this, n, arg).translate();
    }

    @Override
    public Visitable visit(ObjectCreationExpr n, Object arg) {
        return new ObjectCreationExprTranslator(this, n, arg).translate();
    }

    @Override
    public Visitable visit(SwitchExpr n, Object arg) {
        return new SwitchExprTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(UnaryExpr n, Object arg) {
        return new UnaryExprTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(VariableDeclarationExpr n, Object arg) {
        return new VariableDeclarationExprTranslator(this, n).translate();
    }

    // STMT ////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public Visitable visit(BlockStmt n, Object arg) {
        return new BlockStmtTranslator(this, n, arg).translate();
    }

    @Override
    public Visitable visit(ExpressionStmt n, Object arg) {
        return new ExpressionStmtTranslator(this, n, arg).translate();
    }

    @Override
    public Visitable visit(ForEachStmt n, Object arg) {
        return new ForEachStmtTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(ForStmt n, Object arg) {return new ForStmtTranslator(this, n).translate();}

    @Override
    public Visitable visit(IfStmt n, Object arg) {return new IfStmtTranslator(this, n).translate();}

    @Override
    public Visitable visit(ReturnStmt n, Object arg) {
        return new ReturnStmtTranslator(this, n, arg).translate();
    }

    @Override
    public Visitable visit(SwitchStmt n, Object arg) {
        return new SwitchStmtTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(ThrowStmt n, Object arg) {
        return super.visit(n, arg); // TODO
    }

    @Override
    public Visitable visit(WhileStmt n, Object arg) {
        return new WhileStmtTranslator(this, n).translate();
    }

    @Override
    public Visitable visit(YieldStmt n, Object arg) {
        return new YieldStmtTranslator(this, n).translate();
    }

    // util ////////////////////////////////////////////////////////////////////////////////////////////////////////////

    String newVarName() {return VAR_PREFIX + ++ctr;}

    public <N extends Node> NodeList<N> translateList(NodeList<N> list, Object arg) {
        if (list == null) return null;
        return (NodeList<N>) list.accept(this, arg);
    }

    public <N extends Node> NodeList<N> translateList(NodeList<N> list) {return translateList(list, null);}

    public <T extends Node> T translateNode(Optional<T> node, Object arg) {return cloneNode(node, arg);}

    public <T extends Node> T translateNode(Optional<T> node) {return cloneNode(node, null);}

    public <T extends Node> T translateNode(T node, Object arg) {return cloneNode(node, arg);}

    public <T extends Node> T translateNode(T node) {return cloneNode(node, null);}

    public int getFileId() {return fileMetaInfo.getFileId();}

    private void addBreakpointRange(BlockStmt body) {
        body.getRange().ifPresent(range -> {
            LineRange bpRange;
            if (range.getLineCount() > 1) bpRange = new LineRange(range.begin.line, range.end.line - 1);
            else bpRange = new LineRange(range.begin.line, range.end.line);
            fileMetaInfo.addBreakpointRange(bpRange);
        });
    }

    public void addStaticMethod(String fullyQualifiedClassName, String signature) {
        fileMetaInfo.addStaticMethod(fullyQualifiedClassName, signature);
    }

    public FileMetaInfo getFileMetaInfo() {return fileMetaInfo;}

    public TypeSolver getTypeSolver() {return typeSolver;}

    public void setCompilationUnit(CompilationUnit compilationUnit) {this.compilationUnit = compilationUnit;}

    public Deque<TypeDeclaration<?>> getTypeStack() {return typeStack;}

    public Deque<BlockStmt> getBlockStack() {return blockStack;}

    public Deque<AnonymousClassInfo> getAnonymousClassStack() {return anonymousClassStack;}

    public Map<String, Set<String>> getInstrClassMethodMap() {return instrClassMethodMap;}

    public void addInstrType(String qualifiedName) {
        instrClassMethodMap.computeIfAbsent(qualifiedName, str -> new HashSet<>());
    }

    public int getLineNumber() {return lineNumber;}

    public void setLineNumber(int lineNumber) {this.lineNumber = lineNumber;}
}
