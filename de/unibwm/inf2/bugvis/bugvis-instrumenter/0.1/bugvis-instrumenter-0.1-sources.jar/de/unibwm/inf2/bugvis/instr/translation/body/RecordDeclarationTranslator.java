package de.unibwm.inf2.bugvis.instr.translation.body;

import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.body.ReceiverParameter;
import com.github.javaparser.ast.body.RecordDeclaration;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.TypeParameter;
import com.github.javaparser.resolution.declarations.ResolvedReferenceTypeDeclaration;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.DEBUG;

public class RecordDeclarationTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(RecordDeclarationTranslator.class.getName());

    private final TranslationVisitor tv;
    private final RecordDeclaration rd;

    public RecordDeclarationTranslator(TranslationVisitor translationVisitor, RecordDeclaration recordDeclaration) {
        LOGGER.log(DEBUG, () -> "creating RecordDeclarationTranslator (" + recordDeclaration + ")");
        this.tv = translationVisitor;
        this.rd = recordDeclaration;
        ResolvedReferenceTypeDeclaration rrtd = recordDeclaration.resolve();
        translationVisitor.addInstrType(rrtd.getQualifiedName());
    }

    public Node translate() {
        NodeList<Parameter> parameters = tv.translateList(rd.getParameters());
        ReceiverParameter receiverParameter = tv.translateNode(rd.getReceiverParameter());
        NodeList<ClassOrInterfaceType> implementedTypes = tv.translateList(rd.getImplementedTypes());
        NodeList<TypeParameter> typeParameters = tv.translateList(rd.getTypeParameters());
        NodeList<Modifier> modifiers = tv.translateList(rd.getModifiers());
        SimpleName name = tv.translateNode(rd.getName());
        NodeList<AnnotationExpr> annotations = tv.translateList(rd.getAnnotations());
        RecordDeclaration r = new RecordDeclaration(rd.getTokenRange().orElse(null), modifiers, annotations,
                                                    name, parameters, typeParameters, implementedTypes, new NodeList<>(),
                                                    receiverParameter);
        translateMembers(rd, r);
        copyCommentsAndData(rd, r);
        return r;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.DECLARATION_RUNTIME;}
}
