package de.unibwm.inf2.bugvis.instr.translation.expr;

import com.github.javaparser.Range;
import com.github.javaparser.ast.expr.ArrayAccessExpr;
import com.github.javaparser.ast.expr.CastExpr;
import com.github.javaparser.ast.expr.ClassExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.FieldAccessExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.ast.expr.UnaryExpr;
import com.github.javaparser.ast.expr.UnaryExpr.Operator;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.type.Type;
import com.github.javaparser.resolution.declarations.ResolvedFieldDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedValueDeclaration;
import de.unibwm.inf2.bugvis.instr.translation.InstrumentationException;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.List;

import static java.lang.System.Logger.Level.DEBUG;

public class UnaryExprTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(UnaryExprTranslator.class.getName());

    private final Operator operator;
    private final TranslationVisitor tv;
    private final UnaryExpr ue;
    private final Expression expression;

    public UnaryExprTranslator(TranslationVisitor translationVisitor, UnaryExpr unaryExpr) {
        LOGGER.log(DEBUG, () -> "creating UnaryExprTranslator (" + unaryExpr + ")");
        this.tv = translationVisitor;
        this.ue = unaryExpr;
        this.expression = unaryExpr.getExpression();
        this.operator = unaryExpr.getOperator();
    }

    @Override
    public Expression translate() {
        BlockStmt block = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));
        if (operator == Operator.BITWISE_COMPLEMENT
            || operator == Operator.LOGICAL_COMPLEMENT
            || operator == Operator.MINUS
            || operator == Operator.PLUS)
            return unaryExprWithoutSideEffectsTranslation(block);

        return prefixAndPostfixTranslation(block);
    }

    private Expression unaryExprWithoutSideEffectsTranslation(BlockStmt block) {
        String originalValueVar = storeResult(block, tv.translateNode(expression));
        Type type = parseType(ue.calculateResolvedType().describe());
        UnaryExpr newUnaryExpr = new UnaryExpr(new NameExpr(originalValueVar), operator);
        String afterOperationVar = storeResult(block, new CastExpr(type.clone(), newUnaryExpr), type);
        block.addStatement(makeMethodCall(unaryOperatorRange(ue), getRuntime(), UNARY_OPERATION,
                                          List.of(new StringLiteralExpr(replaceQuotationMarks(expression)),
                                                  new StringLiteralExpr(operator.asString()),
                                                  value(new NameExpr(afterOperationVar)))));
        return new NameExpr(afterOperationVar);
    }

    private Range unaryOperatorRange(UnaryExpr expr) {
        return expr.getRange().map(r -> r.withEnd(r.begin))
                   .orElse(UNDEFINED_RANGE);
    }

    private Expression prefixAndPostfixTranslation(BlockStmt block) {
        if (expression.isNameExpr()) {
            NameExpr nameExpr = expression.asNameExpr();
            NameExpr newNameExpr = tv.translateNode(nameExpr);
            StringPair names = prefixOrPostfixTranslation(block, newNameExpr);
            addVarOrFieldSetMethodCall(block, nameExpr, names.newName);
            return new NameExpr(names.oldName);
        }
        else if (expression.isFieldAccessExpr()) {
            FieldAccessExpr fieldAccessExpr = expression.asFieldAccessExpr();
            Expression scope = fieldAccessExpr.getScope();
            String fieldName = fieldAccessExpr.getNameAsString();
            Expression newScope = tv.translateNode(scope);
            FieldAccessExpr newFieldAccessExpr = new FieldAccessExpr(newScope.clone(), fieldName);
            StringPair names = prefixOrPostfixTranslation(block, newFieldAccessExpr);
            final ResolvedFieldDeclaration rfd = fieldAccessExpr.resolve().asField();
            final String qualifiedName = rfd.declaringType().getQualifiedName();
            final Type type = parseType(qualifiedName);
            newScope = rfd.isStatic() ? new ClassExpr(type.clone()) : newScope;
            addStaticOrNotStaticFieldSetMethodCall(rfd, block, newScope, fieldName, names.newName, type);

            return new NameExpr(names.oldName);
        }
        else if (expression.isArrayAccessExpr()) {
            ArrayAccessExpr arrayAccessExpr = expression.asArrayAccessExpr();
            ArrayAccessExpr newArrayAccessExpr = tv.translateNode(arrayAccessExpr);
            StringPair names = prefixOrPostfixTranslation(block, newArrayAccessExpr);
            addArrayVarSetMethodCall(block, arrayAccessExpr, names.newName);
            return new NameExpr(names.oldName);
        }
        throw new InstrumentationException(expression + " must be either a NameExpr, a FieldAccessExpr or an ArrayAccessExpr");
    }

    private StringPair prefixOrPostfixTranslation(BlockStmt block, Expression expression) {
        return operator.isPrefix() ? prefixTranslation(block, expression) : postfixTranslation(block, expression);
    }

    private StringPair prefixTranslation(BlockStmt block, Expression expression) {
        String varName = storeResult(block, new UnaryExpr(expression.clone(), operator));
        unaryPrefixOperationMethodCall(block, varName);
        return new StringPair(varName, varName);
    }

    private StringPair postfixTranslation(BlockStmt block, Expression expression) {
        String oldValueName = storeResult(block, expression.clone());
        block.addStatement(new UnaryExpr(expression.clone(), operator));
        String newValueName = storeResult(block, expression.clone());
        addUnaryPostfixOperationMethodCall(block, oldValueName, newValueName);
        return new StringPair(oldValueName, newValueName);
    }

    private void addArrayVarSetMethodCall(BlockStmt block, ArrayAccessExpr arrayAccessExpr, String varName) {
        block.addStatement(makeMethodCall(ue, Runtime.EXPRESSION_RUNTIME, ARRAY_ASSIGNMENT,
                                          List.of(value(arrayAccessExpr.getName().clone()),
                                                  arrayAccessExpr.getIndex().clone(),
                                                  new StringLiteralExpr(arrayAccessExpr.toString()),
                                                  value(new NameExpr(varName)))));
    }

    private void addStaticOrNotStaticFieldSetMethodCall(ResolvedFieldDeclaration rfd, BlockStmt block, Expression scope,
                                                        String fieldName, String varName, Type declaringType) {
        final ClassExpr classExpr = new ClassExpr(declaringType);
        final NameExpr varExpr = new NameExpr(varName);
        if (rfd.isStatic()) addStaticFieldSetMethodCall(block, fieldName, varExpr, classExpr);
        else addFieldSetMethodCall(block, scope, fieldName, varExpr, classExpr);
    }

    private void addFieldSetMethodCall(BlockStmt block, Expression newScope, String fieldName, NameExpr varExpr,
                                       ClassExpr declaringType) {
        block.addStatement(makeMethodCall(ue, Runtime.DECLARATION_RUNTIME, FIELD_ASSIGNMENT,
                                          List.of(value(newScope), new StringLiteralExpr(fieldName),
                                                  value(varExpr), declaringType)));
    }

    private void addStaticFieldSetMethodCall(BlockStmt block, String fieldName, NameExpr varExpr, ClassExpr declaringType) {
        block.addStatement(makeMethodCall(ue, Runtime.DECLARATION_RUNTIME, STATIC_FIELD_ASSIGNMENT,
                                          List.of(declaringType, new StringLiteralExpr(fieldName), value(varExpr))));
    }

    private void addVarSetMethodCall(BlockStmt block, NameExpr nameExpr, String varName) {
        block.addStatement(makeMethodCall(ue, Runtime.EXPRESSION_RUNTIME, VARIABLE_ASSIGNMENT,
                                          List.of(new StringLiteralExpr(nameExpr.getNameAsString()),
                                                  value(new NameExpr(varName)))));
    }

    private void unaryPrefixOperationMethodCall(BlockStmt block, String varName) {
        block.addStatement(makeMethodCall(unaryPrefixOperatorRange(ue), getRuntime(), UNARY_PREFIX_OPERATION,
                                          List.of(new StringLiteralExpr(expression.toString()),
                                                  new StringLiteralExpr(operator.asString()),
                                                  value(new NameExpr(varName)))));
    }

    private Range unaryPrefixOperatorRange(UnaryExpr expr) {
        return expr.getRange().map(r -> r.withEnd(r.begin.right(1)))
                   .orElse(UNDEFINED_RANGE);
    }

    private void addUnaryPostfixOperationMethodCall(BlockStmt block, String oldValueVarName, String newValueVarName) {
        block.addStatement(makeMethodCall(unaryPostfixOperatorRange(ue), getRuntime(), UNARY_POSTFIX_OPERATION,
                                          List.of(new StringLiteralExpr(expression.toString()),
                                                  new StringLiteralExpr(operator.asString()),
                                                  value(new NameExpr(oldValueVarName)),
                                                  value(new NameExpr(newValueVarName)))));
    }

    private Range unaryPostfixOperatorRange(UnaryExpr expr) {
        return expr.getRange().map(r -> r.withBegin(left(r.end, 1)))
                   .orElse(UNDEFINED_RANGE);
    }

    private void addVarOrFieldSetMethodCall(BlockStmt block, NameExpr nameExpr, String varName) {
        ResolvedValueDeclaration rvd = nameExpr.resolve();
        if (rvd.isField()) {
            final ResolvedFieldDeclaration rfd = rvd.asField();
            final String qualifiedName = rfd.declaringType().getQualifiedName();
            final Type type = parseType(qualifiedName);
            final Expression newScope = rfd.isStatic() ? new ClassExpr(type) : new ThisExpr();
            addStaticOrNotStaticFieldSetMethodCall(rfd, block, newScope, nameExpr.getNameAsString(), varName, type);
        }
        else
            addVarSetMethodCall(block, nameExpr, varName);
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.EXPRESSION_RUNTIME;}

    private record StringPair(String oldName, String newName) {}
}
