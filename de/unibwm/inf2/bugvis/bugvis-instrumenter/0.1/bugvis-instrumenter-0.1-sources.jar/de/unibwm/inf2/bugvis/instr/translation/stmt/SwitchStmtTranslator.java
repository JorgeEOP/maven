package de.unibwm.inf2.bugvis.instr.translation.stmt;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.stmt.SwitchEntry;
import com.github.javaparser.ast.stmt.SwitchStmt;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.DEBUG;

public class SwitchStmtTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(SwitchStmtTranslator.class.getName());

    private final TranslationVisitor tv;
    private final SwitchStmt switchStmt;

    public SwitchStmtTranslator(TranslationVisitor translationVisitor, SwitchStmt switchStmt) {
        LOGGER.log(DEBUG, () -> "creating SwitchStmtTranslator (" + switchStmt + ")");
        this.tv = translationVisitor;
        this.switchStmt = switchStmt;
    }

    @Override
    public Node translate() {
        Expression selector = tv.translateNode(switchStmt.getSelector());
        NodeList<SwitchEntry> entries = tv.translateList(switchStmt.getEntries());
        SwitchStmt r = new SwitchStmt(switchStmt.getTokenRange().orElse(null), selector, entries);
        copyCommentsAndData(switchStmt, r);
        return r;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.STATEMENT_RUNTIME;}
}
