package de.unibwm.inf2.bugvis.instr.translation.expr;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.ClassExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.LambdaExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.ReturnStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.stmt.TryStmt;
import com.github.javaparser.ast.type.Type;
import com.github.javaparser.resolution.MethodUsage;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedTypeParameterDeclaration;
import com.github.javaparser.resolution.types.ResolvedReferenceType;
import com.github.javaparser.resolution.types.ResolvedType;
import com.github.javaparser.resolution.types.parametrization.ResolvedTypeParametersMap;
import de.unibwm.inf2.bugvis.instr.translation.NameType;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;
import de.unibwm.inf2.bugvis.instr.translation.body.MethodLikeTranslator;

import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class LambdaExprTranslator implements MethodLikeTranslator {
    private static final Logger LOGGER = System.getLogger(LambdaExprTranslator.class.getName());

    private static final ResolvedReferenceType RESOLVED_OBJECT_TYPE = getObjectType();

    private final TranslationVisitor tv;
    private final LambdaExpr le;
    private final MethodUsage methodUsage;
    private final ResolvedType interfaceType;

    public LambdaExprTranslator(TranslationVisitor translationVisitor, LambdaExpr lambdaExpr, Object arg) {
        LOGGER.log(Level.INFO, "Creating LambdaExprTranslator (" + lambdaExpr + ")");
        this.tv = translationVisitor;
        this.le = lambdaExpr;
        this.interfaceType = resolveType(lambdaExpr);
        this.methodUsage = getMethodUsage(interfaceType.asReferenceType());
    }

    private ResolvedType resolveType(LambdaExpr lambdaExpr) {
        final Optional<Node> optParentNode = lambdaExpr.getParentNode();
        if (optParentNode.isPresent()) {
            final Node parentNode = optParentNode.get();
            if (parentNode instanceof AssignExpr assignExpr)
                return assignExpr.getTarget().calculateResolvedType();
            else if (parentNode instanceof MethodCallExpr methodCallExpr) {
                final int argumentPosition = methodCallExpr.getArgumentPosition(lambdaExpr);
                return methodCallExpr.resolve().getParam(argumentPosition).getType();
            }
            else if (parentNode instanceof ReturnStmt returnStmt) {
                // TODO: lambda in lambda?
                final Optional<?> ancestor = returnStmt.findAncestor(new Class[]{MethodDeclaration.class, LambdaExpr.class});
                if (ancestor.isEmpty())
                    throw new IllegalStateException("ReturnStmt without method declaration or lambda expression.");
                if (ancestor.get() instanceof MethodDeclaration methodDeclaration)
                    return methodDeclaration.getType().resolve();
                if (ancestor.get() instanceof LambdaExpr)
                    // TODO: realize
                    throw new UnsupportedOperationException("Lambda expression in Lambda expression is due to implementation");
            }
            else if (parentNode instanceof ExpressionStmt)
                // TODO: ask JavaParser Team if realization is possible
                throw new UnsupportedOperationException("Lambda expressions in switch expressions are not supported.");
            else if (parentNode instanceof VariableDeclarator variableDeclarator)
                return variableDeclarator.getType().resolve();
            throw new IllegalStateException("unknown place for lambda expression: '" + lambdaExpr + "' in '" + parentNode + "'.");
        }
        throw new IllegalStateException("unknown place for lambda expression: '" + lambdaExpr + "'.");
    }

    private MethodUsage getMethodUsage(ResolvedReferenceType resolvedType) {
        final Map<String, MethodUsage> abstractMethods = isolateAbstractMethods(resolvedType);
        removeObjectMethods(abstractMethods);
        if (abstractMethods.size() == 1)
            return addTypeParameter(getFirstMethodUsage(abstractMethods), resolvedType);
        throw new IllegalStateException(
                String.format("count of abstract methods of functional interface '%s' is not equal 1.",
                              resolvedType.getQualifiedName()));
    }

    private Map<String, MethodUsage> isolateAbstractMethods(ResolvedReferenceType resolvedType) {
        final List<ResolvedReferenceType> allAncestors = resolvedType.getAllAncestors();
        allAncestors.add(resolvedType);
        Map<String, MethodUsage> implementedMethods = new HashMap<>();
        Map<String, MethodUsage> abstractMethods = new HashMap<>();
        for (ResolvedReferenceType ancestor : allAncestors)
            for (MethodUsage usage : ancestor.getDeclaredMethods()) {
                final ResolvedMethodDeclaration declaration = usage.getDeclaration();
                if (declaration.isAbstract())
                    abstractMethods.put(usage.getSignature(), usage);
                else if (!declaration.isStatic())
                    implementedMethods.put(usage.getSignature(), usage);
            }
        implementedMethods.keySet().forEach(abstractMethods::remove);
        return abstractMethods;
    }

    private void removeObjectMethods(Map<String, MethodUsage> abstractMethods) {
        RESOLVED_OBJECT_TYPE.getDeclaredMethods().stream()
                            .map(MethodUsage::getSignature)
                            .forEach(abstractMethods::remove);
    }

    private MethodUsage addTypeParameter(MethodUsage methodUsage, ResolvedReferenceType resolvedType) {
        final ResolvedTypeParametersMap typeParametersMap = resolvedType.typeParametersMap();
        for (ResolvedTypeParameterDeclaration rtpd : resolvedType.getTypeDeclaration().get().getTypeParameters())
            methodUsage = methodUsage.replaceTypeParameter(rtpd, typeParametersMap.getValue(rtpd));
        return methodUsage;
    }

    private MethodUsage getFirstMethodUsage(Map<String, MethodUsage> abstractMethods) {
        return abstractMethods.get(abstractMethods.keySet().stream().findFirst().get());
    }

    @Override
    public Node translate() {
        Statement body = translateBody();
        NodeList<Parameter> parameters = tv.translateList(le.getParameters());
        LambdaExpr r = new LambdaExpr(le.getTokenRange().orElse(null),
                                      parameters,
                                      body,
                                      le.isEnclosingParameters());
        copyCommentsAndData(le, r);
        return r;
    }

    private Statement translateBody() {
        BlockStmt outerBlock = new BlockStmt();
        tv.getBlockStack().push(outerBlock);
        addEnteredInstr(outerBlock, methodUsage);

        BlockStmt tryBlock = new BlockStmt();
        if (le.getBody().isBlockStmt())
            translateBlockStmt(le.getBody().asBlockStmt(), tryBlock);
        else {
            tv.getBlockStack().push(tryBlock);
            final Type returnType = parseType(methodUsage.returnType().describe());
            Statement stmt = tv.translateNode(le.getBody(), returnType);
            if (!methodUsage.returnType().isVoid() && stmt instanceof ExpressionStmt expressionStmt)
                tryBlock.addStatement(new ReturnStmt(expressionStmt.getExpression()));
            tv.getBlockStack().pop();
        }

        final BlockStmt finallyBlock = createFinallyBlock(methodUsage);
        final TryStmt tryStmt = new TryStmt(tryBlock, new NodeList<>(), finallyBlock);
        tv.getBlockStack().pop();
        outerBlock.addStatement(tryStmt);
        return outerBlock;
    }

    private void addEnteredInstr(BlockStmt blockStmt, MethodUsage methodUsage) {
        final List<Expression> params = new ArrayList<>();
        params.add(new ClassExpr(parseType(interfaceType.erasure().describe())));
        params.add(new StringLiteralExpr(methodUsage.getSignature()));
        final List<NameType> nts = getNameTypes(methodUsage);
        if (!nts.isEmpty()) params.add(params(nts, false));
        blockStmt.addStatement(makeMethodCall(le, getRuntime(), LAMBDA_ENTERED, params));
    }

    private List<NameType> getNameTypes(MethodUsage methodUsage) {
        final ResolvedMethodDeclaration declaration = methodUsage.getDeclaration();
        final List<NameType> nts = new ArrayList<>();
        for (int i = 0; i < declaration.getNumberOfParams(); ++i)
            nts.add(new NameType(le.getParameter(i).getNameAsString(), methodUsage.getParamType(i).describe()));
        return nts;
    }

    private BlockStmt createFinallyBlock(MethodUsage methodUsage) {
        final List<Expression> params = new ArrayList<>();
        params.add(new ClassExpr(parseType(interfaceType.erasure().describe())));
        params.add(new StringLiteralExpr(methodUsage.getSignature()));
        final BlockStmt finallyBlock = new BlockStmt();
        finallyBlock.addStatement(makeMethodCall(blockEndRange(le), getRuntime(), LEAVING_LAMBDA, params));
        return finallyBlock;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.EXPRESSION_RUNTIME;}

    private static ResolvedReferenceType getObjectType() {
        String objectClass = """
                class Test {
                    Object foo() {}
                }
                """;
        final CompilationUnit parse = StaticJavaParser.parse(objectClass);
        return parse.getTypes().get(0).getMembers().get(0).asMethodDeclaration().getType().resolve().asReferenceType();
    }
}
