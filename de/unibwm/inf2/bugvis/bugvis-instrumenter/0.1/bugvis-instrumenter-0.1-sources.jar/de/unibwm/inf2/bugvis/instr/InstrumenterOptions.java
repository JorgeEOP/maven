package de.unibwm.inf2.bugvis.instr;

import java.io.File;
import java.util.Set;

public interface InstrumenterOptions {

    boolean getOverwrite();

    boolean getCopyFailedFiles();

    Set<File> getFilesToCopy();

    Set<File> getFilesToInstrument();

    File getTargetDir();

    File getMetaInfoFile();

    boolean isReflectionTypeSolver();

    Set<File> getJarTypeSolverFiles();

    Set<File> getPathTypeSolverFiles();

    boolean isPreserveComments();
}
