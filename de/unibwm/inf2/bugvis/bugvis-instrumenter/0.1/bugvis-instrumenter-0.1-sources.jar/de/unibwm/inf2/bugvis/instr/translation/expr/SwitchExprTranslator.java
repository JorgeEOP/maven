package de.unibwm.inf2.bugvis.instr.translation.expr;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.SwitchExpr;
import com.github.javaparser.ast.stmt.SwitchEntry;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.DEBUG;

public class SwitchExprTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(SwitchExprTranslator.class.getName());

    private final TranslationVisitor tv;
    private final SwitchExpr se;

    public SwitchExprTranslator(TranslationVisitor translationVisitor, SwitchExpr switchExpr) {
        LOGGER.log(DEBUG, () -> "creating SwitchExprTranslator (" + switchExpr + ")");
        this.tv = translationVisitor;
        this.se = switchExpr;
    }

    @Override
    public Node translate() {
        Expression selector = tv.translateNode(se.getSelector());
        NodeList<SwitchEntry> entries = tv.translateList(se.getEntries());
        SwitchExpr r = new SwitchExpr(se.getTokenRange().orElse(null), selector, entries);
        copyCommentsAndData(se, r);
        return r;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.EXPRESSION_RUNTIME;}
}
