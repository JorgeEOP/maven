package de.unibwm.inf2.bugvis.instr.translation.expr;

import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.type.Type;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.List;

import static java.lang.System.Logger.Level.DEBUG;

public class VariableDeclarationExprTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(VariableDeclarationExprTranslator.class.getName());

    private final TranslationVisitor tv;
    private final VariableDeclarationExpr vde;

    public VariableDeclarationExprTranslator(TranslationVisitor translationVisitor, VariableDeclarationExpr variableDeclarationExpr) {
        LOGGER.log(DEBUG, () -> "Creating VariableDeclarationExprTranslator (" + variableDeclarationExpr + ")");
        this.tv = translationVisitor;
        this.vde = variableDeclarationExpr;
    }

    @Override
    public Node translate() {
        BlockStmt blockStmt = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));

        for (VariableDeclarator vd : vde.getVariables()) {
            // TODO: evaluate correct type. See MethodCallExprTranslator
            Type type = applyFacades(tv.translateNode(vd.getType()));
            Expression initializer = tv.translateNode(vd.getInitializer(), type.clone());
            String tmpVarName = "";
            if (initializer != null) tmpVarName = storeResult(blockStmt, initializer, type.clone());

            String varName = vd.getNameAsString();
            blockStmt.addStatement(makeMethodCall(getNameRange(vd), getRuntime(), VARIABLE_DECLARATION,
                                                  List.of(new StringLiteralExpr(vd.getTypeAsString()),
                                                          new StringLiteralExpr(varName))));

            NodeList<AnnotationExpr> annotations = tv.translateList(vde.getAnnotations());
            NodeList<Modifier> modifiers = tv.translateList(vde.getModifiers());
            NodeList<VariableDeclarator> vds = new NodeList<>();
            vds.add(new VariableDeclarator(type, varName, initializer == null ? null : new NameExpr(tmpVarName)));
            ExpressionStmt stmt = new ExpressionStmt(new VariableDeclarationExpr(modifiers, annotations, vds));
            copyCommentsAndData(vde, stmt);
            blockStmt.addStatement(stmt);

            if (initializer != null)
                blockStmt.addStatement(makeMethodCall(getAssignmentRange(vd), getRuntime(), VARIABLE_ASSIGNMENT,
                                                      List.of(new StringLiteralExpr(varName),
                                                              value(new NameExpr(tmpVarName)))));
        }
        return null;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.EXPRESSION_RUNTIME;}
}
