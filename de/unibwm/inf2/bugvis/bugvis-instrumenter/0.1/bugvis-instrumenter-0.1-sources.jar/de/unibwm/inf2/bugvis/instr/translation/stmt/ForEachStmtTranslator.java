package de.unibwm.inf2.bugvis.instr.translation.stmt;

import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.AssignExpr.Operator;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.ForEachStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.type.VarType;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.List;

import static java.lang.System.Logger.Level.DEBUG;

public class ForEachStmtTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(ForEachStmtTranslator.class.getName());

    private final TranslationVisitor tv;
    private final ForEachStmt fes;

    public ForEachStmtTranslator(TranslationVisitor translationVisitor, ForEachStmt forEachStmt) {
        LOGGER.log(DEBUG, () -> "Creating ForEachStmtTranslator (" + forEachStmt + ")");
        this.tv = translationVisitor;
        this.fes = forEachStmt;
    }

    @Override
    public Node translate() {
        BlockStmt additionalBlock = new BlockStmt();
        tv.getBlockStack().push(additionalBlock);

        // 1. Variable deklarieren
        final VariableDeclarationExpr variable = fes.getVariable();
        if (variable != null) variable.getModifiers().remove(Modifier.finalModifier());
        tv.translateNode(variable);

        // 2. Iterable instrumentieren
        String iterableName = storeResult(additionalBlock, tv.translateNode(fes.getIterable()));

        String tmpVarName = newVarName();
        VariableDeclarator variableDeclarator = new VariableDeclarator(new VarType(), tmpVarName);
        VariableDeclarationExpr variableDeclarationExpr = new VariableDeclarationExpr(variableDeclarator, Modifier.finalModifier());

        // 3. Aktuellen Wert zuweisen
        BlockStmt body = new BlockStmt();
        String variableName = fes.getVariableDeclarator().getNameAsString();
        body.addStatement(new ExpressionStmt(new AssignExpr(new NameExpr(variableName), new NameExpr(tmpVarName), Operator.ASSIGN)));
        body.addStatement(makeMethodCall(fes.getVariableDeclarator(), Runtime.EXPRESSION_RUNTIME, VARIABLE_ASSIGNMENT,
                                         List.of(new StringLiteralExpr(variableName), value(new NameExpr(tmpVarName)))));

        // 4. Body vom ForEachStmt instrumentieren
        if (fes.getBody().isBlockStmt()) {
            BlockStmt oldBlock = fes.getBody().asBlockStmt();
            translateBlockStmt(oldBlock, body);
        }
        else {
            tv.getBlockStack().push(body);
            Statement statement = tv.translateNode(fes.getBody());
            if (statement != null) body.addStatement(statement);
            tv.getBlockStack().pop();
        }

        // 5. Neues ForEachStmt bauen
        ForEachStmt newForEachStmt = new ForEachStmt(variableDeclarationExpr, new NameExpr(iterableName), body);
        copyCommentsAndData(fes, newForEachStmt);
        additionalBlock.addStatement(newForEachStmt);

        tv.getBlockStack().pop();
        return additionalBlock;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.STATEMENT_RUNTIME;}
}
