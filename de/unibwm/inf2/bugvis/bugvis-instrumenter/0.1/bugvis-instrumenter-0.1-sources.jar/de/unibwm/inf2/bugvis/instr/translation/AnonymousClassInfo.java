package de.unibwm.inf2.bugvis.instr.translation;

import java.util.List;

public class AnonymousClassInfo {
    private final String parentClassName;
    private final List<Integer> ids;

    private int childCount;

    public AnonymousClassInfo(String parentClassName, List<Integer> ids) {
        this.parentClassName = parentClassName;
        this.ids = ids;
    }

    public AnonymousClassInfo(String parentClassName, int id) {
        this(parentClassName, List.of(id));
    }

    public String getParentClassName() {return parentClassName;}

    public List<Integer> getIds() {return ids;}

    public int getChildCount() {return childCount;}

    public String getName() {
        return parentClassName + "$" + String.join("$", ids.stream().map(i -> Integer.toString(i)).toList());
    }

    public void increaseChildCount() {++childCount;}
}
