package de.unibwm.inf2.bugvis.instr.translation.expr;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.expr.CastExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.type.Type;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.DEBUG;

public class CastExprTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(CastExprTranslator.class.getName());
    private final TranslationVisitor tv;
    private final CastExpr ce;

    public CastExprTranslator(TranslationVisitor translationVisitor, CastExpr castExpr) {
        LOGGER.log(DEBUG, () -> "creating CastExprTranslator (" + castExpr + ")");
        this.tv = translationVisitor;
        this.ce = castExpr;
    }

    public Node translate() {
        Expression expression = tv.translateNode(ce.getExpression());
        final BlockStmt blockStmt = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));
        String name = storeResult(blockStmt, expression);
        Type type = tv.translateNode(ce.getType());
        CastExpr r = new CastExpr(ce.getTokenRange().orElse(null), type, new NameExpr(name));
        copyCommentsAndData(ce, r);
        return r;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.EXPRESSION_RUNTIME;}
}
