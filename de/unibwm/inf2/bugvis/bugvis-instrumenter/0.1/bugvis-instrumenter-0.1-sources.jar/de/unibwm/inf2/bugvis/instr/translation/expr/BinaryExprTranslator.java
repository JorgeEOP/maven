package de.unibwm.inf2.bugvis.instr.translation.expr;

import com.github.javaparser.Range;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.BinaryExpr;
import com.github.javaparser.ast.expr.BinaryExpr.Operator;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.UnaryExpr;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.type.VarType;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.List;

import static java.lang.System.Logger.Level.DEBUG;

public class BinaryExprTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(BinaryExprTranslator.class.getName());

    private final Operator operator;
    private final TranslationVisitor tv;
    private final BinaryExpr be;
    private final Expression oldLeft;
    private final Expression oldRight;

    public BinaryExprTranslator(TranslationVisitor translationVisitor, BinaryExpr binaryExpr) {
        LOGGER.log(DEBUG, () -> "creating BinaryExprTranslator (" + binaryExpr + ")");
        this.tv = translationVisitor;
        this.be = binaryExpr;
        this.oldLeft = binaryExpr.getLeft();
        this.oldRight = binaryExpr.getRight();
        this.operator = binaryExpr.getOperator();
    }

    @Override
    public Expression translate() {
        BlockStmt block = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));

        Expression newLeft = tv.translateNode(oldLeft);
        String varLeftName = storeResult(block, newLeft);
        Expression r;
        if (operator == Operator.AND || operator == Operator.OR)
            r = handleShortcutOperators(block, varLeftName, newLeft);
        else
            r = handleNonShortcutOperators(block, varLeftName);

        copyCommentsAndData(be, r);
        String varResultName = storeResult(block, r);
        block.addStatement(makeMethodCall(
                binaryExprRange(be), getRuntime(), BINARY_OPERATION,
                List.of(new StringLiteralExpr(replaceQuotationMarks(oldLeft)),
                        new StringLiteralExpr(operator.asString()),
                        new StringLiteralExpr(replaceQuotationMarks(oldRight)),
                        value(new NameExpr(varResultName)))));

        return new NameExpr(varResultName);
    }

    private Range binaryExprRange(BinaryExpr binaryExpr) {
        return getRangeBetween(binaryExpr.getLeft(), binaryExpr.getRight());
    }

    private Expression handleNonShortcutOperators(BlockStmt block, String varLeftName) {
        String varRightName = storeResult(block, tv.translateNode(oldRight));
        return new BinaryExpr(be.getTokenRange().orElse(null),
                              new NameExpr(varLeftName), new NameExpr(varRightName), operator);
    }

    private Expression handleShortcutOperators(BlockStmt block, String varLeftName, Expression newLeft) {
        String tmpVarName = newVarName();
        VariableDeclarator varDec = new VariableDeclarator(new VarType(), tmpVarName, new NameExpr(varLeftName));
        block.addStatement(new VariableDeclarationExpr(varDec));

        BlockStmt body = new BlockStmt();
        tv.getBlockStack().push(body);
        String varRightName = storeResult(body, tv.translateNode(oldRight));
        body.addStatement(new AssignExpr(new NameExpr(tmpVarName),
                                         new NameExpr(varRightName),
                                         AssignExpr.Operator.ASSIGN));
        tv.getBlockStack().pop();

        block.addStatement(new IfStmt(createConditionDependingOnOperator(newLeft), body, null));

        return new NameExpr(tmpVarName);
    }

    private Expression createConditionDependingOnOperator(Expression newLeft) {
        Expression condition = newLeft.clone();
        if (operator == Operator.OR) condition = new UnaryExpr(condition, UnaryExpr.Operator.LOGICAL_COMPLEMENT);
        return condition;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {
        return tv;
    }

    @Override
    public Runtime getRuntime() {return Runtime.EXPRESSION_RUNTIME;}
}
