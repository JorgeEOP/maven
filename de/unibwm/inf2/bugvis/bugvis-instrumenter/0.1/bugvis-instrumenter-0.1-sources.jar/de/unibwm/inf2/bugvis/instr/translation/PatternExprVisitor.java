package de.unibwm.inf2.bugvis.instr.translation;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.BinaryExpr;
import com.github.javaparser.ast.expr.CastExpr;
import com.github.javaparser.ast.expr.EnclosedExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.InstanceOfExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.NullLiteralExpr;
import com.github.javaparser.ast.expr.PatternExpr;
import com.github.javaparser.ast.expr.RecordPatternExpr;
import com.github.javaparser.ast.expr.TypePatternExpr;
import com.github.javaparser.ast.expr.UnaryExpr;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.type.ReferenceType;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import com.github.javaparser.resolution.declarations.ResolvedFieldDeclaration;
import com.github.javaparser.resolution.types.ResolvedType;
import de.unibwm.inf2.bugvis.instr.translation.expr.InstanceOfExprTranslator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public class PatternExprVisitor extends VoidVisitorAdapter<Void> {

    enum OperandSide {LEFT_OPERAND, RIGHT_OPERAND}

    enum BooleanNot {
        NO_NOT, NOT;

        public BooleanNot inverse() {
            return switch (this) {
                case NO_NOT -> NOT;
                case NOT -> NO_NOT;
            };
        }
    }

    private final BlockStmt outerBlock;
    private final TranslationVisitor translationVisitor;
    private final List<Expression> thenStmtList = new ArrayList<>();
    private final List<Expression> elseStmtList = new ArrayList<>();

    private OperandSide operandSide = OperandSide.LEFT_OPERAND;
    private BooleanNot booleanNot = BooleanNot.NO_NOT;

    public PatternExprVisitor(BlockStmt outerBlock, TranslationVisitor translationVisitor) {
        this.outerBlock = outerBlock;
        this.translationVisitor = translationVisitor;
    }

    @Override
    public void visit(InstanceOfExpr n, Void arg) {
        final Optional<PatternExpr> optionalPatternExpr = n.getPattern();
        if (optionalPatternExpr.isPresent()) {
            final String variableName = preparePatternExpr(n);
            final PatternExpr patternExpr = optionalPatternExpr.get();
            if (patternExpr.isTypePatternExpr())
                handleTypePatternExpr(patternExpr, variableName);
            else if (patternExpr.isRecordPatternExpr())
                handleRecordPatternExpr(patternExpr, variableName);
        }
    }

    private String preparePatternExpr(InstanceOfExpr n) {
        final String variableName = translationVisitor.newVarName();
        n.setData(InstanceOfExprTranslator.VAR_NAME, variableName);
        outerBlock.addStatement(new VariableDeclarationExpr(new VariableDeclarator(
                StaticJavaParser.parseType("Object"), variableName, new NullLiteralExpr())));
        return variableName;
    }

    private void handleTypePatternExpr(PatternExpr patternExpr, String variableName) {
        final TypePatternExpr typePatternExpr = patternExpr.asTypePatternExpr();
        final Expression expr = createTypePatternExpr(typePatternExpr, variableName);
        addExprToList(expr);
    }

    private void handleRecordPatternExpr(PatternExpr patternExpr, String variableName) {
        final RecordPatternExpr recordPatternExpr = patternExpr.asRecordPatternExpr();
        final ReferenceType type = recordPatternExpr.getType();
        final ResolvedType resolvedType = type.resolve();
        final Set<ResolvedFieldDeclaration> declaredFields = resolvedType.asReferenceType().getDeclaredFields();
        final List<String> attributeNames = declaredFields.stream().filter(f -> !f.isStatic()).map(ResolvedFieldDeclaration::getName).toList();
        final Iterator<String> nameIt = attributeNames.iterator();
        for (PatternExpr pExpr : recordPatternExpr.getPatternList()) {
            final TypePatternExpr typePatternExpr = pExpr.asTypePatternExpr();
            final Expression expr = createRecordPatternExpr(typePatternExpr, variableName, type, nameIt.next());
            addExprToList(expr);
        }
    }

    private void addExprToList(Expression expr) {
        if (booleanNot == BooleanNot.NO_NOT) thenStmtList.add(expr);
        else elseStmtList.add(expr);
    }

    private static Expression createTypePatternExpr(TypePatternExpr typePatternExpr, String variableName) {
        return new VariableDeclarationExpr(new VariableDeclarator(
                typePatternExpr.getType().clone(), typePatternExpr.getName().clone(),
                new CastExpr(typePatternExpr.getType().clone(), new NameExpr(variableName))));
    }

    private static Expression createRecordPatternExpr(TypePatternExpr typePatternExpr, String variableName,
                                                      ReferenceType type, String name) {
        return new VariableDeclarationExpr(new VariableDeclarator(
                typePatternExpr.getType().clone(), typePatternExpr.getName().clone(),
                new MethodCallExpr(new EnclosedExpr(new CastExpr(type.clone(), new NameExpr(variableName))), name)));
    }

    @Override
    public void visit(BinaryExpr n, Void arg) {
        n.getLeft().accept(this, arg);

        final OperandSide tmpOperandSide = operandSide;
        if (n.getOperator().equals(BinaryExpr.Operator.AND) || n.getOperator().equals(BinaryExpr.Operator.OR))
            operandSide = OperandSide.RIGHT_OPERAND;
        n.getRight().accept(this, arg);
        operandSide = tmpOperandSide;
    }

    @Override
    public void visit(UnaryExpr n, Void arg) {
        BooleanNot tmpBooleanNot = booleanNot;
        booleanNot = booleanNot.inverse();
        n.getExpression().accept(this, arg);
        booleanNot = tmpBooleanNot;
    }

    public List<Expression> getThenStmtList() {return thenStmtList;}

    public List<Expression> getElseStmtList() {return elseStmtList;}
}