package de.unibwm.inf2.bugvis.instr.translation.body;

import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.EnumDeclaration;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.resolution.declarations.ResolvedEnumDeclaration;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.DEBUG;

public class EnumDeclarationTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(EnumDeclarationTranslator.class.getName());
    private final TranslationVisitor tv;
    private final EnumDeclaration ed;

    public EnumDeclarationTranslator(TranslationVisitor translationVisitor, EnumDeclaration enumDeclaration) {
        LOGGER.log(DEBUG, () -> "creating EnumDeclarationTranslator (" + enumDeclaration + ")");
        this.tv = translationVisitor;
        this.ed = enumDeclaration;
        ResolvedEnumDeclaration red = enumDeclaration.resolve();
        translationVisitor.addInstrType(red.getQualifiedName());
    }

    @Override
    public Node translate() {
        NodeList<ClassOrInterfaceType> implementedTypes = tv.translateList(ed.getImplementedTypes());
        NodeList<Modifier> modifiers = tv.translateList(ed.getModifiers());
        SimpleName name = tv.translateNode(ed.getName());
        NodeList<AnnotationExpr> annotations = tv.translateList(ed.getAnnotations());
        EnumDeclaration r = new EnumDeclaration(ed.getTokenRange().orElse(null), modifiers,
                                                annotations, name, implementedTypes, new NodeList<>(), new NodeList<>());
        translateMembers(ed, r);
        tv.getTypeStack().push(r);
        r.setEntries(tv.translateList(ed.getEntries()));
        tv.getTypeStack().pop();
        copyCommentsAndData(ed, r);
        return r;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.DECLARATION_RUNTIME;}
}
