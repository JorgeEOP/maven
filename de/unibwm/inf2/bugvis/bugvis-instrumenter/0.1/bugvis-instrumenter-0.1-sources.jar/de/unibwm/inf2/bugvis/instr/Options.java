package de.unibwm.inf2.bugvis.instr;

import org.kohsuke.args4j.Argument;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;
import org.kohsuke.args4j.ParserProperties;
import org.kohsuke.args4j.spi.ExplicitBooleanOptionHandler;
import org.kohsuke.args4j.spi.MultiFileOptionHandler;

import java.io.File;
import java.io.IOException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Options implements InstrumenterOptions {
    private static final Logger LOGGER = System.getLogger(Options.class.getName());

    private static final String JAVA = ".java";
    private static final String JAR = ".jar";
    private static final String INSTR_TARGET_DIR = "instr-target";
    private static final String META_INFO_JSON = "MetaInfo.json";

    private static final String SRC_FILE = "src file";
    private static final String JAR_FILE = "jar file";
    private static final String TARGET_DIR = "target dir";
    private static final String PATH = "path";
    private static final String META_INFO_PATH = "meta-info path";

    // HELP
    private static final String H_OPT = "-h";
    private static final String LONG_H_OPT = "--help";

    // PATHS
    private static final String O_OPT = "-o";
    private static final String LONG_O_OPT = "--overwrite";
    private static final String S_OPT = "-s";
    private static final String LONG_S_OPT = "--source";
    private static final String C_OPT = "-c";
    private static final String LONG_C_OPT = "--copy";
    private static final String CF_OPT = "-cf";
    private static final String LONG_CF_OPT = "--copy-failed-files";
    private static final String R_OPT = "-r";
    private static final String LONG_R_OPT = "--recursive";
    private static final String T_OPT = "-t";
    private static final String LONG_T_OPT = "--target";
    private static final String X_OPT = "-x";
    private static final String LONG_X_OPT = "--exclude";
    private static final String M_OPT = "-m";
    private static final String LONG_M_OPT = "--meta-info";

    // TYPE SOLVER
    private static final String RTS_OPT = "-rts";
    private static final String LONG_RTS_OPT = "--reflection-type-solver";
    private static final String JTS_OPT = "-jts";
    private static final String LONG_JTS_OPT = "--jar-type-solver";
    private static final String PTS_OPT = "-pts";
    private static final String LONG_PTS_OPT = "--path-type-solver";

    private static final String PC_OPT = "-pc";
    private static final String LONG_PC_OPT = "--preserve-comments";

    @Option(name = H_OPT,
            aliases = {LONG_H_OPT},
            help = true,
            usage = "prints this help text to the console.")
    private boolean helpOption;

    @Option(name = S_OPT,
            aliases = {LONG_S_OPT},
            metaVar = "<file(s) and directories to instrument>",
            usage = "source file(s) and/or directories containing the original, uninstrumented source code, which is to be instrumented.",
            handler = MultiFileOptionHandler.class)
    @Argument(metaVar = "<source file(s) and directories>",
            usage = "source file(s) and/or directories containing the original, uninstrumented source code, which is to be instrumented.",
            handler = MultiFileOptionHandler.class)
    private List<File> cliFilesToInstrument = new ArrayList<>();
    private Set<File> filesToInstrument;

    @Option(name = C_OPT,
            aliases = {LONG_C_OPT},
            metaVar = "<source file(s) and directories>",
            usage = "source file(s) and/or directories containing original, uninstrumented source code, which is to be copied, not instrumented.",
            handler = MultiFileOptionHandler.class)
    private List<File> cliFilesToCopy = new ArrayList<>();
    private Set<File> filesToCopy;

    @Option(name = CF_OPT,
            aliases = {LONG_CF_OPT},
            metaVar = "<boolean>",
            usage = "copy files, when instrumentation fails",
            handler = ExplicitBooleanOptionHandler.class)
    private boolean copyFailedFiles = false;

    @Option(name = O_OPT,
            aliases = {LONG_O_OPT},
            metaVar = "<boolean>",
            usage = "overwrite existing files",
            handler = ExplicitBooleanOptionHandler.class)
    private boolean overwrite = false;

    @Option(name = R_OPT,
            aliases = {LONG_R_OPT},
            metaVar = "<boolean>",
            usage = "recursive folder traversal.",
            handler = ExplicitBooleanOptionHandler.class)
    private boolean recursive = false;

    @Option(name = T_OPT,
            aliases = {LONG_T_OPT},
            metaVar = "<root directory>",
            usage = "root directory for the instrumented source code.")
    private File targetDir = new File(INSTR_TARGET_DIR);

    @Option(name = X_OPT,
            aliases = {LONG_X_OPT},
            metaVar = "<excluded files>",
            usage = "exclusions of the original source code.",
            handler = MultiFileOptionHandler.class)
    private List<File> cliFilesToExclude = new ArrayList<>();
    private Set<File> filesToExclude;

    @Option(name = M_OPT,
            aliases = {LONG_M_OPT},
            metaVar = "<json file>",
            usage = "file containing meta info.")
    private File metaInfoFile;

    @Option(name = RTS_OPT,
            aliases = {LONG_RTS_OPT},
            metaVar = "<boolean>",
            usage = "reflection type solver.")
    private boolean reflectionTypeSolver = false;

    @Option(name = JTS_OPT,
            aliases = {LONG_JTS_OPT},
            metaVar = "<" + JAR_FILE + "(s)>",
            usage = "jar type solver.",
            handler = MultiFileOptionHandler.class)
    private List<File> cliJarTypeSolverFiles = new ArrayList<>();
    private Set<File> jarTypeSolverFiles;

    @Option(name = PTS_OPT,
            aliases = {LONG_PTS_OPT},
            metaVar = "<root source directories>",
            usage = "path type solver.",
            handler = MultiFileOptionHandler.class)
    private List<File> cliPathTypeSolverFiles = new ArrayList<>();
    private Set<File> pathTypeSolverFiles;

    @Option(name = PC_OPT,
            aliases = {LONG_PC_OPT},
            metaVar = "<boolean>",
            usage = "preserve comments, default: true, all comments are removed",
            handler = ExplicitBooleanOptionHandler.class)
    private boolean preserveComments = false;

    public Options(String[] args) {
        ParserProperties props = ParserProperties.defaults()
                                                 .withShowDefaults(false)
                                                 .withUsageWidth(80);
        CmdLineParser parser = new CmdLineParser(this, props);

        try {
            parser.parseArgument(args);

            filesToExclude = makeCanonicalFileSet(cliFilesToExclude);
            filesToInstrument = makeCanonicalFileSet(cliFilesToInstrument);
            filesToInstrument = expandAndCheckSrcFiles(filesToInstrument, recursive, filesToExclude);
            filesToCopy = makeCanonicalFileSet(cliFilesToCopy);
            filesToCopy = expandAndCheckSrcFiles(filesToCopy, recursive, filesToExclude);

            boolean errors = cliFilesToInstrument.isEmpty() ||
                             !Collections.disjoint(filesToCopy, filesToInstrument);
            if (errors || getHelpOption()) {
                usage(parser);
                System.exit(1);
            }

            checkTargetPath();

            if (metaInfoFile == null)
                metaInfoFile = new File(targetDir, META_INFO_JSON);
            metaInfoFile = metaInfoFile.getCanonicalFile();
            checkMetaInfo();

            jarTypeSolverFiles = new HashSet<>(cliJarTypeSolverFiles);
            checkJarTypeSolverFiles();

            pathTypeSolverFiles = new HashSet<>(cliPathTypeSolverFiles);
            checkPathTypeSolverFiles();
        }
        catch (CmdLineException | IOException e) {
            System.out.println(e.getMessage());
            usage(parser);
            System.exit(1);
        }
    }

    private Set<File> makeCanonicalFileSet(List<File> files) throws IOException {
        Set<File> fileSet = new HashSet<>();
        for (File f : files)
            fileSet.add(f.getCanonicalFile());
        return fileSet;
    }

    private Set<File> expandAndCheckSrcFiles(Set<File> files, boolean recursive, Set<File> exclusions)
            throws IOException {
        LOGGER.log(Level.DEBUG, "recursive: {0}, files: {1}", recursive, files);
        Set<File> fileSet = new HashSet<>();
        processFiles(files, exclusions, fileSet);
        return fileSet;
    }

    private Set<File> expandDirRecursively(File dir, Set<File> exclusions) throws IOException {
        LOGGER.log(Level.DEBUG, "processing recursively: \"{0}\"", dir);
        Set<File> fileSet = new HashSet<>();
        final List<File> list = Arrays.stream(dir.listFiles()).toList();
        processFiles(list, exclusions, fileSet);
        return fileSet;
    }

    private void processFiles(Iterable<File> files, Set<File> exclusions, Set<File> fileSet) throws IOException {
        for (File f : files) {
            exists(f, SRC_FILE);
            canRead(f, SRC_FILE);
            if (f.isFile() && f.getName().endsWith(JAVA))
                processFile(exclusions, f, fileSet);
            else if (f.isDirectory())
                processDirectory(exclusions, f, fileSet);
        }
    }

    private void processFile(Set<File> exclusions, File f, Set<File> fileSet) {
        LOGGER.log(Level.DEBUG, "found java file: \"{0}\"", f);
        if (!exclusions.contains(f)) {
            LOGGER.log(Level.DEBUG, "adding java file \"{0}\" to fileSet", f);
            fileSet.add(f);
        }
        else
            LOGGER.log(Level.INFO, "java file \"{0}\" is excluded", f);
    }

    private void processDirectory(Set<File> exclusions, File f, Set<File> fileSet) throws IOException {
        LOGGER.log(Level.DEBUG, "found directory: \"{0}\"", f);
        if (!exclusions.contains(f)) {
            LOGGER.log(Level.DEBUG, "starting to search directory \"{0}\" recursively", f);
            fileSet.addAll(expandDirRecursively(f, exclusions));
        }
        else
            LOGGER.log(Level.INFO, "directory \"{0}\" is excluded", f);
    }

    private void checkMetaInfo() throws IOException {
        if (metaInfoFile.exists())
            canWrite(metaInfoFile, META_INFO_PATH);
    }

    private void checkTargetPath() throws IOException {
        if (!targetDir.exists())
            targetDir.mkdirs();
        if (!targetDir.isDirectory())
            throw new IOException(TARGET_DIR + " \"" + targetDir.getAbsolutePath() + "\" is not a directory.");
        canWrite(targetDir, TARGET_DIR);
    }

    private void checkJarTypeSolverFiles() throws IOException {
        for (File f : jarTypeSolverFiles) {
            if (!f.getName().endsWith(JAR))
                throw new IOException(JAR_FILE + " \"" + f.getAbsolutePath() + "\" doesn't end with \"" + JAR + "\".");
            exists(f, JAR_FILE);
            canRead(f, JAR_FILE);
            if (!f.isFile())
                throw new IOException(JAR_FILE + " \"" + f.getAbsolutePath() + "\" is not a file.");
        }
    }

    private void checkPathTypeSolverFiles() throws IOException {
        for (File f : pathTypeSolverFiles) {
            exists(f, PATH);
            canRead(f, PATH);
            if (!f.isDirectory())
                throw new IOException("path \"" + f.getAbsolutePath() + "\" is not a directory.");
        }
    }

    private void exists(File f, String label) throws IOException {
        if (!f.exists()) throw new IOException(label + " \"" + f.getAbsolutePath() + "\" does not exist.");
    }

    private void canRead(File f, String label) throws IOException {
        if (!f.canRead()) throw new IOException(label + " \"" + f.getAbsolutePath() + "\" is not readable.");
    }

    private void canWrite(File f, String label) throws IOException {
        if (!f.canWrite()) throw new IOException(label + " \"" + f.getAbsolutePath() + "\" is not writable.");
    }

    private void usage(CmdLineParser parser) {
        System.out.println("Arguments: [options...] <list of src files>");
        parser.printUsage(System.out);
        System.out.println();
    }

    @Override
    public boolean getOverwrite() {return overwrite;}

    @Override
    public boolean getCopyFailedFiles() {return copyFailedFiles;}

    @Override
    public Set<File> getFilesToCopy() {return Set.of();}

    @Override
    public Set<File> getFilesToInstrument() {return filesToInstrument;}

    @Override
    public File getTargetDir() {return targetDir;}

    @Override
    public File getMetaInfoFile() {return metaInfoFile;}

    @Override
    public boolean isReflectionTypeSolver() {return reflectionTypeSolver;}

    @Override
    public Set<File> getJarTypeSolverFiles() {return jarTypeSolverFiles;}

    @Override
    public Set<File> getPathTypeSolverFiles() {return pathTypeSolverFiles;}

    @Override
    public boolean isPreserveComments() {return preserveComments;}

    private boolean getHelpOption() {return helpOption;}
}
