package de.unibwm.inf2.bugvis.instr.translation.body;

import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.EnumConstantDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ReturnStmt;
import com.github.javaparser.ast.type.Type;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.List;

import static java.lang.System.Logger.Level.DEBUG;

public class EnumConstantDeclarationTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(EnumConstantDeclarationTranslator.class.getName());

    private final TranslationVisitor tv;
    private final EnumConstantDeclaration ecd;

    public EnumConstantDeclarationTranslator(TranslationVisitor translationVisitor,
                                             EnumConstantDeclaration enumConstantDeclaration) {
        LOGGER.log(DEBUG, () -> "creating ConstructorDeclarationTranslator (" + enumConstantDeclaration + ")");
        this.tv = translationVisitor;
        this.ecd = enumConstantDeclaration;
    }

    @Override
    public Node translate() {
        int idx = 1;
        List<Expression> methodCalls = new ArrayList<>();
        for (Expression arg : ecd.getArguments()) {
            String methodName = ecd.getNameAsString() + idx;
            Type type = parseType(arg.calculateResolvedType().describe());
            MethodDeclaration methodDeclaration = new MethodDeclaration(new NodeList<>(Modifier.staticModifier(),
                                                                                       Modifier.privateModifier()),
                                                                        type, methodName);
            BlockStmt body = new BlockStmt();
            tv.getBlockStack().push(body);
            body.addStatement(new ReturnStmt(tv.translateNode(arg)));
            tv.getBlockStack().pop();
            methodDeclaration.setBody(body);
            getCurrentType().addMember(methodDeclaration);
            methodCalls.add(new MethodCallExpr(null, methodName));
            ++idx;
        }
        final NodeList<AnnotationExpr> annotations = tv.translateList(ecd.getAnnotations());
        final NodeList<Expression> arguments = new NodeList<>(methodCalls);
        EnumConstantDeclaration r = new EnumConstantDeclaration(annotations, ecd.getName().clone(),
                                                                arguments, new NodeList<>());
        r.setClassBody(tv.translateList(ecd.getClassBody()));
        return r;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.DECLARATION_RUNTIME;}
}
