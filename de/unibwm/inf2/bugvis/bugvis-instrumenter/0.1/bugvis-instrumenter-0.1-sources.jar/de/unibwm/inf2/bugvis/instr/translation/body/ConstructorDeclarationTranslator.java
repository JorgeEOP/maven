package de.unibwm.inf2.bugvis.instr.translation.body;

import com.github.javaparser.Range;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.Modifier.Keyword;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.EnumDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.AssignExpr.Operator;
import com.github.javaparser.ast.expr.ClassExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.FieldAccessExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.ast.nodeTypes.NodeWithSimpleName;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ExplicitConstructorInvocationStmt;
import com.github.javaparser.ast.stmt.TryStmt;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.Type;
import com.github.javaparser.ast.type.TypeParameter;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import com.github.javaparser.resolution.declarations.ResolvedConstructorDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedParameterDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedReferenceTypeDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedTypeParameterDeclaration;
import de.unibwm.inf2.bugvis.instr.translation.ClassInfo;
import de.unibwm.inf2.bugvis.instr.translation.NameType;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static java.lang.System.Logger.Level.DEBUG;

public class ConstructorDeclarationTranslator implements MethodLikeTranslator {
    private static final Logger LOGGER = System.getLogger(ConstructorDeclarationTranslator.class.getName());

    private final TranslationVisitor tv;
    private final ConstructorDeclaration cd;
    private final String signature;
    private final Map<String, String> typeParamMap = new HashMap<>();

    public ConstructorDeclarationTranslator(TranslationVisitor translationVisitor, ConstructorDeclaration constructorDeclaration) {
        LOGGER.log(DEBUG, () -> "creating ConstructorDeclarationTranslator (" + constructorDeclaration + ")");
        this.tv = translationVisitor;
        this.cd = constructorDeclaration;
        ResolvedConstructorDeclaration rcd = constructorDeclaration.resolve();
        this.signature = rcd.getSignature();
        translationVisitor.getInstrClassMethodMap().get(rcd.declaringType().getQualifiedName()).add(signature);
    }

    @Override
    public Node translate() {
        switch (getConstructorType(cd)) {
            case CLASS_CONSTRUCTOR -> translateClassConstructorBody();
            case THIS_CALLING_CLASS_CONSTRUCTOR,
                 THIS_CALLING_ENUM_CONSTRUCTOR,
                 SUPER_CALLING_CLASS_CONSTRUCTOR -> translateThisOrSuperCallingConstructor();
            case ENUM_CONSTRUCTOR -> translateEnumConstructorBody();
        }
        return null;
    }

    private ConstructorType getConstructorType(ConstructorDeclaration cd) {
        final Optional<Node> optionalParentNode = cd.getParentNode();
        if (optionalParentNode.isEmpty()) throw new IllegalStateException("constructor got no parent!");

        ConstructorType constructorType = ConstructorType.CLASS_CONSTRUCTOR;
        if (optionalParentNode.get() instanceof EnumDeclaration) {
            if (!cd.getBody().isEmpty() && cd.getBody().getStatement(0).isExplicitConstructorInvocationStmt())
                constructorType = ConstructorType.THIS_CALLING_ENUM_CONSTRUCTOR;
            else constructorType = ConstructorType.ENUM_CONSTRUCTOR;
        }
        else if (!cd.getBody().isEmpty() && cd.getBody().getStatement(0).isExplicitConstructorInvocationStmt()) {
            ExplicitConstructorInvocationStmt ecis = cd.getBody().getStatement(0).asExplicitConstructorInvocationStmt();
            if (ecis.isThis()) constructorType = ConstructorType.THIS_CALLING_CLASS_CONSTRUCTOR;
            else constructorType = ConstructorType.SUPER_CALLING_CLASS_CONSTRUCTOR;
        }
        return constructorType;
    }

    private void translateClassConstructorBody() {
        if (isJavaLangObject())
            instrumentJavaLangObjectConstructor();
        else {
            cd.getBody().addStatement(
                    0, new ExplicitConstructorInvocationStmt(false, null, new NodeList<>()));
            translateThisOrSuperCallingConstructor();
        }
    }

    private void instrumentJavaLangObjectConstructor() {
        ClassOrInterfaceType type = StaticJavaParser.parseClassOrInterfaceType(JAVA_LANG_OBJECT);
        BlockStmt blockStmt = new BlockStmt();
        addEnteredInstr(type, blockStmt);
        addLeavingInstrAndAddToCurrentType(type, blockStmt, new BlockStmt());
    }

    private boolean isJavaLangObject() {
        final Optional<Node> optionalParentNode = cd.getParentNode();
        if (optionalParentNode.isPresent()) {
            final Node node = optionalParentNode.get();
            if (node instanceof TypeDeclaration<?> typeDeclaration && typeDeclaration.isClassOrInterfaceDeclaration()) {
                ClassOrInterfaceDeclaration coid = typeDeclaration.asClassOrInterfaceDeclaration();
                final Optional<String> optionalFullyQualifiedName = coid.getFullyQualifiedName();
                if (optionalFullyQualifiedName.isPresent())
                    return optionalFullyQualifiedName.get().equals(JAVA_LANG_OBJECT);
            }
        }
        return false;
    }

    private void translateThisOrSuperCallingConstructor() {
        final ClassInfo classInfo = getClassInfo(cd);
        final ClassOrInterfaceType type = StaticJavaParser.parseClassOrInterfaceType(classInfo.fullyQualifiedClassName());
        final String icName = getIntermediateClassName();
        final ClassOrInterfaceType intermediateType = StaticJavaParser.parseClassOrInterfaceType(icName);
        final NodeList<Parameter> cdParameters = applyFacades(new NodeList<>(cd.getParameters().stream().map(Parameter::clone).toList()));

        final ExplicitConstructorInvocationStmt ecis = cd.getBody().getStatement(0).asExplicitConstructorInvocationStmt();
        final ResolvedConstructorDeclaration rcd = ecis.resolve();
        final List<ResolvedParameterDeclaration> ecisParameters = new ArrayList<>();
        for (int i = 0; i < rcd.getNumberOfParams(); ++i) {
            final ResolvedParameterDeclaration param = rcd.getParam(i);
            ecisParameters.add(param);
            LOGGER.log(DEBUG, "ecis param {0}: {1} with name {2} added", i, param, param.getName());
        }

        modifyOriginalConstructor(cdParameters, intermediateType, type);
        final Node parentNode = cd.getParentNode().get();
        if (parentNode instanceof ClassOrInterfaceDeclaration coid && !coid.isInterface())
            deductTypeParameters(coid, ecis);
        final List<ResolvedTypeParameterDeclaration> rtp = cd.resolve().declaringType().asReferenceType().getTypeParameters();
        final List<TypeParameter> typeParameters =
                new NodeList<>(rtp.stream()
                                  .map(rtpd -> new TypeParameter(rtpd.getName(),
                                                                 new NodeList<>(rtpd.getBounds().stream()
                                                                                    .map(b -> StaticJavaParser.parseClassOrInterfaceType(b.getType().describe()))
                                                                                    .toList())))
                                  .toList());

        createIntermediateClass(type, cdParameters, ecis, ecisParameters, rcd, icName, typeParameters);
        createIntermediateConstructor(icName, ecis, ecisParameters, typeParameters);
    }

    private void modifyOriginalConstructor(NodeList<Parameter> cdParameters, ClassOrInterfaceType intermediateType,
                                           ClassOrInterfaceType type) {
        final BlockStmt newBlockStmt = new BlockStmt();
        final List<Expression> paramList = new ArrayList<>(cdParameters.stream().map(NodeWithSimpleName::getNameAsExpression).toList());
        newBlockStmt.addStatement(new ExplicitConstructorInvocationStmt(
                true, null, new NodeList<>(new ObjectCreationExpr(
                null, intermediateType.clone(), new NodeList<>(paramList)))));
        newBlockStmt.addStatement(makeMethodCall(cd, getRuntime(), CONSTRUCTOR_RESULT,
                                                 new NodeList<>(value(new ThisExpr()))));
        final BlockStmt tryBlock = new BlockStmt();
        translateBlockStmt(cd.getBody(), tryBlock, true);
        addLeavingInstrAndAddToCurrentType(type, newBlockStmt, tryBlock);
    }

    private void deductTypeParameters(ClassOrInterfaceDeclaration coid, ExplicitConstructorInvocationStmt ecis) {
        final ResolvedReferenceTypeDeclaration parentClass = ecis.resolve().declaringType();
        final List<ResolvedTypeParameterDeclaration> parentClassTypeParameters = parentClass.getTypeParameters();

        final Optional<ClassOrInterfaceType> first = coid.getExtendedTypes().getFirst();
        if (first.isPresent()) {
            final Optional<NodeList<Type>> typeArguments = first.get().getTypeArguments();
            if (typeArguments.isPresent()) {
                final Iterator<ResolvedTypeParameterDeclaration> parentTypeParametersIt = parentClassTypeParameters.iterator();
                final Iterator<Type> typeArgumentsIt = typeArguments.get().iterator();
                while (parentTypeParametersIt.hasNext() && typeArgumentsIt.hasNext())
                    typeParamMap.put(parentTypeParametersIt.next().getName(), typeArgumentsIt.next().asString());
            }
        }
    }

    private void createIntermediateClass(ClassOrInterfaceType type, NodeList<Parameter> cdParameters,
                                         ExplicitConstructorInvocationStmt ecis,
                                         List<ResolvedParameterDeclaration> ecisParameters,
                                         ResolvedConstructorDeclaration rcd, String icName,
                                         List<TypeParameter> typeParameters) {
        final NodeList<Modifier> modifiers = new NodeList<>(Modifier.staticModifier(), Modifier.privateModifier());
        final ClassOrInterfaceDeclaration intermediateClass = new ClassOrInterfaceDeclaration(
                modifiers, new NodeList<>(), false, new SimpleName(icName), new NodeList<>(typeParameters),
                new NodeList<>(), new NodeList<>(), new NodeList<>(), new NodeList<>());
        addFields(intermediateClass, ecisParameters);
        addIntermediateClassConstructor(type, cdParameters, ecis, ecisParameters, rcd, intermediateClass);
        getCurrentType().addMember(intermediateClass);
    }

    private void addFields(ClassOrInterfaceDeclaration intermediateClass,
                           List<ResolvedParameterDeclaration> ecisParameters) {
        for (ResolvedParameterDeclaration param : ecisParameters) {
            Type paramType = applyFacades(replaceTypeParams(parseType(param.describeType())));

            final VariableDeclarator vd = new VariableDeclarator(paramType, param.getName());
            final NodeList<Modifier> fdModifiers = new NodeList<>(Modifier.privateModifier(), Modifier.finalModifier());
            final FieldDeclaration fd = new FieldDeclaration(fdModifiers, vd);
            intermediateClass.addMember(fd);
        }
    }

    /**
     * Adds the constructor of the intermediate class.
     *
     * @param type
     * @param cdParameters
     * @param ecis
     * @param ecisParameters
     * @param rcd
     * @param intermediateClass
     */
    private void addIntermediateClassConstructor(ClassOrInterfaceType type, NodeList<Parameter> cdParameters,
                                                 ExplicitConstructorInvocationStmt ecis,
                                                 List<ResolvedParameterDeclaration> ecisParameters,
                                                 ResolvedConstructorDeclaration rcd,
                                                 ClassOrInterfaceDeclaration intermediateClass) {
        final ConstructorDeclaration intermediateClassConstructor = intermediateClass.addConstructor(Keyword.PRIVATE);
        for (Parameter cDParam : cdParameters) intermediateClassConstructor.addParameter(cDParam.clone());
        final BlockStmt iccBody = intermediateClassConstructor.getBody();
        addEnteredInstr(type, iccBody);
        tv.getBlockStack().push(iccBody);
        for (int i = 0; i < ecisParameters.size(); ++i) {
            FieldAccessExpr fieldAccessExpr = new FieldAccessExpr(new ThisExpr(), ecisParameters.get(i).getName());
            final Type paramType = applyFacades(replaceTypeParams(parseType(ecisParameters.get(i).describeType())));
            String value = storeResult(iccBody, tv.translateNode(ecis.getArgument(i), paramType), paramType);
            iccBody.addStatement(new AssignExpr(fieldAccessExpr, new NameExpr(value), Operator.ASSIGN));
        }
        tv.getBlockStack().pop();

        final List<Expression> constructorCallParams = new ArrayList<>();
        constructorCallParams.add(new ClassExpr(parseType(rcd.declaringType().getQualifiedName())));
        constructorCallParams.add(new StringLiteralExpr(rcd.getSignature()));
        final List<NameType> nts = NameType.fromResolvedMethodLikeDeclaration(rcd);
        if (!nts.isEmpty()) constructorCallParams.add(params(nts, true));
//        listParams(iccBody, constructorCallParams, true, NameType.fromResolvedMethodLikeDeclaration(rcd));
        iccBody.addStatement(makeMethodCall(ecisRange(ecis), getRuntime(),
                                            CONSTRUCTOR_CALL, constructorCallParams));
    }

    private Range ecisRange(ExplicitConstructorInvocationStmt ecis) {
        final Optional<Expression> optionalExpr = ecis.getExpression();
        if (optionalExpr.isPresent()) {
            final Optional<Range> optionalExprRange = optionalExpr.get().getRange();
            if (optionalExprRange.isPresent()) {
                final Range exprRange = optionalExprRange.get();
                return exprRange.withEnd(exprRange.end.right(ecis.isThis() ? 5 : 6));
            }
        }

        return ecis.getRange().map(r -> r.withEnd(r.begin.right(ecis.isThis() ? 3 : 4)))
                   .orElse(UNDEFINED_RANGE);
    }

    /**
     * Add private constructor which uses the results of the intermediate class to invoke an explicit constructor
     * invocation statement.
     *
     * @param icName
     * @param ecis
     * @param ecisParameters
     * @param typeParameters
     */
// TODO: Exceptions of the called constructor?
    private void createIntermediateConstructor(String icName, ExplicitConstructorInvocationStmt ecis,
                                               List<ResolvedParameterDeclaration> ecisParameters,
                                               List<TypeParameter> typeParameters) {
        final ConstructorDeclaration intermediateConstructor = getCurrentType().addConstructor(Keyword.PRIVATE);
        final String objectName = icName.toLowerCase();
        intermediateConstructor.addParameter(new Parameter(generateType(icName, typeParameters), objectName));
        final ExplicitConstructorInvocationStmt icEcis = new ExplicitConstructorInvocationStmt(ecis.isThis(), null, new NodeList<>());
        intermediateConstructor.getBody().addStatement(icEcis);
        for (ResolvedParameterDeclaration param : ecisParameters)
            icEcis.getArguments().add(new FieldAccessExpr(new NameExpr(objectName), param.getName()));
    }

    private Type generateType(String icName, List<TypeParameter> typeParameters) {
        final StringBuilder sb = new StringBuilder(icName);
        if (!typeParameters.isEmpty())
            sb.append("<")
              .append(String.join(", ", typeParameters.stream().map(tp -> tp.getName().getId()).toList()))
              .append(">");
        return parseType(sb.toString());
    }

    private Type replaceTypeParams(Type type) {
        if (type.isClassOrInterfaceType()) {
            final String typeString = type.asClassOrInterfaceType().toString();
            if (typeParamMap.containsKey(typeString))
                return parseType(typeParamMap.get(typeString));

            type.accept(new VoidVisitorAdapter<>() {
                @Override
                public void visit(ClassOrInterfaceType n, Object arg) {
                    final Optional<NodeList<Type>> optionalTypeArguments = n.getTypeArguments();
                    optionalTypeArguments.ifPresent(types -> n.setTypeArguments(
                            new NodeList<>(types.stream().map(t -> {
                                final String typeString1 = t.toString();
                                if (typeParamMap.containsKey(typeString1))
                                    return parseType(typeParamMap.get(typeString1));
                                else return t;
                            }).toList())));
                    super.visit(n, arg);
                }
            }, null);
        }
        return type;
    }

    private void translateEnumConstructorBody() {
        final ClassInfo classInfo = getClassInfo(cd);
        final ClassOrInterfaceType classOrInterfaceType = StaticJavaParser.parseClassOrInterfaceType(classInfo.fullyQualifiedClassName());

        final BlockStmt newBlockStmt = new BlockStmt();
        addEnumEnteredInstr(classOrInterfaceType, newBlockStmt);

        final BlockStmt tryBlock = new BlockStmt();
        translateBlockStmt(cd.getBody(), tryBlock);
        addLeavingInstrAndAddToCurrentType(classOrInterfaceType, newBlockStmt, tryBlock);
    }

    private String getIntermediateClassName() {
        final Optional<Range> optionalRange = cd.getRange();
        if (optionalRange.isEmpty()) throw new IllegalStateException("range is empty");
        if (optionalRange.get().begin.line < 0) return "C0_0";
        return "C" + optionalRange.get().begin.line + "_" + optionalRange.get().begin.column;
    }

    private void addEnteredInstr(ClassOrInterfaceType type, BlockStmt blockStmt) {
        final List<Expression> constrEnteredParams = createParams(false, type);
        final List<NameType> nts = NameType.fromNodeWithParameters(cd);
        if (!nts.isEmpty()) constrEnteredParams.add(params(nts, false));
        blockStmt.addStatement(makeMethodCall(cd.getName(), getRuntime(), CONSTRUCTOR_ENTERED, constrEnteredParams));
    }

    private void addEnumEnteredInstr(ClassOrInterfaceType type, BlockStmt blockStmt) {
        final List<Expression> constrEnteredParams = createEnumEnteredParams(type);
        final List<NameType> nts = NameType.fromNodeWithParameters(cd);
        if (!nts.isEmpty()) constrEnteredParams.add(params(nts, false));
        blockStmt.addStatement(makeMethodCall(cd.getName(), getRuntime(), CONSTRUCTOR_ENTERED, constrEnteredParams));
    }

    private List<Expression> createEnumEnteredParams(ClassOrInterfaceType type) {
        final List<Expression> params = new ArrayList<>();
        params.add(parameter(type.asString(), "this", new ThisExpr()));
        params.add(new StringLiteralExpr(signature));
        return params;
    }

    private void addLeavingInstrAndAddToCurrentType(ClassOrInterfaceType type, BlockStmt blockStmt, BlockStmt tryBlock) {
        final List<Expression> leavingConstrParams = createParams(true, type);
        final BlockStmt finallyBlock = new BlockStmt();
        finallyBlock.addStatement(makeMethodCall(blockEndRange(cd), getRuntime(), LEAVING_CONSTRUCTOR, leavingConstrParams));
        final TryStmt tryStmt = new TryStmt(tryBlock, new NodeList<>(), finallyBlock);
        blockStmt.addStatement(tryStmt);
        getCurrentType().addMember(translateConstructor(blockStmt));
    }

    private List<Expression> createParams(boolean normalConstr, ClassOrInterfaceType type) {
        final List<Expression> params = new ArrayList<>();
        if (normalConstr) params.add(value(new ThisExpr()));
        else params.add(new ClassExpr(type.clone()));
        params.add(new StringLiteralExpr(signature));
        return params;
    }

    private ConstructorDeclaration translateConstructor(BlockStmt body) {
        final MethodLikeComponents result = translateMethodLikeComponents(cd);
        final ConstructorDeclaration r = new ConstructorDeclaration(cd.getTokenRange().orElse(null),
                                                                    result.modifiers(),
                                                                    result.annotations(),
                                                                    result.typeParameters(),
                                                                    result.name(),
                                                                    result.parameters(),
                                                                    result.thrownExceptions(),
                                                                    body,
                                                                    result.receiverParameter());
        copyCommentsAndData(cd, r);
        return r;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.DECLARATION_RUNTIME;}
}
