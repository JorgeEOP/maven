package de.unibwm.inf2.bugvis.instr.translation.expr;

import com.github.javaparser.Range;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.expr.ArrayAccessExpr;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.AssignExpr.Operator;
import com.github.javaparser.ast.expr.BinaryExpr;
import com.github.javaparser.ast.expr.ClassExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.FieldAccessExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.SuperExpr;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.Type;
import com.github.javaparser.resolution.declarations.ResolvedFieldDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedValueDeclaration;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.lang.System.Logger.Level.DEBUG;

public class AssignExprTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(AssignExprTranslator.class.getName());

    private final AssignExpr ae;
    private final TranslationVisitor tv;
    private final Expression target;
    private final Expression value;
    private MethodCallExpr tmpStmt;

    public AssignExprTranslator(TranslationVisitor translationVisitor, AssignExpr assignExpr) {
        LOGGER.log(DEBUG, () -> "creating AssignExprTranslator (" + assignExpr + ")");
        this.tv = translationVisitor;
        this.ae = assignExpr;
        this.target = assignExpr.getTarget();
        this.value = assignExpr.getValue();
    }

    @Override
    public Node translate() {
        BlockStmt blockStmt = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));
        // TODO: evaluate correct type. See MethodCallExprTranslator
        Type type = applyFacades(parseType(target.calculateResolvedType().describe()));
        Expression newTarget = tv.translateNode(target);
        String valueVarName = storeResult(blockStmt, tv.translateNode(value, type), type);

        if (newTarget.isNameExpr())
            valueVarName = handleNameExpr(valueVarName, newTarget.asNameExpr().getNameAsString(), blockStmt);
        else if (newTarget.isFieldAccessExpr())
            valueVarName = handleFieldAccessExpr(newTarget.asFieldAccessExpr(), valueVarName, blockStmt);
        else if (newTarget.isArrayAccessExpr())
            valueVarName = handleArrayAccessExpr(newTarget.asArrayAccessExpr(), valueVarName, blockStmt);
        else
            throw new UnsupportedOperationException("AssignExpr with unknown target class: " + newTarget.getClass() + ".");

        AssignExpr r = new AssignExpr(ae.getTokenRange().orElse(null),
                                      newTarget, new NameExpr(valueVarName), Operator.ASSIGN);
        copyCommentsAndData(ae, r);
        blockStmt.addStatement(r);
        if (tmpStmt != null)
            blockStmt.addStatement(tmpStmt);
        return newTarget.clone();
    }

    private String handleNameExpr(String valueVarName, String targetVarName, BlockStmt blockStmt) {
        LOGGER.log(DEBUG, targetVarName + " = " + valueVarName);
        ResolvedValueDeclaration rvd = target.asNameExpr().resolve();
        valueVarName = handleAssignOperator(new NameExpr(targetVarName), valueVarName, blockStmt);
        List<Expression> exprList = new ArrayList<>();
        if (rvd.isField()) {
            ResolvedFieldDeclaration rfd = rvd.asField();
            if (rfd.isStatic()) exprList.add(new ClassExpr(getType(rfd)));
            else exprList.add(value(new ThisExpr()));
            exprList.addAll(List.of(new StringLiteralExpr(targetVarName), value(new NameExpr(valueVarName))));
            if (!rfd.isStatic()) exprList.add(new ClassExpr(getType(rfd)));
            tmpStmt = makeMethodCall(getRange(ae), Runtime.DECLARATION_RUNTIME, getMethod(rfd), exprList);
        }
        else if (rvd.isVariable() || rvd.isParameter()) {
            exprList.add(new StringLiteralExpr(targetVarName));
            exprList.add(value(new NameExpr(valueVarName)));
            tmpStmt = makeMethodCall(getRange(ae), getRuntime(), VARIABLE_ASSIGNMENT, exprList);
        }
        else
            throw new UnsupportedOperationException("NameExpr is neither a field nor a variable.");
        return valueVarName;
    }

    private Range getRange(AssignExpr assignExpr) {
        return getRangeBetween(assignExpr.getTarget(), assignExpr.getValue());
    }

    private String handleFieldAccessExpr(FieldAccessExpr fieldAccessExpr, String valueVarName, BlockStmt blockStmt) {
        LOGGER.log(DEBUG, fieldAccessExpr.toString() + " = " + valueVarName);
        Expression fieldScope = fieldAccessExpr.getScope() instanceof SuperExpr ? value(new ThisExpr()) : value(fieldAccessExpr.getScope().clone());
        ResolvedValueDeclaration rvd = target.asFieldAccessExpr().resolve();
        valueVarName = handleAssignOperator(fieldAccessExpr.clone(), valueVarName, blockStmt);
        ResolvedFieldDeclaration rfd = rvd.asField();
        if (rfd.isStatic()) fieldScope = new ClassExpr(getType(rfd));
        final List<Expression> paramList = new ArrayList<>();
        paramList.add(fieldScope);
        paramList.add(new StringLiteralExpr(fieldAccessExpr.getNameAsString()));
        paramList.add(value(new NameExpr(valueVarName)));
        if (!rfd.isStatic()) paramList.add(new ClassExpr(getType(rfd)));
        tmpStmt = makeMethodCall(getRange(ae), Runtime.DECLARATION_RUNTIME, getMethod(rfd), paramList);
        return valueVarName;
    }

    private static String getMethod(ResolvedFieldDeclaration rfd) {
        return rfd.isStatic() ? STATIC_FIELD_ASSIGNMENT : FIELD_ASSIGNMENT;
    }

    private String handleArrayAccessExpr(ArrayAccessExpr arrayAccessExpr, String valueVarName, BlockStmt blockStmt) {
        LOGGER.log(DEBUG, arrayAccessExpr.toString() + " = " + valueVarName);
        Expression arrayNameClone = arrayAccessExpr.getName().clone();
        Expression arrayIndexClone = arrayAccessExpr.getIndex().clone();
        String targetString = target.toString();
        valueVarName = handleAssignOperator(arrayAccessExpr.clone(), valueVarName, blockStmt);
        tmpStmt = makeMethodCall(getRange(ae), getRuntime(), ARRAY_ASSIGNMENT,
                                 List.of(value(arrayNameClone), arrayIndexClone,
                                         new StringLiteralExpr(targetString),
                                         value(new NameExpr(valueVarName))));
        return valueVarName;
    }

    private String handleAssignOperator(Expression targetExpr, String valueVarName, BlockStmt blockStmt) {
        if (ae.getOperator() != Operator.ASSIGN) {
            Optional<BinaryExpr.Operator> operatorOptional = ae.getOperator().toBinaryOperator();
            if (operatorOptional.isPresent()) {
                BinaryExpr binaryExpr = new BinaryExpr(targetExpr, new NameExpr(valueVarName), operatorOptional.get());
                valueVarName = storeResult(blockStmt, binaryExpr);
                blockStmt.addStatement(makeMethodCall(
                        getRange(ae), Runtime.EXPRESSION_RUNTIME, BINARY_OPERATION,
                        List.of(new StringLiteralExpr(replaceQuotationMarks(target)),
                                new StringLiteralExpr(operatorOptional.get().asString()),
                                new StringLiteralExpr(replaceQuotationMarks(value)),
                                value(new NameExpr(valueVarName)))));
            }
            else throw new IllegalStateException("Operator is not present!");
        }
        return valueVarName;
    }

    private ClassOrInterfaceType getType(ResolvedFieldDeclaration rfd) {
        String qualifiedName = rfd.declaringType().getQualifiedName();
        return StaticJavaParser.parseClassOrInterfaceType(qualifiedName);
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.EXPRESSION_RUNTIME;}
}
