package de.unibwm.inf2.bugvis.instr.translation.body;

public enum ConstructorType {
    CLASS_CONSTRUCTOR,
    THIS_CALLING_CLASS_CONSTRUCTOR,
    SUPER_CALLING_CLASS_CONSTRUCTOR,
    ENUM_CONSTRUCTOR,
    THIS_CALLING_ENUM_CONSTRUCTOR,
}
