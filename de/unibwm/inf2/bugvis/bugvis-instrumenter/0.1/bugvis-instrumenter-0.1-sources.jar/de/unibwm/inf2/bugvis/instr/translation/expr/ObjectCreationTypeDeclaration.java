package de.unibwm.inf2.bugvis.instr.translation.expr;

import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.visitor.GenericVisitor;
import com.github.javaparser.ast.visitor.VoidVisitor;
import com.github.javaparser.resolution.declarations.ResolvedReferenceTypeDeclaration;

import java.lang.System.Logger;
import java.util.Optional;

import static java.lang.System.Logger.Level.DEBUG;

/**
 * This class is a representation for an {@link ObjectCreationExpr} with anonymous class body. It is used by the
 * {@link de.unibwm.inf2.bugvis.instr.translation.body.FieldDeclarationTranslator FieldDeclarationTranslator} to add
 * the translated field and its initialization method.
 * <p>
 * The methods {@link #resolve()} as well as {@link #accept(com.github.javaparser.ast.visitor.VoidVisitor, Object)} and
 * {@link #accept(com.github.javaparser.ast.visitor.GenericVisitor, Object)} throw
 * {@link UnsupportedOperationException}s!
 * <p>
 * Could be reduced to a NodeWithMember, but FieldDeclarationTranslator needs to be heavily modified for this change.
 */
public class ObjectCreationTypeDeclaration extends TypeDeclaration<ObjectCreationTypeDeclaration> {
    public static final Logger LOGGER = System.getLogger(ObjectCreationTypeDeclaration.class.getName());

    private final NodeList<BodyDeclaration<?>> members;

    public ObjectCreationTypeDeclaration(ObjectCreationExpr objectCreationExpr) {
        LOGGER.log(DEBUG, () -> "Creating ObjectCreationTypeDeclaration");
        Optional<NodeList<BodyDeclaration<?>>> bodyDecl = objectCreationExpr.getAnonymousClassBody();
        this.members = bodyDecl.orElseGet(NodeList::new);
        objectCreationExpr.setAnonymousClassBody(this.members);
    }

    @Override
    public NodeList<BodyDeclaration<?>> getMembers() {return members;}

    @Override
    public ResolvedReferenceTypeDeclaration resolve() {throw new UnsupportedOperationException();}

    @Override
    public <R, A> R accept(GenericVisitor<R, A> v, A arg) {throw new UnsupportedOperationException();}

    @Override
    public <A> void accept(VoidVisitor<A> v, A arg) {throw new UnsupportedOperationException();}
}
