package de.unibwm.inf2.bugvis.instr;

import com.github.javaparser.ParserConfiguration.LanguageLevel;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.symbolsolver.JavaSymbolSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import de.unibwm.inf2.bugvis.instr.metainfo.MetaInfo;

import java.io.File;
import java.io.IOException;
import java.lang.System.Logger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Collection;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static java.lang.System.Logger.Level.ERROR;

/**
 * Instrumenter Top Level
 */
public class Instrumenter {
    private static final Logger LOGGER = System.getLogger(Instrumenter.class.getName());
    private static final String FILE_SEPARATOR = "/";

    private final InstrumenterOptions options;
    private final TypeSolverSupport typeSolverSupport;

    private final Set<Target> instrumentedFiles = new HashSet<>();
    private final Set<Target> failedFiles = new HashSet<>();

    public Instrumenter(InstrumenterOptions options) {
        this.options = options;
        this.typeSolverSupport = new TypeSolverSupport(options);
    }

    // instrument //////////////////////////////////////////////////////////////////////////////////////////////////////

    public void instrument() {
        final CombinedTypeSolver typeSolver = typeSolverSupport.getTypeSolver();
        initializeJavaParser(typeSolver);
        final FileInstrumenter instrumenter = new FileInstrumenter(typeSolver, !options.isPreserveComments());
        final MetaInfo metaInfo = new MetaInfo();
        final Set<Target> targets = createTargetSet(options.getFilesToInstrument().stream().sorted().toList());

        beforeInstrumentation(targets);
        for (Target target : targets) {
            beforeFileInstrumentation(target);
            FileInstrumenterResult result = instrumenter.instrument(target);
            if (result.isSuccessful()) {
                instrumentedFiles.add(target);
                MetaInfoSupport.updateMetaInfo(metaInfo, result);
            }
            else
                failedFiles.add(target);
            afterFileInstrumentation(result);
        }
        afterInstrumentation(targets, instrumentedFiles, failedFiles);

        if (options.getCopyFailedFiles())
            copyFiles(failedFiles, options.getOverwrite());
        copyFiles(createTargetSet(options.getFilesToCopy()), options.getOverwrite());

        MetaInfoSupport.writeMetaInfo(options.getMetaInfoFile(), metaInfo);
    }

    private void initializeJavaParser(CombinedTypeSolver typeSolver) {
        StaticJavaParser.getParserConfiguration().setSymbolResolver(new JavaSymbolSolver(typeSolver));
        StaticJavaParser.getParserConfiguration().setLanguageLevel(LanguageLevel.BLEEDING_EDGE);
    }

    protected void beforeInstrumentation(Set<Target> targets) {
        /* method stub for extending classes */
    }

    protected void afterInstrumentation(Set<Target> targets, Set<Target> instrumentedFiles, Set<Target> failedFiles) {
        /* method stub for extending classes */
    }

    protected void beforeFileInstrumentation(Target target) {
        /* method stub for extending classes */
    }

    protected void afterFileInstrumentation(FileInstrumenterResult result) {
        /* method stub for extending classes */
    }

    private Set<Target> createTargetSet(Collection<File> files) {
        final Set<Target> targetSet = new HashSet<>();
        for (File file : files) {
            try {
                final File original = file.getCanonicalFile();
                final CompilationUnit compilationUnit = StaticJavaParser.parse(original);
                final String relativePath = getRelativePath(compilationUnit);
                final File target = new File(createTargetFileName(options.getTargetDir(), relativePath, original));
                targetSet.add(new Target(original, relativePath, target));
            }
            catch (IOException e) {
                LOGGER.log(ERROR, e);
            }
        }
        return targetSet;
    }

    private void copyFiles(Set<Target> targetSet, boolean overwrite) {
        for (Target target : targetSet) {
            try {
                Path original = target.original().toPath();
                Path instrumented = target.instrumented().toPath();
                if (overwrite) Files.copy(original, instrumented, StandardCopyOption.REPLACE_EXISTING);
                else Files.copy(original, instrumented);
            }
            catch (IOException exception) {
                LOGGER.log(ERROR, exception);
            }
        }
    }

    private String getRelativePath(CompilationUnit compilationUnit) {
        StringBuilder identifier = new StringBuilder();
        Optional<PackageDeclaration> packageDeclaration = compilationUnit.getPackageDeclaration();
        if (packageDeclaration.isPresent()) {
            Name name = packageDeclaration.get().getName();
            identifier.append(name.getIdentifier());

            Optional<Name> optionalQualifier = name.getQualifier();
            while (optionalQualifier.isPresent()) {
                final String id = optionalQualifier.get().getIdentifier();
                identifier.insert(0, FILE_SEPARATOR).insert(0, id);
                optionalQualifier = optionalQualifier.get().getQualifier();
            }
        }
        return identifier.toString();
    }

    private String createTargetFileName(File targetDir, String relativePath, File file) {
        return targetDir + FILE_SEPARATOR + relativePath + FILE_SEPARATOR + file.getName();
    }
}
