package de.unibwm.inf2.bugvis.instr.translation.body;

import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.AnnotationDeclaration;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.resolution.declarations.ResolvedAnnotationDeclaration;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.DEBUG;

public class AnnotationDeclarationTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(AnnotationDeclarationTranslator.class.getName());
    private final TranslationVisitor tv;
    private final AnnotationDeclaration ad;

    public AnnotationDeclarationTranslator(TranslationVisitor translationVisitor, AnnotationDeclaration annotationDeclaration) {
        LOGGER.log(DEBUG, () -> "creating AnnotationDeclarationTranslator (" + annotationDeclaration + ")");
        this.tv = translationVisitor;
        this.ad = annotationDeclaration;
        ResolvedAnnotationDeclaration rad = annotationDeclaration.resolve();
        translationVisitor.addInstrType(rad.getQualifiedName());
    }

    @Override
    public Node translate() {
        NodeList<Modifier> modifiers = tv.translateList(ad.getModifiers());
        SimpleName name = tv.translateNode(ad.getName());
        NodeList<AnnotationExpr> annotations = tv.translateList(ad.getAnnotations());
        AnnotationDeclaration r = new AnnotationDeclaration(ad.getTokenRange().orElse(null),
                                                            modifiers, annotations, name, new NodeList<>());
        translateMembers(ad, r);
        copyCommentsAndData(ad, r);
        return r;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.DECLARATION_RUNTIME;}
}
