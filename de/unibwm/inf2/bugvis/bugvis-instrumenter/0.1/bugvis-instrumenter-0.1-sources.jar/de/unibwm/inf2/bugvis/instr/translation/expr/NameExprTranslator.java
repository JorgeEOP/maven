package de.unibwm.inf2.bugvis.instr.translation.expr;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.expr.ClassExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.resolution.UnsolvedSymbolException;
import com.github.javaparser.resolution.declarations.ResolvedFieldDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedValueDeclaration;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;
import java.util.List;
import java.util.Optional;

import static java.lang.System.Logger.Level.DEBUG;
import static java.lang.System.Logger.Level.WARNING;

public class NameExprTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(NameExprTranslator.class.getName());

    private final TranslationVisitor tv;
    private final NameExpr ne;

    public NameExprTranslator(TranslationVisitor translationVisitor, NameExpr nameExpr, Object arg) {
        LOGGER.log(DEBUG, () -> "creating NameExprTranslator (" + nameExpr + "), range: " + nameExpr.getRange().orElse(null));
        this.tv = translationVisitor;
        this.ne = nameExpr;
    }

    @Override
    public Node translate() {
        try {
            final ResolvedValueDeclaration resolved = ne.resolve();
            if (resolved != null && resolved.isField()) {
                final ResolvedFieldDeclaration resolvedField = resolved.asField();
                String declaringClass = resolvedField.declaringType().getQualifiedName();
                String containingClass = getContainingTypeName(ne);
                Name thisScope = null;
                if (!containingClass.equals(declaringClass) && containingClass.startsWith(declaringClass))
                    thisScope = StaticJavaParser.parseName(declaringClass);
                Expression objectOrClass = resolvedField.isStatic() ?
                        new ClassExpr(parseType(declaringClass)) :
                        value(new ThisExpr(thisScope));
                getCurrentBlock().ifPresent(b -> b.addStatement(
                        makeMethodCall(ne, getRuntime(), FIELD_ACCESS, List.of(
                                objectOrClass,
                                new StringLiteralExpr(ne.getNameAsString()),
                                new ClassExpr(parseType(declaringClass))))));
            }
        }
        catch (UnsolvedSymbolException e) {
            LOGGER.log(WARNING, e);
        }

        SimpleName name = tv.translateNode(ne.getName());
        NameExpr r = new NameExpr(ne.getTokenRange().orElse(null), name);

        copyCommentsAndData(ne, r);
        return r;
    }

    private String getContainingTypeName(Node node) {
        final Optional<TypeDeclaration> containingClassOptional = node.findAncestor(TypeDeclaration.class);
        if (containingClassOptional.isPresent()) {
            final TypeDeclaration<?> typeDeclaration = containingClassOptional.get();
            final Optional<String> fullyQualifiedNameOptional = typeDeclaration.getFullyQualifiedName();
            if (fullyQualifiedNameOptional.isPresent())
                return fullyQualifiedNameOptional.get();
            else if (typeDeclaration.isClassOrInterfaceDeclaration() && typeDeclaration.asClassOrInterfaceDeclaration().isLocalClassDeclaration()) {
                return typeDeclaration.getNameAsString();
            }
        }
        throw new IllegalStateException("Cannot find containing type for: " + node);
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.EXPRESSION_RUNTIME;}
}
