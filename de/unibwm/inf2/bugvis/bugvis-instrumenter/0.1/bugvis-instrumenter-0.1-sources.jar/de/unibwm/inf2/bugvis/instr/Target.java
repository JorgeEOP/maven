package de.unibwm.inf2.bugvis.instr;

import java.io.File;

public record Target(File original, String relativePath, File instrumented) {}