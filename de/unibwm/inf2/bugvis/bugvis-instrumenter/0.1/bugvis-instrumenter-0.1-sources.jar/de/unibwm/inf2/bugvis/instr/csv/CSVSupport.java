package de.unibwm.inf2.bugvis.instr.csv;

import java.io.FileWriter;
import java.io.IOException;
import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.List;

import static java.lang.System.Logger.Level.ERROR;

public class CSVSupport {
    private static final Logger LOGGER = System.getLogger(CSVSupport.class.getName());
    private static final String DEFAULT_DELIMITER = ";";

    private final String delimiter;
    private final String fileName;
    private final List<String> headings = new ArrayList<>();
    private final List<CSVEntry> entries = new ArrayList<>();

    public CSVSupport(String fileName) {
        this(fileName, DEFAULT_DELIMITER);
    }

    public CSVSupport(String fileName, String delimiter) {
        this.fileName = fileName;
        this.delimiter = delimiter;
    }

    public CSVSupport addColumn(String title) {
        this.headings.add(title);
        return this;
    }

    public CSVEntry newEntry() {
        final CSVEntry entry = new CSVEntry();
        entries.add(entry);
        return entry;
    }

    public CSVEntry getEntry(int index) {return entries.get(index);}

    public CSVEntry getLastEntry() {return entries.getLast();}

    public void clear() {entries.clear();}

    public void write() {
        try (FileWriter fileWriter = new FileWriter(fileName)) {
            fileWriter.write(String.join(delimiter, headings));
            fileWriter.write("\n");
            for (CSVEntry entry : entries) {
                fileWriter.write(entry.toString(DEFAULT_DELIMITER));
                fileWriter.write("\n");
            }
        }
        catch (IOException e) {
            e.printStackTrace();
            LOGGER.log(ERROR, e.getMessage());
        }
    }
}
