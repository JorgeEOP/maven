package de.unibwm.inf2.bugvis.instr.translation.expr;

import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.AssignExpr.Operator;
import com.github.javaparser.ast.expr.ConditionalExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.type.Type;
import com.github.javaparser.ast.type.VarType;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.DEBUG;

public class ConditionalExprTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(ConditionalExprTranslator.class.getName());

    private final ConditionalExpr ce;
    private final TranslationVisitor tv;
    private final Expression condition;
    private final Expression thenExpr;
    private final Expression elseExpr;
    private final Type type;

    public ConditionalExprTranslator(TranslationVisitor translationVisitor, ConditionalExpr conditionalExpr, Object arg) {
        LOGGER.log(DEBUG, () -> "creating ConditionalExprTranslator (" + conditionalExpr + ")");
        this.tv = translationVisitor;
        this.ce = conditionalExpr;
        this.condition = conditionalExpr.getCondition();
        this.thenExpr = conditionalExpr.getThenExpr();
        this.elseExpr = conditionalExpr.getElseExpr();
        if (arg instanceof Type typeArg) this.type = typeArg;
        else this.type = null;
    }

    @Override
    public Expression translate() {
        BlockStmt block = getCurrentBlock().orElseThrow(() -> new IllegalStateException("blockStmt == null"));

        final String conditionVarName = storeResult(block, tv.translateNode(condition));
        Type localType = new VarType();
        if (this.type != null) localType = this.type;
        else {
            try {
                localType = parseType(ce.calculateResolvedType().describe());
            }
            catch (IllegalStateException e) {
                if (!e.getMessage().equals("No data of this type found. Use containsData to check for this first."))
                    throw e;
            }
        }
        String varName = newVarName();
        VariableDeclarationExpr variableDeclarationExpr = new VariableDeclarationExpr(localType, varName);
        block.addStatement(variableDeclarationExpr);
        BlockStmt thenBlock = createBlock(varName, thenExpr, localType);
        BlockStmt elseBlock = createBlock(varName, elseExpr, localType);
        IfStmt ifStmt = new IfStmt(new NameExpr(conditionVarName), thenBlock, elseBlock);
        copyCommentsAndData(ce, ifStmt);
        block.addStatement(ifStmt);
        return new NameExpr(varName);
    }

    private BlockStmt createBlock(String varName, Expression originalExpr, Type type) {
        BlockStmt newBlock = new BlockStmt();
        tv.getBlockStack().push(newBlock);
        Expression newExpr = tv.translateNode(originalExpr, type);
        AssignExpr assignExpr = new AssignExpr(new NameExpr(varName), newExpr, Operator.ASSIGN);
        newBlock.addStatement(assignExpr);
        tv.getBlockStack().pop();
        return newBlock;
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {
        return tv;
    }

    @Override
    public Runtime getRuntime() {return Runtime.EXPRESSION_RUNTIME;}
}
