package de.unibwm.inf2.bugvis.instr.translation.body;

import com.github.javaparser.Position;
import com.github.javaparser.Range;
import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.Modifier.Keyword;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.TypeParameter;
import com.github.javaparser.resolution.declarations.ResolvedReferenceTypeDeclaration;
import de.unibwm.inf2.bugvis.instr.translation.NodeTranslator;
import de.unibwm.inf2.bugvis.instr.translation.Runtime;
import de.unibwm.inf2.bugvis.instr.translation.TranslationVisitor;

import java.lang.System.Logger;

import static java.lang.System.Logger.Level.DEBUG;

public class ClassOrInterfaceDeclarationTranslator implements NodeTranslator {
    private static final Logger LOGGER = System.getLogger(ClassOrInterfaceDeclarationTranslator.class.getName());
    private final ClassOrInterfaceDeclaration coid;
    private final TranslationVisitor tv;

    public ClassOrInterfaceDeclarationTranslator(TranslationVisitor translationVisitor, ClassOrInterfaceDeclaration coid) {
        LOGGER.log(DEBUG, () -> "creating ClassOrInterfaceDeclarationTranslator (" + coid + ")");
        this.tv = translationVisitor;
        this.coid = coid;
        ResolvedReferenceTypeDeclaration rrtd = coid.resolve();
        LOGGER.log(DEBUG, () -> "add Instr Type: " + rrtd.getQualifiedName());
        translationVisitor.addInstrType(rrtd.getQualifiedName());
    }

    @Override
    public Node translate() {
        NodeList<ClassOrInterfaceType> extendedTypes = tv.translateList(coid.getExtendedTypes());
        NodeList<ClassOrInterfaceType> implementedTypes = tv.translateList(coid.getImplementedTypes());
        NodeList<TypeParameter> typeParameters = tv.translateList(coid.getTypeParameters());
        NodeList<Modifier> modifiers = tv.translateList(coid.getModifiers());
        SimpleName name = tv.translateNode(coid.getName());
        NodeList<AnnotationExpr> annotations = tv.translateList(coid.getAnnotations());
        ClassOrInterfaceDeclaration r = new ClassOrInterfaceDeclaration(coid.getTokenRange().orElse(null),
                                                                        modifiers, annotations, coid.isInterface(),
                                                                        name, typeParameters, extendedTypes,
                                                                        implementedTypes, new NodeList<>(),
                                                                        new NodeList<>());
        if (!coid.isInterface() && coid.getConstructors().isEmpty()) addEmptyDefaultConstructor();
        translateMembers(coid, r);
        copyCommentsAndData(coid, r);
        return r;
    }

    private void addEmptyDefaultConstructor() {
        ConstructorDeclaration cd = coid.addConstructor(Keyword.PUBLIC);
        final Position pos = new Position(-1, -1);
        cd.setRange(new Range(pos, pos));
        cd.getName().setRange(new Range(pos, pos));
    }

    @Override
    public TranslationVisitor getTranslationVisitor() {return tv;}

    @Override
    public Runtime getRuntime() {return Runtime.DECLARATION_RUNTIME;}
}
