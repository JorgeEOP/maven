package de.unibwm.inf2.bugvis.instr.translation;

import com.github.javaparser.Position;
import com.github.javaparser.Range;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.DataKey;
import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.Modifier.Keyword;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.comments.Comment;
import com.github.javaparser.ast.expr.BooleanLiteralExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.IntegerLiteralExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.NullLiteralExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.UnaryExpr;
import com.github.javaparser.ast.expr.UnaryExpr.Operator;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.nodeTypes.NodeWithStatements;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.Type;
import com.github.javaparser.ast.type.VarType;
import com.github.javaparser.resolution.types.ResolvedType;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

// TODO: aufräumen
public interface NodeTranslator extends NodeTranslatorConstants {

    /**
     * Mandatory method to translate/instrument the wrapped Node.
     *
     * @return The translated/instrumented Node. Sometimes null, if all modifications have already been added to the
     * AST.
     */
    Node translate();

    /**
     * Returns the currently used translation visitor.
     *
     * @return the currently used translation visitor.
     */
    TranslationVisitor getTranslationVisitor();

    /**
     * Returns the currently relevant instrumentation runtime.
     *
     * @return the currently relevant instrumentation runtime.
     */
    Runtime getRuntime();

    default MethodCallExpr value(Expression expr) {
        return makeMethodCallWithoutInitParams(BUG_VIS_INSTR, METHOD_V, new NodeList<>(expr));
    }

    default MethodCallExpr parameter(String type, String name, Expression expr) {
        return makeMethodCallWithoutInitParams(BUG_VIS_INSTR, METHOD_P, new NodeList<>(new StringLiteralExpr(type),
                                                                                       new StringLiteralExpr(name),
                                                                                       expr));
    }

    default MethodCallExpr parameter(String type, String name) {return parameter(type, name, new NameExpr(name));}

    default MethodCallExpr makeMethodCall(Node node, Runtime runtime, String methodName, List<Expression> list) {
        final Optional<Range> optionalRange = node.getRange();
        if (optionalRange.isEmpty())
            throw new IllegalStateException("range is not present");
        return makeMethodCall(optionalRange.get(), runtime, methodName, list);
    }

    default MethodCallExpr makeMethodCall(Range range, Runtime runtime, String methodName, List<Expression> list) {
        List<Expression> paramList = initInstrumentationParams(range);
        paramList.addAll(list);
        MethodCallExpr scope = new MethodCallExpr(new NameExpr(Runtime.BUG_VIS_INSTR), runtime.getMethodName());
        return new MethodCallExpr(scope, methodName, new NodeList<>(paramList));
    }

    default MethodCallExpr makeMethodCallWithoutInitParams(String qualifier, String methodName, List<Expression> list) {
        Expression expr = StaticJavaParser.parseExpression(qualifier);
        return new MethodCallExpr(expr, methodName, new NodeList<>(list));
    }

    default List<Expression> initInstrumentationParams(Range range) {
        List<Expression> params = new ArrayList<>();
        params.add(new IntegerLiteralExpr(Integer.toString(getTranslationVisitor().getFileId())));
        final int line = range.begin.line;
        params.add(makeIntegerLiteralExpr(line));
        params.add(makeIntegerLiteralExpr(range.begin.column));
        params.add(makeIntegerLiteralExpr(range.end.line));
        params.add(makeIntegerLiteralExpr(range.end.column));
        params.add(new BooleanLiteralExpr(line != getTranslationVisitor().getLineNumber()));
        getTranslationVisitor().setLineNumber(line);
        return params;
    }

    private static Expression makeIntegerLiteralExpr(int i) {
        Expression expression = new IntegerLiteralExpr(String.valueOf(Math.abs(i)));
        if (i < 0) expression = new UnaryExpr(expression, Operator.MINUS);
        return expression;
    }

    default void copyCommentsAndData(Node source, Node destination) {
        destination.setComment(getTranslationVisitor().translateNode(source.getComment(), null));
        source.getOrphanComments().stream().map(Comment::clone).forEach(destination::addOrphanComment);
        source.getDataKeys().forEach(k -> setData(source, destination, k));
    }

    private static <M> void setData(Node src, Node dest, DataKey<M> dataKey) {
        if (src.containsData(dataKey)) dest.setData(dataKey, src.getData(dataKey));
    }

    default String newVarName() {return getTranslationVisitor().newVarName();}

    default String storeResult(BlockStmt blockStmt, Expression expr) {
        Type type;
        if (expr.isNullLiteralExpr()) type = new ClassOrInterfaceType(null, "Object");
        else type = new VarType();
        return storeResult(blockStmt, expr, type);
    }

    default String storeResult(BlockStmt blockStmt, Expression expr, Type type) {
        final String variableName = newVarName();
        final var declarator = new VariableDeclarator(type, variableName, expr);
        final var declExpr = new VariableDeclarationExpr(declarator, new Modifier(Keyword.FINAL));
        blockStmt.addStatement(declExpr);
        return variableName;
    }

    /**
     * Method for all {@link com.github.javaparser.ast.stmt.BlockStmt}s or code blocks.
     * Translates {@link com.github.javaparser.ast.stmt.Statement}s of the source code block and
     * adds them to the target code block.
     * <p>
     * Used in {@link com.github.javaparser.ast.body.MethodDeclaration},
     * {@link com.github.javaparser.ast.stmt.BlockStmt},
     * </p>
     * <p>
     * Will be used in {@link com.github.javaparser.ast.stmt.TryStmt},
     * {@link com.github.javaparser.ast.stmt.CatchClause},
     * {@link com.github.javaparser.ast.stmt.ForStmt},
     * {@link com.github.javaparser.ast.stmt.WhileStmt},
     * {@link com.github.javaparser.ast.stmt.DoStmt},
     * {@link com.github.javaparser.ast.stmt.IfStmt},
     * ...
     * </p>
     *
     * @param source the source code block.
     * @param target the target code block.
     */
    default void translateBlockStmt(NodeWithStatements<?> source, BlockStmt target) {
        translateBlockStmt(source, target, false, null);
    }

    default void translateBlockStmt(NodeWithStatements<?> source, BlockStmt target, Object arg) {
        translateBlockStmt(source, target, false, arg);
    }

    default void translateBlockStmt(NodeWithStatements<?> source, BlockStmt target, boolean skipFirst) {
        translateBlockStmt(source, target, skipFirst, null);
    }

    default void translateBlockStmt(NodeWithStatements<?> source, BlockStmt target, boolean skipFirst, Object arg) {
        getTranslationVisitor().getBlockStack().push(target);
        for (Statement stmt : source.getStatements()) {
            if (skipFirst) skipFirst = false;
            else {
                Statement newStmt = getTranslationVisitor().translateNode(stmt, arg);
                if (newStmt != null) target.addStatement(newStmt);
            }
        }
        getTranslationVisitor().getBlockStack().pop();
    }

    default Optional<BlockStmt> getCurrentBlock() {
        BlockStmt blockStmt = getTranslationVisitor().getBlockStack().peek();
        if (blockStmt == null) return Optional.empty();
        return Optional.of(blockStmt);
    }

    default TypeDeclaration<?> getCurrentType() {
        TypeDeclaration<?> containingType = getTranslationVisitor().getTypeStack().peek();
        if (containingType == null) throw new IllegalStateException("containingType == null");
        return containingType;
    }

    /**
     * Method for all {@link com.github.javaparser.ast.body.TypeDeclaration}s.
     * Translates {@link com.github.javaparser.ast.body.BodyDeclaration}s of the source type and
     * adds them to the target type.
     * <p>
     * Used in ClassOrInterfaceDeclaration,
     * </p>
     * <p>
     * Will be used in {@link com.github.javaparser.ast.body.EnumDeclaration},
     * {@link com.github.javaparser.ast.body.RecordDeclaration} and
     * {@link com.github.javaparser.ast.body.AnnotationDeclaration}
     * </p>
     *
     * @param source the source type.
     * @param target the target type.
     */
    default void translateMembers(TypeDeclaration<?> source, TypeDeclaration<?> target) {
        getTranslationVisitor().getTypeStack().push(target);
        for (BodyDeclaration<?> bd : source.getMembers()) {
            BodyDeclaration<?> newBodyDeclaration = getTranslationVisitor().translateNode(bd);
            if (newBodyDeclaration != null) target.addMember(newBodyDeclaration);
        }
        getTranslationVisitor().getTypeStack().pop();
    }

    default ClassInfo getClassInfo(Node node) {
        String fullyQualifiedClassName = "";
        Optional<Node> parentNodeOptional = node.getParentNode();
        if (parentNodeOptional.isEmpty())
            throw new IllegalStateException("'" + node + "' has no parent node.");
        Node parentNode = parentNodeOptional.get();

        boolean anon = false;
        List<Integer> anonClassIds = List.of();
        if (parentNode instanceof TypeDeclaration<?> typeDeclaration) {
            // TODO: getFullyQualifiedName is empty if the type is local, see method description
            Optional<String> typeDeclarationOptional = typeDeclaration.getFullyQualifiedName();
            if (typeDeclarationOptional.isPresent()) fullyQualifiedClassName = typeDeclarationOptional.get();
            else if (typeDeclaration.isClassOrInterfaceDeclaration() && typeDeclaration.asClassOrInterfaceDeclaration().isLocalClassDeclaration()) {
                fullyQualifiedClassName = typeDeclaration.getNameAsString();
            }
            else throw new IllegalStateException(String.format("typeDeclaration '%s' without fully qualified name!",
                                                               typeDeclaration));
        }
        else if (parentNode instanceof ObjectCreationExpr) {
            anon = true;
            if (getTranslationVisitor().getAnonymousClassStack().isEmpty())
                throw new IllegalStateException("anonymousClassStack is empty");
            AnonymousClassInfo anonymousClassInfo = getTranslationVisitor().getAnonymousClassStack().peek();
            if (anonymousClassInfo == null) throw new IllegalStateException("anonymousClassInfo is null");
            fullyQualifiedClassName = anonymousClassInfo.getParentClassName();
            anonClassIds = anonymousClassInfo.getIds();
        }
        else
            throw new IllegalStateException(String.format("The type (%s) of the parent node of '%s' is not supported.",
                                                          parentNode.getClass(), node));
        return new ClassInfo(fullyQualifiedClassName, anon, anonClassIds);
    }

    default String replaceQuotationMarks(Expression expression) {return replaceQuotationMarks(expression.toString());}

    default String replaceQuotationMarks(String string) {
        return string.replace("\\", "\\\\")
                     .replace("\"", "\\\"");
    }

    default MethodCallExpr announcementParams(List<String> argNames) {
        final List<Expression> list = argNames.stream()
                                              .map(a -> a == null ? value(new NullLiteralExpr()) : value(new NameExpr(a)))
                                              .map(a -> (Expression) a)
                                              .toList();
        return makeMethodCallWithoutInitParams(FQCN_LIST, METHOD_OF, list);
    }

    // Ranges //////////////////////////////////////////////////////////////////////////////////////////////////////////

    default Position left(Position position, int characters) {return position.withColumn(position.column - characters);}

    default Range blockEndRange(Node n) {
        return n.getRange().map(r -> r.withBegin(r.end))
                .orElse(UNDEFINED_RANGE);
    }

    default Range getRangeBetween(Node leftNode, Node rightNode) {
        final Optional<Range> leftRange = leftNode.getRange();
        final Optional<Range> rightRange = rightNode.getRange();
        if (leftRange.isPresent() && rightRange.isPresent()) {
            Position start = leftRange.get().end.right(1);
            Position end = left(rightRange.get().begin, 1);
            return Range.range(start, end);
        }
        return UNDEFINED_RANGE;
    }

    default Range getNameRange(VariableDeclarator vd) {
        return vd.getName().getRange().orElse(UNDEFINED_RANGE);
    }

    default Range getAssignmentRange(VariableDeclarator vd) {
        final Optional<Expression> optionalInitializer = vd.getInitializer();
        if (optionalInitializer.isEmpty())
            return getNameRange(vd);
        return getRangeBetween(vd.getName(), optionalInitializer.get());
    }

    // Type parsing ////////////////////////////////////////////////////////////////////////////////////////////////////

    default Type parseType(String type) {
        final String noPrimitiveTypeInGenerics = overridePrimitiveClassTypes(type);
        final String noBoundsType = removeTypeBounds(noPrimitiveTypeInGenerics);
        final String noWildcardType = replaceWildcardWithObject(noBoundsType);
        final String noDotsType = replaceDots(noWildcardType);
        return StaticJavaParser.parseType(noDotsType);
    }

    private String replaceDots(String noWildcardType) {return noWildcardType.replace("...", "[]");}

    private String replaceWildcardWithObject(String type) {return type.equals("?") ? "Object" : type;}

    private String removeTypeBounds(String type) {return type.replaceAll("\\? super|\\? extends", "");}

    private String overridePrimitiveClassTypes(String type) {
        if (type.startsWith("java.lang.Class<")) {
            type = type.replace("boolean", "Boolean")
                       .replace("char", "Character")
                       .replace("byte", "Byte")
                       .replace("short", "Short")
                       .replace("int", "Integer")
                       .replace("long", "Long")
                       .replace("float", "Float")
                       .replace("double", "Double")
                       .replace("void", "Void");
        }
        return type;
    }

    default Type applyFacades(Type type) {
        if (type.isClassOrInterfaceType()) {
            final String oldCoit = type.asClassOrInterfaceType().getNameAsString();
            if (FACADE_MAP.containsKey(oldCoit)) {
                final ClassOrInterfaceType newCoit = StaticJavaParser.parseClassOrInterfaceType(FACADE_MAP.get(oldCoit));
                type.asClassOrInterfaceType().getTypeArguments().ifPresent(newCoit::setTypeArguments);
                type = newCoit;
            }
        }
        return type;
    }

    default boolean containsTypeVariablesOrWildcards(ResolvedType type) {
        if (type.isTypeVariable() || type.isWildcard())
            return true;
        if (type.isReferenceType())
            for (ResolvedType t : type.asReferenceType().typeParametersMap().getTypes())
                if (containsTypeVariablesOrWildcards(t))
                    return true;
        if (type.isArray())
            return containsTypeVariablesOrWildcards(type.asArrayType().getComponentType());
        return false;
    }
}
