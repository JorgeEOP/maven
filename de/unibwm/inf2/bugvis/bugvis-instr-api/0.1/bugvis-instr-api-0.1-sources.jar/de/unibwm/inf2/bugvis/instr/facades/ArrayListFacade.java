package de.unibwm.inf2.bugvis.instr.facades;

import java.util.ArrayList;
import java.util.Spliterator;

public class ArrayListFacade<E> extends ListFacade<E, ArrayList<E>> implements ArrayListInterface<E>, Cloneable {

    public ArrayListFacade(ArrayList<E> wrapped, HistoryListener historyListener) {
        super(wrapped, historyListener);
    }

    public void trimToSize() {
        wrapped.trimToSize();
    } // Würde nicht getestet

    public void ensureCapacity(int minCapacity) {
        wrapped.ensureCapacity(minCapacity);
    } //Würde nicht getestet

    @Override
    public Object clone() {
        return new ArrayListFacade<E>((ArrayList<E>) wrapped.clone(), history);
    }

    @Override
    public Spliterator<E> spliterator() {
        throw new UnsupportedOperationException();
    }
}
