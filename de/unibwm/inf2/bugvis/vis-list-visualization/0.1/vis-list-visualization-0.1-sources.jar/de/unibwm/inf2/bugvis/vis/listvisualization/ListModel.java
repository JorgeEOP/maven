package de.unibwm.inf2.bugvis.vis.listvisualization;

import de.unibwm.inf2.bugvis.model.VisualizationObject;

import java.util.List;

public class ListModel implements VisualizationObject {
    private final int hashCode;
    private final int size;
    private final List<Object> items;

    public ListModel(int origin, int size, List<Object> items) {
        this.hashCode = origin;
        this.size = size;
        this.items = items;
    }

    @Override
    public int getHashCode() {
        return hashCode;
    }

    public Object getIndex(int index) {
        return items.get(index);
    }

    public int getSize() {
        return size;
    }

    public List<Object> getItems() {
        return items;
    }
}
