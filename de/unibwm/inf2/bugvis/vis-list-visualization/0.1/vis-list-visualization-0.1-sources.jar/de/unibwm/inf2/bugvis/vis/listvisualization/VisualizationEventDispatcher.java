package de.unibwm.inf2.bugvis.vis.listvisualization;

import de.unibwm.inf2.bugvis.model.VisualizationObject;
import de.unibwm.inf2.bugvis.model.notification.visualize.StartVisualizationEvent;
import de.unibwm.inf2.bugvis.model.notification.visualize.StopVisualizationEvent;
import de.unibwm.inf2.bugvis.model.notification.visualize.UpdateVisualizationEvent;
import de.unibwm.inf2.bugvis.model.notification.visualize.VisualizeEventListener;

import java.util.concurrent.CountDownLatch;

public interface VisualizationEventDispatcher extends VisualizeEventListener {
    @Override
    default void receivedEvent(StartVisualizationEvent ev, CountDownLatch count) {
        final VisualizationObject vo = ev.getVisualizationObject();
        if (vo instanceof ListModel)
            startVisualization(ev.getVisualizationObject().getHashCode(), count);
        else
            throw new UnsupportedOperationException("Unsupported event type: " + vo);
    }

    @Override
    default void receivedEvent(StopVisualizationEvent ev, CountDownLatch count) {
        final VisualizationObject vo = ev.getVisualizationObject();
        if (vo instanceof ListModel)
            stopVisualization(ev.getVisualizationObject().getHashCode(), count);
        else
            throw new UnsupportedOperationException("Unsupported event type: " + vo);
    }

    @Override
    default void receivedEvent(UpdateVisualizationEvent ev, CountDownLatch count) {
        final VisualizationObject oldVO = ev.getOldVisualizationObject();
        final VisualizationObject newVO = ev.getNewVisualizationObject();
        if (oldVO instanceof ListModel olm && newVO instanceof ListModel nlm)
            updateVisualization(olm, nlm, count);
        else
            throw new UnsupportedOperationException("Unsupported event types: " + newVO);
    }

    void startVisualization(int hashCode, CountDownLatch count);

    void updateVisualization(ListModel oldListModel, ListModel newListModel, CountDownLatch count);

    void stopVisualization(int hashCode, CountDownLatch count);
}
