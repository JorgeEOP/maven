package de.unibwm.inf2.bugvis.vis.listvisualization;

import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.control.events.SelectEvent;
import de.unibwm.inf2.bugvis.gui.visulization.AbstractVisualizationPane;
import de.unibwm.inf2.bugvis.model.notification.visualize.VisualizationBigStepEvent;
import de.unibwm.inf2.bugvis.model.value.Value;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.CountDownLatch;

import static java.awt.Color.WHITE;
import static java.lang.System.Logger.Level.INFO;
import static java.lang.System.identityHashCode;

public class ListVisualizationPane extends AbstractVisualizationPane implements VisualizationEventDispatcher {

    public static final Color BLUE = new Color(204, 229, 255);
    private static final Logger LOGGER = System.getLogger(ListVisualizationPane.class.getName());
    private static final int PANE_WIDTH = 100;
    private static final int PANE_HEIGHT = 100;
    // event management
    private final Deque<Runnable> smallStepQueue = new ArrayDeque<>();
    private final Map<Integer, JTable> lists = new HashMap<>();
    private final Map<JTable, JScrollPane> scrollPanes = new HashMap<>();
    private final DebugControl control;

    public ListVisualizationPane(DebugControl control) {
        LOGGER.log(INFO, "Creating ListVisualizationPane");
        this.control = control;
        this.control.addSelectListener(this);
        setLayout(new GridLayout());
        setPreferredSize(new Dimension(PANE_WIDTH, PANE_HEIGHT));
    }

    @Override
    public void startVisualization(int hashCode, CountDownLatch count) {
        processSmallStep(() -> invoke(() -> createTable(hashCode)), count);
    }

    @Override
    public void stopVisualization(int hashCode, CountDownLatch count) {
        processSmallStep(() -> invoke(() -> stopTableVisualization(hashCode)), count);
    }

    @Override
    public void updateVisualization(ListModel oldListModel, ListModel newListModel, CountDownLatch count) {
        processSmallStep(() -> invoke(() -> updateList(oldListModel, newListModel)), count);
    }

    /**
     * Creates a new Table and wraps it in a {@code JScrollPane}. It adds the Pane to the layout and
     * caches the list and pane.
     *
     * @param listHashCode
     */
    private void createTable(int listHashCode) {
        LOGGER.log(INFO, "Creating table with id: ({0})", listHashCode);
        final JTable table = new JTable(new Vector<>(), new Vector<>()); // Um das DefaultTableModel als Model zu nutzen.
        final JScrollPane scrollPane = new JScrollPane(table);

        add(scrollPane, BorderLayout.CENTER);
        revalidate();

        lists.put(listHashCode, table);
        scrollPanes.put(table, scrollPane);
    }

    /**
     * Updates a cached table (or more precisely, its model) with the elements of the {@code newModel}.
     *
     * @param currentModel
     * @param newModel
     */
    private void updateList(ListModel currentModel, ListModel newModel) {
        LOGGER.log(INFO, "CurrentModel size: {0} ; NewModel Size: {1}", currentModel.getSize(), newModel.getSize());
        final List<Object> items = newModel.getItems();
        if (items == null) return;

        final JTable table = lists.get(newModel.getHashCode());
        final DefaultTableModel tableModel = (DefaultTableModel) table.getModel();

        final Object[] asArray = items.toArray();
        final Object[][] newRows = new Object[asArray.length][1];

        for (int i = 0; i < asArray.length; i++) {
            newRows[i][0] = asArray[i];
        }
        // Column name: IdentityHashCode
        final Value mirrorObject = control.getState().getMirrorObject(newModel.getHashCode());
        final String[] title = {String.valueOf(Integer.toHexString(System.identityHashCode(mirrorObject)))};

        tableModel.setDataVector(newRows, title);
        lists.put(newModel.getHashCode(), table);
    }

    /**
     * Removes the {@code listObject} from the cached lists.
     * Removes the pane containing the {@code listObject}.
     * Repaints and revalidates the panel to clean and recalculate the objects in the layout.
     *
     * @param hashCode
     */
    private void stopTableVisualization(int hashCode) {
        LOGGER.log(INFO, "Remove List for {0}", hashCode);
        final JTable table = lists.get(hashCode);
        final JScrollPane pane = scrollPanes.get(table);

        if (pane != null && table != null) {
            LOGGER.log(INFO, "Stop Table Visualization for object: ( {0} )", identityHashCode(table));
            lists.remove(hashCode);
            scrollPanes.remove(table);
            remove(pane);
            repaint();
            revalidate();
        }
        else
            LOGGER.log(Level.INFO, "Table for given List not found!");
    }

    @Override
    public void receivedEvent(VisualizationBigStepEvent event, CountDownLatch count) {
        if (smallStepQueue.isEmpty()) {
            count.countDown();
        }
        else {
            LOGGER.log(INFO, "visualizationBigStepEvent received, start smallStepQueue ...");
            while (!smallStepQueue.isEmpty())
                smallStepQueue.poll().run();
            LOGGER.log(INFO, "... start smallStepQueue finished");
            count.countDown();
        }
    }

    private void processSmallStep(Runnable smallStep, CountDownLatch count) {
        if (getBigStepVisualizations()) {
            smallStepQueue.addLast(smallStep);
            count.countDown();
        }
        else {
            while (!smallStepQueue.isEmpty())
                smallStepQueue.poll().run();
            smallStep.run();
            count.countDown();
        }
    }

    private void invoke(Runnable runnable) {SwingUtilities.invokeLater(runnable);}

    @Override
    public void receivedEvent(SelectEvent event) {
        invoke(() -> {
            LOGGER.log(INFO, "Selecting node with id: {0}", identityHashCode(event.getHashCode()));
            JTable table = lists.get(event.getHashCode());
            lists.values().forEach(t -> t.setBackground(WHITE));
            if (table != null)
                table.setBackground(BLUE);
        });
    }
}