package de.unibwm.inf2.bugvis.vis.listvisualization;

import de.unibwm.inf2.bugvis.control.DebugControl;
import de.unibwm.inf2.bugvis.gui.BugVisFrame;
import de.unibwm.inf2.bugvis.gui.options.Options;
import de.unibwm.inf2.bugvis.gui.visulization.VisualizationFrame;

import javax.swing.SwingUtilities;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.System.Logger;
import java.util.logging.LogManager;

import static java.lang.System.Logger.Level.DEBUG;
import static java.lang.System.Logger.Level.ERROR;

public class ListDebugger {
    public static final String TITLE = "BugVis (List)";
    private static final String LOGGING_PROPERTIES = "logging.properties";

    static {
        Logger logger;
        try {
            LogManager.getLogManager().readConfiguration(new FileInputStream(LOGGING_PROPERTIES));
            logger = System.getLogger(ListDebugger.class.getName());
            logger.log(DEBUG, "Successfully read logging properties"); //NON-NLS
        }
        catch (IOException e) {
            logger = System.getLogger(ListDebugger.class.getName());
            logger.log(ERROR, e::getMessage);
        }
    }

    public static void main(String[] args) {
        System.out.println("Starting ListDebugger");
        final Options options = new Options(args);
        final DebugControl control = new DebugControl(options);
        control.getPluginControl().addPlugin(new ListPlugin());
        BugVisFrame.initUI();
        SwingUtilities.invokeLater(() -> {
            control.useDefaultInstrumentationRuntime();
            final BugVisFrame frame = new BugVisFrame(control);
            frame.setTitle(TITLE);
            frame.pack();
            frame.setVisible(true);
            final VisualizationFrame visFrame = new VisualizationFrame(frame);
            visFrame.setTitle(TITLE + " Visualization");
            visFrame.setVisualizationPane(new ListVisualizationPane(control));
            visFrame.pack();
            visFrame.setVisible(true);
            control.runDebugee();
        });
    }
}