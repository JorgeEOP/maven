package de.unibwm.inf2.bugvis.vis.listvisualization;

import de.unibwm.inf2.bugvis.control.Plugin;
import listvisualization.ListInterface;

import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.List;

import static java.lang.System.Logger.Level.ERROR;
import static java.lang.System.Logger.Level.INFO;

public class ListPlugin implements Plugin<ListInterface<?>, ListModel> {
    public static final String EXCEPTION_OCCURRED = "Unexpected exception occurred";
    private static final Logger LOGGER = System.getLogger(ListPlugin.class.getName());

    @Override
    public boolean isApplicable(Object object) {
        LOGGER.log(INFO, "IS APPLICABLE!" +  object.getClass());
        return object instanceof ListInterface<?>;}



    @Override
    public ListModel createModel(ListInterface<?> list) {
        class Extractor extends AbstractExtractor<ListModel> {
            int size;
            final List<Object> items = new ArrayList<>();

            public ListModel create() {
                LOGGER.log(INFO, "CREATE A TABLE!");
                extract(() -> size = list.size());

                extract(() -> {
                    for (int i = 0; i <= list.size(); i++)
                        if (list.size() != 0)
                            items.add(list.get(i));
                });

                if (getError())
                    LOGGER.log(ERROR, "AN ERROR OCCURED " + getError());
                return new ListModel(System.identityHashCode(list), size, items);
            }
        }

        return new Extractor().create();
    }

    @Override
    public boolean hasToBeDeleted(Object object, String signature) {return false;}
}
