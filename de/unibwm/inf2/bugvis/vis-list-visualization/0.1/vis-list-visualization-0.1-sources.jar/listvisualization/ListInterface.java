package listvisualization;

public interface ListInterface<E> {
    int size();

    E get(int index);
}
